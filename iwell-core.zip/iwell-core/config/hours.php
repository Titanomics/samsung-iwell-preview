<?php
/**
 * 진료시간 기본값. Iwell\Core\Hours\Store::config()가 관리자 옵션 iwell_hours 를 이 위에 깊은 병합한다
 * (공휴일 목록은 config/holidays.php → 설정 키 `holidays`). 화면·구조화 데이터·llms.txt 는 이 파일을 직접 읽지 않고 Store::config()만 쓴다.
 *
 * 근거: 병원 공지 #37(2026-01-19부터) — 병원 확인 전 잠정값(계획서 Global Constraints, 설계서 §12-4).
 *   화~금 09:00~18:00(점심 13:00~14:00) / 토·일·공휴일 09:00~13:00(점심 없이) / 휴진 매주 월요일·매월 마지막주 일요일.
 *   월요일이 공휴일이면 휴진(mondayHolidayPolicy — 'closed' | 'open'(공휴일 시간으로 진료)).
 *
 * 키(시간은 Asia/Seoul, 'H:i'):
 *   weekly              ISO 요일(1=월 … 7=일) → list<{from, to}>. 빈 목록 = 그 요일 휴진.
 *   holidayHours        공휴일 진료 세션(요일 시간 대신).
 *   closedWeekdays      정기 휴진 요일(ISO 번호 목록).
 *   closeLastSunday     매월 마지막 일요일 휴진.
 *   mondayHolidayPolicy 휴진 요일인 월요일이 공휴일일 때: 'closed' 또는 'open'.
 *   exceptions          'Y-m-d' → list<{from, to}>(그날만 이 시간) 또는 {closed: true, reason: string}(그날 휴진). 모든 규칙보다 우선.
 *   doctorsByDate       'Y-m-d' → 담당 의사 표시 문자열.
 */

defined( 'ABSPATH' ) || exit;

return array(
	'weekly'              => array(
		1 => array(), // 월: 정기 휴진. 공지에 월요일 진료시간이 없어 비워 둔다 — 열려면 closedWeekdays 에서 1을 빼고 여기에 세션을 넣는다.
		2 => array( array( 'from' => '09:00', 'to' => '13:00' ), array( 'from' => '14:00', 'to' => '18:00' ) ),
		3 => array( array( 'from' => '09:00', 'to' => '13:00' ), array( 'from' => '14:00', 'to' => '18:00' ) ),
		4 => array( array( 'from' => '09:00', 'to' => '13:00' ), array( 'from' => '14:00', 'to' => '18:00' ) ),
		5 => array( array( 'from' => '09:00', 'to' => '13:00' ), array( 'from' => '14:00', 'to' => '18:00' ) ),
		6 => array( array( 'from' => '09:00', 'to' => '13:00' ) ),
		7 => array( array( 'from' => '09:00', 'to' => '13:00' ) ),
	),
	'holidayHours'        => array( array( 'from' => '09:00', 'to' => '13:00' ) ),
	'closedWeekdays'      => array( 1 ),
	'closeLastSunday'     => true,
	'mondayHolidayPolicy' => 'closed',
	'exceptions'          => array(),
	'doctorsByDate'       => array(),
);
