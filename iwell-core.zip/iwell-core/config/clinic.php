<?php
/**
 * 병원 기본 정보 — 병원 확인 전 잠정값(계획서 Global Constraints, analysis/iwell/content/content-inventory.md §1).
 * 이 파일 한 곳에서만 정한다. 화면(Task 7 머리·바닥글)·구조화 데이터(Task 6 MedicalClinic)·llms.txt(Task 9)는
 * 이 파일을 직접 읽지 않고 Iwell\Core\Schema\Graph::clinicInfo()로만 읽는다(주소 한 줄 addressText 도 거기서 만든다).
 *
 * 키:
 *   name              상호.
 *   address           region(시·도) · locality(시·군·구) · street(나머지: 읍·면·동, 도로명, 건물) · country(ISO 3166-1).
 *                     화면용 한 줄 = region + ' ' + locality + ' ' + street.
 *   telephone · fax   화면 표기 그대로(구조화 데이터도 같은 값 — 화면과 다르게 쓰지 않는다).
 *   medicalSpecialty  schema.org MedicalSpecialty 값(소아청소년과 = Pediatric).
 *   representative · businessNumber · email  바닥글 사업자 정보(화면 전용, Task 7).
 *   youtube           병원 유튜브 채널 주소(화면 PC 우측 퀵바 전용, 2026-11-23).
 */

defined( 'ABSPATH' ) || exit;

return array(
	'name'             => '삼성아이웰소아청소년과',
	'address'          => array(
		'region'   => '경기도',
		'locality' => '용인시 처인구',
		'street'   => '포곡읍 포곡로 113, 2층(우상빌딩)',
		'country'  => 'KR',
	),
	'telephone'        => '031-322-7799',
	'fax'              => '031-322-7798',
	'medicalSpecialty' => 'Pediatric',
	// 바닥글 사업자 정보(Task 7) — 현 사이트 바닥글 원문(병원 자료 docx "대표자 : 고시환 | 사업자등록번호 : 667-91-02129 | … | E-mail : gfph@naver.com").
	// 구조화 데이터에는 쓰지 않는다(화면 바닥글 전용).
	'representative'   => '고시환',
	'businessNumber'   => '667-91-02129',
	'email'            => 'gfph@naver.com',
	// 원장 칼럼 작성자(Task 8) — 칼럼 = 네이버 블로그 gfph 원문(원장 본인 글, 설계서 §6-9). 화면 '작성자 {columnAuthor} {columnAuthorTitle}'(병원 자료
	// "고시환 대표원장", docx L199) · 구조화 데이터 칼럼 author = 같은 이름의 게시된 의료진 페이지(iwell_physician.name)가 있으면 그 Physician @id, 없으면
	// Person{name, jobTitle}. (평면 키 — 이 파일을 '키' => '값' 으로 읽는 시험이 있어 'name' 같은 키를 중첩해 겹치지 않게.)
	'columnAuthor'      => '고시환',
	'columnAuthorTitle' => '대표원장',
	// 유튜브 채널(대표 지시 2026-11-23 — 고시환 대표원장 채널 「아이 성장 감별사, 닥터 고시환」, 공유 추적 인자 si 뺌).
	// 화면 PC 우측 퀵바 바로가기 전용(테마 quickBar, 새 창). 구조화 데이터에는 쓰지 않는다. 빈 값이면 단추 없음.
	'youtube'           => 'https://www.youtube.com/channel/UC6auCu-6FXG7D-ePFRdua1A',
);
