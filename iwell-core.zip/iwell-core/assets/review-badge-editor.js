/**
 * 블록 iwell/review-badge 편집기용 최소 등록(Task 8 — 코디네이터 결정 2026-11-15). 서버 렌더 블록(PageMeta::registerBlock)인데 편집기 쪽 등록이 없어
 * 블록 편집기가 "지원하지 않는 블록"(core/missing)으로 보였다 → 직원이 지우려 하지 않게 설명 자리표시만 그린다.
 * 서버 쪽(공개 화면 렌더·원장 검토 지문 허용 목록·기록)은 그대로 — 저장 형식도 그대로(save = null, 동적 블록 주석만 저장).
 * 빌드 없이 워드프레스 전역(wp.*)만 쓴다. 고정 페이지 블록 편집기에서만 실린다(src/EditorPanel.php).
 */
( function ( wp ) {
	if ( ! wp || ! wp.blocks || ! wp.element || wp.blocks.getBlockType( 'iwell/review-badge' ) ) {
		return;
	}
	var el = wp.element.createElement;
	var useBlockProps = wp.blockEditor && wp.blockEditor.useBlockProps;
	wp.blocks.registerBlockType( 'iwell/review-badge', {
		apiVersion: 3,
		title: '의학적 검토 배지',
		description: '의학적 검토자·기준일(페이지 속성에서 자동 — 원장이 승인·게시하면 기록).',
		category: 'text',
		icon: 'yes-alt',
		supports: { html: false },
		edit: function () {
			var props = useBlockProps ? useBlockProps( { className: 'iwell-review-badge-placeholder' } ) : { className: 'iwell-review-badge-placeholder' };
			return el( 'p', props, '원장 검토 표시(자동) — 원장이 승인·게시하면 "의학적 검토: 이름 · 기준일"이 이 자리에 나옵니다.' );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
