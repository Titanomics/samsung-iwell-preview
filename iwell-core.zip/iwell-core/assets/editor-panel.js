/**
 * 편집기 사이드 패널 "의학 정보"(iwell-core Task 6) — 고정 페이지 블록 편집기에서만 실린다(src/EditorPanel.php).
 * 빌드 없이 워드프레스 전역(wp.*)만 쓴다.
 *
 * - 기준일·출처: 편집기 메타(iwell_data_asof·iwell_sources)로 저장 → 게시된 페이지는 수정안에 들어가고 원장 승인 때 반영.
 * - 검토자·검토일: 읽기 전용 글자(REST 필드 iwell_review). 원장이 승인·게시하면 서버가 기록한다.
 * - 저장 요청 정리: 검토자·검토일, Rank Math 제목·설명의 옛 사본을 페이지 저장 요청에서 뺀다(src/EditorPanel.php 머리말).
 */
( function ( wp ) {
	if ( ! wp || ! wp.plugins || ! wp.element || ! wp.data || ! wp.components ) {
		return;
	}
	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;
	var TextControl = wp.components.TextControl;
	var Button = wp.components.Button;
	var PluginDocumentSettingPanel = ( wp.editor && wp.editor.PluginDocumentSettingPanel ) || ( wp.editPost && wp.editPost.PluginDocumentSettingPanel );

	// ── 저장 요청 정리 ───────────────────────────────────────────────
	var STRIP = [ 'iwell_reviewed_by', 'iwell_reviewed_at', 'rank_math_title', 'rank_math_description' ];
	var SAVE_PATH = /\/wp\/v2\/pages\/\d+(?:\/autosaves)?\/?(?:[?&]|$)/;

	if ( wp.apiFetch && wp.apiFetch.use ) {
		wp.apiFetch.use( function ( options, next ) {
			var method = String( options.method || 'GET' ).toUpperCase();
			var target = String( options.path || options.url || '' );
			try {
				target = decodeURIComponent( target );
			} catch ( e ) {}
			var data = options.data;
			if ( 'GET' !== method && SAVE_PATH.test( target ) && data && data.meta && 'object' === typeof data.meta ) {
				var meta = {};
				Object.keys( data.meta ).forEach( function ( key ) {
					if ( STRIP.indexOf( key ) === -1 ) {
						meta[ key ] = data.meta[ key ];
					}
				} );
				options = Object.assign( {}, options, { data: Object.assign( {}, data, { meta: meta } ) } );
			}
			return next( options );
		} );
	}

	if ( ! PluginDocumentSettingPanel ) {
		return;
	}

	// ── 패널 ────────────────────────────────────────────────────────
	function MedicalInfoPanel() {
		var state = useSelect( function ( select ) {
			var editor = select( 'core/editor' );
			return {
				postType: editor.getCurrentPostType(),
				meta: editor.getEditedPostAttribute( 'meta' ) || {},
				review: editor.getCurrentPostAttribute( 'iwell_review' ) || null,
			};
		}, [] );
		var editPost = useDispatch( 'core/editor' ).editPost;

		if ( 'page' !== state.postType ) {
			return null;
		}

		var meta = state.meta;
		var sources = Array.isArray( meta.iwell_sources ) ? meta.iwell_sources : [];
		var review = state.review || {};

		function setMeta( patch ) {
			editPost( { meta: patch } );
		}
		function setSource( index, key, value ) {
			setMeta( {
				iwell_sources: sources.map( function ( s, i ) {
					if ( i !== index ) {
						return s;
					}
					var copy = Object.assign( { title: '', url: '', accessed: '' }, s );
					copy[ key ] = value;
					return copy;
				} ),
			} );
		}

		var rows = sources.map( function ( source, i ) {
			var n = i + 1;
			return el(
				'div',
				{ key: 'source-' + i, className: 'iwell-medical-info__source' },
				el( TextControl, {
					label: '출처 ' + n + ' 제목',
					value: source.title || '',
					onChange: function ( v ) {
						setSource( i, 'title', v );
					},
					__nextHasNoMarginBottom: true,
				} ),
				el( TextControl, {
					label: '출처 ' + n + ' 주소',
					type: 'url',
					value: source.url || '',
					onChange: function ( v ) {
						setSource( i, 'url', v );
					},
					__nextHasNoMarginBottom: true,
				} ),
				el( TextControl, {
					label: '출처 ' + n + ' 확인일',
					type: 'date',
					value: source.accessed || '',
					onChange: function ( v ) {
						setSource( i, 'accessed', v );
					},
					__nextHasNoMarginBottom: true,
				} ),
				el(
					Button,
					{
						variant: 'link',
						isDestructive: true,
						onClick: function () {
							setMeta( {
								iwell_sources: sources.filter( function ( s, j ) {
									return j !== i;
								} ),
							} );
						},
					},
					'출처 ' + n + ' 삭제'
				)
			);
		} );

		return el(
			PluginDocumentSettingPanel,
			{ name: 'iwell-medical-info', title: '의학 정보', className: 'iwell-medical-info' },
			el( 'p', { className: 'iwell-medical-info__review' }, '검토자: ' + ( review.name ? review.name : '원장 승인 전' ) ),
			el( 'p', { className: 'iwell-medical-info__review' }, '검토일: ' + ( review.at ? review.at : '—' ) ),
			el( 'p', { className: 'description' }, '검토자·검토일은 원장이 승인·게시할 때 자동으로 기록됩니다.' ),
			el( TextControl, {
				label: '기준일',
				type: 'date',
				value: meta.iwell_data_asof || '',
				onChange: function ( v ) {
					setMeta( { iwell_data_asof: v } );
				},
				__nextHasNoMarginBottom: true,
			} ),
			el( Fragment, null, rows ),
			el(
				Button,
				{
					variant: 'secondary',
					onClick: function () {
						setMeta( { iwell_sources: sources.concat( [ { title: '', url: '', accessed: '' } ] ) } );
					},
				},
				'출처 추가'
			)
		);
	}

	wp.plugins.registerPlugin( 'iwell-medical-info', { render: MedicalInfoPanel } );
} )( window.wp );
