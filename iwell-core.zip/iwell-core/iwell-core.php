<?php
/**
 * Plugin Name: iwell-core
 * Description: 삼성아이웰소아청소년과 자체 기능(진료시간·구조화 데이터·페이지 메타·권한·주소·상담 보호·칼럼 수신).
 * Version: 0.1.0
 * Requires at least: 6.7
 * Requires PHP: 8.2
 * License: GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;

// src/ 아래 클래스: Iwell\Core\Foo\Bar → src/Foo/Bar.php
spl_autoload_register(
	static function ( string $class ): void {
		$prefix = 'Iwell\\Core\\';
		if ( 0 !== strncmp( $class, $prefix, strlen( $prefix ) ) ) {
			return;
		}
		$file = __DIR__ . '/src/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_file( $file ) ) {
			require $file;
		}
	}
);

// 활성화 시: 역할·카테고리(Task 3) → 고유주소·재작성 규칙·허브 상태(Task 9 — 카테고리가 먼저 있어야 한다).
register_activation_hook( __FILE__, array( Iwell\Core\Roles::class, 'install' ) );
register_activation_hook( __FILE__, array( Iwell\Core\Routes::class, 'install' ) );

Iwell\Core\Roles::register();
Iwell\Core\ApprovalGuard::register();
Iwell\Core\Hours\Render::register(); // 블록 iwell/today-bar·iwell/hours-table(Task 5)
Iwell\Core\Hours\Admin::register();  // 관리자 메뉴 `진료시간`(Task 5)
Iwell\Core\Sources::register();      // 고정 페이지 공개 원천 의존성 해석기(Task 6 수정 7 결정 2) — PageMeta 보다 먼저(같은 훅에서 기억을 먼저 비운다)
Iwell\Core\Fingerprint::register();  // 출력 지문 — 공개 화면 결과·관찰한 의존성·세대 캐시(Task 6 수정 10)
Iwell\Core\Seal::register();         // 원장 승인 지문(Task 6 수정 7 결정 1, 수정 10 지문 형식 2)
Iwell\Core\PageMeta::register();     // 페이지 메타·검토 자동 기록·블록 iwell/review-badge·REST iwell/v1/pages/by-path(Task 6)
Iwell\Core\LiveSeal::register();     // 공개 판정 = 실제로 보낸 화면 — 출력 버퍼·영역 표식·승인 지문 비교·검토 표시 넣기/지우기(Task 6 수정 12)
Iwell\Core\ReviewAudit::register();  // 재승인 필요 페이지 목록 — 도구 → 원장 검토 점검·wp iwell review-check(Task 6 수정 10 결정 5)
Iwell\Core\EditorPanel::register();  // 편집기 패널 "의학 정보"(Task 6)
Iwell\Core\Schema\Graph::register(); // Rank Math JSON-LD 한 @graph — MedicalClinic·Physician·MedicalWebPage·DefinedTermSet(Task 6)
Iwell\Core\Nav::register();          // 게시된 페이지 계층 → 메뉴·브레드크럼·형제 이동, 공개 목적지 규칙(Task 7)
Iwell\Core\Columns\Meta::register(); // 칼럼 글 메타 계약 iwell_naver_log_no·iwell_imported_at(Task 8 — 값 쓰기는 Task 12)
Iwell\Core\Columns\Rest::register(); // 칼럼 수신 API iwell/v1/columns/state·attempt·import, media/import — 서버 잠금·중복 방지(Task 12)
Iwell\Core\Routes::register();       // 고유주소·/notices/·/columns/ 목록·옛 /category/ 301·빈 게시판 404·빈 허브 비공개(Task 9)
Iwell\Core\Crawl::register();        // robots.txt(봇 11개·Sitemap 2줄)·llms.txt(Task 9)
Iwell\Core\Redirects::register();    // 옛 주소 301 — config/redirects.csv(PC /sub/·모바일 /m/·공지 상세), 404 요청만·공개 목적지 규칙(Task 10)
Iwell\Core\Consult\Policy::register();     // 상담 KBoard: 비밀글 강제·비회원 비밀번호·필수/선택 동의·처리방침 없으면 닫힘·목록 제목 가림·읽기 권한(Task 11)
Iwell\Core\Consult\Lockout::register();    // 글당 비밀번호 5회 실패 → 15분 잠금·없는 글 = 틀린 비밀번호 응답(Task 11)
Iwell\Core\Consult\Rest::register();       // POST iwell/v1/consult/retention(X-Iwell-Cron) → 자동 삭제(Task 11)
Iwell\Core\Consult\CronSecret::register(); // 설정 > iwell-core 설정 > 크론 비밀값 새로 만들기(Task 11)
Iwell\Core\Comments::register();           // 워드프레스 기본 댓글·핑백 늘 닫힘(기존 글 포함, 설정 → 토론 기본값 closed) — 봇 댓글로 이름·이메일·IP 수집 막기(2026-11-25)
Iwell\Core\Emoji::register();              // 코어 이모지 스크립트·s.w.org 요청 끄기 — 처리방침 "외부 요청·쿠키 없음" 전제(2026-11-25)
