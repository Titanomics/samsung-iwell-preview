<?php
/**
 * 구조화 데이터(Task 6) — Rank Math 의 JSON-LD 한 덩어리(@graph)에 병원·의료진·의학 페이지·용어 사전을 얹는다(설계서 §8 GEO 레인).
 *
 * 데이터 원천(화면과 같은 값):
 *   - 병원 기본 정보: config/clinic.php 한 곳 → clinicInfo().
 *   - 진료시간: Store::config() + Rules 만(화면의 오늘 진료 바·진료시간 표와 같은 계산, 오늘 = Rules::today() — 필터 iwell_now).
 *   - 페이지: PageMeta::get()(정리된 메타). 검토자 이름 = PageMeta::reviewerName()(검토 배지와 같은 값).
 *
 * MedicalClinic(clinic()):
 *   - openingHoursSpecification: 정기 일정. 요일의 하루 일정(세션 목록)이 같은 요일끼리 묶고 세션마다 한 항목(화면 표의 묶음과 같다).
 *     정기 휴진 요일(closedWeekdays)·세션 없는 요일은 넣지 않는다(= 휴진).
 *   - specialOpeningHoursSpecification: 오늘부터 60일(오늘 ~ 오늘+59일). 그날의 Rules 결과가 정기 일정과 다르거나(마지막주 일요일 휴진·
 *     공휴일 시간·임시 휴진·임시 진료시간), 공휴일·날짜 예외가 있는 날. 휴진일은 Google 지침대로 opens = closes = '00:00'.
 *     description = Rules 의 사유(휴진 사유·공휴일 이름) — 오늘 진료 바의 '오늘 휴진 · {사유}'와 같은 글자. 사유 없는 휴진('휴진')은 넣지 않는다.
 *     정기 휴진 월요일처럼 정기 일정과 같은 날은 넣지 않는다(공휴일이면 넣는다).
 *
 * Rank Math 와 합치기(한 @graph — Rank Math 1.0.282 includes/modules/schema/class-jsonld.php):
 *   - 우선순위 9 seedPublisher(): $data['publisher'] = 우리 MedicalClinic. Rank Math 의 기본 publisher(Publisher 스니펫, 우선순위 10
 *     add_context_data)는 `! isset( $data['publisher'] )` 일 때만 만들어지므로 생기지 않고, WebSite·Article·저자 worksFor 가 publisher 를
 *     가리킬 때 우리 @id 를 쓴다(add_prop_publisher). Rank Math Local SEO 모듈(켜면 같은 우선순위 9 로 Organization/LocalBusiness 를
 *     publisher 에 넣음 — 기본 영업시간 매일 09:00-17:00)도 같은 자리를 쓴다.
 *   - 우선순위 100 filterJsonLd() → compose(): Rank Math 의 마지막 정리(connect_schema_entities 99 — FAQ 합침 포함) 뒤.
 *     publisher 가 우리 것이 아니면(Local SEO 가 나중에 덮은 경우) 우리 것으로 바꾸고 옛 @id 참조를 모두 우리 @id 로, Local SEO 의 Place 노드 삭제.
 *     → 병원(조직) 노드는 MedicalClinic 하나만 남는다.
 *     의료진 노드(physicians())를 더하고, 의학 페이지면 Rank Math 의 WebPage 노드(@id = 주소#webpage, 이름 = SEO 제목)를 MedicalWebPage 로 바꿔
 *     reviewedBy·lastReviewed·citation 을 붙인다(FAQ 블록이 있으면 ['MedicalWebPage','FAQPage']). 용어 사전이면 DefinedTermSet 노드.
 *   - 브레드크럼(BreadcrumbList)은 Rank Math 가 만든다 — 테마 지원 rank-math-breadcrumbs 를 켠다(Helper::is_breadcrumbs_enabled =
 *     테마 지원 || 설정, 기본 설정은 꺼짐). 화면에 브레드크럼을 그리는 자리는 테마(Task 7).
 *
 * 고정 페이지의 JSON-LD 는 우리 Graph 만이 원천(Task 6 수정 5 F3 — 코디네이터 결정, 설계서 §8 "스키마 = 화면과 같은 값"):
 *   Rank Math 사용자 정의 스키마(메타 rank_math_schema_{유형} — 스키마 탭·rankmath/v1/updateSchemas·가져오기)는 검토 대상이 아니라서
 *   관리자가 넣으면 미검토 headline·description 이 의학 페이지 JSON-LD 에 나오고 검토 표시는 그대로였다.
 *   - 우선순위 11 dropCustomSchemas(): 고정 페이지 단일 화면이면 Rank Math 가 우선순위 10 add_schema 로 넣은 schema-{메타 ID} 노드
 *     (includes/modules/schema/class-frontend.php:47·63-84, 키 = class-db.php:78)를 뺀다 — 99 connect_schema_entities 가 FAQPage 를
 *     WebPage 에 합치거나(change_webpage_entity — :288-321) Product 로 WebPage 를 ItemPage 로 바꾸기(:289-291) 전이다.
 *     블록 FAQ·HowTo(Block_Parser 우선순위 8 — 키 faq·howto, 본문 = 검토 대상)·기본 노드는 그대로.
 *     Rank Math 는 사용자 정의 스키마가 있으면 기본 Article(richSnippet)을 만들지 않는다(snippets/class-singular.php:74-83) — 그 페이지는 Article 도 없다.
 *   - 같은 스키마로 Rank Math 가 만드는 Open Graph 태그(og:video·product:*·article:*_time — schema/class-opengraph.php:29·37-61)는 태그별
 *     필터 rank_math/opengraph/facebook/{태그}(opengraph/class-opengraph.php:181 — 빈 값이면 출력 안 함)로 뺀다(사용자 정의 스키마가 있는 고정 페이지만).
 *
 * 같은 원칙의 확장(Task 6 수정 6 — 수정 5 보고 §8 코디네이터 결정):
 *   ① 고정 페이지 작성자 = 병원(clinicAsAuthor — compose 안): Rank Math 는 단일 화면마다 작성자 Person(키 ProfilePage — 이름·소개·웹사이트·
 *      sameAs·아바타: snippets/class-author.php:34-49·66-105, 넣는 조건 class-jsonld.php:242)과 Article.author(class-article.php:42-50)를 만든다.
 *      작성자 프로필은 직원·seedbot 이 스스로 바꿀 수 있어(Task 13 시드 페이지 작성자 = seedbot) 원장 승인 없이 의학 페이지 JSON-LD 가 바뀌었다
 *      → 고정 페이지면 ProfilePage 노드를 빼고 author 속성(중첩 포함)을 모두 {"@id": 병원}, 옛 작성자 @id 참조도 병원으로. 의료진 노드는 그대로.
 *      Open Graph 작성자 태그도 작성자 프로필 값을 쓴다 — article:author(opengraph/class-facebook.php:133·275-336 사용자 메타 facebook)·
 *      twitter:creator(class-twitter.php:79-81·218-228 사용자 메타 twitter) → 고정 페이지면 병원(사이트 설정 facebook_author_urls·
 *      twitter_author_names — 관리자 설정) 값, 없으면 빈 값(출력 안 함).
 *   ④ ② 고정 페이지에서 Rank Math 스키마 짧은 코드(SCHEMA_SHORTCODES — class-snippet-shortcode.php:47-48)는 아무것도 출력하지 않는다
 *      (dropSchemaShortcode — pre_do_shortcode_tag, wp-includes/shortcodes.php:427). 블록 rank-math/rich-snippet(blocks/schema/class-block-schema.php:75-82)과
 *      본문 자동 삽입(reviewLocation — class-snippet-shortcode.php:365-392)도 이 짧은 코드로 그리므로 함께 빠진다. 사용자 정의 스키마는 검토 대상이 아니다(F3).
 *
 * 고정 페이지 작성자 파생 값 = 병원(Task 6 수정 7 결정 3 — Codex 재확인 3 D·C):
 *   D Rank Math 작성자 변수(%name%·%post_author% → 병원 이름, %user_description% → 빈 값 — clinicAuthorVariables, rank_math/replacements)
 *     → 승인된 제목·설명 템플릿의 공개 <title>·description·Open Graph·JSON-LD 가 직원 프로필을 읽지 않는다.
 *   C oEmbed 응답 author_name·author_url → 병원 이름·병원 주소(clinicOembedAuthor, oembed_response_data). 글(고정 페이지 아님)은 둘 다 그대로.
 *   (Task 8 수정 1 F2 — Codex 교차 검증) 공지(병원 명의 — 판단 ⑤)·칼럼(원장 글)도 작성 계정 프로필을 공개 작성자로 내지 않는다: Open Graph·Twitter
 *   작성자(article:author·twitter:creator — 공지 = 병원 사이트 설정 값, 칼럼 = 빈 값), Slack "Written by"(twitter:data1 — boardWrittenBy), 작성자 변수·oEmbed
 *   = 공지 병원 / 칼럼 원장(columnAuthor). 게시판(공지·칼럼) 밖 글만 Rank Math 그대로(수정 6 ① 대조).
 *   reviewedBy·lastReviewed 는 PageMeta::get() 이 승인 지문을 확인한 값만 준다(결정 1).
 *
 * 홈(Task 7 수정 2 — 대표 결정 2026-11-13, 코디네이터 Ruling A·B):
 *   - 병원 정의 한 문장 clinicSentence()(config/clinic.php 이름·주소) = 홈 히어로 H1 다음 글자(테마 iwell/clinic-definition) = 홈 meta description
 *     첫머리(rank_math/frontend/description → frontDescription, ≤ DESCRIPTION_MAX 자).
 *   - 홈 FAQ: 글 목록 홈은 Rank Math 블록 파서(단일 화면 본문만 읽음)가 FAQ 를 못 본다 → 화면에 그린 FAQ 블록을 captureFaq 로 모아 우선순위 8
 *     frontFaq 에서 Rank Math 의 블록별 필터로 FAQPage 를 만든다(같은 블록 = 화면 문답과 같은 원본, 홈 ld+json 1개의 @graph 안).
 */

namespace Iwell\Core\Schema;

use DateTimeImmutable;
use Iwell\Core\Columns\Meta as ColumnMeta;
use Iwell\Core\Hours\Render;
use Iwell\Core\Hours\Rules;
use Iwell\Core\Hours\Store;
use Iwell\Core\LiveSeal;
use Iwell\Core\PageMeta;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Graph {
	public const SPECIAL_DAYS = 60;

	private const DAY_NAMES = array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday' );

	/** Rules 가 사유 없는 휴진에 채우는 기본 사유(바도 '오늘 휴진'만 보인다 — Render::DEFAULT_CLOSED_REASON 과 같은 값). */
	private const DEFAULT_CLOSED_REASON = '휴진';

	/** Rank Math 가 사용자 정의 스키마로 만드는 Open Graph 태그(필터 이름의 태그 부분 — ':' → '_'). */
	public const SCHEMA_OG_TAGS = array( 'og_video', 'video_duration', 'product_brand', 'product_price_amount', 'product_price_currency', 'product_availability', 'article_published_time', 'article_modified_time' );

	/** Rank Math 1.0.282 스키마 짧은 코드 전부(includes/modules/schema/class-snippet-shortcode.php:47-48 — 설치본 add_shortcode 전수 검색, 수정 6 ④ ②). */
	public const SCHEMA_SHORTCODES = array( 'rank_math_rich_snippet', 'rank_math_review_snippet' );

	/** Rank Math Open Graph 설정(사이트 단위 — manage_options) 옵션 이름(includes/class-settings.php:43). */
	private const RANK_MATH_TITLES = 'rank-math-options-titles';

	/** 정의 문장의 진료과 이름 — config/clinic.php medicalSpecialty(schema.org 값) → 화면 표기(병원 자료 진료과목 "소아청소년과", docx L14). */
	private const SPECIALTY_NAMES = array( 'Pediatric' => '소아청소년과' );

	/** 홈 meta description 최대 길이(글자 — 수정 2 Ruling A). */
	public const DESCRIPTION_MAX = 160;

	/** @var list<array> 글 목록 홈에서 그린 Rank Math FAQ 블록(파싱된 모양) — 다음 rank_math/json_ld 에서 FAQPage 로 한 번 낸다. */
	private static array $frontFaqBlocks = array();

	public static function register(): void {
		add_filter( 'rank_math/json_ld', array( self::class, 'frontFaq' ), 8 );
		add_filter( 'render_block_rank-math/faq-block', array( self::class, 'captureFaq' ), 10, 2 );
		add_filter( 'rank_math/frontend/description', array( self::class, 'frontDescription' ) );
		add_filter( 'rank_math/json_ld', array( self::class, 'seedPublisher' ), 9 );
		add_filter( 'rank_math/json_ld', array( self::class, 'dropCustomSchemas' ), 11, 2 );
		add_filter( 'rank_math/json_ld', array( self::class, 'filterJsonLd' ), 100, 2 );
		foreach ( self::SCHEMA_OG_TAGS as $tag ) {
			add_filter( "rank_math/opengraph/facebook/$tag", array( self::class, 'dropSchemaTag' ) );
		}
		add_filter( 'rank_math/opengraph/facebook/article_author', array( self::class, 'clinicArticleAuthor' ) );
		add_filter( 'rank_math/opengraph/twitter/twitter_creator', array( self::class, 'clinicTwitterCreator' ) );
		add_filter( 'rank_math/opengraph/slack_enhanced_data', array( self::class, 'boardWrittenBy' ) );
		add_filter( 'pre_do_shortcode_tag', array( self::class, 'dropSchemaShortcode' ), 10, 2 );
		add_filter( 'rank_math/replacements', array( self::class, 'clinicAuthorVariables' ), 10, 2 );
		add_filter( 'oembed_response_data', array( self::class, 'clinicOembedAuthor' ), 10, 2 );
		add_action( 'after_setup_theme', array( self::class, 'breadcrumbSupport' ), 20 );
	}

	/**
	 * rank_math/replacements(replace-variables/class-replacer.php — 치환 직전, 인자 = 치환 대상 글) — 고정 페이지면 작성자 프로필을 읽는 Rank Math 변수를
	 * 병원으로(수정 7 결정 3 D — includes/replace-variables/class-author-variables.php 의 변수 4개 중 프로필을 읽는 3개): %name%·%post_author%
	 * (작성자 표시 이름 — :55-73 등록, :107-112 get_name) = 병원 이름, %user_description%(작성자 소개 — :77-84, :119-124) = 빈 값.
	 * 제목·설명·Open Graph·JSON-LD 가 모두 이 치환기를 쓴다(class-replacer.php:113 이 필터). 공지는 병원 이름, 칼럼은 원장 이름(Task 8 수정 1 F2),
	 * 게시판 밖 글은 그대로.
	 * %userid%(작성자 ID 숫자 — 직원이 바꿀 수 없는 값)는 그대로.
	 *
	 * @param mixed $replacements
	 * @param mixed $args 치환 대상(글 필드 객체 — Replacer::$args).
	 * @return mixed
	 */
	public static function clinicAuthorVariables( $replacements, $args = null ) {
		// 치환 대상의 글 종류로 판정(작성자 보관함은 사용자 객체 — 그 ID 가 우연히 고정 페이지 ID 와 같아도 건드리지 않게).
		$type = is_object( $args ) && isset( $args->post_type ) ? (string) $args->post_type : '';
		if ( ! is_array( $replacements ) ) {
			return $replacements;
		}
		if ( PageMeta::POST_TYPE === $type ) {
			$name = self::clinicInfo()['name'];
		} else {
			// 공지 = 병원, 칼럼 = 원장(Task 8 수정 1 F2 — 글 JSON-LD 작성자와 같은 주체). 게시판 밖 글은 그대로.
			$post = 'post' === $type && isset( $args->ID ) ? get_post( (int) $args->ID ) : null;
			$name = self::boardAuthorName( $post instanceof WP_Post ? $post : null );
			if ( null === $name ) {
				return $replacements;
			}
		}
		return array_merge(
			$replacements,
			array(
				'%name%'             => $name,
				'%post_author%'      => $name,
				'%user_description%' => '',
			)
		);
	}

	/**
	 * oembed_response_data(wp-includes/embed.php — author_name·author_url 은 작성자 표시 이름·작성자 보관함 :614-615) — 고정 페이지면 병원 이름·병원 주소
	 * (수정 7 결정 3 C). 공지도 병원, 칼럼은 원장 이름·원장 의료진 페이지(Task 8 수정 1 F2). 게시판 밖 글은 그대로.
	 *
	 * @param mixed $data
	 * @param mixed $post
	 * @return mixed
	 */
	public static function clinicOembedAuthor( $data, $post = null ) {
		if ( ! is_array( $data ) || ! $post instanceof WP_Post ) {
			return $data;
		}
		$board = self::board( $post );
		if ( PageMeta::POST_TYPE !== $post->post_type && null === $board ) {
			return $data;
		}
		// 고정 페이지·공지 = 병원 이름·병원 주소, 칼럼 = 원장 이름·원장 의료진 페이지(없으면 병원 주소) — Task 8 수정 1 F2.
		$doctor              = 'columns' === $board ? self::columnAuthor() : null;
		$data['author_name'] = null === $doctor ? self::clinicInfo()['name'] : $doctor['name'];
		$data['author_url']  = null === $doctor || null === $doctor['physician'] ? home_url( '/' ) : (string) $doctor['physician']['url'];
		return $data;
	}

	/**
	 * rank_math/opengraph/facebook/article_author — 고정 페이지·공지(병원 명의 — Task 8 판단 ⑤)면 작성자 프로필(facebook) 대신 병원(사이트 설정
	 * facebook_author_urls) 값(수정 6 ① · Task 8 수정 1 F2), 칼럼(원장 글)이면 빈 값(원장 개인 계정 설정 없음 — 작성 계정 칼럼 봇 값을 내지 않는다).
	 * 빈 값은 출력 안 함(opengraph/class-opengraph.php:181).
	 */
	public static function clinicArticleAuthor( $content ) {
		$board = self::board( self::queriedPost() );
		if ( self::onPage() || 'notices' === $board ) {
			return self::rankMathTitle( 'facebook_author_urls' );
		}
		return 'columns' === $board ? '' : $content;
	}

	/** rank_math/opengraph/twitter/twitter_creator — 고정 페이지·공지면 작성자 프로필(twitter) 대신 병원(사이트 설정 twitter_author_names) 값, 칼럼이면 빈 값(같은 규칙). */
	public static function clinicTwitterCreator( $content ) {
		$board = self::board( self::queriedPost() );
		if ( ! self::onPage() && 'notices' !== $board ) {
			return 'columns' === $board ? '' : $content;
		}
		$site = ltrim( self::rankMathTitle( 'twitter_author_names' ), '@' );
		return '' === $site ? '' : '@' . $site;
	}

	/**
	 * rank_math/opengraph/slack_enhanced_data(opengraph/class-slack.php:98 — 글 단일 화면의 twitter:label1 "Written by"·twitter:data1 = 작성 계정 표시 이름
	 * get_the_author(), :266) — 공지면 병원 이름, 칼럼이면 원장 이름(config columnAuthor). 화면 작성자·JSON-LD author 와 같은 주체(Task 8 수정 1 F2).
	 * 게시판 밖 글은 그대로. 고정 페이지에는 Rank Math 가 "Written by" 를 넣지 않는다(:283 get_page_data).
	 *
	 * @param mixed $data
	 * @return mixed
	 */
	public static function boardWrittenBy( $data ) {
		$name = self::boardAuthorName( self::queriedPost() );
		// phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- Rank Math 가 같은 문구·텍스트 도메인으로 만든 키를 찾는다.
		$key = __( 'Written by', 'seo-by-rank-math' );
		if ( null === $name || ! is_array( $data ) || ! array_key_exists( $key, $data ) ) {
			return $data;
		}
		$data[ $key ] = $name;
		return $data;
	}

	/** 글(post)의 게시판 — 'columns'(원장 칼럼) | 'notices'(공지) | null(게시판 밖 글·글이 아님). post() 와 같은 순서(칼럼 먼저). */
	private static function board( ?WP_Post $post ): ?string {
		if ( null === $post || 'post' !== $post->post_type ) {
			return null;
		}
		if ( has_category( 'columns', $post ) ) {
			return 'columns';
		}
		return has_category( 'notices', $post ) ? 'notices' : null;
	}

	/** 게시판 글의 공개 작성자 이름 — 공지 = 병원 이름, 칼럼 = 원장 이름(columnAuthor), 그 밖 null. */
	private static function boardAuthorName( ?WP_Post $post ): ?string {
		$board = self::board( $post );
		if ( null === $board ) {
			return null;
		}
		return 'notices' === $board ? self::clinicInfo()['name'] : self::columnAuthor()['name'];
	}

	/**
	 * pre_do_shortcode_tag — 고정 페이지(공개 단일 화면 또는 지금 그리는 글)에서 Rank Math 스키마 짧은 코드는 빈 출력(수정 6 ④ ②).
	 * false 가 아닌 값을 돌려주면 워드프레스가 짧은 코드 함수를 부르지 않는다(wp-includes/shortcodes.php:427-430).
	 */
	public static function dropSchemaShortcode( $output, $tag = '' ) {
		if ( ! in_array( $tag, self::SCHEMA_SHORTCODES, true ) ) {
			return $output;
		}
		$current = get_post();
		return self::onPage() || ( $current instanceof WP_Post && PageMeta::POST_TYPE === $current->post_type ) ? '' : $output;
	}

	/** 지금 화면이 고정 페이지 단일 화면인가. */
	private static function onPage(): bool {
		$post = self::queriedPost();
		return null !== $post && PageMeta::POST_TYPE === $post->post_type;
	}

	/** Rank Math 사이트 설정(Titles & Meta) 값 — 문자열이 아니면 ''. */
	private static function rankMathTitle( string $key ): string {
		$titles = get_option( self::RANK_MATH_TITLES );
		return is_array( $titles ) && is_string( $titles[ $key ] ?? null ) ? trim( $titles[ $key ] ) : '';
	}

	/**
	 * rank_math/json_ld 우선순위 11 — 고정 페이지면 Rank Math 사용자 정의 스키마(schema-{메타 ID}) 노드를 뺀다(수정 5 F3).
	 *
	 * @param mixed $data
	 * @param mixed $context Rank Math JsonLD(필터) 또는 시험이 주는 글. 글이 아니면 지금 화면의 글.
	 */
	public static function dropCustomSchemas( $data, $context = null ): array {
		$data = is_array( $data ) ? $data : array();
		$post = $context instanceof WP_Post ? $context : self::queriedPost();
		if ( null === $post || PageMeta::POST_TYPE !== $post->post_type ) {
			return $data;
		}
		foreach ( array_keys( $data ) as $key ) {
			if ( is_string( $key ) && str_starts_with( $key, 'schema-' ) ) {
				unset( $data[ $key ] );
			}
		}
		return $data;
	}

	/** rank_math/opengraph/facebook/{태그} — 사용자 정의 스키마가 있는 고정 페이지면 그 스키마로 만든 태그를 비운다(빈 값은 출력 안 함). */
	public static function dropSchemaTag( $content ) {
		$post = self::queriedPost();
		return null !== $post && PageMeta::POST_TYPE === $post->post_type && self::hasCustomSchema( $post->ID ) ? '' : $content;
	}

	/** Rank Math 사용자 정의 스키마가 있는가 — DB::get_schemas 와 같은 조건(메타 키 rank_math_schema 로 시작, 빈 값 제외 — class-db.php:64-80). */
	public static function hasCustomSchema( int $post_id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Rank Math 와 같은 조회.
		$values = $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s", $post_id, $wpdb->esc_like( 'rank_math_schema' ) . '%' ) );
		foreach ( $values as $value ) {
			if ( ! empty( maybe_unserialize( $value ) ) ) {
				return true;
			}
		}
		return false;
	}

	private static function queriedPost(): ?WP_Post {
		$post = is_singular() ? get_queried_object() : null;
		return $post instanceof WP_Post ? $post : null;
	}

	public static function breadcrumbSupport(): void {
		add_theme_support( 'rank-math-breadcrumbs' );
	}

	public static function clinicId(): string {
		return home_url( '/#clinic' );
	}

	/** @return array{name: string, address: array{region: string, locality: string, street: string, country: string}, telephone: string, fax: string, medicalSpecialty: string, addressText: string} */
	public static function clinicInfo(): array {
		$info                = require dirname( __DIR__, 2 ) . '/config/clinic.php';
		$address             = $info['address'];
		$info['addressText'] = implode( ' ', array_filter( array( $address['region'], $address['locality'], $address['street'] ), static fn( $s ): bool => '' !== (string) $s ) );
		return $info;
	}

	/**
	 * 병원 정의 한 문장(수정 2 Ruling A — 홈 히어로 H1 바로 다음·홈 meta description 첫머리): "{이름}는 {시·도} {시·군·구} {읍·면·동}에 있는 {진료과}입니다."
	 * 이름·주소·진료과는 병원 정보($info, 기본 = config/clinic.php)에서만 — 효능·순위·"전문" 같은 말을 붙이지 않는다.
	 * 읍·면·동 = 도로명 주소(street)의 첫 낱말이 읍·면·동으로 끝날 때만. 진료과 표기를 모르면 빈 문장(지어내지 않음).
	 */
	public static function clinicSentence( ?array $info = null ): string {
		$info    ??= self::clinicInfo();
		$name      = trim( (string) ( $info['name'] ?? '' ) );
		$address   = (array) ( $info['address'] ?? array() );
		$specialty = self::SPECIALTY_NAMES[ (string) ( $info['medicalSpecialty'] ?? '' ) ] ?? '';
		$first     = explode( ' ', trim( (string) ( $address['street'] ?? '' ) ) )[0];
		$area      = array_values(
			array_filter(
				array( trim( (string) ( $address['region'] ?? '' ) ), trim( (string) ( $address['locality'] ?? '' ) ), 1 === preg_match( '/^\S+[읍면동]$/u', $first ) ? $first : '' ),
				static fn( string $s ): bool => '' !== $s
			)
		);
		if ( '' === $name || array() === $area || '' === $specialty ) {
			return '';
		}
		return sprintf( '%s%s %s에 있는 %s입니다.', $name, self::topicParticle( $name ), implode( ' ', $area ), $specialty );
	}

	/** 주제 조사 — 끝 글자가 받침 있는 한글이면 '은', 아니면 '는'. */
	private static function topicParticle( string $word ): string {
		$code = mb_ord( mb_substr( $word, -1, 1, 'UTF-8' ), 'UTF-8' ) - 0xAC00;
		return $code >= 0 && $code <= 11171 && 0 !== $code % 28 ? '은' : '는';
	}

	/**
	 * 홈 meta description(수정 2 Ruling A): 첫머리 = 정의 문장. Rank Math 홈 설명(설정 titles.homepage_description — 비면 사이트 설명)이 있으면 그 뒤에,
	 * 이미 정의 문장으로 시작하면 그대로. DESCRIPTION_MAX 자를 넘으면 정의 문장만. og:description 은 Rank Math 가 이 값을 이어받는다
	 * (opengraph/class-opengraph.php:135-155 — 홈 Facebook 설명이 비었을 때).
	 */
	public static function homeDescription( string $current ): string {
		$sentence = self::clinicSentence();
		$current  = trim( $current );
		if ( '' === $sentence ) {
			return $current;
		}
		if ( '' === $current ) {
			$out = $sentence;
		} elseif ( str_starts_with( $current, $sentence ) ) {
			$out = $current;
		} else {
			$out = $sentence . ' ' . $current;
		}
		return mb_strlen( $out, 'UTF-8' ) <= self::DESCRIPTION_MAX ? $out : $sentence;
	}

	/** rank_math/frontend/description — 홈이면 homeDescription(). */
	public static function frontDescription( $description ) {
		return is_front_page() ? self::homeDescription( (string) $description ) : $description;
	}

	/** 글 목록 홈(단일 화면 아님)인가 — Rank Math 블록 파서가 FAQ 를 읽지 않는 화면. */
	private static function onFront(): bool {
		return is_front_page() && ! is_singular();
	}

	/**
	 * render_block_rank-math/faq-block — 글 목록 홈에서 그린 FAQ 블록을 모은다(출력은 그대로). 블록 테마는 템플릿을 wp_head 보다 먼저 그리므로
	 * (wp-includes/template-canvas.php) 같은 요청의 rank_math/json_ld 에서 frontFaq() 가 쓴다. 단일 화면은 Rank Math 가 본문에서 읽으므로 모으지 않는다.
	 *
	 * @param mixed $content 블록 출력.
	 * @param mixed $block   파싱된 블록.
	 */
	public static function captureFaq( $content, $block = null ) {
		if ( is_array( $block ) && '' !== trim( (string) $content ) && self::onFront() ) {
			self::$frontFaqBlocks[] = $block;
		}
		return $content;
	}

	/**
	 * rank_math/json_ld 우선순위 8(Rank Math 블록 파서와 같은 자리) — 홈에서 그린 FAQ 블록을 Rank Math 의 블록별 필터(rank_math/schema/block/faq-block —
	 * blocks/faq/class-block-faq.php add_graph)에 그대로 넘겨 FAQPage(키 faqs)를 만든다 = 단일 화면 FAQ 와 같은 문답 모양. 99 connect_schema_entities 가
	 * 이 FAQPage 를 WebPage 노드에 합친다(한 @graph). Question.url 은 Rank Math 가 전역 글(get_permalink())로 만드므로 홈 주소#id 로 바로잡는다.
	 * 모은 블록은 한 번만 낸다.
	 *
	 * @param mixed $data
	 */
	public static function frontFaq( $data ): array {
		$data                 = is_array( $data ) ? $data : array();
		$blocks               = self::$frontFaqBlocks;
		self::$frontFaqBlocks = array();
		if ( array() === $blocks || ! self::onFront() ) {
			return $data;
		}
		foreach ( $blocks as $block ) {
			$data = (array) apply_filters( 'rank_math/schema/block/faq-block', $data, $block );
		}
		foreach ( (array) ( $data['faqs']['mainEntity'] ?? array() ) as $i => $question ) {
			$hash                                    = strrchr( (string) ( $question['url'] ?? '' ), '#' );
			$data['faqs']['mainEntity'][ $i ]['url'] = home_url( '/' ) . ( false === $hash ? '' : $hash );
		}
		return $data;
	}

	/** MedicalClinic 노드. */
	public static function clinic(): array {
		$info   = self::clinicInfo();
		$config = Store::config();
		return array(
			'@type'                            => 'MedicalClinic',
			'@id'                              => self::clinicId(),
			'name'                             => $info['name'],
			'url'                              => home_url( '/' ),
			'telephone'                        => $info['telephone'],
			'faxNumber'                        => $info['fax'],
			'address'                          => array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => $info['address']['street'],
				'addressLocality' => $info['address']['locality'],
				'addressRegion'   => $info['address']['region'],
				'addressCountry'  => $info['address']['country'],
			),
			'medicalSpecialty'                 => $info['medicalSpecialty'],
			'openingHoursSpecification'        => self::weekly( $config ),
			'specialOpeningHoursSpecification' => self::special( $config, Rules::today() ),
		);
	}

	/** 정기 진료시간: 하루 일정이 같은 요일끼리(처음 나온 요일 순), 세션마다 한 항목. */
	public static function weekly( array $config ): array {
		$groups = array();
		foreach ( self::regularByWeekday( $config ) as $weekday => $sessions ) {
			if ( array() === $sessions ) {
				continue;
			}
			$key              = self::key( $sessions );
			$groups[ $key ] ??= array(
				'days'     => array(),
				'sessions' => $sessions,
			);
			$groups[ $key ]['days'][] = self::DAY_NAMES[ $weekday ];
		}
		$out = array();
		foreach ( $groups as $group ) {
			foreach ( $group['sessions'] as $s ) {
				$out[] = array(
					'@type'     => 'OpeningHoursSpecification',
					'dayOfWeek' => $group['days'],
					'opens'     => $s['from'],
					'closes'    => $s['to'],
				);
			}
		}
		return $out;
	}

	/** 오늘부터 SPECIAL_DAYS 일 동안 정기 일정과 다른 날·공휴일·날짜 예외. */
	public static function special( array $config, DateTimeImmutable $today ): array {
		$regular = self::regularByWeekday( $config );
		$start   = Rules::today( $today );
		$out     = array();
		for ( $i = 0; $i < self::SPECIAL_DAYS; $i++ ) {
			$date    = $start->modify( "+$i days" );
			$ymd     = $date->format( 'Y-m-d' );
			$day     = Rules::forDate( $date, $config );
			$actual  = $day['open'] ? Render::merge( $day['sessions'] ) : array();
			$listed  = isset( $config['holidays'][ $ymd ] ) || isset( $config['exceptions'][ $ymd ] );
			$differs = self::key( $actual ) !== self::key( $regular[ (int) $date->format( 'N' ) ] );
			if ( ! $listed && ! $differs ) {
				continue;
			}
			$reason = trim( (string) ( $day['reason'] ?? '' ) );
			$extra  = '' !== $reason && self::DEFAULT_CLOSED_REASON !== $reason ? array( 'description' => $reason ) : array();
			$base   = array(
				'@type'        => 'OpeningHoursSpecification',
				'validFrom'    => $ymd,
				'validThrough' => $ymd,
			);
			if ( array() === $actual ) {
				$out[] = $base + array(
					'opens'  => '00:00',
					'closes' => '00:00',
				) + $extra;
				continue;
			}
			foreach ( $actual as $s ) {
				$out[] = $base + array(
					'opens'  => $s['from'],
					'closes' => $s['to'],
				) + $extra;
			}
		}
		return $out;
	}

	/** 게시된 의료진 페이지(메타 iwell_physician 에 이름이 있는 것) → Person·Physician 노드. 메뉴 순서 → ID 순. */
	public static function physicians(): array {
		$posts = get_posts(
			array(
				'post_type'        => PageMeta::POST_TYPE,
				'post_status'      => 'publish',
				'meta_key'         => 'iwell_physician', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- 의료진 몇 명.
				'posts_per_page'   => 50,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'ID'         => 'ASC',
				),
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);
		$out = array();
		foreach ( $posts as $post ) {
			$physician = PageMeta::physician( $post->ID );
			if ( '' === ( $physician['name'] ?? '' ) ) {
				continue;
			}
			$link = get_permalink( $post );
			$node = array(
				'@type' => array( 'Person', 'Physician' ),
				'@id'   => $link . '#physician',
				'name'  => $physician['name'],
				'url'   => $link,
			);
			foreach ( array( 'jobTitle', 'medicalSpecialty' ) as $key ) {
				if ( isset( $physician[ $key ] ) ) {
					$node[ $key ] = $physician[ $key ];
				}
			}
			if ( isset( $physician['alumniOf'] ) ) {
				$node['alumniOf'] = array_map(
					static fn( string $name ): array => array(
						'@type' => 'EducationalOrganization',
						'name'  => $name,
					),
					$physician['alumniOf']
				);
			}
			if ( isset( $physician['sameAs'] ) ) {
				$node['sameAs'] = $physician['sameAs'];
			}
			$node['worksFor'] = array( '@id' => self::clinicId() );
			$out[]            = $node;
		}
		return $out;
	}

	/** 의학 페이지(기준일 또는 출처가 있는 고정 페이지) → MedicalWebPage, 아니면 null. */
	public static function page( WP_Post $post ): ?array {
		if ( PageMeta::POST_TYPE !== $post->post_type ) {
			return null;
		}
		$meta = PageMeta::get( $post->ID );
		if ( '' === $meta['asof'] && array() === $meta['sources'] ) {
			return null;
		}
		$link = get_permalink( $post );
		$node = array(
			'@type' => 'MedicalWebPage',
			'@id'   => $link . '#webpage',
			'url'   => $link,
			'name'  => $post->post_title,
		);
		if ( '' !== $meta['reviewedAt'] ) {
			$node['lastReviewed'] = $meta['reviewedAt'];
		}
		$reviewer = self::reviewer( $meta['reviewedBy'] );
		if ( null !== $reviewer ) {
			$node['reviewedBy'] = $reviewer;
		}
		if ( array() !== $meta['sources'] ) {
			$node['citation'] = array_map(
				static fn( array $s ): array => array(
					'@type' => 'CreativeWork',
					'name'  => $s['title'],
					'url'   => $s['url'],
				),
				$meta['sources']
			);
		}
		return $node;
	}

	/** 용어 사전(용어가 있는 고정 페이지) → DefinedTermSet, 아니면 null. */
	public static function glossary( WP_Post $post ): ?array {
		if ( PageMeta::POST_TYPE !== $post->post_type ) {
			return null;
		}
		$terms = PageMeta::get( $post->ID )['terms'];
		if ( array() === $terms ) {
			return null;
		}
		$link = get_permalink( $post );
		$id   = $link . '#glossary';
		return array(
			'@type'          => 'DefinedTermSet',
			'@id'            => $id,
			'url'            => $link,
			'name'           => $post->post_title,
			'hasDefinedTerm' => array_map(
				static fn( array $t ): array => array(
					'@type'            => 'DefinedTerm',
					'name'             => $t['term'],
					'description'      => $t['description'],
					'inDefinedTermSet' => array( '@id' => $id ),
				),
				$terms
			),
		);
	}

	/** rank_math/json_ld 우선순위 9 — publisher 자리에 우리 병원. */
	public static function seedPublisher( $data ): array {
		$data              = is_array( $data ) ? $data : array();
		$data['publisher'] = self::clinic();
		return $data;
	}

	/**
	 * rank_math/json_ld 우선순위 100. 검토 필드(reviewedBy·lastReviewed)는 실제로 보낸 공개 응답의 판정(LiveSeal — Task 6 수정 12 Ruling 1·2)이 통과할 때만
	 * 그 응답에 들어간다 — 여기서는 언제나 빼고, 판정 중인 페이지면 값만 판정에 넘긴다(compose()·page() 는 원천 그대로 — 시험·편집 패널).
	 */
	public static function filterJsonLd( $data, $jsonld = null ): array {
		$post = is_singular() ? get_queried_object() : null;
		$post = $post instanceof WP_Post ? $post : null;
		return LiveSeal::jsonLd( self::compose( is_array( $data ) ? $data : array(), $post ), $post );
	}

	/** Rank Math 데이터 + 우리 노드 → 한 그래프(병원 노드 하나). */
	public static function compose( array $data, ?WP_Post $post ): array {
		$clinic = isset( $data['publisher']['@type'] ) && 'MedicalClinic' === $data['publisher']['@type'] && self::clinicId() === ( $data['publisher']['@id'] ?? null )
			? $data['publisher']
			: self::clinic();
		$old    = $data['publisher']['@id'] ?? null;
		unset( $data['place'] ); // Rank Math Local SEO 의 Place(옛 publisher.location 전용).
		$data['publisher'] = $clinic;
		if ( is_string( $old ) && $old !== $clinic['@id'] ) {
			$data = self::repoint( $data, $old, $clinic['@id'] );
		}

		foreach ( self::physicians() as $i => $physician ) {
			$data[ 'iwellPhysician' . $i ] = $physician;
		}

		if ( null !== $post ) {
			if ( PageMeta::POST_TYPE === $post->post_type ) {
				$data = self::clinicAsAuthor( $data, $clinic['@id'] );
			} elseif ( 'post' === $post->post_type ) {
				$data = self::post( $data, $post, $clinic['@id'] );
			}
			$page = self::page( $post );
			if ( null !== $page ) {
				if ( isset( $data['WebPage'] ) && is_array( $data['WebPage'] ) ) {
					$types = array_map( static fn( $t ) => 'WebPage' === $t ? 'MedicalWebPage' : $t, (array) ( $data['WebPage']['@type'] ?? array() ) );
					if ( ! in_array( 'MedicalWebPage', $types, true ) ) {
						array_unshift( $types, 'MedicalWebPage' );
					}
					$types                     = array_values( array_unique( $types ) );
					$data['WebPage']['@type'] = 1 === count( $types ) ? $types[0] : $types;
					foreach ( array( 'lastReviewed', 'reviewedBy', 'citation' ) as $key ) {
						if ( isset( $page[ $key ] ) ) {
							$data['WebPage'][ $key ] = $page[ $key ];
						}
					}
				} else {
					$data['iwellWebPage'] = $page;
				}
			}
			$glossary = self::glossary( $post );
			if ( null !== $glossary ) {
				$data['iwellGlossary'] = $glossary;
			}
		}
		return $data;
	}

	/**
	 * 고정 페이지 작성자 = 병원(수정 6 ①): Rank Math 작성자 Person(키 ProfilePage)을 빼고, author 속성(중첩 포함 — Article.author 등)을 모두
	 * {"@id": 병원}, 그 밖에 옛 작성자 @id 를 가리키던 참조도 병원으로. 작성자 프로필(이름·소개·웹사이트·sameAs·아바타)이 그래프에 남지 않는다.
	 */
	public static function clinicAsAuthor( array $data, string $clinic_id ): array {
		$profile = isset( $data['ProfilePage']['@id'] ) && is_string( $data['ProfilePage']['@id'] ) ? $data['ProfilePage']['@id'] : null;
		unset( $data['ProfilePage'] );
		$data = self::authorsTo( $data, $clinic_id );
		return null === $profile ? $data : self::repoint( $data, $profile, $clinic_id );
	}

	/**
	 * 원장 칼럼 작성자(Task 8 — 칼럼 = 원장 본인 글, 계획 Task 8 "칼럼 = 원장 이름"): config/clinic.php columnAuthor·columnAuthorTitle(이름이 없으면 대표자 이름).
	 * physician = 같은 이름(iwell_physician.name)의 게시된 의료진 노드(physicians() 순서의 첫째) — 화면 작성자 링크·JSON-LD author @id. 없으면 null.
	 *
	 * @param array|null $info 병원 정보(기본 = clinicInfo()).
	 * @return array{name: string, title: string, label: string, physician: ?array}
	 */
	public static function columnAuthor( ?array $info = null ): array {
		$info    ??= self::clinicInfo();
		$name      = trim( (string) ( $info['columnAuthor'] ?? '' ) );
		$name      = '' === $name ? trim( (string) ( $info['representative'] ?? '' ) ) : $name;
		$title     = trim( (string) ( $info['columnAuthorTitle'] ?? '' ) );
		$physician = null;
		if ( '' !== $name ) {
			foreach ( self::physicians() as $node ) {
				if ( $node['name'] === $name ) {
					$physician = $node;
					break;
				}
			}
		}
		return array(
			'name'      => $name,
			'title'     => $title,
			'label'     => trim( $name . ' ' . $title ),
			'physician' => $physician,
		);
	}

	/**
	 * 글(공지·칼럼) JSON-LD(Task 8 T6 — 대표 승인 GEO 2). Rank Math 1.0.282 는 글 단일 화면에 BlogPosting(키 richSnippet)·WebPage·작성 계정
	 * Person(키 ProfilePage)을 만든다(9414 실측). 작성 계정(칼럼 봇·직원)의 프로필은 그래프에 남기지 않는다:
	 *   - 공지(notices): 작성자 = 병원(clinicAsAuthor — 고정 페이지와 같은 규칙, 화면 작성자 = 병원 이름).
	 *   - 게시판 카테고리(공지·칼럼) 밖의 글은 Rank Math 그대로(Task 6 수정 6 ① 시험 — 이 사이트의 글은 공지·칼럼뿐).
	 *   - 칼럼(columns): 작성자 = 원장(columnAuthor — 같은 이름의 게시된 의료진 노드 @id, 없으면 Person 노드 #column-author).
	 *     datePublished = post_date(원문 게시 시각 — Task 12 가 원문 pubDate 로 쓴다), dateModified = 홈페이지 정리일(iwell_imported_at, 있으면)·없으면 post_modified
	 *     (BlogPosting·WebPage 같은 값). 원문 번호가 있으면 BlogPosting isBasedOn·sameAs = 원문 주소. 원장 검토 표시(reviewedBy·lastReviewed)는 붙이지
	 *     않는다(칼럼은 원장 본인 글 — Task 6 원칙). Rank Math 가 BlogPosting 을 만들지 않는 설정이면 같은 값의 BlogPosting 노드를 더한다.
	 */
	public static function post( array $data, WP_Post $post, string $clinic_id ): array {
		if ( ! has_category( 'columns', $post ) ) {
			return has_category( 'notices', $post ) ? self::clinicAsAuthor( $data, $clinic_id ) : $data;
		}
		$author = self::columnAuthor();
		if ( null !== $author['physician'] ) {
			$ref = array( '@id' => $author['physician']['@id'] );
		} else {
			$ref                       = array( '@id' => home_url( '/#column-author' ) );
			$data['iwellColumnAuthor'] = array_filter(
				array(
					'@type'    => 'Person',
					'@id'      => $ref['@id'],
					'name'     => $author['name'],
					'jobTitle' => $author['title'],
					'worksFor' => array( '@id' => $clinic_id ),
				),
				static fn( $v ): bool => '' !== $v
			);
		}
		$profile = isset( $data['ProfilePage']['@id'] ) && is_string( $data['ProfilePage']['@id'] ) ? $data['ProfilePage']['@id'] : null;
		unset( $data['ProfilePage'] );
		$data = self::authorsTo( $data, $ref['@id'] );
		if ( null !== $profile ) {
			$data = self::repoint( $data, $profile, $ref['@id'] );
		}

		$published = (string) get_post_time( 'c', false, $post );
		$imported  = ColumnMeta::importedAt( $post->ID );
		$modified  = '' !== $imported ? $imported : (string) get_post_modified_time( 'c', false, $post );
		$source    = ColumnMeta::originalUrl( $post->ID );
		if ( ! isset( $data['richSnippet'] ) || ! is_array( $data['richSnippet'] ) ) {
			$link                = get_permalink( $post );
			$data['richSnippet'] = array(
				'@type'            => 'BlogPosting',
				'@id'              => $link . '#richSnippet',
				'headline'         => get_the_title( $post ),
				'url'              => $link,
				'author'           => $ref,
				'publisher'        => array( '@id' => $clinic_id ),
				'mainEntityOfPage' => array( '@id' => $link . '#webpage' ),
			);
		}
		foreach ( array( 'richSnippet', 'WebPage' ) as $key ) {
			if ( isset( $data[ $key ] ) && is_array( $data[ $key ] ) ) {
				$data[ $key ]['datePublished'] = $published;
				$data[ $key ]['dateModified']  = $modified;
			}
		}
		if ( '' !== $source ) {
			$data['richSnippet']['isBasedOn'] = $source;
			$data['richSnippet']['sameAs']    = array( $source );
		}
		return $data;
	}

	/** 키가 'author' 인 값을 모두 {"@id": $id} 로(중첩 배열까지). */
	private static function authorsTo( array $node, string $id ): array {
		foreach ( $node as $key => $value ) {
			if ( 'author' === $key ) {
				$node[ $key ] = array( '@id' => $id );
			} elseif ( is_array( $value ) ) {
				$node[ $key ] = self::authorsTo( $value, $id );
			}
		}
		return $node;
	}

	/** 검토자 → 같은 이름의 의료진 노드 참조, 없으면 Person(이름). 검토자가 없으면 null. */
	private static function reviewer( int $user_id ): ?array {
		$name = PageMeta::reviewerName( $user_id );
		if ( '' === $name ) {
			return null;
		}
		foreach ( self::physicians() as $physician ) {
			if ( $physician['name'] === $name ) {
				return array( '@id' => $physician['@id'] );
			}
		}
		return array(
			'@type' => 'Person',
			'name'  => $name,
		);
	}

	/** 값이 정확히 $old 인 '@id' 를 모두 $new 로(중첩 배열까지). */
	private static function repoint( array $node, string $old, string $new ): array {
		foreach ( $node as $key => $value ) {
			if ( '@id' === $key && $old === $value ) {
				$node[ $key ] = $new;
			} elseif ( is_array( $value ) ) {
				$node[ $key ] = self::repoint( $value, $old, $new );
			}
		}
		return $node;
	}

	/** ISO 요일(1~7) → 그 요일의 정기 세션(합친 것). 정기 휴진 요일은 빈 목록. */
	private static function regularByWeekday( array $config ): array {
		$closed = array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) );
		$out    = array();
		for ( $weekday = 1; $weekday <= 7; $weekday++ ) {
			$out[ $weekday ] = in_array( $weekday, $closed, true ) ? array() : Render::merge( $config['weekly'][ $weekday ] ?? array() );
		}
		return $out;
	}

	private static function key( array $sessions ): string {
		return implode( ',', array_map( static fn( array $s ): string => $s['from'] . '-' . $s['to'], $sessions ) );
	}
}
