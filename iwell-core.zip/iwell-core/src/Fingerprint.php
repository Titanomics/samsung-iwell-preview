<?php
/**
 * 출력 지문 — 승인 지문을 "화면 결과"로(Task 6 수정 10, 대표 결정 2026-11-15).
 *
 * 수정 3~9 는 "블록이 무엇을 읽는지 예측해 입력을 해시"했고 매번 새 입력 경로가 나왔다(패턴·첨부·각주·작성자 변수·깊이·갤러리 동적 원천·FAQ 이미지,
 * Codex 재확인 6 N1 각주 안 짧은 코드·N2 패턴 덮어쓰기 문자열·N3 첨부 하위 크기 파일). 그래서 원장 승인 때 공개 화면의 결과(사람이 보는 것)를
 * 정규화해 지문으로 남기고(Seal 'out:*'), 보여 줄 때 다시 만들어 다르면 검토 기록을 내린다 — 어떤 경로로 바뀌든 결과가 바뀌면 잡힌다.
 *
 * 결정 1 렌더 대상(extract — 공개 단일 화면과 같은 전역 질의·같은 the_content 경로):
 *   out:body     페이지 본문 apply_filters('the_content') — 블록(각주·동기화 패턴·덮어쓰기)·짧은 코드 실행·wp_filter_content_tags(srcset) 결과
 *   out:title    템플릿 블록 iwell/page-title(자기 제목 — 본문에 H1 이 없을 때)
 *   out:sources  템플릿 블록 iwell/sources(검토 대상 메타 iwell_sources 를 그림 — page.html). 기준일을 따로 그리는 템플릿 블록은 없다(배지 안 — 가림).
 *   out:featured 대표 이미지 출력값(JSON-LD primaryImageOfPage ImageObject·og:image 가 쓰는 원본 주소·폭·높이 + 대체 글·캡션)
 *   SEO 실제 출력값은 Seal 'expand:*'(수정 8 결정 3 그대로). JSON-LD 의 나머지 검토 범위 노드는 같은 원천이 이미 지문 안이다 — MedicalWebPage
 *   name·citation(제목·iwell_sources)·DefinedTermSet(iwell_terms)·FAQPage 문답(FAQ 블록 속성 — 화면 문답과 같은 do_shortcode, out:body).
 *   검토 기록 필드(reviewedBy·lastReviewed)·날짜(datePublished·dateModified)·진료시간(openingHours)은 넣지 않는다.
 * 가림(MASKED — 코드 한 곳): 지문 렌더 때만 고정 토큰으로 바꾼다(실제 화면 렌더는 그대로). 시간에 따라 바뀌는 오늘 진료 바·진료시간 표, 검토 배지
 *   (자기 자신 — 지문이 검토 기록을 읽으면 순환). 본문 안 core/post-content(자기 본문을 다시 그림 — 워드프레스 재귀 방지 $seen_ids 가 호출 문맥에 따라
 *   빈 값을 내므로 토큰으로 고정; 그 내용은 out:body 자체다).
 * 정규화(normalize — 마크업 사소한 변화로 전체가 풀리지 않게): 보이는 글자(공백 정리, script·style 안 제외) + img 마다 src·srcset(수정 15: 후보 순서 그대로)·alt +
 *   a href + 영상·오디오·iframe·source·embed·track src(video poster, object data) + 표 칸 경계. 주소는 http/https 를 뗀다. 클래스·스타일(url() 밖)·래퍼 구조·
 *   nonce·data-·lazy·decoding·폭/높이 속성은 넣지 않는다.
 *   수정 16(수정 15 관찰 O-1~O-5 — 빼는 것도 합치는 정규화): 링크·그림·불러오기 목적지와 글의 뜻을 바꾸는 표시는 넣는다 — TRACK·ANY 표의 속성(area·map·
 *   form·input·button·iframe srcdoc·SVG href·base·meta refresh·link·background·style url()·colspan·rowspan·source media·type·sizes(맨 앞 auto 뗌)·
 *   ol 번호·MathML 구조 등, 있을 때만), MARKED 태그(del·s·strike·ins·q·bdo·bdi·dir 속성·MathML)는 글자 줄 안 표시 ⟪…⟫, BREAKS = 표준 UA 블록 요소 전부.
 *   수정 17(Codex 재확인 12 C12-1~6·O-6·O-7·NBSP): 구조는 WP_HTML_Processor(HTML 표준 트리 빌더 — 포기하면 원문 그대로), 공백은 CSS 공백 합침(lines — 문서
 *   공백 5자만, 인라인 줄 앞뒤 공백·링크 끝·표 구조·목록·sup·sub·상자·pre 원문 공백·form 소유를 넣는다), sizes 맨 앞 auto 는 lazy 그림에서 남긴다(승인 계산은
 *   그림 카운터 0 — fix), 우리 사이트 쿼리 인자가 min(max_input_vars, 64) 보다 많으면 정렬하지 않는다(sortable).
 *
 * 결정 2 관찰한 의존성: 지문 렌더 중 실제로 읽힌 첨부(OBSERVERS 필터 표)·렌더된 동기화 패턴(core/block ref)을 모은다. 승인(Seal::stamp) 때 페이지 메타
 *   DEP_KEY(행 하나 = 'a:{첨부 ID}'·'b:{패턴 ID}')로 남기고, Sources::pagesUsing 이 기존 해석기 결과 ∪ 이 목록으로 "승인 페이지가 쓰는 것"을 판정한다
 *   (직원·봇 403 — Roles, 관리자·cron 변경 lapse — PageMeta).
 *
 * 결정 3 캐시: (페이지 ID, 전역 콘텐츠 세대 값 GEN_OPTION) → 페이지 메타 CACHE_KEY. 세대 값은 글·첨부·메타·옵션·용어 쓰기·테마/플러그인 변경마다 오른다
 *   (BUMP_ON — 넓게 올려도 정확성에는 안전, 다시 계산할 뿐). 지문 자기 메타·검토 기록·수정본 메타·cron 옵션처럼 출력에 안 나오는 쓰기는 올리지 않는다.
 *   코드 배포(파일 복사)는 쓰기가 아니라서 세대가 안 오르므로 캐시는 워드프레스 판·CACHE_TTL 도 함께 본다.
 *
 * 수정 11(Codex 재확인 7 뒤 코디네이터 Ruling):
 *   C7-1 캐시 열쇠 = 세대 + 입력 값(inputs — 이 페이지·렌더가 관찰한/해석기가 찾은 첨부·패턴의 글 행과 메타를 DB 에서 직접 읽은 해시, 객체 캐시를 믿지 않는다).
 *        쓰기 훅 없는 직접 SQL(+ wp_cache_flush)로 그 값이 바뀌어도 바로 다음 출력이 다시 렌더한다. 열쇠에 못 넣는 워드프레스 밖 경로(파일 복사 배포·
 *        옵션 직접 SQL)는 CACHE_TTL(10분) 또는 재승인 필요 목록(ReviewAudit — 다름을 찾으면 forget() 으로 그 페이지 캐시를 지운다)이 상한이다.
 *   C7-2 렌더 감시(닫힌 쪽): 지문 렌더 중 짧은 코드가 실행되거나(pre_do_shortcode_tag — watchedShortcode) 허용 목록 밖 서버 렌더 블록이 그려지면
 *        (pre_render_block·render_block_data — noteRendered) 그 페이지는 검토 불가(of() 'unresolved' → Seal::unresolved·sealable). 원본 문자열 검사(Sources)가
 *        못 보는 각주 JSON·이스케이프한 패턴 덮어쓰기·플러그인이 렌더 때 덧붙인 것도 실제 렌더에서 잡힌다. 판정 규칙은 Sources::unsealableBlock·
 *        unsealableShortcode 한 곳(원본 검사와 같다).
 *
 * 수정 12(Codex 재확인 8 C8-1 뒤 코디네이터 Ruling 3 — 승인 지문 렌더 = 실제 공개 화면과 같은 문맥):
 *   extract() 는 본문 the_content 만 루프 밖에서 따로 그리던 것을 그만두고, 그 화면이 실제로 쓰는 블록 템플릿(Screen::template — template-loader 와 같은
 *   순서)을 실제 화면과 같은 메인 질의로 get_the_block_template_html() 로 그린다 — 워드프레스가 거기서 메인 루프를 연다(the_post: in_the_loop·
 *   is_main_query·is_singular·loop_start 가 실제와 같다). 공급 Rank Math HTML 사이트맵처럼 메인 루프 안에서만 본문을 바꾸는 필터도 승인 지문에 든다.
 *   지문 조각은 그 HTML 의 검토 범위 영역(Screen — 본문 core/post-content·제목 iwell/page-title·출처 iwell/sources, 가림 토큰)을 정규화한 것이고,
 *   공개 판정(LiveSeal)은 실제로 보낸 응답에서 같은 코드로 같은 영역을 잘라 이 지문과 비교한다. 관찰(첨부·패턴)·렌더 감시는 영역 안에서만 본다(머리·
 *   바닥글·메뉴 템플릿은 검토 범위 밖 — 수정 8 결정 4). 공개 화면은 이 캐시를 배지 결정에 쓰지 않는다(Ruling 4 — 템플릿 전 계산 warm 도 뗐다).
 */

namespace Iwell\Core;

use WP_Post;
use WP_Query;

defined( 'ABSPATH' ) || exit;

final class Fingerprint {
	/** 검토 범위 영역 안에서 고정 토큰으로 바꾸는 블록(결정 1 가림 — 목록은 여기 한 곳). 영역 안 core/post-content(자기 본문 재귀)도 토큰(Screen). */
	public const MASKED = array( 'iwell/today-bar', 'iwell/hours-table', 'iwell/review-badge' );

	/** 캐시(보호 내부 메타): {g: 세대, w: 워드프레스 판, t: 계산 시각, i: 입력 값 해시(수정 11), h: 조각 → 해시, a: 관찰 첨부, b: 관찰 패턴, u: 렌더 중 검토 불가 사유(수정 11)}. */
	public const CACHE_KEY = '_iwell_fp_cache';

	/** 승인 때 관찰한 의존성(보호 내부 메타, 여러 행): 'a:{첨부 ID}'·'b:{패턴 ID}' — 역방향 조회(그 첨부를 쓰는 승인 페이지)용. */
	public const DEP_KEY = '_iwell_seal_dep';

	/** 출력 지문 불일치로 검토 기록을 내린 기록(보호 내부 메타): {at: 'Y-m-d H:i:s' KST, parts: 바뀐 지문 조각}. 원장이 다시 승인하면 지운다. */
	public const LAPSE_KEY = '_iwell_seal_lapsed';

	/**
	 * 공개 응답이 승인 지문과 달랐다는 알림(수정 13 Ruling 3 — 보호 내부 메타, 덮어쓰는 한 줄): {t: 유닉스 시각, at: 'Y-m-d H:i:s' KST, parts: 다른 조각,
	 * url: 요청 경로 앞부분 + 쿼리 앞부분(LiveSeal::requestUrl — 쿠키·사용자·IP·브라우저 없음), n: 쓴 횟수}. 승인 때 빈 자리 {t: 0, n: 0} 를 만들어
	 * 공개 요청의 쓰기는 모두 비교-교체(noteLive)다 — 빈 자리가 없으면 쓰지 않는다(수정 14 C10-3). 검토 기록·지문 캐시와 상관없다(점검 화면 ReviewAudit 에만 보인다).
	 */
	public const LIVE_KEY = '_iwell_live_note';

	/** 공개 차이 알림 쓰기 묶음(초) — 페이지당 이 시간에 한 번(창 안에서는 조각·주소가 달라도 건너뜀: 익명 요청이 몰리거나 번갈아 와도 쓰기가 늘지 않게). */
	public const LIVE_EVERY = 10 * MINUTE_IN_SECONDS;

	/** 전역 콘텐츠 세대 값(옵션). */
	public const GEN_OPTION = 'iwell_content_gen';

	/**
	 * 캐시 열쇠(세대·입력 값)에 못 넣는 워드프레스 밖 변화(파일 복사 배포·옵션 직접 SQL)의 상한(초) — 그보다 오래된 캐시는 다시 계산한다(수정 11: 1시간 → 10분).
	 * 그 전에 바로 반영하려면 재승인 필요 목록(ReviewAudit)을 연다 — 다름을 찾은 페이지는 캐시를 지워 다음 출력에서 해제된다.
	 */
	public const CACHE_TTL = 10 * MINUTE_IN_SECONDS;

	/** 세대를 올리지 않는 메타(출력에 안 나오는 값 — 지문 자기 메타·검토 기록·편집 잠금). */
	private const QUIET_META = array( self::CACHE_KEY, self::DEP_KEY, self::LAPSE_KEY, self::LIVE_KEY, Seal::KEY, PageMeta::PENDING_KEY, 'iwell_reviewed_by', 'iwell_reviewed_at', '_edit_lock', '_edit_last' );

	/** kses_init_filters() 가 거는 필터 = kses_remove_filters() 가 떼는 것(훅·함수·우선순위 — WP 7.1 wp-includes/kses.php). 고정 문맥이 사용자를 바꾸면 코어가 kses_init 을 부른다. */
	private const KSES_FILTERS = array(
		array( 'title_save_pre', 'wp_filter_kses', 10 ),
		array( 'pre_comment_content', 'wp_filter_post_kses', 10 ),
		array( 'pre_comment_content', 'wp_filter_kses', 10 ),
		array( 'content_save_pre', 'wp_filter_global_styles_post', 9 ),
		array( 'content_filtered_save_pre', 'wp_filter_global_styles_post', 9 ),
		array( 'content_save_pre', 'wp_filter_post_kses', 10 ),
		array( 'excerpt_save_pre', 'wp_filter_post_kses', 10 ),
		array( 'content_filtered_save_pre', 'wp_filter_post_kses', 10 ),
	);

	/** 세대를 올리지 않는 옵션(출력에 안 나오는 값). */
	private const QUIET_OPTIONS = array( self::GEN_OPTION, 'cron', '_transient_doing_cron', '_transient_timeout_doing_cron' );

	/**
	 * 결정 2 관찰 필터(지문 렌더 중에만 건다) — 필터 → 첨부 ID 인자 위치(0부터).
	 *   get_post_metadata               첨부 글의 메타 읽기 전부(대체 글·크기 메타·파일 — get_post_meta 를 거치는 모든 읽기)
	 *   wp_get_attachment_metadata      크기 메타(srcset·하위 크기 파일)
	 *   wp_get_attachment_image_src     그릴 크기의 주소·폭·높이
	 *   wp_calculate_image_srcset       srcset 계산(wp_filter_content_tags·wp_get_attachment_image)
	 *   wp_get_attachment_caption       캡션(갤러리·이미지 블록 캡션 옵션)
	 *   wp_get_attachment_url           원본 주소
	 *   get_attached_file               파일 경로
	 *   wp_get_attachment_image_attributes  img 속성(WP_Post 인자)
	 */
	private const OBSERVERS = array(
		'get_post_metadata'                  => 1,
		'wp_get_attachment_metadata'         => 1,
		'wp_get_attachment_image_src'        => 1,
		'wp_calculate_image_srcset'          => 4,
		'wp_get_attachment_caption'          => 1,
		'wp_get_attachment_url'              => 1,
		'get_attached_file'                  => 1,
		'wp_get_attachment_image_attributes' => 1,
	);

	/**
	 * 블록 경계(글자 사이 공백) — 정규화. 수정 16 Ruling 3(O-1): HTML 표준 렌더링 절(UA 스타일시트, html.spec.whatwg.org/multipage/rendering.html)에서
	 * display 가 inline 이 아닌 요소를 모두 — 15.3.2 html·body / 15.3.3 address·blockquote·center·dialog·div·figure·figcaption·footer·form·header·hr·
	 * legend·listing·main·p·plaintext·pre·search·xmp / 15.3.6 article·aside·h1~h6(:heading)·hgroup·nav·section / 15.3.7 dir·dd·dl·dt·menu·ol·ul·li /
	 * 15.3.8 table·caption·colgroup·col·thead·tbody·tfoot·tr·td·th / 15.3.10 input·button(inline-block) / 15.3.12 fieldset / 15.5.5 details·summary /
	 * 15.5.13 marquee·15.5.14 meter·15.5.15 progress(inline-block) / 15.5.16 select(inline-block)·option·optgroup(block) / 위젯 textarea(inline-block).
	 * display:none 요소(15.3.1 area·base·link·meta·script·style·template·title 등)는 넣지 않는다 — 화면에서 붙어 있는 글자를 떼면 안 된다.
	 * BR 은 수정 10 그대로. ruby·rt(display ruby·ruby-text)는 판정만(넣지 않음).
	 * 수정 17: 블록 경계는 앞뒤 공백을 지우고 공백 하나(수정 10 형식 — 글자만 있는 옛 승인 그대로). SUP·SUB(Ruling 3 — 인라인, 표시 ⟪sup⟫)와 인라인 블록
	 * input·button·select·textarea·meter·progress·marquee(Ruling 7 — 바깥 공백이 화면에 남는다, 상자 표시 BOXES)는 뺐다: 블록 경계로 두면 앞뒤 공백 유무가 합쳐진다.
	 */
	private const BREAKS = array(
		'HTML', 'BODY',
		'ADDRESS', 'BLOCKQUOTE', 'CENTER', 'DIALOG', 'DIV', 'FIGURE', 'FIGCAPTION', 'FOOTER', 'FORM', 'HEADER', 'HR', 'LEGEND', 'LISTING', 'MAIN', 'P', 'PLAINTEXT', 'PRE', 'SEARCH', 'XMP',
		'ARTICLE', 'ASIDE', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'HGROUP', 'NAV', 'SECTION',
		'DIR', 'DD', 'DL', 'DT', 'MENU', 'OL', 'UL', 'LI',
		'TABLE', 'CAPTION', 'COLGROUP', 'COL', 'THEAD', 'TBODY', 'TFOOT', 'TR', 'TD', 'TH',
		'FIELDSET', 'DETAILS', 'SUMMARY', 'OPTION', 'OPTGROUP',
		'BR',
	);

	/**
	 * 인라인 블록·대체 요소 상자(수정 17 Ruling 7 — 표준 UA display inline-block·대체 요소): 상자는 글자 하나처럼 보여 바깥 공백이 따로 남고(a <button></button> b ≠
	 * a <button></button>b), 안은 새 줄처럼 앞뒤 공백이 없다. 모두 MARKED(여닫음 표시 — 상자가 있다는 것, 안 글자의 범위).
	 */
	private const BOXES = array( 'INPUT', 'BUTTON', 'SELECT', 'TEXTAREA', 'METER', 'PROGRESS', 'MARQUEE', 'SVG', 'CANVAS' );

	/**
	 * UA 가 생성 글자를 그리는 인라인 요소(수정 17 — 차분 퍼징 자가 점검): q 는 ::before·::after 로 여닫는 따옴표를 그린다 → 그 표시는 글자 하나처럼(안 끝 공백은
	 * 닫는 따옴표 앞이라 그려진다 — “A ” ≠ “A”, 공백이 표시를 넘어 합쳐지지 않는다).
	 */
	private const GLYPHS = array( 'Q' );

	/** 원문 공백 문맥(수정 17 Ruling 4 — UA white-space: pre): 이 요소 안(자손 포함) 글자의 공백·줄바꿈·탭은 그대로. xmp·textarea 는 원문 글자 토큰, plaintext 는 해석기가 포기(원문 그대로). */
	private const PRE = array( 'PRE', 'LISTING' );

	/** 글자 줄 안 표시의 여닫는 글자(수정 16 Ruling 4 — ⟪태그 속성=값⟫·⟪/태그⟫). 글자에 나오면 두 번 쓴다(⟪⟪·⟫⟫ — esc). */
	private const OPEN  = "\u{27EA}";
	private const CLOSE = "\u{27EB}";

	/**
	 * 늘 표시하는 태그(수정 16): 글의 뜻을 바꾸는 글자 표시(del·s·strike 지워진 값, ins, q — UA 가 따옴표를 그린다, bdo·bdi 글자 방향 — Ruling 4)와
	 * 태그가 있는 것만으로 목적지·화면이 생기는 것(area 지도 링크·map 지도·form 보내기·input·button 입력·<image> — HTML 은 img 로 그린다, Ruling 1·6).
	 * MathML(WP 7.1 KSES 허용 요소 전부 — Ruling 6 전수표): 분수·첨자·근호·표 구조가 뜻이다(<mfrac>1 2</mfrac> = ½, <mrow>1 2</mrow> = 12) → 모든 요소의
	 * 여닫음을 표시(토큰 요소 mi·mn·mo·mtext 경계 = 분자·분모 경계도).
	 * 수정 17: 표시는 해석기(WP_HTML_Processor)가 정한 요소 단위 — 표시를 낸 요소는 그 요소가 실제로 닫히는 자리(암묵 닫힘 포함)에 ⟪/태그⟫(수정 16 의 "태그
	 * 이름 단위 이후 모두" 대신 — 범위가 정확하다). 더한 것: sup·sub(Ruling 3), 목록 ol·ul·menu·dir·li(Ruling 5 — UA 가 그리는 번호·글머리), 표 구조
	 * table·caption·thead·tbody·tfoot(Ruling 8 — 표 끝·칸 밖 글자·tfoot 은 아래에 그려진다), 상자(BOXES — select·option·optgroup·textarea·meter·progress·
	 * marquee·svg·canvas: 상자가 있다는 것과 안 글자의 범위). 링크(a href)의 끝은 링크 줄의 짝 ⟪/a⟫.
	 */
	private const MARKED = array(
		'DEL', 'S', 'STRIKE', 'INS', 'Q', 'BDO', 'BDI', 'AREA', 'MAP', 'FORM', 'INPUT', 'BUTTON', 'IMAGE',
		'SUP', 'SUB', 'OL', 'UL', 'MENU', 'DIR', 'LI', 'TABLE', 'CAPTION', 'THEAD', 'TBODY', 'TFOOT',
		'SELECT', 'OPTION', 'OPTGROUP', 'TEXTAREA', 'METER', 'PROGRESS', 'MARQUEE', 'SVG', 'CANVAS',
		'MATH', 'ANNOTATION', 'MENCLOSE', 'MERROR', 'MFRAC', 'MI', 'MMULTISCRIPTS', 'MN', 'MO', 'MOVER', 'MPADDED', 'MPHANTOM', 'MPRESCRIPTS', 'MROOT', 'MROW', 'MS',
		'MSPACE', 'MSQRT', 'MSTYLE', 'MSUB', 'MSUBSUP', 'MSUP', 'MTABLE', 'MTD', 'MTEXT', 'MTR', 'MUNDER', 'MUNDEROVER', 'SEMANTICS',
	);

	/**
	 * 태그별로 더 넣는 속성(수정 16 — 있을 때만): 이름 → 종류(url 주소 정규화 · srcset · sizes 맨 앞 auto 만 뗌 · trim 앞뒤 HTML 공백만 · raw 값 그대로 ·
	 * bool 있음 · alt 공백 정리 · css style 안 url()). 근거·판정은 수정 16 보고서 §2 전수표(KSES 허용 태그 × 속성 + HTML 표준 주소 속성).
	 * 열거 값(shape·method·type·dir 등)은 공백도 뜻을 바꿔(" post " 는 GET) 값 그대로. 줄이 있는 태그(img·a·영상 등·표 칸)는 줄 다음 칸 줄(탭 + 이름=값),
	 * 나머지는 글자 줄 안 표시(⟪태그 이름=값⟫ — 값은 공백·%·⟪⟫ 를 %XX).
	 */
	private const TRACK = array(
		'IMG'      => array( 'usemap' => 'raw', 'ismap' => 'bool', 'sizes' => 'sizes' ),
		'IMAGE'    => array( 'src' => 'url', 'srcset' => 'srcset', 'alt' => 'alt', 'sizes' => 'sizes', 'usemap' => 'raw', 'ismap' => 'bool' ),
		// 수정 17 Ruling 6(C12-6): 폼에 딸린 요소의 form(소유 폼 id — 값 그대로: id 는 정확히 같아야 맞는다)과 form 의 id.
		'OBJECT'   => array( 'usemap' => 'raw', 'type' => 'trim', 'form' => 'raw' ),
		'FIELDSET' => array( 'form' => 'raw' ),
		'OUTPUT'   => array( 'form' => 'raw' ),
		'EMBED'    => array( 'type' => 'trim' ),
		'SOURCE'   => array( 'media' => 'trim', 'type' => 'trim', 'sizes' => 'sizes' ),
		'TRACK'    => array( 'kind' => 'raw', 'srclang' => 'raw', 'label' => 'raw', 'default' => 'bool' ),
		'IFRAME'   => array( 'srcdoc' => 'raw' ),
		'TD'       => array( 'colspan' => 'raw', 'rowspan' => 'raw' ),
		'TH'       => array( 'colspan' => 'raw', 'rowspan' => 'raw' ),
		'AREA'     => array( 'href' => 'url', 'shape' => 'raw', 'coords' => 'trim', 'alt' => 'alt', 'nohref' => 'bool' ),
		'MAP'      => array( 'name' => 'raw', 'id' => 'raw' ),
		// 폼: 보내는 곳·방법과 보내는 값(GET 이면 이름=값이 보내기 주소의 쿼리 — 목적지의 일부).
		'FORM'     => array( 'action' => 'url', 'method' => 'raw', 'enctype' => 'raw', 'accept-charset' => 'raw', 'id' => 'raw' ),
		'BUTTON'   => array( 'type' => 'raw', 'formaction' => 'url', 'formmethod' => 'raw', 'name' => 'raw', 'value' => 'raw', 'form' => 'raw' ),
		'INPUT'    => array( 'type' => 'raw', 'src' => 'url', 'alt' => 'alt', 'formaction' => 'url', 'formmethod' => 'raw', 'name' => 'raw', 'value' => 'raw', 'placeholder' => 'raw', 'checked' => 'bool', 'form' => 'raw' ),
		'TEXTAREA' => array( 'name' => 'raw', 'placeholder' => 'raw', 'form' => 'raw' ),
		'SELECT'   => array( 'name' => 'raw', 'form' => 'raw' ),
		'OPTION'   => array( 'label' => 'raw', 'value' => 'raw', 'selected' => 'bool' ),
		'OPTGROUP' => array( 'label' => 'raw' ),
		'OL'       => array( 'start' => 'raw', 'reversed' => 'bool', 'type' => 'raw' ),
		'LI'       => array( 'value' => 'raw', 'type' => 'raw' ),
		'LINK'     => array( 'rel' => 'raw', 'media' => 'trim' ),
		'META'     => array( 'http-equiv' => 'raw', 'content' => 'trim' ),
		// 그림으로 보이는 수치(막대가 채워지는 정도).
		'METER'    => array( 'value' => 'raw', 'min' => 'raw', 'max' => 'raw', 'low' => 'raw', 'high' => 'raw', 'optimum' => 'raw' ),
		'PROGRESS' => array( 'value' => 'raw', 'max' => 'raw' ),
		// MathML: 표 칸 병합(O-2 와 같은 형태)·둘러싸기 표기(취소선 updiagonalstrike — O-5 와 같은 형태)·분수 막대(0 이면 이항 계수)·글자 변형(ℝ)·블록 표시.
		'MTD'      => array( 'columnspan' => 'raw', 'rowspan' => 'raw' ),
		'MENCLOSE' => array( 'notation' => 'raw' ),
		'MFRAC'    => array( 'linethickness' => 'raw' ),
		'MI'       => array( 'mathvariant' => 'raw' ),
		'MATH'     => array( 'display' => 'raw' ),
	);

	/**
	 * 모든 태그에 더 넣는 속성(위 표에 같은 이름이 없으면 — 수정 16): href·xlink:href(base·link·SVG a·image·use·feImage·textPath 등·MathML — 목적지·그림),
	 * 옛 background 속성(배경 그림), style 안 url()(배경 그림 — 다른 선언은 넣지 않는다)과 SVG 표현 속성 안 url(), dir(글자 방향 — 늘 글자 줄 안 표시).
	 */
	private const ANY = array(
		'href'         => 'url',
		'xlink:href'   => 'url',
		'background'   => 'url',
		'style'        => 'css',
		// SVG 표현 속성(CSS 선언과 같은 값 — url() 이 있을 때만, Ruling 6: style url() 과 같은 규칙).
		'fill'         => 'css',
		'stroke'       => 'css',
		'filter'       => 'css',
		'clip-path'    => 'css',
		'mask'         => 'css',
		'marker-start' => 'css',
		'marker-mid'   => 'css',
		'marker-end'   => 'css',
		'cursor'       => 'css',
		'dir'          => 'raw',
	);

	/** 주소를 가진 미디어 태그 → 속성(정규화). */
	private const MEDIA = array(
		'IFRAME' => array( 'src' ),
		'VIDEO'  => array( 'src', 'poster' ),
		'AUDIO'  => array( 'src' ),
		'SOURCE' => array( 'src', 'srcset' ),
		'EMBED'  => array( 'src' ),
		'TRACK'  => array( 'src' ),
		'OBJECT' => array( 'data' ),
	);

	/** 정규화 추출물의 태그 줄 머리말(img·a·MEDIA 이름 소문자 + 공백, 표 칸 |, 표 줄 /) — 같은 말로 시작하는 글자 줄은 앞에 \ (수정 15 Ruling 3, textLine). */
	private const LINES = array( 'img', 'a', 'iframe', 'video', 'audio', 'source', 'embed', 'track', 'object', '|', '/' );

	/** 세대를 올리는 쓰기 훅(결정 3). */
	private const BUMP_ON = array(
		'save_post',
		'deleted_post',
		'clean_post_cache',
		'add_attachment',
		'edit_attachment',
		'delete_attachment',
		'attachment_updated',
		'created_term',
		'edited_term',
		'delete_term',
		'set_object_terms',
		'switch_theme',
		'activated_plugin',
		'deactivated_plugin',
		'upgrader_process_complete',
		'_core_updated_successfully',
		'customize_save_after',
		'profile_update',
		'wp_update_nav_menu',
	);

	private static int $busy = 0;

	/** @var array{a: array<int, true>, b: array<int, true>, u: array<string, true>}|null 진행 중인 관찰(u = 렌더 중 검토 불가 사유 — 수정 11 C7-2). */
	private static ?array $observing = null;

	/** 관찰·감시 필터를 건 횟수(승인 렌더와 공개 응답이 겹쳐도 바깥이 끝날 때까지 떼지 않는다 — 수정 12). */
	private static int $hooked = 0;

	/** 영역 밖에서도 첨부 읽기를 관찰한다(대표 이미지 출력값 featured() — 수정 12). */
	private static bool $observeAll = false;

	/** @var array<int, array{0: string, 1: array}> 요청 안 기억 — 글 ID → [세대, 결과]. */
	private static array $memo = array();

	private static ?string $gen = null;

	/** 캐시를 건너뛰고 새로 렌더한다(ReviewAudit — 코드 배포 뒤에도 정확하게). */
	private static bool $fresh = false;

	/** @var list<\Closure(): void> 걸려 있는 승인 계산 고정 문맥의 되돌림(안쪽이 끝 — 수정 14: finally 를 못 거친 치명 종료·exit 는 shutdown 맨 앞 recover()). */
	private static array $undo = array();

	/** @var array{0: array<string, true>, 1: array<string, true>}|null 이 요청이 가져온 $_GET·$_POST 키(수정 14 A+ — arrive: iwell-core 적재 때). */
	private static ?array $given = null;

	/** @var array{0: array<string, mixed>, 1: array<string, mixed>, 2: array<string, mixed>} 고정 렌더 안에서 코드가 새로 넣은 $_GET·$_POST·$_REQUEST 키 → 값(이 요청 동안 — 수정 14 A+). */
	private static array $learned = array( array(), array(), array() );

	public static function register(): void {
		self::arrive(); // 수정 14 A+: 적재 때(플러그인 이름 순 — KBoard 보다 먼저) 이 요청이 가져온 키를 찍는다.
		add_action( 'shutdown', array( self::class, 'recover' ), PHP_INT_MIN ); // 수정 14 C10-2: 다른 shutdown 동작(출력 버퍼·알림·세션 저장)보다 먼저.
		foreach ( self::BUMP_ON as $hook ) {
			add_action( $hook, array( self::class, 'bump' ), 1, 0 );
		}
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'bumpOnMeta' ), 1, 3 );
		}
		foreach ( array( 'added_option', 'updated_option', 'deleted_option' ) as $hook ) {
			add_action( $hook, array( self::class, 'bumpOnOption' ), 1, 1 );
		}
		add_filter( 'wp_update_attachment_metadata', array( self::class, 'bumpPassing' ), 1 );
		// 수정 12: 공개 화면은 지문을 계산하지 않는다(실제 응답으로 판정 — LiveSeal). 수정 10 의 template_redirect 미리 계산(warm)은 뗐다.
	}

	/** 지문 렌더 중인가(그 안에서는 검토 기록 확인·lapse 를 하지 않는다 — PageMeta::verifiedReview). */
	public static function busy(): bool {
		return self::$busy > 0;
	}

	// ── 결정 3 세대 값 ─────────────────────────────────────────────────────

	public static function generation(): string {
		if ( null === self::$gen ) {
			self::$gen = (string) get_option( self::GEN_OPTION, '0' );
		}
		return self::$gen;
	}

	/** 세대를 올린다(값은 겹치지 않는 새 토큰 — 동시 요청의 읽기·쓰기 경쟁에서도 옛 캐시가 맞지 않게). */
	public static function bump(): void {
		self::$gen  = uniqid( '', true ) . wp_rand( 0, 9999 );
		self::$memo = array();
		update_option( self::GEN_OPTION, self::$gen, true );
		Seal::flush();
	}

	/** @param mixed $value */
	public static function bumpPassing( $value ) {
		self::bump();
		return $value;
	}

	/** @param int|int[] $meta_id */
	public static function bumpOnMeta( $meta_id, $object_id, $meta_key ): void {
		if ( in_array( (string) $meta_key, self::QUIET_META, true ) || ( (int) $object_id > 0 && 'revision' === get_post_type( (int) $object_id ) ) ) {
			return;
		}
		self::bump();
	}

	public static function bumpOnOption( $option ): void {
		if ( in_array( (string) $option, self::QUIET_OPTIONS, true ) ) {
			return;
		}
		self::bump();
	}

	// ── 결정 1 출력 지문 ─────────────────────────────────────────────────

	/**
	 * 이 글의 출력 지문 조각·관찰한 의존성·렌더 중 검토 불가 사유(캐시 — 같은 세대·같은 입력 값·같은 워드프레스 판·CACHE_TTL 안이면 다시 렌더하지 않는다).
	 *
	 * @return array{parts: array<string, string>, attachments: int[], blocks: int[], unresolved: string[]}
	 */
	public static function of( WP_Post $post ): array {
		$gen = self::generation();
		if ( ! self::$fresh && isset( self::$memo[ $post->ID ] ) && self::$memo[ $post->ID ][0] === $gen ) {
			return self::$memo[ $post->ID ][1];
		}
		$version = (string) get_bloginfo( 'version' );
		$cached  = self::$fresh ? null : get_post_meta( $post->ID, self::CACHE_KEY, true );
		$result  = null;
		if ( is_array( $cached ) && $gen === ( $cached['g'] ?? null ) && $version === ( $cached['w'] ?? null ) && time() - (int) ( $cached['t'] ?? 0 ) < self::CACHE_TTL
			&& is_array( $cached['h'] ?? null ) && is_array( $cached['a'] ?? null ) && is_array( $cached['b'] ?? null ) && is_array( $cached['u'] ?? null ) && is_string( $cached['i'] ?? null )
			&& hash_equals( $cached['i'], self::inputs( $post, $cached['a'], $cached['b'] ) ) ) {
			// 입력 값(C7-1)까지 같을 때만 — 쓰기 훅 없이 DB 가 바뀌었으면(직접 SQL) 세대가 같아도 다시 렌더한다.
			$result = array(
				'parts'       => $cached['h'],
				'attachments' => array_map( 'intval', $cached['a'] ),
				'blocks'      => array_map( 'intval', $cached['b'] ),
				'unresolved'  => array_map( 'strval', $cached['u'] ),
			);
		}
		if ( null === $result ) {
			$extract = self::extract( $post );
			$result  = array(
				'parts'       => array_map( array( self::class, 'digest' ), $extract['texts'] ),
				'attachments' => $extract['attachments'],
				'blocks'      => $extract['blocks'],
				'unresolved'  => $extract['unresolved'],
			);
			if ( ! self::$fresh && $gen === self::generation() && PageMeta::trusted( $post->ID ) ) {
				// 렌더 중 쓰기가 있었으면(세대가 바뀜) 남기지 않는다 — 그 결과는 이미 옛 세대다. 수정 14 C10-2: 권한 있는 요청(edit_post·cron·WP-CLI)만 쓴다 —
				// 익명·편집 권한 없는 요청의 계산 결과가 캐시를 거쳐 원장·직원 편집 패널의 해제로 이어지지 않게(요청 안 기억은 그대로).
				update_metadata(
					'post',
					$post->ID,
					self::CACHE_KEY,
					array(
						'g' => $gen,
						'w' => $version,
						't' => time(),
						'i' => self::inputs( $post, $result['attachments'], $result['blocks'] ),
						'h' => $result['parts'],
						'a' => $result['attachments'],
						'b' => $result['blocks'],
						'u' => $result['unresolved'],
					)
				);
			}
		}
		if ( ! self::$fresh ) {
			self::$memo[ $post->ID ] = array( $gen, $result );
		}
		return $result;
	}

	/**
	 * 캐시 열쇠의 입력 값(수정 11 C7-1): 이 글 + 렌더가 관찰한 첨부·패턴 + 해석기(Sources)가 찾은 첨부·패턴의 글 행(posts 전체 열)과 메타(postmeta —
	 * 출력에 안 나오는 QUIET_META 는 뺀다: 지문 자기 메타·검토 기록·편집 잠금)를 DB 에서 직접 읽어 해시한다. 객체 캐시를 거치지 않는다(직접 SQL 뒤 캐시를
	 * 비우거나 오래된 객체 캐시가 남아도 DB 값으로). 쿼리 2번(글 행·메타).
	 */
	private static function inputs( WP_Post $post, array $attachments, array $blocks ): string {
		global $wpdb;
		$deps = Sources::of( $post );
		$ids  = array_values( array_unique( array_filter( array_map( 'intval', array_merge( array( $post->ID ), $attachments, $blocks, $deps['attachments'], $deps['blocks'] ) ), static fn( int $id ): bool => $id > 0 ) ) );
		sort( $ids );
		$in    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$quiet = implode( ',', array_fill( 0, count( self::QUIET_META ), '%s' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 캐시 열쇠: 객체 캐시를 믿지 않고 DB 값(자리표시자 수를 맞춤).
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->posts} WHERE ID IN ($in) ORDER BY ID", ...$ids ), ARRAY_N );
		$meta = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id IN ($in) AND meta_key NOT IN ($quiet) ORDER BY post_id, meta_key, meta_id", ...$ids, ...self::QUIET_META ), ARRAY_N );
		// phpcs:enable
		return substr( hash( 'sha256', serialize( array( $ids, $rows, $meta ) ) ), 0, 32 ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- 비교용(되돌려 읽지 않음).
	}

	/**
	 * 이 글의 저장된 지문 캐시와 요청 안 기억을 버린다(수정 11 C7-1 ② — 재승인 필요 목록이 다름을 찾은 페이지: 다음 출력이 새로 렌더해 그 자리에서 해제한다).
	 * 검토 기록·승인 지문·관찰 목록은 그대로(지문 자기 메타라 세대도 오르지 않는다).
	 */
	public static function forget( int $post_id ): void {
		unset( self::$memo[ $post_id ] );
		delete_metadata( 'post', $post_id, self::CACHE_KEY );
		Seal::flush();
	}

	/** 캐시 없이 $fn 을 실행한다(ReviewAudit). */
	public static function freshly( callable $fn ): mixed {
		$was         = self::$fresh;
		self::$fresh = true;
		Seal::flush(); // 지문 조각 기억도 새로(캐시로 계산한 조각이 남지 않게).
		try {
			return $fn();
		} finally {
			self::$fresh = $was;
			Seal::flush();
		}
	}

	/** 지문 조각 해시(정규화 추출물 → sha256 앞 20자) — 승인 지문(of)과 공개 판정(LiveSeal)이 같은 함수. */
	public static function digest( string $text ): string {
		return substr( hash( 'sha256', $text ), 0, 20 );
	}

	/**
	 * 공개 결과를 렌더해 정규화 추출물과 관찰한 의존성·렌더 중 검토 불가 사유를 만든다(수정 12 — 실제 공개 화면과 같은 문맥: 그 화면의 블록 템플릿을
	 * 메인 질의로 그리면 워드프레스가 메인 루프를 연다. 질의는 실행하지 않고 단일 화면 상태만 — 초안·수정안도 같게. 전역은 끝나면 되돌린다).
	 * 수정 13 Ruling 2: 고정 문맥(fixed — 익명·요청 인자·쿠키 없음·주소 = 그 페이지 경로)에서 그린다 — 누가 어떤 요청으로 부르든 같은 승인 계산.
	 *
	 * @return array{texts: array<string, string>, attachments: int[], blocks: int[], unresolved: string[]}
	 */
	public static function extract( WP_Post $post ): array {
		return self::fixed( $post, static fn(): array => self::render( $post ) );
	}

	/**
	 * 승인 계산 고정 문맥(수정 13 Ruling 2 — Codex 재확인 9 C9-1): 렌더하는 동안만 익명(사용자 0) · $_GET·$_POST·$_REQUEST·$_COOKIE 빈 값 · REQUEST_URI =
	 * 그 페이지 주소 경로(쿼리 없음)·QUERY_STRING 빈 값. 원장 승인·편집 패널(?context=edit&_locale=user)·익명 REST(?x=y)·getHead·cron·점검 어디서 부르든
	 * 같은 결과라서, 방문자가 고른 요청 문맥(로그인 여부·추적 인자·쿠키)이 저장된 원장 승인을 지우지 못한다. 끝나면(예외여도) 현재 사용자(같은 객체)·요청 값·
	 * kses 필터 상태를 들어오기 전 그대로 되돌린다(사용자 전환이 kses_init 을 부른다 — Task 9 수정 1 C04 와 같은 방식: 사용자 기준으로 새로 정하지 않는다).
	 * 요청 종류(REST_REQUEST 상수 — 정의되면 되돌릴 수 없다)는 고정하지 못한다(알려진 한계, 수정 13 보고서).
	 *
	 * 수정 14(Codex 재확인 10 C10-2 — Ruling 2·4): 요청 환경도 고정한다 — HTTP_USER_AGENT 빈 값·HTTP_SEC_CH_UA* 키 없음(wp_is_mobile — KBoard 모바일 쪽 수
	 * index.php:899·993·1119·1292)·열린 세션 $_SESSION 빈 배열(KBoard 정렬 기억 KBContentList.class.php:1499). 원장·직원이 휴대폰으로 편집 패널을 열어도
	 * 같은 결과. 공개되지 않은 페이지(Task 9 허브 자동 비공개)의 제목 접두어 private_title_format = '%s'(승인 지문 = 게시 화면 — 비밀번호 페이지의
	 * protected_title_format 은 방문자에게도 보이므로 그대로). 되돌림은 키 유무까지(같은 방식). 치명 종료·exit 로 finally 를 거치지 못하면 shutdown 맨 앞
	 * (recover — PHP_INT_MIN)에서 아직 걸려 있는 고정 문맥을 되돌린다(다른 shutdown 동작·PHP 세션 저장이 고정 문맥 값으로 돌지 않게).
	 *
	 * 수정 14 A+(코디네이터 판단 — KBoard kboard_mod 요청 첫 호출 static): 요청 값은 빈 배열이 아니라 끈끈한 키(sticky — 이 요청이 가져오지 않았는데 코드가 넣은 키)만
	 * 두고 시작한다. 그래서 한 요청 안 몇 번째 고정 렌더든, 첫 호출이 바깥 본문(편집 패널 content.rendered)이든 고정 렌더 안이든 같은 결과. 끝나면 바깥 요청 값은
	 * 지금처럼 키 유무까지 정확히 되돌린다(고정 렌더 안에서 넣은 키는 바깥에 새어 나가지 않고 다음 고정 렌더만 배운다 — learn).
	 *
	 * 수정 17 Ruling 2(코디네이터 승인 A): 워드프레스 그림 카운터(wp_increase_content_media_count — 요청 단위 정적 값, wp_get_loading_optimization_attributes 가
	 * 메인 루프 그림의 lazy 여부를 정한다: 카운터가 기준 wp_omit_loading_attr_threshold 보다 작으면 eager, 아니면 lazy + wp_img_tag_add_auto_sizes 의 sizes "auto,")
	 * 도 고정한다 — 렌더 동안 0(= 새 요청의 첫 공개 응답), 끝나면(예외·shutdown 맨 앞 recover·겹친 렌더도) 들어오기 전 값. 같은 게시 요청의 두 번째 승인 계산·
	 * 점검 화면·WP-CLI 처럼 한 요청에서 여러 번 그려도 그림 loading·sizes 가 공개 응답과 같다(실측 — 수정 17 보고서 §3).
	 * 수정 17(코디네이터 승인 — 조건 2 실측에서 찾음): 같은 함수가 관리 화면(is_admin() 참 — current_screen·WP_ADMIN, 점검 화면·admin-ajax 빠른 편집 저장)에서는
	 * 메인 루프 그림을 늘 lazy 로 그린다. 그래서 is_admin() 이 참이면 렌더 동안만 화면을 앞 화면 WP_Screen::get('front')(워드프레스가 in_admin 거짓으로 만든다)으로
	 * 두고 끝나면 원래 값(키 유무·null·같은 객체). 렌더 안 get_current_screen() 은 front — 관리 화면 전용 동작을 하는 the_content 필터도 공개와 같게 돈다(의도).
	 *
	 * @template T
	 * @param callable(): T $fn
	 * @return T
	 */
	private static function fixed( WP_Post $post, callable $fn ): mixed {
		$undo = self::fix( $post );
		try {
			return $fn();
		} finally {
			self::unfix( $undo );
		}
	}

	/** 고정 문맥을 걸고 되돌림(한 번만 돈다)을 쌓아 돌려준다. */
	private static function fix( WP_Post $post ): \Closure {
		$user    = wp_get_current_user();
		$kses    = self::ksesState();
		$request = array( $_GET, $_POST, $_REQUEST, $_COOKIE ); // phpcs:ignore WordPress.Security.NonceVerification -- 되돌릴 값(읽기만).
		$server  = array();
		foreach ( array_merge( array( 'REQUEST_URI', 'QUERY_STRING', 'HTTP_USER_AGENT' ), self::clientHints() ) as $key ) {
			$server[ $key ] = array( array_key_exists( $key, $_SERVER ), $_SERVER[ $key ] ?? null );
		}
		$session = isset( $_SESSION ) && is_array( $_SESSION ) ? array( $_SESSION ) : null; // 세션이 열려 있을 때만(값을 담아 둔다).
		$title   = false === has_filter( 'private_title_format', array( self::class, 'plainTitle' ) ); // 겹친 고정 문맥 — 바깥이 건 것은 안쪽이 떼지 않는다.
		$path    = wp_parse_url( (string) get_permalink( $post ), PHP_URL_PATH );
		$sticky  = self::sticky();
		$media   = function_exists( 'wp_increase_content_media_count' ) ? (int) wp_increase_content_media_count( 0 ) : null;
		$screen  = is_admin() && class_exists( 'WP_Screen' ) ? array( array_key_exists( 'current_screen', $GLOBALS ), $GLOBALS['current_screen'] ?? null ) : null; // 수정 17: 관리 화면 문맥일 때만.
		$done    = false;
		$undo    = static function () use ( $user, $kses, $request, $server, $session, $title, $sticky, $media, $screen, &$done ): void {
			if ( $done ) {
				return;
			}
			$done = true;
			if ( null !== $media ) {
				wp_increase_content_media_count( $media - (int) wp_increase_content_media_count( 0 ) ); // 수정 17: 그림 카운터를 들어오기 전 값으로.
			}
			if ( null !== $screen ) {
				if ( $screen[0] ) {
					$GLOBALS['current_screen'] = $screen[1]; // 수정 17: 관리 화면(같은 객체 — admin-ajax 는 null)을 그대로.
				} else {
					unset( $GLOBALS['current_screen'] );
				}
			}
			self::learn( $sticky ); // 수정 14 A+: 이 고정 렌더 안에서 코드가 새로 넣은 키(다음 고정 렌더 시작 때 미리 넣는다).
			list( $_GET, $_POST, $_REQUEST, $_COOKIE ) = $request; // phpcs:ignore WordPress.Security.NonceVerification -- 되돌림.
			foreach ( self::clientHints() as $key ) {
				unset( $_SERVER[ $key ] ); // 렌더 중 생긴 키도 — 아래에서 들어오기 전 키만 다시 넣는다.
			}
			foreach ( $server as $key => list( $had, $value ) ) {
				if ( $had ) {
					$_SERVER[ $key ] = $value;
				} else {
					unset( $_SERVER[ $key ] );
				}
			}
			if ( null !== $session ) {
				$_SESSION = $session[0];
			}
			if ( $title ) {
				remove_filter( 'private_title_format', array( self::class, 'plainTitle' ), PHP_INT_MAX );
			}
			if ( wp_get_current_user() !== $user ) {
				wp_set_current_user( (int) $user->ID ); // 전역 사용자 값(setup_userdata) — 코어가 kses_init 을 부른다 → 아래에서 기록대로 맞춘다.
				$GLOBALS['current_user'] = $user; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 들어오기 전 그 객체 그대로.
			}
			self::restoreKses( $kses );
		};
		self::$undo[] = $undo;
		// phpcs:disable WordPress.Security.NonceVerification -- 요청 값을 비운다(렌더 동안만 — 끈끈한 키만 남긴다, 수정 14 A+).
		$_GET     = $sticky[0];
		$_POST    = $sticky[1];
		$_REQUEST = $sticky[2];
		$_COOKIE  = array();
		// phpcs:enable
		$_SERVER['REQUEST_URI']     = is_string( $path ) && '' !== $path ? $path : '/';
		$_SERVER['QUERY_STRING']    = '';
		$_SERVER['HTTP_USER_AGENT'] = '';
		foreach ( self::clientHints() as $key ) {
			unset( $_SERVER[ $key ] );
		}
		if ( null !== $session ) {
			$_SESSION = array();
		}
		if ( $title ) {
			add_filter( 'private_title_format', array( self::class, 'plainTitle' ), PHP_INT_MAX );
		}
		if ( 0 !== (int) $user->ID ) {
			wp_set_current_user( 0 );
		}
		if ( null !== $media ) {
			wp_increase_content_media_count( -$media ); // 수정 17: 그림 카운터 0(새 요청의 첫 공개 응답과 같다).
		}
		if ( null !== $screen ) {
			$GLOBALS['current_screen'] = \WP_Screen::get( 'front' ); // 수정 17: 앞 화면(워드프레스가 in_admin 거짓으로 만든다) — 렌더 안 is_admin() 거짓 = 공개 응답.
		}
		return $undo;
	}

	/** 고정 문맥을 끝낸다(쌓인 자리에서 빼고 되돌림 — recover 가 이미 되돌렸으면 아무것도 하지 않는다). */
	private static function unfix( \Closure $undo ): void {
		$at = array_search( $undo, self::$undo, true );
		if ( false !== $at ) {
			array_splice( self::$undo, (int) $at, 1 );
		}
		$undo();
	}

	/**
	 * shutdown(PHP_INT_MIN — 수정 14 C10-2): 치명 종료·exit 로 finally 를 거치지 못해 아직 걸려 있는 승인 계산 고정 문맥을 안쪽부터 되돌린다(현재 사용자·요청 값·
	 * 요청 환경·세션·kses·제목 필터). 다른 shutdown 동작(출력 버퍼 끝·공개 차이 알림·다른 플러그인의 저장)과 PHP 세션 저장이 고정 문맥 값으로 돌지 않게.
	 */
	public static function recover(): void {
		while ( array() !== self::$undo ) {
			$undo = array_pop( self::$undo );
			$undo();
		}
	}

	/**
	 * 요청 시작(수정 14 A+ — 코디네이터 판단): 이 요청이 가져온 $_GET·$_POST 키를 찍고 배운 끈끈한 키를 비운다. iwell-core 적재 때(register — 플러그인 이름 순으로
	 * KBoard 보다 먼저) 한 번. 그 뒤 코어 wp_magic_quotes 가 $_REQUEST 를 GET+POST 로 다시 만드는 것은 코드 추가가 아니다($_REQUEST 의 가져온 키 = GET·POST 키 합).
	 * 시험이 요청을 흉내 낼 때도 부른다.
	 */
	public static function arrive(): void {
		self::$given   = array( self::keys( $_GET ), self::keys( $_POST ) ); // phpcs:ignore WordPress.Security.NonceVerification -- 키 이름만.
		self::$learned = array( array(), array(), array() );
	}

	/**
	 * 끈끈한 키(수정 14 A+): 이 요청이 가져오지 않은 키를 코드가 이 요청 안에서 넣은 것 — 바깥 흐름에 지금 있는 것(값 = 코드가 쓴 그대로)과 앞선 고정 렌더 안에서 넣은 것.
	 * 고정 렌더는 요청 값 대신 이것만 두고 시작한다: 요청당 첫 호출에만 요청 값에 키를 쓰는 플러그인 static(KBoard 6.8 kboard_mod — helper/Functions.helper.php:1137,
	 * kboard_pagination 은 $_GET 에 mod 키가 있으면 쪽 링크에 mod=list — helper/Pagination.helper.php:10)이 첫 호출을 어디서 했든 고정 렌더가 새 요청의 그 화면과 같다.
	 * 방문자가 준 키(가져온 키 — 예: ?mod=document)는 끈끈한 키가 아니다(그 응답만 닫힌다 — 익명은 기록 그대로).
	 *
	 * @return array{0: array<string, mixed>, 1: array<string, mixed>, 2: array<string, mixed>}
	 */
	private static function sticky(): array {
		// phpcs:disable WordPress.Security.NonceVerification -- 요청 값 읽기(고정 렌더 시작 값).
		$given = self::$given ?? array( self::keys( $_GET ), self::keys( $_POST ) );
		$had   = array( $given[0], $given[1], $given[0] + $given[1] );
		$now   = array( $_GET, $_POST, $_REQUEST );
		// phpcs:enable
		$out = array();
		foreach ( $had as $i => $keys ) {
			$out[ $i ] = array_diff_key( ( is_array( $now[ $i ] ) ? $now[ $i ] : array() ) + self::$learned[ $i ], $keys );
		}
		return $out;
	}

	/**
	 * 고정 렌더가 끝날 때(되돌리기 전) 그 안에서 코드가 새로 넣은 키를 배운다(수정 14 A+ — $start = 시작 때 둔 끈끈한 키). 가져온 키는 sticky 가 뺀다.
	 *
	 * @param array{0: array<string, mixed>, 1: array<string, mixed>, 2: array<string, mixed>} $start
	 */
	private static function learn( array $start ): void {
		// phpcs:ignore WordPress.Security.NonceVerification -- 요청 값 읽기(고정 렌더 끝 값).
		foreach ( array( $_GET, $_POST, $_REQUEST ) as $i => $now ) {
			if ( is_array( $now ) ) {
				self::$learned[ $i ] = array_diff_key( $now, $start[ $i ] ) + self::$learned[ $i ];
			}
		}
	}

	/** @return array<string, true> 배열의 키 이름. */
	private static function keys( mixed $values ): array {
		return is_array( $values ) ? array_fill_keys( array_map( 'strval', array_keys( $values ) ), true ) : array();
	}

	/** @return list<string> 지금 $_SERVER 의 브라우저 힌트 머리 키(Sec-CH-UA·Sec-CH-UA-Mobile·Sec-CH-UA-Platform …). */
	private static function clientHints(): array {
		return array_values( array_filter( array_map( 'strval', array_keys( $_SERVER ) ), static fn( string $key ): bool => str_starts_with( $key, 'HTTP_SEC_CH_UA' ) ) );
	}

	/** private_title_format(고정 문맥 동안만 — 수정 14 Ruling 4): 공개되지 않은 페이지도 게시 화면과 같은 제목('비공개: ' 접두어 없음). */
	public static function plainTitle(): string {
		return '%s';
	}

	/** @return list<bool> KSES_FILTERS 순서대로 지금 걸려 있나. */
	private static function ksesState(): array {
		return array_map( static fn( array $f ): bool => has_filter( $f[0], $f[1], $f[2] ), self::KSES_FILTERS );
	}

	/** @param list<bool> $state ksesState() 기록 — 다른 것만 걸거나 뗀다. */
	private static function restoreKses( array $state ): void {
		foreach ( self::KSES_FILTERS as $i => list( $hook, $fn, $priority ) ) {
			$now = has_filter( $hook, $fn, $priority );
			if ( $state[ $i ] && ! $now ) {
				add_filter( $hook, $fn, $priority );
			} elseif ( ! $state[ $i ] && $now ) {
				remove_filter( $hook, $fn, $priority );
			}
		}
	}

	/** @return array{texts: array<string, string>, attachments: int[], blocks: int[], unresolved: string[]} extract() 의 렌더(고정 문맥 안). */
	private static function render( WP_Post $post ): array {
		global $wp_query, $wp_the_query, $_wp_current_template_id, $_wp_current_template_content;
		$saved_post = $GLOBALS['post'] ?? null;
		$saved      = array( $wp_query, $wp_the_query, $_wp_current_template_id, $_wp_current_template_content );
		$watch      = self::observeStart();
		$screen     = Screen::start();
		$html       = '';
		$featured   = '';
		++self::$busy;
		try {
			$query = new WP_Query();
			$query->parse_query( array( 'page_id' => $post->ID ) );
			// get_posts() 가 채우는 질의 변수(the_post 가 읽는다 — 글 객체 전체).
			$query->query_vars['fields']                 = 'all';
			$query->query_vars['update_post_term_cache'] = true;
			$query->query_vars['update_post_meta_cache'] = true;
			$query->posts             = array( $post );
			$query->post_count        = 1;
			$query->found_posts       = 1;
			$query->max_num_pages     = 1;
			$query->queried_object    = $post;
			$query->queried_object_id = $post->ID;
			// phpcs:disable WordPress.WP.GlobalVariablesOverride.Prohibited -- 공개 단일 화면 문맥(끝나면 되돌림).
			$wp_query        = $query;
			$wp_the_query    = $query;
			$GLOBALS['post'] = $post;
			// phpcs:enable
			setup_postdata( $post );
			Screen::template(); // 그 화면이 실제로 쓰는 블록 템플릿(전역 $_wp_current_template_*).
			ob_start(); // 렌더 중 다른 코드가 직접 낸 출력은 버린다(승인 요청의 응답을 더럽히지 않게).
			try {
				$html = (string) get_the_block_template_html(); // 메인 루프(the_post) 안에서 그린다 — 실제 화면과 같다.
			} finally {
				ob_end_clean();
			}
			self::$observeAll = true; // 대표 이미지 출력값은 템플릿 영역 밖(JSON-LD·og:image)이어도 원장 검토 범위.
			try {
				$featured = self::featured( $post );
			} finally {
				self::$observeAll = false;
			}
		} finally {
			$marks = Screen::stop( $screen );
			--self::$busy;
			$observed = self::observeStop( $watch );
			// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 되돌림.
			list( $wp_query, $wp_the_query, $_wp_current_template_id, $_wp_current_template_content ) = $saved;
			$GLOBALS['post'] = $saved_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- 되돌림.
			if ( $saved_post instanceof WP_Post ) {
				setup_postdata( $saved_post );
			}
		}
		$regions = $marks['broken'] ? null : Screen::regions( $html, $marks['nonce'] );
		if ( null === $regions ) {
			$observed['u']['screen:markers'] = true; // 영역 표식을 못 읽음 — 승인 화면을 알 수 없다(닫힌 쪽).
			$regions                         = array();
		}
		$texts = array();
		foreach ( Screen::REGIONS as $part ) {
			$texts[ $part ] = self::normalize( (string) ( $regions[ $part ] ?? '' ) );
		}
		$texts['out:featured'] = $featured;
		$attachments           = array_map( 'intval', array_keys( $observed['a'] ) );
		$blocks                = array_map( 'intval', array_keys( $observed['b'] ) );
		$unresolved            = array_map( 'strval', array_keys( $observed['u'] ) );
		sort( $attachments );
		sort( $blocks );
		sort( $unresolved );
		return array(
			'texts'       => $texts,
			'attachments' => $attachments,
			'blocks'      => $blocks,
			'unresolved'  => $unresolved,
		);
	}

	/**
	 * 관찰(첨부·패턴)·렌더 감시(짧은 코드·목록 밖 블록)를 시작한다 — 승인 렌더(extract)·공개 응답(LiveSeal). 검토 범위 영역 안(Screen::inRegion)만 본다.
	 *
	 * @return array{outer: array|null} observeStop 에 넘길 토큰
	 */
	public static function observeStart(): array {
		$token           = array( 'outer' => self::$observing );
		self::$observing = array(
			'a' => array(),
			'b' => array(),
			'u' => array(),
		);
		self::observe( true );
		return $token;
	}

	/**
	 * 관찰을 끝내고 모은 것을 돌려준다(바깥 관찰이 있으면 거기에도 합친다).
	 *
	 * @return array{a: array<int, true>, b: array<int, true>, u: array<string, true>}
	 */
	public static function observeStop( array $token ): array {
		$observed        = self::$observing ?? array(
			'a' => array(),
			'b' => array(),
			'u' => array(),
		);
		self::$observing = $token['outer'] ?? null;
		self::observe( false );
		if ( null !== self::$observing ) {
			self::$observing['a'] += $observed['a'];
			self::$observing['b'] += $observed['b'];
			self::$observing['u'] += $observed['u'];
		}
		return $observed;
	}

	/**
	 * 영역 안에서 실제로 그려지는 블록(Screen::enter — render_block_data 가 바꾼 뒤) 또는 다른 필터가 대신 그린 블록(pre_render_block): 렌더된 동기화 패턴을
	 * 관찰(결정 2)하고, 허용 목록 밖 서버 렌더 블록이면 검토 불가 사유 'block:{이름}'(수정 11 C7-2 ② — 규칙 = Sources::unsealableBlock).
	 *
	 * @param mixed $parsed
	 */
	public static function noteRendered( string $name, $parsed = null ): void {
		if ( null === self::$observing || '' === $name ) {
			return;
		}
		if ( 'core/block' === $name && is_array( $parsed ) && is_numeric( $parsed['attrs']['ref'] ?? null ) ) {
			self::$observing['b'][ (int) $parsed['attrs']['ref'] ] = true;
		}
		$reason = Sources::unsealableBlock( $name );
		if ( null !== $reason ) {
			self::$observing['u'][ $reason ] = true;
		}
	}

	/**
	 * pre_render_block(PHP_INT_MAX — 다른 필터 다음): 다른 필터가 대신 그린 블록(값이 null 이 아님 — render_block_data·render_block 이 불리지 않는다)도
	 * 영역 안이면 감시한다(수정 11 C7-2 ② "다른 필터가 대신 그린 블록").
	 *
	 * @param mixed $pre
	 * @param mixed $parsed
	 * @return mixed
	 */
	public static function watchedPreRender( $pre, $parsed = null ) {
		if ( null !== $pre && Screen::inRegion() && is_array( $parsed ) ) {
			self::noteRendered( (string) ( $parsed['blockName'] ?? '' ), $parsed );
		}
		return $pre;
	}

	/**
	 * 대표 이미지 출력값 — JSON-LD primaryImageOfPage·og:image 가 쓰는 원본 주소·폭·높이 + 대체 글·캡션(없으면 빈 값). 공개 판정(LiveSeal)도 같은 함수.
	 * 수정 15 Ruling 3: 칸(주소·대체 글·캡션)은 줄바꿈·역슬래시를 \ 로(cell) — 대체 글 안 "⏎caption=…" 이 캡션 칸과 섞이지 않게(보통 값은 그대로).
	 */
	public static function featured( WP_Post $post ): string {
		$id = absint( get_post_meta( $post->ID, '_thumbnail_id', true ) );
		if ( $id <= 0 ) {
			return '';
		}
		$src = wp_get_attachment_image_src( $id, 'full' );
		return implode(
			"\n",
			array(
				is_array( $src ) ? self::cell( self::url( (string) $src[0] ), '' ) . ' ' . (int) $src[1] . 'x' . (int) $src[2] : 'missing',
				'alt=' . self::cell( trim( (string) get_post_meta( $id, PageMeta::ATTACHMENT_ALT, true ) ), '' ),
				'caption=' . self::cell( trim( (string) wp_get_attachment_caption( $id ) ), '' ),
			)
		);
	}

	/** 관찰 필터(결정 2)와 렌더 감시(수정 11 C7-2 — 짧은 코드·대신 그린 블록)를 걸거나 뗀다(겹쳐 걸면 바깥이 끝날 때 뗀다 — 수정 12). */
	private static function observe( bool $on ): void {
		if ( $on ) {
			if ( 1 !== ++self::$hooked ) {
				return;
			}
		} elseif ( self::$hooked <= 0 || 0 !== --self::$hooked ) {
			self::$hooked = max( 0, self::$hooked );
			return;
		}
		foreach ( self::OBSERVERS as $hook => $index ) {
			if ( $on ) {
				add_filter( $hook, array( self::class, 'observed' . $index ), PHP_INT_MAX, $index + 1 );
			} else {
				remove_filter( $hook, array( self::class, 'observed' . $index ), PHP_INT_MAX );
			}
		}
		if ( $on ) {
			add_filter( 'pre_do_shortcode_tag', array( self::class, 'watchedShortcode' ), PHP_INT_MAX, 2 );
			add_filter( 'pre_render_block', array( self::class, 'watchedPreRender' ), PHP_INT_MAX, 2 );
		} else {
			remove_filter( 'pre_do_shortcode_tag', array( self::class, 'watchedShortcode' ), PHP_INT_MAX );
			remove_filter( 'pre_render_block', array( self::class, 'watchedPreRender' ), PHP_INT_MAX );
		}
	}

	/**
	 * 렌더 감시(수정 11 C7-2 ①) — pre_do_shortcode_tag(PHP_INT_MAX — 다른 필터 다음): 검토 범위 영역 안(수정 12 — Screen::inRegion)에서 짧은 코드가 실행되면
	 * (짧은 코드 함수가 불리거나 다른 필터가 대신 출력을 냄) 검토 불가 사유 'shortcode:{이름}'(허용 0 — 원본 검사가 못 본 각주 JSON·이스케이프한 덮어쓰기·
	 * 렌더 때 덧붙은 짧은 코드도). 다른 필터가 빈 출력으로 막은 것('' — 고정 페이지의 Rank Math 스키마 짧은 코드, Graph::dropSchemaShortcode)은 실행이 아니다:
	 * 워드프레스가 짧은 코드 함수를 부르지 않고 빈 값을 그대로 낸다(wp-includes/shortcodes.php do_shortcode_tag). 이 예외는 수정 12 에서도 둔다 — 승인 렌더에서
	 * 빈 값으로 막혔던 짧은 코드가 실제 공개 요청에서는 실행되면(로그인·루프·요청 종류 분기) 그 응답의 영역이 승인 지문과 달라지고 공개 응답의 감시도 실행을
	 * 보므로 실제 출력 판정(LiveSeal)이 그 응답에서 검토 표시를 지운다. 이스케이프한 [[…]] 는 이 필터 전에 글자로 돌아간다.
	 *
	 * @param mixed $output
	 * @return mixed
	 */
	public static function watchedShortcode( $output, $tag = '' ) {
		if ( null !== self::$observing && Screen::inRegion() && '' !== $output && null !== $output ) {
			$reason = Sources::unsealableShortcode( (string) $tag );
			if ( null !== $reason ) {
				self::$observing['u'][ $reason ] = true;
			}
		}
		return $output;
	}

	/** 관찰 필터 — 둘째 인자가 첨부(ID). @param mixed $value */
	public static function observed1( $value, $id = 0 ) {
		self::note( $id );
		return $value;
	}

	/** 관찰 필터 — 다섯째 인자가 첨부 ID(wp_calculate_image_srcset). @param mixed $value */
	public static function observed4( $value, $a = null, $b = null, $c = null, $id = 0 ) {
		self::note( $id );
		return $value;
	}

	/** @param mixed $id 첨부 ID 또는 첨부 글. 검토 범위 영역 안(또는 대표 이미지 출력값)에서 읽힌 것만(수정 12 — 머리·바닥글 템플릿의 그림은 범위 밖). */
	private static function note( $id ): void {
		if ( null === self::$observing || ( ! self::$observeAll && ! Screen::inRegion() ) ) {
			return;
		}
		$id = $id instanceof WP_Post ? $id->ID : ( is_numeric( $id ) ? (int) $id : 0 );
		if ( $id > 0 && ! isset( self::$observing['a'][ $id ] ) && 'attachment' === get_post_type( $id ) ) {
			self::$observing['a'][ $id ] = true;
		}
	}

	/**
	 * 정규화 추출물(결정 1): 보이는 글자(공백 정리) + img src·srcset(후보 순서 그대로 — 수정 15)·alt + a href + 영상·오디오·iframe 등 src + 표 칸 경계.
	 * 클래스·스타일·래퍼 구조·nonce·data-·lazy·decoding·폭/높이는 넣지 않는다. 주소는 http/https 를 뗀다(같은 사이트를 cron·REST·공개 화면에서 그려도 같게).
	 * 수정 15 Ruling 3: 줄·칸 이어 붙이기가 다른 출력을 합치지 않게 — 태그 줄처럼 시작하는 글자 줄은 앞에 \(textLine), 주소·srcset 칸은 경계 글자를 \ 로(cell).
	 * 수정 16: 더 넣는 속성(TRACK·ANY — 있을 때만)은 ① 줄이 있는 태그(img·링크 a·영상 등·표 칸·표 줄)면 그 줄 바로 다음 "칸 줄"(탭 + 이름=값 — 한 줄에
	 *   속성 하나, 값은 cell) ② 아니면 글자 줄 안 표시 ⟪태그 이름=값 …⟫(값은 공백·%·⟪⟫ 를 %XX — pct). dir 과 MARKED 태그(del·q·bdo·MathML 등)는 늘 표시.
	 *   글자 안 ⟪·⟫ 는 두 번(esc) — 글자로 표시를 만들 수 없다. 탭으로 시작하는 줄은 글자 줄·태그 줄과 섞이지 않는다.
	 * 수정 17(Codex 재확인 12 + O-6·O-7·NBSP — 코디네이터 Ruling 1~10):
	 *   구조 = 이 워드프레스 WP_HTML_Processor(HTML 표준 트리 빌더 — create_fragment, 본문 문맥): 암묵 닫힘·가상 tbody·a 안 a·td 밖 td 무시·pre 첫 줄바꿈 버림을
	 *   브라우저처럼 정하고 요소가 실제로 닫히는 자리(가상 닫는 토큰 포함)를 준다. 표시를 낸 요소는 그 자리에 ⟪/태그⟫, 링크 줄(a href)의 짝은 ⟪/a⟫(O-7 범위 끝).
	 *   해석기가 포기하는 HTML(표 안 맨 글자 foster parenting·블록을 넘는 서식 태그 다시 열기·남은 </a>·<plaintext> 등)과 조각 해석이 버리는 <html>·<body>
	 *   속성 병합은 원문 그대로(raw — ⟪!⟫ + 원문, 닫힌 쪽).
	 *   공백(CSS 공백 합침 — lines): 문서 공백 5자(탭·LF·FF·CR·스페이스)만 합친다(NBSP·U+2003 등은 글자 — Ruling 9). 인라인 경계(표시·링크 줄·주석·빈 요소)를 넘는
	 *   연속 공백은 하나, 블록 경계는 앞뒤 공백을 지우고 공백 하나(수정 10 형식), 표 칸·표 줄 줄은 앞뒤 공백 없음, 그림·영상 등 대체 요소 줄과 상자(BOXES)는
	 *   글자 하나처럼(앞뒤 공백이 따로 남는다) — 인라인 줄 앞뒤 실제 공백이 지문에 든다(O-6: 앞뒤를 자르던 글자 줄이 이제 끝 공백·앞 공백을 가진다).
	 *   원문 공백 문맥(pre·listing 자손, xmp·textarea 글자 — Ruling 4): 공백·줄바꿈·탭 연속은 그대로 표시 ⟪%20⟫·⟪%0A%0A⟫·⟪%09⟫(줄 구조와 섞이지 않는다).
	 */
	public static function normalize( string $html ): string {
		if ( '' === trim( $html ) ) {
			return '';
		}
		// 조각 해석(본문 문맥)은 <html>·<body> 여는 태그를 버린다 — 브라우저는 그 속성을 문서 html·body 에 더한다(배경·글자 방향): 원문 그대로(닫힌 쪽).
		if ( 1 === preg_match( '~<(?:html|body)[\t\n\x0C\r />]~i', $html ) ) {
			return self::raw( $html );
		}
		$p = \WP_HTML_Processor::create_fragment( $html );
		if ( ! $p instanceof \WP_HTML_Processor ) {
			return self::raw( $html );
		}
		$pieces = array(); // ['t', 글자] · ['p', 원문 공백 글자] · ['m', 표시] · ['o'|'c'|'v', 상자 열림·닫힘·빈 상자 표시] · ['b'] 블록 경계 · ['l', 줄, 종류, 칸 줄들].
		$stack  = array(); // 닫는 토큰을 기다리는 요소: ['tag', 닫는 표시|null, 상자인가, 원문 공백 문맥인가, picture 정보|null].
		$pre    = 0;
		while ( $p->next_token() ) {
			$type = $p->get_token_type();
			if ( '#text' === $type || '#cdata-section' === $type ) {
				$text     = $p->get_modifiable_text();
				$pieces[] = $pre > 0 ? array( 'p', self::preserve( $text ) ) : array( 't', self::esc( $text ) );
				continue;
			}
			if ( '#tag' !== $type ) {
				continue; // 주석·doctype 등 — 공백 합침에는 보이지 않는 경계.
			}
			$tag = (string) $p->get_tag();
			if ( $p->is_tag_closer() ) {
				$top = array_pop( $stack );
				if ( null === $top || $top[0] !== $tag ) {
					return self::raw( $html ); // 해석기 닫는 순서가 열린 요소와 다르다(일어나지 않아야 한다 — 닫힌 쪽).
				}
				if ( in_array( $tag, self::BREAKS, true ) ) {
					$pieces[] = array( 'b' );
				}
				if ( null !== $top[1] ) {
					$pieces[] = array( $top[2] ? 'c' : ( in_array( $tag, self::GLYPHS, true ) ? 'v' : 'm' ), $top[1] );
				}
				$pre -= $top[3] ? 1 : 0;
				continue;
			}
			$link = 'A' === $tag && null !== $p->get_attribute( 'href' );
			$main = 'IMG' === $tag ? array( 'src', 'srcset', 'alt' ) : ( $link ? array( 'href' ) : ( self::MEDIA[ $tag ] ?? ( in_array( $tag, array( 'TD', 'TH', 'TR' ), true ) ? array() : null ) ) );
			$lazy = in_array( $tag, array( 'IMG', 'IMAGE' ), true ) && 'lazy' === strtolower( (string) $p->get_attribute( 'loading' ) );
			list( $mark, $cells ) = self::extras( $p, $tag, null !== $main, $main ?? array(), $lazy );
			$box = in_array( $tag, self::BOXES, true );
			if ( in_array( $tag, self::BREAKS, true ) ) {
				$pieces[] = array( 'b' );
			}
			$open = null === $mark && ! in_array( $tag, self::MARKED, true ) ? null : self::OPEN . self::pct( strtolower( $tag ) ) . (string) $mark . self::CLOSE;
			$atom = ! $p->expects_closer();
			if ( null !== $open ) {
				$pieces[] = array( $box ? ( $atom && ! in_array( $tag, array( 'TEXTAREA' ), true ) ? 'v' : 'o' ) : ( in_array( $tag, self::GLYPHS, true ) ? 'v' : 'm' ), $open ); // 줄 태그면 앞 글자 줄 끝(바로 다음 줄이 그 태그 줄).
			}
			$parent = array_key_last( $stack );
			if ( 'IMG' === $tag ) {
				// 칸: src(뒤 경계 ' [') · srcset(뒤 경계 ']') · alt(줄 끝 — 공백 정리로 줄바꿈 없음).
				$pieces[] = array( 'l', 'img ' . self::cell( self::url( self::attr( $p, 'src' ) ), '[' ) . ' [' . self::cell( self::srcset( self::attr( $p, 'srcset' ) ), ']' ) . '] alt=' . self::squash( self::attr( $p, 'alt' ) ), 'atom', $cells );
				if ( null !== $parent && 'PICTURE' === $stack[ $parent ][0] && null === $stack[ $parent ][4]['lazy'] ) {
					$stack[ $parent ][4]['lazy'] = $lazy; // 수정 17 Ruling 2: 그 picture 의 source sizes 맨 앞 auto 는 이 img 가 lazy 일 때만 뜻이 있다.
					foreach ( $lazy ? $stack[ $parent ][4]['sources'] : array() as list( $at, $lazy_cells ) ) {
						$pieces[ $at ][3] = $lazy_cells;
					}
				}
			} elseif ( $link ) {
				$pieces[] = array( 'l', 'a ' . self::cell( self::url( self::attr( $p, 'href' ) ), '' ), 'inline', $cells );
			} elseif ( isset( self::MEDIA[ $tag ] ) ) {
				$parts = array();
				foreach ( self::MEDIA[ $tag ] as $name ) {
					// 칸 사이 ' '(주소 칸은 공백·[ 를 \ 로), srcset 은 [ ] 안(] 를 \ 로).
					$parts[] = 'srcset' === $name ? '[' . self::cell( self::srcset( self::attr( $p, $name ) ), ']' ) . ']' : self::cell( self::url( self::attr( $p, $name ) ), ' [' );
				}
				if ( 'SOURCE' === $tag && null !== $parent && 'PICTURE' === $stack[ $parent ][0] && null === $stack[ $parent ][4]['lazy'] ) {
					$lazy_cells = self::extras( $p, $tag, true, $main ?? array(), true )[1];
					if ( $lazy_cells !== $cells ) {
						$stack[ $parent ][4]['sources'][] = array( count( $pieces ), $lazy_cells ); // img 가 lazy 면 이 칸들로(img 는 source 뒤에 온다).
					}
				}
				// source·track 은 상자가 아니다(보이지 않음 — 공백 합침에 보이지 않는 경계), 나머지는 대체 요소(글자 하나처럼).
				$pieces[] = array( 'l', strtolower( $tag ) . ' ' . implode( ' ', $parts ), in_array( $tag, array( 'SOURCE', 'TRACK' ), true ) ? 'inline' : 'atom', $cells );
			} elseif ( 'TD' === $tag || 'TH' === $tag ) {
				$pieces[] = array( 'l', '|', 'block', $cells );
			} elseif ( 'TR' === $tag ) {
				$pieces[] = array( 'l', '/', 'block', $cells );
			} elseif ( 'TEXTAREA' === $tag || 'XMP' === $tag ) {
				// 원문 글자 토큰(닫는 토큰 없음 — 해석기는 안 글자를 이 토큰에 준다): textarea(white-space: pre-wrap)·xmp(pre) 안 글자는 공백 그대로.
				$pieces[] = array( 'p', self::preserve( $p->get_modifiable_text() ) );
				if ( null !== $open ) {
					$pieces[] = array( $box ? 'c' : 'm', self::OPEN . '/' . self::pct( strtolower( $tag ) ) . self::CLOSE );
				}
				if ( in_array( $tag, self::BREAKS, true ) ) {
					$pieces[] = array( 'b' );
				}
			}
			if ( ! $atom ) {
				$close   = null !== $open || $link ? self::OPEN . '/' . self::pct( strtolower( $tag ) ) . self::CLOSE : null;
				$stack[] = array( $tag, $close, $box, in_array( $tag, self::PRE, true ), 'PICTURE' === $tag ? array( 'lazy' => null, 'sources' => array() ) : null );
				$pre    += in_array( $tag, self::PRE, true ) ? 1 : 0;
			}
		}
		if ( null !== $p->get_last_error() || array() !== $stack ) {
			return self::raw( $html ); // 해석기가 포기(지원하지 않는 HTML) — 원문 그대로(닫힌 쪽).
		}
		return self::lines( $pieces );
	}

	/**
	 * 조각 → 추출물 줄(수정 17 — CSS 공백 합침, 표준 CSS Text 3 white-space: normal): 글자 안 문서 공백 5자 연속 → 한 칸, 표시·링크 줄·source 줄(보이지 않는 경계)을
	 * 넘는 연속 공백 → 하나(앞의 것), 블록 경계 → 그 앞 공백을 지우고 공백 하나(줄 머리면 없음), 표 칸·표 줄 줄 → 앞뒤 공백 없음, 대체 요소 줄(img·영상)·빈 상자 →
	 * 글자 하나처럼(앞 공백도 뒤 공백도 따로 남는다), 상자 → 안은 새 줄(앞뒤 공백 없음)·바깥은 글자 하나처럼, 추출물 앞뒤 → 공백 없음. 원문 공백 글자('p')는 합치지
	 * 않는 글자. 글자 줄은 줄 태그 사이마다 하나(빈 줄은 뺀다) — 인라인 줄 앞뒤 공백이 글자 줄 끝·앞 공백으로 남는다(O-6).
	 *
	 * @param list<array> $pieces
	 */
	private static function lines( array $pieces ): string {
		$rows  = array(); // ['t', 조각들] · ['l', 줄, 칸 줄들].
		$cur   = -1;      // 지금 글자 줄(rows 번호, -1 = 없음).
		$prev  = 'start'; // 바로 앞 보이는 것: start(줄 머리 — 앞 공백 없음) · space(지울 수 있는 공백) · char.
		$space = null;    // 지울 수 있는 마지막 공백의 자리 [줄, 조각].
		$add   = static function ( string $s ) use ( &$rows, &$cur ): array {
			if ( $cur < 0 ) {
				$rows[] = array( 't', array() );
				$cur    = count( $rows ) - 1;
			}
			$rows[ $cur ][1][] = $s;
			return array( $cur, count( $rows[ $cur ][1] ) - 1 );
		};
		$drop  = static function () use ( &$rows, &$space ): void {
			if ( null !== $space ) {
				$rows[ $space[0] ][1][ $space[1] ] = substr( $rows[ $space[0] ][1][ $space[1] ], 0, -1 );
				$space                             = null;
			}
		};
		foreach ( $pieces as $piece ) {
			switch ( $piece[0] ) {
				case 't':
					$s = (string) preg_replace( '/[\t\n\x0C\r ]+/', ' ', $piece[1] ); // 문서 공백 5자만(NBSP 등은 글자 — Ruling 9, 바이트 단위라 잘못된 UTF-8 도 그대로).
					if ( '' !== $s && ' ' === $s[0] && 'char' !== $prev ) {
						$s = substr( $s, 1 );
					}
					if ( '' === $s ) {
						break;
					}
					$at = $add( $s );
					if ( ' ' === substr( $s, -1 ) ) {
						$space = $at;
						$prev  = 'space';
					} else {
						$space = null;
						$prev  = 'char';
					}
					break;
				case 'p':
					if ( '' !== $piece[1] ) {
						$add( $piece[1] );
						$space = null;
						$prev  = 'char';
					}
					break;
				case 'm':
					$add( $piece[1] );
					break;
				case 'o':
					$add( $piece[1] );
					$space = null;
					$prev  = 'start';
					break;
				case 'c':
					$drop();
					$add( $piece[1] );
					$prev = 'char';
					break;
				case 'v':
					$add( $piece[1] );
					$space = null;
					$prev  = 'char';
					break;
				case 'b':
					if ( 'start' !== $prev ) {
						$drop();
						$space = $add( ' ' );
						$prev  = 'space';
					}
					break;
				default: // 'l' 줄 태그.
					if ( 'block' === $piece[2] ) {
						$drop();
						$prev = 'start';
					} elseif ( 'atom' === $piece[2] ) {
						$space = null;
						$prev  = 'char';
					}
					$rows[] = array( 'l', $piece[1], $piece[3] );
					$cur    = -1;
			}
		}
		$drop();
		$out = array();
		foreach ( $rows as $row ) {
			if ( 't' === $row[0] ) {
				$text = implode( '', $row[1] );
				if ( '' !== $text ) {
					$out[] = self::textLine( $text );
				}
				continue;
			}
			$out[] = $row[1];
			foreach ( $row[2] as $c ) {
				$out[] = "\t" . $c; // 칸 줄 — 탭으로 시작하는 줄은 글자 줄(문서 공백은 합쳐 스페이스)·태그 줄과 섞이지 않고, 바로 앞 태그 줄에 붙는다.
			}
		}
		return implode( "\n", $out );
	}

	/** 원문 공백 문맥 글자(수정 17 Ruling 4): 문서 공백 5자 연속을 표시 ⟪%XX…⟫(pct — % 로 시작하는 표시는 태그 표시와 섞이지 않는다), 나머지는 글자(esc). */
	private static function preserve( string $text ): string {
		return (string) preg_replace_callback( '/[\t\n\x0C\r ]+/', static fn( array $m ): string => self::OPEN . self::pct( $m[0] ) . self::CLOSE, self::esc( $text ) );
	}

	/** 해석기가 포기한 HTML(수정 17 Ruling 8 — 닫힌 쪽): ⟪!⟫ + 원문 그대로(정규화한 추출물은 ⟪! 로 시작할 수 없다 — 글자 ⟪ 는 두 번, 표시는 태그 이름·/·% 로 시작). */
	private static function raw( string $html ): string {
		return self::OPEN . '!' . self::CLOSE . $html;
	}

	/**
	 * 여는 태그 하나의 더 넣는 속성(수정 16 — TRACK 의 그 태그 속성 다음 ANY, 있을 때만): [글자 줄 안 표시 칸 문자열|null, 칸 줄 목록].
	 * $line = 줄이 있는 태그 — dir 말고는 칸 줄(이름=값, cell), 아니면 모두 표시 칸(' 이름=값', pct). $main = 그 줄에 이미 있는 속성(넣지 않음).
	 * $lazy = 수정 17 Ruling 2 — sizes 맨 앞 auto 가 뜻이 있는 그림(img loading=lazy · picture source 는 그 img).
	 *
	 * @param string[] $main
	 * @return array{0: string|null, 1: string[]}
	 */
	private static function extras( \WP_HTML_Tag_Processor $p, string $tag, bool $line, array $main, bool $lazy = false ): array {
		$mark  = '';
		$cells = array();
		foreach ( ( self::TRACK[ $tag ] ?? array() ) + self::ANY as $name => $kind ) {
			if ( in_array( $name, $main, true ) || ( 'META' === $tag && 'content' === $name && null === $p->get_attribute( 'http-equiv' ) ) ) {
				continue; // 줄에 이미 있음 / http-equiv 없는 meta content 는 화면과 상관없다.
			}
			$raw = $p->get_attribute( $name );
			if ( null === $raw ) {
				continue;
			}
			foreach ( self::field( $name, $kind, true === $raw ? '' : (string) $raw, $lazy ) as list( $n, $v ) ) {
				if ( $line && 'dir' !== $name ) {
					$cells[] = null === $v ? $n : $n . '=' . self::cell( $v, '' );
				} else {
					$mark .= ' ' . ( null === $v ? $n : $n . '=' . self::pct( $v ) );
				}
			}
		}
		return array( '' === $mark ? null : $mark, $cells );
	}

	/**
	 * 속성 하나 → 칸(이름, 값 — null 이면 있음만). css 는 url() 마다 칸 하나(style=주소), 해석이 이상하면 값 그대로(style-odd=값), url() 없으면 칸 없음.
	 *
	 * @return list<array{0: string, 1: string|null}>
	 */
	private static function field( string $name, string $kind, string $raw, bool $lazy = false ): array {
		switch ( $kind ) {
			case 'bool':
				return array( array( $name, null ) );
			case 'url':
				return array( array( $name, self::url( $raw ) ) );
			case 'srcset':
				return array( array( $name, self::srcset( $raw ) ) );
			case 'sizes':
				$sizes = self::sizes( $raw, $lazy );
				return array( null === $sizes ? array( $name . '-odd', $raw ) : array( $name, $sizes ) ); // 수정 17: 확실하지 않으면 값 그대로(sizes-odd).
			case 'trim':
				return array( array( $name, trim( $raw, "\t\n\x0C\r " ) ) );
			case 'alt':
				return array( array( $name, self::squash( $raw ) ) );
			case 'css':
				$urls = self::cssUrls( $raw );
				return null === $urls ? array( array( $name . '-odd', $raw ) ) : array_map( static fn( string $u ): array => array( $name, self::url( $u ) ), $urls );
			default:
				return array( array( $name, $raw ) );
		}
	}

	/**
	 * img·source sizes(수정 16 Ruling 5 → 수정 17 Ruling 2 — Codex C12-2): HTML 표준(parse a sizes attribute · allows auto-sizes)대로 맨 앞 auto 는 그림이 lazy
	 * (loading 값 정확히 lazy — 대소문자 무시)이고 sizes 가 "auto" 이거나 "auto," 로 시작할 때(대소문자 무시)만 뜻이 있다(배치 폭으로 후보를 고른다 — Codex 실측
	 * Chrome 도 " AUTO , …" 은 쓰지 않았다). ① 맨 앞 항목이 auto 가 아니면 앞뒤 HTML 공백만 정리 ② lazy 가 아니면 맨 앞 auto 만 뗀다(브라우저가 쓰지 않는다 —
	 * 워드프레스가 lazy 여부에 따라 붙이거나 빼도 같은 화면) ③ lazy 이고 표준 꼴이면 'auto' + 나머지(앞뒤 공백 정리)로 남긴다 ④ lazy 인데 auto 앞뒤에 공백이 섞여
	 * 브라우저가 쓰는지 확실하지 않으면 null(sizes-odd = 값 그대로 — 닫힌 쪽). loading 자체는 넣지 않는다(auto 가 없으면 그림 선택을 바꾸지 않는다).
	 * picture source 의 lazy = 그 picture 의 img(normalize — img 는 source 뒤에 온다).
	 */
	private static function sizes( string $sizes, bool $lazy ): ?string {
		$ws    = "\t\n\x0C\r ";
		$parts = explode( ',', $sizes, 2 );
		if ( 'auto' !== strtolower( trim( $parts[0], $ws ) ) ) {
			return trim( $sizes, $ws );
		}
		if ( ! $lazy ) {
			return trim( $parts[1] ?? '', $ws ); // lazy 가 아니면 브라우저가 쓰지 않는 맨 앞 auto 만 뗀다.
		}
		if ( 'auto' === strtolower( $parts[0] ) ) {
			return 'auto' . ( isset( $parts[1] ) ? ',' . trim( $parts[1], $ws ) : '' ); // 표준 꼴 — 배치 폭으로 고른다(남긴다).
		}
		return null; // lazy 인데 auto 앞뒤에 공백 — 브라우저가 쓰는지 확실하지 않다(값 그대로).
	}

	/**
	 * style 속성 안 그림 주소(수정 16 Ruling 1): CSS Syntax 3 토큰 해석으로 url 토큰과 url()·src() 함수 안 문자열을 원래 순서로 꺼낸다 — 주석·따옴표·공백·
	 * 이스케이프(\61·\75 rl( 등)·대소문자는 CSS 문법대로, 숫자 단위(1url( 는 url 이 아니다)도 구분. 해석이 이상하면 null(값 그대로 — 닫힌 쪽): bad-url·
	 * bad-string, url()·src() 안에 문자열 하나 말고 다른 것(var() 등), url·src 밖 함수 안의 문자열(image-set("…")·image()·cross-fade() 등 — 그 문자열이
	 * 주소일 수 있다), element() 요소 참조.
	 *
	 * @return list<string>|null
	 */
	private static function cssUrls( string $css ): ?array {
		$s     = str_replace( array( "\r\n", "\r", "\x0C", "\0" ), array( "\n", "\n", "\n", "\u{FFFD}" ), $css );
		$n     = strlen( $s );
		$i     = 0;
		$urls  = array();
		$stack = array(); // 열린 함수·괄호: [이름(소문자 — 괄호는 ''), url·src 안 문자열|null, 그 안 토큰 수].
		$at    = static fn( int $k ): string => $k < $n ? $s[ $k ] : '';
		$ws    = static fn( string $c ): bool => ' ' === $c || "\t" === $c || "\n" === $c;
		$start = static fn( string $c ): bool => '' !== $c && ( ctype_alpha( $c ) || '_' === $c || ord( $c ) >= 0x80 );
		$namec = static fn( string $c ): bool => $start( $c ) || ( '' !== $c && ( ctype_digit( $c ) || '-' === $c ) );
		$esc   = static fn( int $k ): bool => '\\' === $at( $k ) && "\n" !== $at( $k + 1 );
		$ident = static fn( int $k ): bool => '-' === $at( $k ) ? ( $start( $at( $k + 1 ) ) || '-' === $at( $k + 1 ) || $esc( $k + 1 ) ) : ( $start( $at( $k ) ) || $esc( $k ) );
		$cp    = static function () use ( &$i, $s, $n, $at ): string { // 이스케이프 다음 글자(역슬래시 뒤에서 부른다).
			if ( $i >= $n ) {
				return "\u{FFFD}";
			}
			if ( ctype_xdigit( $s[ $i ] ) ) {
				$hex = '';
				while ( $i < $n && strlen( $hex ) < 6 && ctype_xdigit( $s[ $i ] ) ) {
					$hex .= $s[ $i++ ];
				}
				if ( ' ' === $at( $i ) || "\t" === $at( $i ) || "\n" === $at( $i ) ) {
					++$i;
				}
				$v = (int) hexdec( $hex );
				return 0 === $v || ( $v >= 0xD800 && $v <= 0xDFFF ) || $v > 0x10FFFF ? "\u{FFFD}" : self::utf8( $v );
			}
			$len = ord( $s[ $i ] ) >= 0xF0 ? 4 : ( ord( $s[ $i ] ) >= 0xE0 ? 3 : ( ord( $s[ $i ] ) >= 0xC0 ? 2 : 1 ) );
			$c   = substr( $s, $i, $len );
			$i  += $len;
			return $c;
		};
		$name  = static function () use ( &$i, $at, $namec, $esc, $cp ): string {
			$out = '';
			while ( true ) {
				if ( $namec( $at( $i ) ) ) {
					$out .= $at( $i++ );
				} elseif ( $esc( $i ) ) {
					++$i;
					$out .= $cp();
				} else {
					return $out;
				}
			}
		};
		$token = static function ( string $kind, string $value = '' ) use ( &$stack, &$urls ): bool { // false = 이상함.
			$top = array() === $stack ? null : $stack[ count( $stack ) - 1 ][0];
			if ( 'url' === $top || 'src' === $top ) {
				$k = count( $stack ) - 1;
				if ( 'string' !== $kind || $stack[ $k ][2] > 0 ) {
					return false; // url("a" b)·src(var(--x)) 등.
				}
				$stack[ $k ][1] = $value;
				++$stack[ $k ][2];
				return true;
			}
			if ( 'url-token' === $kind ) {
				$urls[] = $value;
			} elseif ( 'string' === $kind && null !== $top && '' !== $top ) {
				return false; // image-set("…")·image("…") 등 url·src 밖 함수 안 문자열.
			}
			return true;
		};
		while ( $i < $n ) {
			$c = $s[ $i ];
			if ( '/' === $c && '*' === $at( $i + 1 ) ) {
				$e = strpos( $s, '*/', $i + 2 );
				$i = false === $e ? $n : $e + 2;
				continue;
			}
			if ( $ws( $c ) ) {
				++$i;
				continue;
			}
			if ( '"' === $c || "'" === $c ) {
				++$i;
				$str = '';
				while ( true ) {
					$d = $at( $i );
					if ( '' === $d || $d === $c ) {
						$i += '' === $d ? 0 : 1;
						break;
					}
					if ( "\n" === $d ) {
						return null; // bad-string.
					}
					if ( '\\' === $d ) {
						++$i;
						if ( '' === $at( $i ) ) {
							continue;
						}
						if ( "\n" === $at( $i ) ) {
							++$i; // 줄 이음.
							continue;
						}
						$str .= $cp();
						continue;
					}
					$str .= $d;
					++$i;
				}
				if ( ! $token( 'string', $str ) ) {
					return null;
				}
				continue;
			}
			if ( ctype_digit( $c ) || ( ( '+' === $c || '-' === $c ) && ( ctype_digit( $at( $i + 1 ) ) || ( '.' === $at( $i + 1 ) && ctype_digit( $at( $i + 2 ) ) ) ) ) || ( '.' === $c && ctype_digit( $at( $i + 1 ) ) ) ) {
				$i += ( '+' === $c || '-' === $c ) ? 1 : 0;
				$i += strspn( $s, '0123456789', $i );
				if ( '.' === $at( $i ) && ctype_digit( $at( $i + 1 ) ) ) {
					$i += 1 + strspn( $s, '0123456789', $i + 1 );
				}
				if ( ( 'e' === $at( $i ) || 'E' === $at( $i ) ) && ( ctype_digit( $at( $i + 1 ) ) || ( ( '+' === $at( $i + 1 ) || '-' === $at( $i + 1 ) ) && ctype_digit( $at( $i + 2 ) ) ) ) ) {
					$i += 2;
					$i += strspn( $s, '0123456789', $i );
				}
				if ( $ident( $i ) ) {
					$name(); // 단위(1url( 의 url 은 함수가 아니다).
				} elseif ( '%' === $at( $i ) ) {
					++$i;
				}
				if ( ! $token( 'number' ) ) {
					return null;
				}
				continue;
			}
			if ( $ident( $i ) ) {
				$word = $name();
				if ( '(' !== $at( $i ) ) {
					if ( ! $token( 'ident' ) ) {
						return null;
					}
					continue;
				}
				++$i;
				$lower = strtolower( $word );
				if ( 'url' === $lower ) {
					$j = $i;
					while ( $ws( $at( $j ) ) ) {
						++$j;
					}
					if ( '"' !== $at( $j ) && "'" !== $at( $j ) ) {
						// url 토큰: 공백 건너뛰기 → ) 또는 끝까지. 따옴표·( ·인쇄 안 되는 글자·공백 뒤 다른 글자·잘못된 이스케이프 = bad-url.
						$i   = $j;
						$url = '';
						while ( true ) {
							$d = $at( $i );
							if ( '' === $d || ')' === $d ) {
								$i += '' === $d ? 0 : 1;
								break;
							}
							if ( $ws( $d ) ) {
								while ( $ws( $at( $i ) ) ) {
									++$i;
								}
								if ( ')' === $at( $i ) || '' === $at( $i ) ) {
									$i += '' === $at( $i ) ? 0 : 1;
									break;
								}
								return null;
							}
							$o = ord( $d );
							if ( '"' === $d || "'" === $d || '(' === $d || $o <= 0x08 || 0x0B === $o || ( $o >= 0x0E && $o <= 0x1F ) || 0x7F === $o ) {
								return null;
							}
							if ( '\\' === $d ) {
								if ( ! $esc( $i ) ) {
									return null;
								}
								++$i;
								$url .= $cp();
								continue;
							}
							$url .= $d;
							++$i;
						}
						if ( ! $token( 'url-token', $url ) ) {
							return null;
						}
						continue;
					}
				}
				if ( 'element' === $lower || '-moz-element' === $lower || ! $token( 'function' ) ) {
					return null; // 요소 참조 / url()·src() 안 함수.
				}
				$stack[] = array( $lower, null, 0 );
				continue;
			}
			if ( '(' === $c ) {
				if ( ! $token( 'paren' ) ) {
					return null;
				}
				$stack[] = array( '', null, 0 );
				++$i;
				continue;
			}
			if ( ')' === $c ) {
				++$i;
				$top = array_pop( $stack );
				if ( null !== $top && ( 'url' === $top[0] || 'src' === $top[0] ) ) {
					if ( null === $top[1] ) {
						return null; // src() 처럼 문자열 없음.
					}
					$urls[] = $top[1];
				}
				continue;
			}
			if ( '#' === $c && ( $namec( $at( $i + 1 ) ) || $esc( $i + 1 ) ) ) {
				++$i;
				$name(); // 해시(#url( 은 함수가 아니다).
			} elseif ( '@' === $c && $ident( $i + 1 ) ) {
				++$i;
				$name();
			} else {
				$i += ord( $c ) >= 0xF0 ? 4 : ( ord( $c ) >= 0xE0 ? 3 : ( ord( $c ) >= 0xC0 ? 2 : 1 ) );
			}
			if ( ! $token( 'delim' ) ) {
				return null;
			}
		}
		foreach ( $stack as $open ) { // 끝까지 안 닫힌 url("…")·src("…") 도 CSS 는 닫힌 것으로 읽는다.
			if ( 'url' === $open[0] || 'src' === $open[0] ) {
				if ( null === $open[1] ) {
					return null;
				}
				$urls[] = $open[1];
			}
		}
		return $urls;
	}

	/** 코드 포인트 → UTF-8(CSS 이스케이프 — mbstring 없이). */
	private static function utf8( int $v ): string {
		if ( $v < 0x80 ) {
			return chr( $v );
		}
		if ( $v < 0x800 ) {
			return chr( 0xC0 | ( $v >> 6 ) ) . chr( 0x80 | ( $v & 0x3F ) );
		}
		if ( $v < 0x10000 ) {
			return chr( 0xE0 | ( $v >> 12 ) ) . chr( 0x80 | ( ( $v >> 6 ) & 0x3F ) ) . chr( 0x80 | ( $v & 0x3F ) );
		}
		return chr( 0xF0 | ( $v >> 18 ) ) . chr( 0x80 | ( ( $v >> 12 ) & 0x3F ) ) . chr( 0x80 | ( ( $v >> 6 ) & 0x3F ) ) . chr( 0x80 | ( $v & 0x3F ) );
	}

	/**
	 * 공백 정리(연속 공백 → 한 칸, 앞뒤 자름 — img alt 등 칸 값). 수정 17 Ruling 9: HTML·CSS 문서 공백 5자(탭·LF·FF·CR·스페이스)만 — NBSP·U+2003·U+3000·U+2028·
	 * U+0085 등은 브라우저가 합치지 않으므로 글자 그대로(수정 16 까지의 /\s+/u 는 합쳤다). 바이트 단위라 잘못된 UTF-8 도 그대로(수정 16 S1 과 같은 규칙 — 글자 줄도 lines()).
	 */
	private static function squash( string $s ): string {
		return trim( (string) preg_replace( '/[\t\n\x0C\r ]+/', ' ', $s ), ' ' );
	}

	/** 글자 안 표시 글자를 두 번(⟪ → ⟪⟪, ⟫ → ⟫⟫ — 수정 16: 글자 그대로는 표시를 만들 수 없다. 바이트 단위라 잘못된 UTF-8 도 그대로). */
	private static function esc( string $text ): string {
		return str_replace( array( self::OPEN, self::CLOSE ), array( self::OPEN . self::OPEN, self::CLOSE . self::CLOSE ), $text );
	}

	/** 표시 칸 값 — 공백·제어 글자·%·⟪·⟫ 를 %XX(바이트 단위 — 표시 안에 공백·⟪⟫ 가 없어 경계가 하나로 정해진다, 공백 정리에도 그대로). */
	private static function pct( string $value ): string {
		return (string) preg_replace_callback( '/[\x00-\x20\x7F%]|\xE2\x9F[\xAA\xAB]/', static fn( array $m ): string => rawurlencode( $m[0] ), $value );
	}

	private static function attr( \WP_HTML_Tag_Processor $p, string $name ): string {
		$value = $p->get_attribute( $name );
		return is_string( $value ) ? $value : '';
	}

	/**
	 * 주소 정규화: 스킴 뗌 + 우리 사이트 주소(ours)의 쿼리 인자를 열쇠(queryKey)순 안정 정렬. 이름·값·경로·조각·인코딩 바이트는 그대로.
	 * 수정 13: KBoard 는 요청당 한 번(static) $_GET 에 category1~5·uid 빈 값을 써 넣고(helper/Functions.helper.php kboard_category1·kboard_uid) KBUrl 이 그
	 * $_GET 을 복사해 링크 인자 순서를 정하므로, 그 요청에서 KBoard 가 이미 초기화됐는지에 따라 같은 링크의 인자 순서만 바뀐다(고정 문맥은 렌더마다 $_GET 을 비운다).
	 * 수정 14(Codex 재확인 10 C10-1 — Ruling 1): 정렬이 다른 뜻을 합치지 않게 — ① 우리 사이트 주소만(바깥 서버가 인자 순서를 어떻게 읽는지 모른다 — 순서가
	 * 바뀌면 다른 지문) ② 범위 = 첫 ? 뒤 ~ 첫 # 앞(# 가 ? 보다 앞이면 쿼리 없음 — 조각은 정렬하지 않는다) ③ 열쇠가 같은 인자(PHP 가 같은 변수로 읽는
	 * 이름 — %61 = a, a[] = a%5B%5D = a, a.b = a_b = a+b)는 서로의 순서 그대로(뒤 값이 이긴다 — 순서가 뜻).
	 */
	private static function url( string $url ): string {
		$raw  = trim( $url );
		$url  = (string) preg_replace( '#^https?:(?=//)#i', '', $raw );
		$q    = strpos( $url, '?' );
		$hash = strpos( $url, '#' );
		if ( false === $q || ( false !== $hash && $hash < $q ) || ! self::ours( $raw ) ) {
			return $url;
		}
		$end   = false === $hash ? strlen( $url ) : $hash;
		$query = substr( $url, $q + 1, $end - $q - 1 );
		if ( ! self::sortable( $query, (string) ini_get( 'arg_separator.input' ), min( (int) ini_get( 'max_input_vars' ), 64 ) ) ) {
			return $url; // 수정 17 Ruling 1(C12-1): PHP 는 앞에서부터 max_input_vars 개만 받는다 — 정렬하면 잘리는 인자가 바뀐다(원래 순서 — 닫힌 쪽).
		}
		$pairs = explode( '&', $query );
		$keys  = array_map( array( self::class, 'queryKey' ), $pairs );
		$order = array_keys( $pairs );
		usort( $order, static fn( int $x, int $y ): int => strcmp( $keys[ $x ], $keys[ $y ] ) ?: $x <=> $y ); // 같은 열쇠는 원래 순서(안정).
		return substr( $url, 0, $q + 1 ) . implode( '&', array_map( static fn( int $i ): string => $pairs[ $i ], $order ) ) . substr( $url, $end );
	}

	/**
	 * 쿼리 인자를 정렬해도 되는가(수정 17 Ruling 1 — Codex C12-1): 받는 PHP 의 인자 구분자(arg_separator.input — 글자마다 구분자)가 & 하나이고, & 로 나눈 빈 칸 아닌
	 * 조각 수(PHP php_default_treat_data 가 세는 수 — php_strtok_r 는 빈 칸을 건너뛴다)가 $limit(= min(max_input_vars, 64)) 이하. 같은 서버가 지문을 계산하고 링크도
	 * 받으므로 그 서버 ini 값을 쓴다(값이 바뀌어 정렬 여부가 달라지면 다른 지문이 될 뿐 — 닫힌 쪽).
	 */
	private static function sortable( string $query, string $separators, int $limit ): bool {
		return '&' === $separators && count( array_filter( explode( '&', $query ), static fn( string $piece ): bool => '' !== $piece ) ) <= $limit;
	}

	/**
	 * 우리 사이트 주소인가(수정 14 C10-1 — 브라우저 해석 기준 닫힌 쪽): 상대 주소(스킴·// 없음) 또는 //호스트[:포트] 가 home_url 과 완전히 같다(스킴 무관 —
	 * http·https). 판정은 브라우저처럼 탭·CR·LF 를 지우고 역슬래시를 슬래시로 본다(/\바깥·\\바깥·/<탭>/바깥 은 바깥). http(s): 뒤에 // 가 없으면 바깥
	 * (다른 스킴 문서에서 브라우저는 http:바깥 을 바깥 주소로 읽는다), 사용자 정보(…@)·다른 포트·다른 스킴(mailto:·javascript: …)도 바깥.
	 */
	private static function ours( string $url ): bool {
		$u = str_replace( '\\', '/', (string) preg_replace( '/[\t\n\r]/', '', ltrim( $url, "\x00..\x20" ) ) );
		if ( 1 === preg_match( '#^https?:#i', $u ) ) {
			$u = (string) preg_replace( '#^https?:#i', '', $u );
			if ( ! str_starts_with( $u, '//' ) ) {
				return false;
			}
		}
		if ( str_starts_with( $u, '//' ) ) {
			$home = wp_parse_url( home_url() );
			$host = strtolower( (string) ( $home['host'] ?? '' ) );
			$mine = '' === $host ? '' : $host . ( isset( $home['port'] ) ? ':' . (int) $home['port'] : '' );
			return '' !== $mine && 1 === preg_match( '#^//([^/?\#]*)#', $u, $m ) && strtolower( $m[1] ) === $mine;
		}
		return 1 !== preg_match( '#^[a-z][a-z0-9+.\-]*:#i', $u );
	}

	/**
	 * 쿼리 인자의 정렬 열쇠(수정 14 C10-1 → 수정 15 C11-1): 이름을 한 번 퍼센트 디코딩(+ = 공백) → 앞 공백 지움·NUL 뒤 자름(PHP 변수 등록과 같은 쪽) →
	 * [·_·공백·. 중 처음 나오는 글자 앞까지 → 소문자. PHP 는 이름의 공백·.·짝 없는 [ 만 _ 로 바꾸고 짝 있는 [ 에서 자른다(PHP 7·8 의 나머지 처리 차이는
	 * 그 글자 뒤에서만) — 그래서 PHP 가 같은 변수로 읽는 두 이름은 이 글자들 앞부분이 늘 같다(a[ = a_ = a. = a = a%5B …). 열쇠가 다르면 다른 변수라
	 * 순서를 바꿔도 뜻이 같다. 넉넉히 묶을수록(순서를 더 지킬수록) 닫힌 쪽이다(대소문자도 묶는다). PHP 버전과 무관하다.
	 */
	private static function queryKey( string $pair ): string {
		$name = urldecode( explode( '=', $pair, 2 )[0] );
		$name = ltrim( explode( "\0", $name, 2 )[0], ' ' );
		return strtolower( substr( $name, 0, strcspn( $name, '[_ .' ) ) );
	}

	/**
	 * srcset 정규화(수정 15 C11-2 — Ruling 2): HTML 표준 srcset 해석(parse a srcset attribute)으로 후보를 나누고 **원래 순서 그대로** 후보마다 주소 정규화
	 * (url)와 공백 정리만 한다 — 같은 밀도 후보는 앞의 것을 고르는 등 순서가 뜻이라 정렬하지 않는다. 주소 = 공백 아닌 글자의 연속, 주소 끝 쉼표는 뗀다(그
	 * 후보는 설명자 없음 — A,B 1x 는 주소 1개, A, B 1x 는 후보 2개), 설명자 = 괄호 밖 다음 쉼표까지. 해석이 이상하면(쉼표만 있는 자리·주소 끝 쉼표 2개 이상·
	 * 괄호·설명자 형식 밖·설명자 2개 이상·빈 주소) 값을 그대로 쓴다(odd). 후보 사이는 ', ' — 주소 안 쉼표는 '\,'(cell) 이라 경계와 섞이지 않는다.
	 */
	private static function srcset( string $srcset ): string {
		$ws  = "\t\n\x0C\r "; // HTML ASCII 공백(세로 탭 \x0B 는 아니다 — 주소 글자).
		$len = strlen( $srcset );
		$at  = 0;
		$out = array();
		while ( true ) {
			$skip = strspn( $srcset, $ws . ',', $at );
			if ( str_contains( substr( $srcset, $at, $skip ), ',' ) ) {
				return self::odd( $srcset ); // 쉼표만 있는 자리(표준의 해석 오류).
			}
			$at += $skip;
			if ( $at >= $len ) {
				break;
			}
			$n    = strcspn( $srcset, $ws, $at );
			$url  = substr( $srcset, $at, $n );
			$at  += $n;
			$desc = array();
			$bare = rtrim( $url, ',' );
			if ( $bare !== $url ) {
				if ( strlen( $url ) - strlen( $bare ) > 1 ) {
					return self::odd( $srcset );
				}
				$url = $bare; // 주소 끝 쉼표 하나 = 이 후보 끝(설명자 없음).
			} else {
				$at   += strspn( $srcset, $ws, $at );
				$cur   = '';
				$after = false;
				while ( true ) {
					$c = $at < $len ? $srcset[ $at ] : '';
					if ( $after ) {
						if ( '' === $c ) {
							break;
						}
						if ( ! str_contains( $ws, $c ) ) {
							$after = false;
							continue; // 이 글자를 설명자 안에서 다시 본다.
						}
					} elseif ( '' === $c ) {
						if ( '' !== $cur ) {
							$desc[] = $cur;
						}
						break;
					} elseif ( str_contains( $ws, $c ) ) {
						if ( '' !== $cur ) {
							$desc[] = $cur;
							$cur    = '';
						}
						$after = true;
					} elseif ( ',' === $c ) {
						++$at;
						if ( '' !== $cur ) {
							$desc[] = $cur;
						}
						break;
					} elseif ( '(' === $c ) {
						return self::odd( $srcset ); // 괄호 안 설명자(표준은 다음 쉼표를 넘어 읽는다) — 이상하다.
					} else {
						$cur .= $c;
					}
					++$at;
				}
			}
			$url = self::url( $url );
			if ( '' === $url || count( $desc ) > 1 || ( array() !== $desc && 1 !== preg_match( '/^(?:(?!0+w$)[0-9]+w|(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?x)$/', $desc[0] ) ) ) {
				return self::odd( $srcset );
			}
			$out[] = self::cell( $url, ',' ) . ( array() !== $desc ? ' ' . $desc[0] : '' );
		}
		return implode( ', ', $out );
	}

	/** 해석이 이상한 srcset — 값을 그대로(앞에 ',' — 정규화한 srcset 은 주소 첫 글자로 시작하므로 ',' 로 시작하지 않는다: 둘이 섞이지 않는다). */
	private static function odd( string $srcset ): string {
		return ',' . $srcset;
	}

	/**
	 * 정규화 추출물 줄 안의 칸 하나(수정 15 Ruling 3 — 이어 붙이기가 다른 출력을 합치지 않게): 역슬래시·줄바꿈과 $stops(그 칸 뒤 경계 글자)를 역슬래시로
	 * 바꾼다(addcslashes — 되읽기가 하나로 정해진다). 보통 값(주소·srcset 에 역슬래시·줄바꿈·경계 글자가 없음)은 그대로라 옛 승인 지문이 유지된다.
	 */
	private static function cell( string $value, string $stops ): string {
		return addcslashes( $value, "\\\n" . $stops );
	}

	/**
	 * 정규화 추출물의 글자 줄(수정 15 Ruling 3): 태그 줄(img·a·영상 등 이름 + 공백 · 표 칸 | · 표 줄 /)과 같은 말로 시작하거나 역슬래시로 시작하면 앞에
	 * 역슬래시를 붙인다 — "a /evil" 글자와 /evil 로 가는 링크가 같은 줄이 되지 않게. 보통 글자(한글 문장 등)는 그대로.
	 */
	private static function textLine( string $text ): string {
		$head = explode( ' ', $text, 2 )[0];
		return str_starts_with( $text, '\\' ) || in_array( $head, self::LINES, true ) ? '\\' . $text : $text;
	}

	// ── 결정 2 관찰한 의존성 저장·조회 ────────────────────────────────────

	/** 승인 때 관찰한 의존성을 남긴다(이전 행을 지우고 새로). */
	public static function index( int $post_id, array $attachments, array $blocks ): void {
		delete_metadata( 'post', $post_id, self::DEP_KEY );
		foreach ( array_unique( array_map( 'intval', $attachments ) ) as $id ) {
			add_metadata( 'post', $post_id, self::DEP_KEY, 'a:' . $id );
		}
		foreach ( array_unique( array_map( 'intval', $blocks ) ) as $id ) {
			add_metadata( 'post', $post_id, self::DEP_KEY, 'b:' . $id );
		}
	}

	/** 이 글이 승인 때 이 첨부('attachment')·패턴('block')을 쓰는 것을 관찰했는가. */
	public static function observes( int $post_id, string $kind, int $id ): bool {
		return in_array( self::depValue( $kind, $id ), array_map( 'strval', (array) get_post_meta( $post_id, self::DEP_KEY ) ), true );
	}

	/** @return int[] 승인 때 이 첨부·패턴을 쓰는 것을 관찰한 글. */
	public static function pagesObserving( string $kind, int $id ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 역방향 조회(관찰한 의존성 행).
		return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s", self::DEP_KEY, self::depValue( $kind, $id ) ) ) );
	}

	private static function depValue( string $kind, int $id ): string {
		return ( 'block' === $kind ? 'b:' : 'a:' ) . $id;
	}

	// ── 결정 5 해제 기록(운영 — 재승인 필요 목록) ───────────────────────────

	/**
	 * 출력 지문 불일치로 검토 기록을 내린다는 기록(바뀐 지문 조각). $src = 'live' 면 실제로 보낸 공개 응답의 판정(수정 12 — LiveSeal)이 내렸다
	 * (재승인 필요 목록이 승인 계산을 새로 해 "실제 화면과 승인 계산이 다름"인지 본다).
	 */
	public static function noteLapse( int $post_id, array $parts ): void {
		update_metadata(
			'post',
			$post_id,
			self::LAPSE_KEY,
			array(
				'at'    => wp_date( 'Y-m-d H:i:s' ),
				'parts' => array_values( array_map( 'strval', $parts ) ),
			)
		);
	}

	/** 승인 때 공개 차이 알림 빈 자리(수정 13 Ruling 3) — 다시 승인하면 알림도 지워지고, 그 뒤 공개 요청의 첫 쓰기도 비교-교체가 된다(동시 첫 쓰기 경쟁 없음). */
	public static function resetLive( int $post_id ): void {
		update_metadata(
			'post',
			$post_id,
			self::LIVE_KEY,
			array(
				't' => 0,
				'n' => 0,
			)
		);
	}

	/**
	 * 공개 응답이 승인 지문과 달랐다는 알림을 덮어쓴다(수정 13 Ruling 3 — LiveSeal::commit, 응답을 보낸 뒤). 검토 기록·지문 캐시·세대는 건드리지 않는다
	 * (LIVE_KEY 는 QUIET_META). 페이지당 LIVE_EVERY 에 한 번: 지난 알림이 창 안이면 조각·주소가 달라도 쓰지 않는다. 쓸 때는 이 요청이 읽은 값(객체 캐시 —
	 * 메인 질의가 채운 메타)을 조건으로 비교-교체(update_metadata $prev_value → UPDATE … WHERE meta_value = 읽은 값): 같은 순간 다른 요청이 먼저 썼으면
	 * 0행이라 덮어쓰지 않는다 — 익명 요청이 몰려도 창마다 쓰기 1회. 수정 14(Codex 재확인 10 C10-3 — Ruling 3): 공개 요청은 행을 새로 만들지 않는다 —
	 * 빈 자리 행이 없으면(수정 13 이전 승인) 쓰지 않는다(조회와 INSERT 는 원자적이지 않아 "행 없음"을 같이 본 두 요청이 두 행을 만들었다). 그 응답은 이미
	 * 검토 표시 없이 나갔다(원칙 그대로). 다시 승인하면 빈 자리가 생긴다(Seal::stamp → resetLive). 공개 판정(LiveSeal::commit)과 권한 없는 요청의 승인 계산
	 * 차이(PageMeta::verifiedReview)가 쓴다.
	 *
	 * @param string[] $parts
	 * @return bool 썼나
	 */
	public static function noteLive( int $post_id, array $parts, string $url ): bool {
		$old = get_post_meta( $post_id, self::LIVE_KEY, true );
		$now = time();
		if ( ! is_array( $old ) || $now - (int) ( $old['t'] ?? 0 ) < self::LIVE_EVERY ) {
			return false; // 빈 자리 행 없음(옛 승인 — INSERT 하지 않는다) 또는 창 안.
		}
		$new = array(
			't'     => $now,
			'at'    => wp_date( 'Y-m-d H:i:s', $now ),
			'parts' => array_values( array_map( 'strval', $parts ) ),
			'url'   => $url,
			'n'     => (int) ( $old['n'] ?? 0 ) + 1,
		);
		// update_metadata 는 DB 에 그 키 행이 없으면 add_metadata 로 넘어간다(읽은 값이 오래된 객체 캐시였을 때) — 그 길도 막는다(행을 만들지 않는다).
		$no_insert = static fn( $check, $object_id = 0, $meta_key = '' ) => self::LIVE_KEY === $meta_key ? false : $check;
		add_filter( 'add_post_metadata', $no_insert, PHP_INT_MAX, 3 );
		try {
			return true === update_metadata( 'post', $post_id, self::LIVE_KEY, $new, $old );
		} finally {
			remove_filter( 'add_post_metadata', $no_insert, PHP_INT_MAX );
		}
	}
}
