<?php
/**
 * 역할·권한(Task 3) — 직원 초안·원장 승인·공지 즉시 게시·칼럼 전용 계정.
 *
 * 역할(활성화 때 만들고, VERSION 이 바뀌면 다음 요청에서 다시 맞춘다 — zip 업데이트는 활성화 훅이 돌지 않으므로):
 * - iwell_staff(직원): 고정 페이지는 초안·검토 대기·수정안까지만(publish_pages·edit_published_pages 없음 → 게시된 페이지는
 *   PublishPress Revisions 수정안으로만 고친다. 예약(future) 고정 페이지·원장이 예약 승인한 수정안(future-revision)은 편집·수정안
 *   만들기 모두 불가 — Task 6 수정 2·3, map_meta_cap),
 *   글은 `notices`(공지사항) 카테고리만 공개, 진료시간 관리, 상담 열람·답변.
 * - iwell_director(원장): 워드프레스 편집자 권한 + 상담 삭제 + 블록 잠금 해제(+ 직원의 iwell 권한).
 *   게시된 페이지를 고칠 수 있으므로 PublishPress Revisions 승인 판정(revisionary_main.php:1364, 원본 edit_post)을 통과한다.
 * - iwell_columnbot(칼럼 자동 등록): `columns`(원장 칼럼) 카테고리 글 생성·게시와 미디어 업로드만. 고정 페이지·다른 카테고리 불가.
 * - seedbot 계정(Task 13)은 iwell_staff 역할을 쓴다(게시 불가) — 계정은 dev/blueprint.json(로컬)·운영 절차서(Task 14)에서 만든다.
 *
 * 글 카테고리 정책(워드프레스 기본 권한은 카테고리를 구분하지 못해 여기서 판정):
 * - 직원: 공개 상태(publish·future·private)가 되는 글은 카테고리가 모두 notices 일 때만. 초안·검토 대기는 어느 카테고리든 가능.
 * - 칼럼 봇: 상태와 관계없이 카테고리가 모두 columns 인 글만.
 * - 원장·편집자·관리자 역할이 하나라도 있으면 제한 없음.
 * 막는 자리 4곳: ① map_meta_cap(이미 있는 글의 edit_post·delete_post·publish_post) ② rest_pre_insert_post(블록 편집기·
 * 봇의 REST 저장 → 403) ③ wp_insert_post_empty_content(편집기 밖 경로에서 칼럼 봇의 범위 밖 글은 만들지 않음)
 * ④ wp_insert_post_data(편집기 밖 경로 — 빠른 편집·XML-RPC 등 — 에서 직원의 범위 밖 공개 요청은 검토 대기로).
 *
 * 우리가 만드는 권한(CUSTOM_CAPS)은 뒤 태스크가 이 이름으로 판정한다: iwell_manage_hours(Task 5) · iwell_read_consult·
 * iwell_reply_consult·iwell_delete_consult(Task 11) · iwell_unlock_blocks(Task 8). 관리자 역할에도 모두 준다.
 *
 * 동기화 패턴·첨부(Task 6 수정 5 F2 — 직원 변경은 원장 승인 없이 공개되지 않는다):
 * - 직원·봇(글 범위가 있는 역할 — iwell_staff·seedbot·iwell_columnbot)은 동기화 패턴(wp_block)을 만들기·고치기·지우기 불가. 패턴은 페이지에
 *   <!-- wp:block {"ref":ID} /--> 로 들어가 공개 화면에서 그 패턴의 지금 본문을 그리므로, 고치면 원장 승인 없이 의학 페이지가 바뀐다.
 *   섹션은 테마 패턴·블록 잠금으로 만든다(설계서 §6) — 직원에게 동기화 패턴이 필요 없다. 워드프레스는 패턴 만들기를 publish_posts 로
 *   판정해(wp-includes/post.php:340, 직원은 공지 게시 때문에 이 권한이 있다) 패턴 글 종류의 create_posts 를 우리 권한 이름
 *   CREATE_PATTERNS 로 바꾸고(register_post_type_args) map_meta_cap 에서 직원·봇 = 거부, 그 밖 = publish_posts 로 판정한다.
 *   이미 있는 패턴은 edit_post·delete_post·publish_post 거부.
 * - 게시·예약된 고정 페이지(원장이 예약 승인한 수정안 포함)가 쓰는 첨부는 직원·봇이 고치거나 지울 수 없다(PageMeta::attachmentInApprovedUse).
 *   "쓰는지"는 의존성 해석기 하나(Sources — Task 6 수정 7 결정 2)가 정한다: 동기화 패턴 안(중첩)·대표 이미지·블록 속성·실제 gallery/playlist 짧은
 *   코드·파일 주소. 이미지 편집기(회전·자르기·복원)도 edit_post 로 판정해 같이 막힌다.
 *   중첩 패턴은 워드프레스가 그리는 만큼 따라가고(안전 상한 64), 상한에서 해석이 멈춘 승인 페이지가 후보이면 그 첨부는 "사용 중"(Task 6 수정 8 결정 1 — 닫힌 쪽).
 * - 테마 템플릿·템플릿 파트(wp_template·wp_template_part)는 워드프레스 기본 edit_theme_options 판정 — 직원·봇은 없음(403, 수정 8 결정 4 시험으로 고정).
 *   원장 검토 범위 밖이다(검토 = 페이지 본문·각주·쓰는 첨부·대표 이미지·검토 대상 SEO 값).
 */

namespace Iwell\Core;

use WP_Error;
use WP_REST_Request;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class Roles {
	public const STAFF     = 'iwell_staff';
	public const DIRECTOR  = 'iwell_director';
	public const COLUMNBOT = 'iwell_columnbot';

	public const NOTICES = 'notices';
	public const COLUMNS = 'columns';

	public const VERSION        = '1';
	public const VERSION_OPTION = 'iwell_roles_version';

	/** 동기화 패턴(wp_block) 만들기 권한 이름(create_posts) — map_meta_cap 이 직원·봇 = 거부, 그 밖 = publish_posts 로 바꾼다(수정 5 F2 ①). */
	public const CREATE_PATTERNS = 'iwell_create_patterns';

	public const CUSTOM_CAPS = array(
		'iwell_manage_hours',
		'iwell_read_consult',
		'iwell_reply_consult',
		'iwell_delete_consult',
		'iwell_unlock_blocks',
	);

	/** 카테고리 slug → 이름(활성화 때 없으면 만든다). */
	public const CATEGORIES = array(
		self::NOTICES => '공지사항',
		self::COLUMNS => '원장 칼럼',
	);

	/** 글 범위: publish = 공개할 수 있는 카테고리, write = 다룰 수 있는 카테고리(null = 제한 없음). 표에 없는 역할은 제한 없음. */
	private const POST_SCOPES = array(
		self::STAFF     => array(
			'publish' => array( self::NOTICES ),
			'write'   => null,
		),
		self::COLUMNBOT => array(
			'publish' => array( self::COLUMNS ),
			'write'   => array( self::COLUMNS ),
		),
	);

	/** 이 역할이 하나라도 있으면 글 범위 제한을 받지 않는다. */
	private const UNSCOPED_ROLES = array( 'administrator', 'editor', self::DIRECTOR );

	/** 공개로 보는 글 상태. */
	private const LIVE = array( 'publish', 'future', 'private' );

	/** 워드프레스 기본 편집자 권한(wp-admin/includes/schema.php populate_roles). */
	private const EDITOR_CAPS = array(
		'moderate_comments',
		'manage_categories',
		'manage_links',
		'upload_files',
		'unfiltered_html',
		'edit_posts',
		'edit_others_posts',
		'edit_published_posts',
		'publish_posts',
		'edit_pages',
		'read',
		'edit_others_pages',
		'edit_published_pages',
		'publish_pages',
		'delete_pages',
		'delete_others_pages',
		'delete_published_pages',
		'delete_posts',
		'delete_others_posts',
		'delete_published_posts',
		'delete_private_posts',
		'edit_private_posts',
		'read_private_posts',
		'delete_private_pages',
		'edit_private_pages',
		'read_private_pages',
	);

	/** Rank Math 1.0.282 기본값(includes/modules/role-manager/class-capability-manager.php) — 편집자·글쓴이 몫 그대로. */
	private const RANK_MATH_EDITOR = array( 'rank_math_site_analysis', 'rank_math_onpage_analysis', 'rank_math_onpage_general', 'rank_math_onpage_snippet', 'rank_math_onpage_social' );
	private const RANK_MATH_AUTHOR = array( 'rank_math_onpage_analysis', 'rank_math_onpage_general', 'rank_math_onpage_snippet', 'rank_math_onpage_social' );

	/** @return array<string, array{0: string, 1: array<string, bool>}> 역할 slug → [이름, 권한]. */
	public static function definitions(): array {
		$levels = static fn( int $max ): array => array_map( static fn( int $i ): string => "level_$i", range( 0, $max ) );
		$caps   = static fn( array ...$lists ): array => array_fill_keys( array_values( array_unique( array_merge( ...$lists ) ) ), true );

		return array(
			self::STAFF     => array(
				'직원',
				$caps(
					array( 'read', 'upload_files' ),
					$levels( 2 ),
					// 고정 페이지: 초안·검토 대기·수정안(남의 페이지 수정안도 — PublishPress 수정자 역할과 같은 구성).
					array( 'edit_pages', 'edit_others_pages', 'delete_pages', 'read_private_pages' ),
					// 글: 공지 바로 게시(카테고리 정책으로 notices 만 공개).
					array( 'edit_posts', 'edit_others_posts', 'edit_published_posts', 'publish_posts', 'delete_posts', 'delete_published_posts' ),
					array( 'iwell_manage_hours', 'iwell_read_consult', 'iwell_reply_consult' ),
					self::RANK_MATH_AUTHOR
				),
			),
			self::DIRECTOR  => array(
				'원장',
				$caps( self::EDITOR_CAPS, $levels( 7 ), self::CUSTOM_CAPS, self::RANK_MATH_EDITOR ),
			),
			self::COLUMNBOT => array(
				'칼럼 자동 등록',
				$caps( array( 'read', 'upload_files', 'edit_posts', 'publish_posts' ), $levels( 2 ) ),
			),
		);
	}

	public static function register(): void {
		add_action( 'init', array( self::class, 'maybe_sync' ) );
		add_filter( 'map_meta_cap', array( self::class, 'map_meta_cap' ), 10, 4 );
		add_filter( 'register_post_type_args', array( self::class, 'pattern_post_type_args' ), 10, 2 );
		add_filter( 'rest_pre_insert_post', array( self::class, 'rest_pre_insert_post' ), 10, 2 );
		add_filter( 'wp_insert_post_empty_content', array( self::class, 'refuse_out_of_scope_insert' ), 10, 2 );
		add_filter( 'wp_insert_post_data', array( self::class, 'hold_out_of_scope_publish' ), 10, 2 );
	}

	/** 활성화 훅. 역할을 정의대로 다시 만들고(사용자 배정은 그대로), 관리자에 iwell 권한, 카테고리 2개. */
	public static function install(): void {
		foreach ( self::definitions() as $slug => list( $label, $caps ) ) {
			remove_role( $slug );
			add_role( $slug, $label, $caps );
		}
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( self::CUSTOM_CAPS as $cap ) {
				$admin->add_cap( $cap );
			}
		}
		foreach ( self::CATEGORIES as $slug => $name ) {
			if ( ! get_term_by( 'slug', $slug, 'category' ) ) {
				wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
			}
		}
		update_option( self::VERSION_OPTION, self::VERSION );
	}

	public static function maybe_sync(): void {
		if ( get_option( self::VERSION_OPTION ) !== self::VERSION ) {
			self::install();
		}
	}

	/**
	 * 이 사용자의 글 범위. null = 제한 없음.
	 *
	 * @return array{publish: string[], write: ?string[]}|null
	 */
	public static function post_scope( ?WP_User $user = null ): ?array {
		$user ??= wp_get_current_user();
		if ( ! $user instanceof WP_User || ! $user->exists() || array_intersect( $user->roles, self::UNSCOPED_ROLES ) || user_can( $user, 'manage_options' ) ) {
			return null;
		}
		$scopes = array_intersect_key( self::POST_SCOPES, array_flip( $user->roles ) );
		if ( ! $scopes ) {
			return null;
		}
		$publish = array();
		$write   = array();
		foreach ( $scopes as $scope ) {
			$publish = array_merge( $publish, $scope['publish'] );
			$write   = null === $scope['write'] || null === $write ? null : array_merge( $write, $scope['write'] );
		}
		return array(
			'publish' => array_values( array_unique( $publish ) ),
			'write'   => null === $write ? null : array_values( array_unique( $write ) ),
		);
	}

	/**
	 * 카테고리 $term_ids 의 글을 $status 로 두는 것을 이 사용자에게 허용하는가.
	 *
	 * @return null|'write'|'publish' null = 허용, 'write' = 이 카테고리 글을 다룰 수 없음, 'publish' = 공개할 수 없음.
	 */
	public static function post_violation( array $term_ids, string $status, ?WP_User $user = null ): ?string {
		$scope = self::post_scope( $user );
		if ( null === $scope ) {
			return null;
		}
		$slugs = self::category_slugs( $term_ids );
		if ( null !== $scope['write'] && ! self::within( $slugs, $scope['write'] ) ) {
			return 'write';
		}
		if ( in_array( $status, self::LIVE, true ) && ! self::within( $slugs, $scope['publish'] ) ) {
			return 'publish';
		}
		return null;
	}

	/**
	 * ① 이미 있는 글: 범위 밖이면 수정·삭제·게시 불가.
	 * 예약(future) 고정 페이지(Task 6 수정 2)·승인된 예약 수정안(future-revision, 수정 3): 직원·봇(글 범위가 있는 역할 — iwell_staff·
	 * seedbot·iwell_columnbot)은 편집(edit_post — REST 본문·메타·편집기·Rank Math updateMeta 가 모두 이 판정)과 수정안 만들기(PublishPress
	 * copy_post — 그 처리기 우선순위 5 뒤에 덮는다) 모두 불가. 원장이 예약·예약 승인한 순간이 승인이라, 그 뒤 바뀌면 원장 확인 없이
	 * 공개된다. 수정안 흐름은 게시된 페이지만(작성자가 직원이어도 — 직원 초안을 원장이 예약한 페이지).
	 */
	public static function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		if ( self::CREATE_PATTERNS === $cap ) {
			$user = get_userdata( $user_id );
			return $user && null === self::post_scope( $user ) ? array( 'publish_posts' ) : array( 'do_not_allow' );
		}
		if ( empty( $args[0] ) ) {
			return $caps;
		}
		if ( in_array( $cap, array( 'edit_post', 'copy_post' ), true ) && self::is_held_future_page( $args[0], $user_id ) ) {
			return array( 'do_not_allow' );
		}
		if ( ! in_array( $cap, array( 'edit_post', 'delete_post', 'publish_post' ), true ) ) {
			return $caps;
		}
		if ( self::guards_live_source( $args[0], $user_id ) ) {
			return array( 'do_not_allow' );
		}
		$post = get_post( $args[0] );
		$user = get_userdata( $user_id );
		if ( ! $post || 'post' !== $post->post_type || 'auto-draft' === $post->post_status || ! $user ) {
			return $caps;
		}
		$status = 'publish_post' === $cap ? 'publish' : $post->post_status;
		return null === self::post_violation( wp_get_post_categories( $post->ID ), $status, $user ) ? $caps : array( 'do_not_allow' );
	}

	/**
	 * 승인이 걸린 예약 고정 페이지이고 사용자가 직원·봇(글 범위 있음 — 원장·편집자·관리자 역할이 하나라도 있으면 아님)인가.
	 * 예약 페이지(future) + PublishPress 가 예약 승인한 수정안(post_mime_type future-revision, post_status 는 pending — Task 6 수정 3:
	 * 승인 뒤 직원이 REST·편집기·Rank Math 로 고쳐도 그대로 공개되던 구멍). 제출 전 수정안(draft/pending-revision)은 그대로 편집한다.
	 */
	private static function is_held_future_page( $post, int $user_id ): bool {
		$post = get_post( $post );
		$user = get_userdata( $user_id );
		return $post && 'page' === $post->post_type
			&& ( 'future' === $post->post_status || PageMeta::SCHEDULED_REVISION === $post->post_mime_type )
			&& $user && null !== self::post_scope( $user );
	}

	/**
	 * 직원·봇에게 막는 공개 원천(수정 5 F2): 동기화 패턴(wp_block) 전부, 게시·예약된 고정 페이지(승인 수정안 포함)가 쓰는 첨부.
	 * 원장·편집자·관리자(글 범위 없음)는 해당 없음.
	 */
	private static function guards_live_source( $post, int $user_id ): bool {
		$post = get_post( $post );
		if ( ! $post || ! in_array( $post->post_type, array( PageMeta::PATTERN_TYPE, 'attachment' ), true ) ) {
			return false;
		}
		$user = get_userdata( $user_id );
		if ( ! $user || null === self::post_scope( $user ) ) {
			return false;
		}
		return PageMeta::PATTERN_TYPE === $post->post_type || PageMeta::attachmentInApprovedUse( $post->ID );
	}

	/** register_post_type_args — 동기화 패턴 만들기 권한(create_posts, 워드프레스 기본 publish_posts)을 우리 권한 이름으로(map_meta_cap 이 판정). */
	public static function pattern_post_type_args( $args, $post_type ) {
		if ( PageMeta::PATTERN_TYPE === $post_type && is_array( $args ) ) {
			$args['capabilities']                 = isset( $args['capabilities'] ) && is_array( $args['capabilities'] ) ? $args['capabilities'] : array();
			$args['capabilities']['create_posts'] = self::CREATE_PATTERNS;
		}
		return $args;
	}

	/**
	 * ② REST(블록 편집기·봇) 저장: 저장될 카테고리·상태로 판정해 403. 판정한 카테고리를 post_category 로 넘겨
	 * ③·④가 같은 값을 보게 한다(REST 는 카테고리를 글 저장 뒤에 따로 넣는다).
	 *
	 * @param \stdClass|WP_Error $prepared
	 * @return \stdClass|WP_Error
	 */
	public static function rest_pre_insert_post( $prepared, WP_REST_Request $request ) {
		if ( is_wp_error( $prepared ) || null === self::post_scope() ) {
			return $prepared;
		}
		$existing = ! empty( $prepared->ID ) ? get_post( (int) $prepared->ID ) : null;
		if ( isset( $request['categories'] ) ) {
			$cats = array_map( 'intval', (array) $request['categories'] );
		} elseif ( $existing ) {
			$cats = wp_get_post_categories( $existing->ID );
		} else {
			$cats = array( (int) get_option( 'default_category' ) );
		}
		$status = $prepared->post_status ?? ( $existing ? $existing->post_status : 'draft' );
		if ( 'auto-draft' !== $status ) {
			$violation = self::post_violation( $cats, $status );
			if ( null !== $violation ) {
				return self::error( $violation );
			}
		}
		$prepared->post_category = $cats;
		return $prepared;
	}

	/** ③ 편집기 밖 경로: 칼럼 봇의 범위 밖 글은 만들지 않는다(wp_insert_post 가 WP_Error/0 을 돌려준다). */
	public static function refuse_out_of_scope_insert( $maybe_empty, $postarr ) {
		if ( $maybe_empty || ! is_array( $postarr ) || 'post' !== ( $postarr['post_type'] ?? 'post' ) ) {
			return $maybe_empty;
		}
		$status = (string) ( $postarr['post_status'] ?? 'draft' );
		if ( 'auto-draft' === $status ) {
			return $maybe_empty;
		}
		return 'write' === self::post_violation( self::categories_of( $postarr ), $status ) ? true : $maybe_empty;
	}

	/** ④ 편집기 밖 경로: 직원의 범위 밖 공개 요청은 검토 대기로 저장(원장이 게시). */
	public static function hold_out_of_scope_publish( array $data, array $postarr ): array {
		if ( 'post' !== ( $data['post_type'] ?? '' ) || ! in_array( $data['post_status'] ?? '', self::LIVE, true ) ) {
			return $data;
		}
		if ( null !== self::post_violation( self::categories_of( $postarr ), $data['post_status'] ) ) {
			$data['post_status'] = 'pending';
		}
		return $data;
	}

	/** wp_insert_post 에 들어온 값으로 저장될 카테고리를 구한다(워드프레스와 같은 순서: 지정값 → 기존값 → 기본 카테고리). */
	private static function categories_of( array $postarr ): array {
		if ( ! empty( $postarr['post_category'] ) ) {
			return array_map( 'intval', (array) $postarr['post_category'] );
		}
		if ( ! empty( $postarr['tax_input']['category'] ) ) {
			return array_map( 'intval', (array) $postarr['tax_input']['category'] );
		}
		if ( ! empty( $postarr['ID'] ) ) {
			$existing = wp_get_post_categories( (int) $postarr['ID'] );
			if ( $existing ) {
				return $existing;
			}
		}
		return array( (int) get_option( 'default_category' ) );
	}

	/** @return string[] 카테고리 slug(없는 id 는 '#id' — 어떤 범위에도 들지 않음). */
	private static function category_slugs( array $term_ids ): array {
		$slugs = array();
		foreach ( $term_ids as $id ) {
			$term    = get_term( (int) $id, 'category' );
			$slugs[] = $term && ! is_wp_error( $term ) ? $term->slug : '#' . (int) $id;
		}
		return array_values( array_unique( $slugs ) );
	}

	/** 카테고리가 하나 이상이고 모두 허용 목록 안인가. */
	private static function within( array $slugs, array $allowed ): bool {
		return array() !== $slugs && array() === array_diff( $slugs, $allowed );
	}

	private static function error( string $violation ): WP_Error {
		$scope = self::post_scope();
		$names = implode( '·', array_map( static fn( string $slug ): string => self::CATEGORIES[ $slug ] ?? $slug, (array) ( 'write' === $violation ? $scope['write'] : $scope['publish'] ) ) );
		return new WP_Error(
			'iwell_post_category_forbidden',
			'write' === $violation
				? sprintf( '이 계정은 %s 카테고리 글만 만들거나 고칠 수 있습니다.', $names )
				: sprintf( '이 계정은 %s 카테고리 글만 공개할 수 있습니다. 다른 카테고리 글은 초안·검토 대기로 저장하면 원장이 게시합니다.', $names ),
			array( 'status' => 403 )
		);
	}
}
