<?php
/**
 * 편집기 사이드 패널 "의학 정보"(Task 6) — 고정 페이지 블록 편집기(PublishPress 수정안 편집 화면 포함)에만 assets/editor-panel.js 를 싣는다.
 *
 * 패널(빌드 없이 wp.* 전역만 쓰는 스크립트):
 *   - 기준일(iwell_data_asof)·출처(iwell_sources: 제목·주소·확인일, 추가·삭제) 입력 — 편집기 메타(core/editor editPost)로 저장되므로
 *     게시된 페이지에서는 수정안에 들어가고 원장 승인 때 반영된다(PublishPress 메타 복사).
 *   - 검토자·검토일은 읽기 전용 글자(REST 필드 iwell_review — PageMeta, 원장 승인·게시 때 자동 기록).
 *   - 저장 요청 정리(apiFetch 미들웨어): 블록 편집기는 메타를 하나만 고쳐도 메타 객체 전체를 보낸다(core-data mergedEdits). 그래서
 *     ① 검토자·검토일 — 서버도 무시하지만 아예 보내지 않는다, ② Rank Math 제목·설명 — Rank Math 패널은 따로 rankmath/v1/updateMeta 로
 *     저장하는데, 편집기를 연 때의 옛 값 사본이 같은 저장에 실려 가면 두 요청의 도착 순서에 따라 새 SEO 값이 옛 값으로 되돌아갈 수 있다 → 뺀다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class EditorPanel {
	public const HANDLE = 'iwell-editor-panel';

	public static function register(): void {
		add_action( 'enqueue_block_editor_assets', array( self::class, 'enqueue' ) );
	}

	public static function enqueue(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || PageMeta::POST_TYPE !== $screen->post_type ) {
			return;
		}
		$file = dirname( __DIR__ ) . '/assets/editor-panel.js';
		wp_enqueue_script(
			self::HANDLE,
			plugins_url( 'assets/editor-panel.js', dirname( __DIR__ ) . '/iwell-core.php' ),
			array( 'wp-api-fetch', 'wp-components', 'wp-data', 'wp-editor', 'wp-element', 'wp-plugins' ),
			(string) filemtime( $file ),
			true
		);
		// 검토 배지 블록의 편집기용 최소 등록(Task 8 — 설명 자리표시만, 서버 쪽 동작은 그대로): core/missing 으로 보여 직원이 지우려 하지 않게.
		$badge = dirname( __DIR__ ) . '/assets/review-badge-editor.js';
		wp_enqueue_script(
			self::HANDLE . '-badge',
			plugins_url( 'assets/review-badge-editor.js', dirname( __DIR__ ) . '/iwell-core.php' ),
			array( 'wp-blocks', 'wp-block-editor', 'wp-element' ),
			(string) filemtime( $badge ),
			true
		);
	}
}
