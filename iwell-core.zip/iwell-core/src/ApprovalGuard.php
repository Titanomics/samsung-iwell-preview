<?php
/**
 * 승인 우회 차단(대표 결정 2026-11-12 A안, Review Focus 5) — Rank Math 쓰기 경로를 워드프레스 권한 판정으로 다시 거른다.
 *
 * 문제(docs/compat-gate.md 1-b, Rank Math 1.0.282 설치본):
 *   Rank Math 의 글 권한 판정 `Rest_Helper::can_edit_post()`(includes/rest/class-rest-helper.php:169-188)가
 *   `current_user_can( edit_post, ID ) || current_user_can( edit_others_posts 원시 권한 )` 이라, 게시된 페이지를 고칠 수 없는
 *   직원(edit_others_pages 만 있음)도 통과한다 → 원장 승인 없이 공개 SEO 메타가 바로 바뀐다.
 * 같은 판정을 쓰는 쓰기 경로(설치본 전체 검색, 2026-11-12):
 *   - REST `rankmath/v1/updateMeta`        includes/rest/class-shared.php:60-69 → get_object_permissions_check → can_edit_post
 *   - REST `rankmath/v1/updateSchemas`     includes/rest/class-shared.php:71-80 → get_schema_permissions_check(:64-74) → 같은 판정
 *   - REST `rankmath/v1/updateRedirection` includes/rest/class-shared.php:49-58 → get_redirection_permissions_check(:45-55) — 대상 글 판정 자체가 없음
 *   - REST `rankmath/v1/updateMetaBulk`    includes/rest/class-post.php:39-50 → 행마다 can_process(:107-142)의 같은 OR 판정(:131-139),
 *                                          제목·설명·초점 키워드·이미지 대체 글·첨부 제목(wp_update_post) 저장
 *   - AJAX `wp_ajax_rank_math_mark_page_as` includes/admin/class-admin-bar-menu.php:51·58-98 → can_edit_object → can_edit_post
 *                                          (관리 막대의 noindex·nofollow·필러 콘텐츠 표시 — REST 는 아니지만 같은 우회라 같이 막는다)
 *   읽기 전용이라 막지 않은 것: REST `rankmath/v1/getFeaturedImageId`(includes/rest/class-front.php:52-63·119-137, 대표 이미지 id 만 돌려줌),
 *   Abilities API 읽기 능력(includes/abilities/*: get-post-seo-meta 등 — 값 변경 없음).
 *
 * 처리: 요청이 건드리는 대상마다 워드프레스 판정(글 edit_post · 용어 edit_term · 사용자 edit_user)이 거짓이면 403.
 *   수정안(PublishPress Revisions 가 만든 draft/pending-revision 글)은 작성한 직원에게 edit_post 가 참이므로 정상 흐름은 그대로다.
 *   objectID 0(updateMeta 의 사이트 편집기 홈 화면 경로 — rank_math_titles 권한 필요)은 Rank Math 자체 판정에 맡긴다.
 * 경로 식별: 요청 경로(대소문자·끝 / 무시 — 워드프레스 경로 비교와 같게) 또는 실제로 실행될 Rank Math 처리기 이름.
 *   경로·처리기 이름이 업데이트로 바뀌면 tests/roles.test.php 의 등록 확인 시험이 실패한다.
 */

namespace Iwell\Core;

use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || exit;

final class ApprovalGuard {
	public const RANK_MATH_ROUTES = array(
		'/rankmath/v1/updateMeta',
		'/rankmath/v1/updateMetaBulk',
		'/rankmath/v1/updateSchemas',
		'/rankmath/v1/updateRedirection',
	);

	/** 위 경로의 처리기(Rank Math 1.0.282 RankMath\Rest\Shared · RankMath\Rest\Post 메서드). */
	private const RANK_MATH_CALLBACKS = array( 'update_metadata', 'update_bulk_meta', 'update_schemas', 'update_redirection' );

	public static function register(): void {
		add_filter( 'rest_request_before_callbacks', array( self::class, 'rest_request_before_callbacks' ), 10, 3 );
		add_action( 'wp_ajax_rank_math_mark_page_as', array( self::class, 'guard_mark_page_as' ), 1 );
	}

	public static function is_guarded( WP_REST_Request $request, array $handler ): bool {
		$route = strtolower( untrailingslashit( $request->get_route() ) );
		if ( in_array( $route, array_map( 'strtolower', self::RANK_MATH_ROUTES ), true ) ) {
			return true;
		}
		$callback = $handler['callback'] ?? null;
		return is_array( $callback )
			&& isset( $callback[0], $callback[1] )
			&& is_object( $callback[0] )
			&& str_starts_with( get_class( $callback[0] ), 'RankMath\\' )
			&& in_array( $callback[1], self::RANK_MATH_CALLBACKS, true );
	}

	/**
	 * 권한 확인(permission_callback)보다 먼저 불린다(WP_REST_Server::respond_to_request).
	 *
	 * @param mixed $response
	 * @param array $handler
	 * @param mixed $request
	 * @return mixed
	 */
	public static function rest_request_before_callbacks( $response, $handler, $request ) {
		if ( is_wp_error( $response ) || ! $request instanceof WP_REST_Request || ! self::is_guarded( $request, (array) $handler ) ) {
			return $response;
		}
		$denied = self::denied_objects( $request );
		if ( array() === $denied ) {
			return $response;
		}
		return new WP_Error(
			'iwell_approval_required',
			'게시된 내용의 SEO 설정은 바로 바꿀 수 없습니다. 수정안을 만들어 원장 승인을 받으세요.',
			array(
				'status'  => 403,
				'objects' => $denied,
			)
		);
	}

	/** @return int[] 이 요청이 건드리지만 현재 사용자가 수정할 수 없는 대상 id. */
	public static function denied_objects( WP_REST_Request $request ): array {
		$type = $request->get_param( 'objectType' );
		$type = is_string( $type ) ? $type : 'post';
		if ( '/rankmath/v1/updatemetabulk' === strtolower( untrailingslashit( $request->get_route() ) ) || null !== $request->get_param( 'rows' ) ) {
			$rows = $request->get_param( 'rows' );
			$ids  = is_array( $rows ) ? array_map( 'absint', array_keys( $rows ) ) : array();
			// updateMetaBulk 는 'term' 이 아니면 모두 글로 처리한다(class-post.php:112-139).
			$type = 'term' === $type ? 'term' : 'post';
		} else {
			$ids = array( absint( $request->get_param( 'objectID' ) ) );
		}
		$denied = array();
		foreach ( array_unique( $ids ) as $id ) {
			if ( $id > 0 && ! self::can_edit_object( $type, $id ) ) {
				$denied[] = $id;
			}
		}
		return $denied;
	}

	/** 관리 막대 AJAX(noindex·nofollow·필러 표시)도 같은 판정. Rank Math 처리기(우선순위 10)보다 먼저 돈다. */
	public static function guard_mark_page_as(): void {
		if ( self::mark_page_as_denied( wp_unslash( $_POST ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- 거부만 한다(허용은 Rank Math 가 nonce 확인).
			wp_die( '게시된 내용의 SEO 설정은 바로 바꿀 수 없습니다. 수정안을 만들어 원장 승인을 받으세요.', '', array( 'response' => 403 ) );
		}
	}

	public static function mark_page_as_denied( array $post ): bool {
		$id = absint( $post['objectID'] ?? 0 );
		return $id > 0 && ! self::can_edit_object( is_string( $post['objectType'] ?? null ) ? $post['objectType'] : 'post', $id );
	}

	private static function can_edit_object( string $type, int $id ): bool {
		switch ( $type ) {
			case 'term':
				return current_user_can( 'edit_term', $id );
			case 'user':
				return current_user_can( 'edit_user', $id );
			default:
				return current_user_can( 'edit_post', $id );
		}
	}
}
