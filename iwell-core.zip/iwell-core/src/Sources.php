<?php
/**
 * 고정 페이지의 공개 원천 의존성 해석기(Task 6 수정 7 결정 2 — 하나로 통일).
 *
 * 고정 페이지 공개 화면이 그때그때 읽는 다른 글: 동기화 패턴(core/block ref — 재귀·순환, 깊이 MAX_DEPTH)과 첨부(대표 이미지 포함).
 * 이 한 함수(of)가 "무엇이 의존성인가"를 정하고, 다음 셋이 모두 같은 결과를 쓴다:
 *   ① 직원·봇의 첨부 수정·삭제 차단(Roles::map_meta_cap → PageMeta::attachmentInApprovedUse → pagesUsing)
 *   ② 관리자·로그인 없는 코드가 패턴·첨부를 바꿀 때 그것을 쓰는 페이지 lapse(PageMeta — pagesUsing)
 *   ③ 승인 지문(Seal::parts — 결정 1)
 *
 * 의존성으로 보는 것(공개 출력이 실제로 그 글을 읽는 자리만 — C4 평문 ids=362 는 아님):
 *   - 블록 속성: core/block 의 ref(parse_blocks 로 확정 — JSON 공백 "ref": 351 포함, C2), 그 밖의 블록의 id·mediaId(정수)·ids(정수 목록)
 *     (core/image·cover·media-text·video·audio·file·gallery 옛 형식 — 워드프레스가 그 첨부를 읽어 그린다)
 *   - 본문 HTML 의 wp-image-{id} 클래스(워드프레스 wp_filter_content_tags 가 그 첨부 메타로 srcset·크기를 붙인다 — classic 본문 포함)
 *   - 실제 [gallery]·[playlist] 짧은 코드(get_shortcode_regex + shortcode_parse_atts — 이스케이프한 [[gallery]] 는 글자 그대로라 제외):
 *     ids·include 의 정수, 둘 다 없으면 그 짧은 코드가 그려지는 페이지(또는 id 속성의 글)에 붙은 첨부(post_parent — gallery_shortcode 와 같은 조회).
 *     수정 9 부터 짧은 코드가 든 페이지는 검토 불가지만, 게시 페이지가 쓰는 첨부라 직원·봇 차단(①)에는 그대로 쓴다.
 *   - 업로드 폴더 파일 주소(크기 변형 -{w}x{h}·-scaled 포함) → _wp_attached_file 이 그 파일인 첨부
 *   - 대표 이미지(_thumbnail_id)
 *   - Rank Math FAQ 블록의 questions[].imageID·imageUrl, 질문 제목·답 문자열 안의 위 참조(faqReads — 수정 9 결정 2, Codex 재확인 5 F2)
 * 수정 10 결정 2: 원장 승인 때 지문 렌더(Fingerprint)가 실제로 읽은 첨부·렌더한 패턴(관찰 목록 — 페이지 메타 Fingerprint::DEP_KEY)도 합친다(pagesUsing —
 *   기존 해석기 결과 ∪ 관찰 목록). 해석기는 그대로 겹으로 둔다(검토 불가 판정·승인 전 페이지의 직원 차단).
 * 역방향(pagesUsing — 이 패턴·첨부를 쓰는 페이지)은 후보를 넓게 찾고(본문에 그 숫자·파일 이름이 있는 페이지·패턴, 대표 이미지, 첨부가 붙은 글,
 * 그 패턴을 다시 쓰는 패턴) of() 로 확정한다 — 다른 ID 의 부분 일치("ref":3510)·평문은 여기서 빠진다.
 *
 * 같은 요청 안에서 결과를 기억하고, 글·메타가 바뀌면(clean_post_cache·글 메타 쓰기·글 삭제) 비운다.
 *
 * 해석 불완전·검토 불가 원천(Task 6 수정 8 — Codex 재확인 4 F1 뒤 코디네이터 결정): of() 의 'unresolved' 가 비어 있지 않으면 그 페이지의 공개 출력은
 * 위 의존성만으로 정해지지 않는다 → 모든 소비처가 닫힌 쪽으로 판정한다(Seal::sealable — 검토 기록 없음, pagesUsing — TOO_DEEP 이면 "사용 중").
 *   - TOO_DEEP(결정 1): 워드프레스는 중첩 동기화 패턴을 깊이 한도 없이 그린다(render_block_core_block 은 같은 패턴 반복만 막는다 — 1000단계 실측,
 *     t6-fix8 보고). 여기서는 방문 집합으로 순환을 막고 끝까지 따라가되 안전 상한 MAX_DEPTH 를 넘는 패턴이 있으면 해석을 멈추고 불완전으로 표시한다.
 *   - block:{이름}·shortcode:{이름}·binding:{원천}(결정 2): 공개 출력이 다른 글·댓글·사용자 프로필·사이트 설정·외부 주소를 그때그때 읽는 동적 블록
 *     (SEALABLE_BLOCKS 밖의 서버 렌더 블록 — core/query·latest-posts·rss·latest-comments·post-author-*·template-part·pattern·navigation·page-list·
 *     breadcrumbs·site-title 등, 수정 9 부터는 gallery·post-date·post-terms 처럼 T2~T5 가 쓰지 않는 블록도), 짧은 코드(등록된 짧은 코드 전부 — 수정 9
 *     부터 허용 목록이 비었다), 블록 연결(metadata.bindings — 패턴 덮어쓰기 밖의 원천: core/post-meta 등). 목록 밖의 새 동적 블록·짧은 코드도 같은 쪽(닫힌 쪽).
 *   - 허용 목록은 "필요한 최소"(수정 9 결정 1)이고 새 블록은 docs/review-blocks.md 의 블록 추가 규칙으로만 넣는다.
 */

namespace Iwell\Core;

use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Sources {
	/**
	 * 중첩 동기화 패턴을 따라가는 안전 상한(수정 8 결정 1). 워드프레스 렌더는 한도가 없다(같은 패턴 반복만 $seen_refs 로 막는다) — 실제 의학 페이지는
	 * 1~2단계라 64 는 여유가 크고, 한 단계마다 글 1개 읽기·블록 해석 1번이라 비용의 위쪽 끝을 정한다. 넘으면 TOO_DEEP(닫힌 쪽).
	 */
	public const MAX_DEPTH = 64;

	/** 해석 불완전 사유(결정 1) — 안전 상한을 넘는 중첩 패턴이 있다. */
	public const TOO_DEEP = 'depth';

	/**
	 * 지문 안에서 검토할 수 있는 서버 렌더(동적) 블록 — **T2~T5 에 실제로 필요한 최소**(수정 9 결정 1, Codex 재확인 5 F1~F4 뒤 코디네이터 결정).
	 * 수정 3~8 에서 허용 목록 블록이 "무엇을 읽는지 다 알 수 없는" 조합(gallery 동적 원천·FAQ/HowTo imageID·post-date 전역 날짜 형식·post-terms 용어)으로
	 * 매번 새 우회가 나왔다 → T1~T5 패턴·dev 시드·설계서 §5 가 쓰는 블록만 남기고, 남은 블록마다 읽는 것을 전부 수집한다(아래 주석 = 읽는 것 · 수집 위치).
	 * 정적 블록(core/paragraph·list-item·table·group — 저장 HTML 만, 렌더 콜백 없음)은 목록과 상관없다. 목록 밖 동적 블록은 검토 불가(닫힌 쪽).
	 * 새 블록을 넣으려면 docs/review-blocks.md 의 "블록 추가 규칙"(읽는 것 전부 → 이 파일에서 수집 → 시험: 직원 403·관리자 lapse·지문 → 목록)을 따른다.
	 *
	 * 테마 iwell 블록(Task 7 — 수정 3 코디네이터 결정)은 하나도 넣지 않는다: T2 끝의 관련 페이지(다른 게시 페이지 제목·주소 — 탐색 장치)·예약·전화(병원
	 * 설정)·출처(자기 페이지 iwell_sources — 검토 대상 메타라 지문 안)는 본문이 아니라 고정 페이지 템플릿(page.html)이 그리고(템플릿은 검토 범위 밖 — 결정 4),
	 * 홈 블록은 홈 템플릿·패턴에만 있다. 본문에 넣으면 이 목록 밖 서버 렌더 블록이라 그 페이지는 검토 불가(분류 표는 Task 7 수정 3 보고서).
	 */
	private const SEALABLE_BLOCKS = array(
		'core/block',                // 동기화 패턴 본문·공개 상태·비밀번호·덮어쓰기 값(ref 재귀 — of() 의 큐, 지문 Seal::parts 'block:').
		'core/footnotes',            // 자기 페이지 footnotes 메타(검토 대상 메타 — PageMeta::REVIEWED_META).
		'core/image',                // 저장 HTML·속성 + 첨부 id/wp-image-{id}/업로드 주소(scan() ID_ATTRS·wp-image·uploadPaths) + 전역 lightbox 설정(테마 — 범위 밖).
		'core/heading',              // 저장 HTML·속성만(block_core_heading_render — 클래스만 붙임).
		'core/list',                 // 저장 HTML·속성만(block_core_list_render — 클래스만 붙임).
		'core/post-title',           // 자기 페이지 제목(쿼리 밖 — 지문 'post'). isLink 면 자기 주소(슬러그는 기존 예외).
		'core/post-content',         // 자기 페이지 본문(지문 'post' — 같은 본문을 이 해석기가 읽는다).
		'core/post-featured-image',  // 자기 _thumbnail_id(검토 대상 메타 + of() 첨부) · useFirstImageFromPost 면 자기 본문의 첫 이미지(같은 본문 스캔).
		'iwell/today-bar',           // 병원 진료시간 설정·현재 시각 — 명시 예외(코디네이터 결정: 지문 밖, 검토 유지).
		'iwell/hours-table',         // 병원 진료시간 설정 — 명시 예외.
		'iwell/review-badge',        // 자기 검토 기록(PageMeta::verifiedReview — 출력 직전 지문 재검사).
		'rank-math/faq-block',       // 속성(본문)의 질문·답 + questions[].imageID·imageUrl 첨부(scan() faqReads — 수정 9 결정 2), 답·제목 문자열도 본문 규칙으로 스캔.
		'rank-math/rich-snippet',    // 고정 페이지에서는 빈 출력(Graph::dropSchemaShortcode — 수정 6 ④ ②).
	);

	/**
	 * 지문 안에서 검토할 수 있는 짧은 코드 — 없음(수정 9 결정 1, 질문 답 A). T2~T5 는 짧은 코드를 쓰지 않고, 남겨 두면 같은 종류 미수집 경로가 있다
	 * ([audio]/[video] 의 src 없음 → get_attached_media·[playlist] 첨부의 대표 이미지 — wp-includes/media.php:3599·3858·3358). 해석된 본문(패턴·FAQ 문자열
	 * 포함)에 등록된 짧은 코드가 있으면 검토 불가. 이스케이프한 [[…]] 는 글자 그대로라 제외. 원격 embed(줄 단독 주소 자동 embed)는 보고만(수정 8 결정 5).
	 */
	private const SEALABLE_SHORTCODES = array();

	/** FAQ 블록(rank-math/faq-block)의 질문 목록 속성 — imageID·imageUrl·title·content 를 읽는다(blocks/faq/class-block-faq.php markup·add_graph). */
	private const FAQ_BLOCK = 'rank-math/faq-block';

	/** 검토할 수 있는 블록 연결(metadata.bindings) 원천 — 패턴 덮어쓰기(값이 페이지 본문의 core/block 속성에 저장된다). */
	private const SEALABLE_BINDINGS = array( 'core/pattern-overrides' );

	/** 첨부 ID 로 읽는 블록 속성(정수 하나·정수 목록). */
	private const ID_ATTRS   = array( 'id', 'mediaId' );
	private const LIST_ATTRS = array( 'ids' );

	/** 첨부를 그리는 짧은 코드(wp-includes/media.php gallery_shortcode·wp_playlist_shortcode). */
	private const MEDIA_SHORTCODES = array( 'gallery', 'playlist' );

	/** @var array<string, mixed> 요청 안 기억(글·메타 쓰기 때 비움). */
	private static array $memo = array();

	public static function register(): void {
		add_action( 'clean_post_cache', array( self::class, 'flush' ) );
		add_action( 'deleted_post', array( self::class, 'flush' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'flush' ) );
		}
	}

	public static function flush(): void {
		self::$memo = array();
	}

	/**
	 * 검토할 수 없는 블록이면 사유 'block:{이름}', 아니면 null — 등록된 서버 렌더(동적) 블록 가운데 SEALABLE_BLOCKS 밖(수정 8 결정 2·수정 9 결정 1).
	 * 원본 검사(scan)와 지문 렌더 중 실행 감시(Fingerprint — 수정 11 C7-2)가 같은 규칙을 쓴다(규칙은 여기 한 곳).
	 */
	public static function unsealableBlock( string $name ): ?string {
		if ( '' === $name || in_array( $name, self::SEALABLE_BLOCKS, true ) ) {
			return null;
		}
		$type = \WP_Block_Type_Registry::get_instance()->get_registered( $name );
		return $type instanceof \WP_Block_Type && $type->is_dynamic() ? "block:$name" : null;
	}

	/** 검토할 수 없는 짧은 코드면 사유 'shortcode:{이름}', 아니면 null — 허용 목록(SEALABLE_SHORTCODES)은 비어 있다(수정 9 결정 1). 원본 검사·렌더 감시 공용. */
	public static function unsealableShortcode( string $tag ): ?string {
		return in_array( $tag, self::SEALABLE_SHORTCODES, true ) ? null : "shortcode:$tag";
	}

	/**
	 * 이 글(고정 페이지·수정안)의 공개 원천 의존성.
	 *
	 * @return array{blocks: int[], attachments: int[], unresolved: string[]} 정렬된 ID 목록(없는 글·첨부 아닌 글의 ID 도 그대로 — 지문에서 'missing'),
	 *         unresolved = 해석 불완전·검토 불가 사유(TOO_DEEP·block:…·shortcode:…·binding:… — 비어 있어야 검토 기록을 붙일 수 있다, 수정 8).
	 */
	public static function of( WP_Post $post ): array {
		$key = 'of:' . $post->ID;
		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}
		$blocks      = array();
		$attachments = array();
		$paths       = array();
		$parents     = array();
		$unresolved  = array();
		// 너비 우선 — 패턴마다 가장 얕은 깊이에서 한 번만 펼친다(방문 집합 $blocks 가 순환을 막는다). 깊이 d 본문의 ref 는 d < MAX_DEPTH 일 때만 펼친다.
		$queue = array( array( (string) $post->post_content, 0 ) );
		while ( array() !== $queue ) {
			list( $content, $depth ) = array_shift( $queue );
			$found                   = self::scan( $content );
			foreach ( $found['refs'] as $ref ) {
				if ( isset( $blocks[ $ref ] ) ) {
					continue; // 순환·같은 패턴 다시 — 한 번만 펼친다.
				}
				$blocks[ $ref ] = true;
				if ( $depth >= self::MAX_DEPTH ) {
					$unresolved[ self::TOO_DEEP ] = true; // 안전 상한 — 그 안을 모른다(결정 1, 닫힌 쪽).
					continue;
				}
				$pattern = get_post( $ref );
				if ( $pattern instanceof WP_Post && PageMeta::PATTERN_TYPE === $pattern->post_type ) {
					$queue[] = array( (string) $pattern->post_content, $depth + 1 );
				}
			}
			$unresolved  += array_fill_keys( $found['external'], true );
			$attachments += array_fill_keys( $found['ids'], true );
			$paths       += array_fill_keys( $found['paths'], true );
			foreach ( $found['parents'] as $parent ) {
				$parents[ 0 === $parent ? $post->ID : $parent ] = true; // 0 = 그 짧은 코드가 그려지는 페이지(패턴 안이어도 페이지).
			}
		}
		$thumb = absint( get_post_meta( $post->ID, '_thumbnail_id', true ) );
		if ( $thumb > 0 ) {
			$attachments[ $thumb ] = true;
		}
		$attachments += array_fill_keys( self::attachmentsByPath( array_keys( $paths ) ), true );
		$attachments += array_fill_keys( self::attachmentsOf( array_keys( $parents ) ), true );
		$blocks       = array_map( 'intval', array_keys( $blocks ) );
		$attachments  = array_values( array_filter( array_map( 'intval', array_keys( $attachments ) ), static fn( int $id ): bool => $id > 0 ) );
		$unresolved   = array_keys( $unresolved );
		sort( $blocks );
		sort( $attachments );
		sort( $unresolved );
		self::$memo[ $key ] = array(
			'blocks'      => $blocks,
			'attachments' => $attachments,
			'unresolved'  => $unresolved,
		);
		return self::$memo[ $key ];
	}

	/**
	 * 이 패턴('block')·첨부('attachment')를 쓰는 고정 페이지(수정안 포함). $approved_only = 게시·예약·비공개 고정 페이지(수정안 제외)와
	 * 예약 승인 수정안만(직원·봇 차단 기준 — 수정 5 F2 ③), 아니면 자동 초안·수정본·휴지통 밖 모두(lapse 가 상태별로 정한다).
	 * 후보(본문에 그 숫자·파일 이름이 있는 페이지 — 패턴 사슬은 깊이 한도 없이 거슬러 올라간다) 가운데 해석이 안전 상한에서 멈춘 페이지(TOO_DEEP)는
	 * 그 안에서 쓰는지 알 수 없으므로 "사용 중"으로 본다(수정 8 결정 1 — 직원·봇 403, 관리자 변경은 lapse).
	 *
	 * @return int[]
	 */
	public static function pagesUsing( string $kind, int $id, bool $approved_only = false, bool $first_only = false ): array {
		$key = "using:$kind:$id:" . (int) $approved_only . (int) $first_only;
		if ( isset( self::$memo[ $key ] ) ) {
			return self::$memo[ $key ];
		}
		$pages = array();
		foreach ( self::candidates( $kind, $id ) as $page_id ) {
			$page = get_post( $page_id );
			if ( ! $page instanceof WP_Post || PageMeta::POST_TYPE !== $page->post_type || ! self::statusMatches( $page, $approved_only ) ) {
				continue;
			}
			$deps = self::of( $page );
			// 기존 해석기 결과 ∪ 승인 때 지문 렌더가 관찰한 의존성(수정 10 결정 2 — 각주·덮어쓰기 안 짧은 코드처럼 입력 예측이 놓친 것).
			if ( in_array( $id, 'block' === $kind ? $deps['blocks'] : $deps['attachments'], true ) || in_array( self::TOO_DEEP, $deps['unresolved'], true )
				|| Fingerprint::observes( $page->ID, $kind, $id ) ) {
				$pages[] = $page->ID;
				if ( $first_only ) {
					break;
				}
			}
		}
		sort( $pages );
		self::$memo[ $key ] = $pages;
		return $pages;
	}

	/** 게시·예약·비공개 고정 페이지(수정안 제외)·예약 승인 수정안(휴지통·수정본 제외) — $approved_only 가 아니면 자동 초안·수정본·휴지통 밖 모두. */
	private static function statusMatches( WP_Post $page, bool $approved_only ): bool {
		if ( in_array( $page->post_status, array( 'auto-draft', 'inherit', 'trash' ), true ) ) {
			return false;
		}
		if ( ! $approved_only ) {
			return true;
		}
		if ( PageMeta::SCHEDULED_REVISION === $page->post_mime_type ) {
			return true;
		}
		return in_array( $page->post_status, array( 'publish', 'future', 'private' ), true ) && ! in_array( $page->post_mime_type, PageMeta::REVISION_MIME_TYPES, true );
	}

	/**
	 * 역방향 후보(넓게 — of() 로 확정한다): 본문에 그 숫자(또는 첨부 파일 이름)가 있는 고정 페이지·패턴, 첨부면 대표 이미지로 쓰는 페이지와
	 * 첨부가 붙은 글(post_parent — 짧은 코드 기본값). 후보 패턴은 그 패턴을 다시 쓰는 페이지·패턴으로 넓힌다(순환 멈춤).
	 *
	 * @return int[] 고정 페이지 ID(수정안 포함)
	 */
	private static function candidates( string $kind, int $id ): array {
		global $wpdb;
		$needles = array( (string) $id );
		$pages   = array();
		if ( 'attachment' === $kind ) {
			$file = (string) get_post_meta( $id, '_wp_attached_file', true );
			if ( '' !== $file ) {
				$needles[] = (string) preg_replace( '/(?:-scaled)?\.[^.\/]+$/', '', wp_basename( $file ) );
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 대표 이미지로 쓰는 글.
			foreach ( $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %s", (string) $id ) ) as $page_id ) {
				$pages[ (int) $page_id ] = true;
			}
			$attachment = get_post( $id );
			if ( $attachment instanceof WP_Post && (int) $attachment->post_parent > 0 ) {
				// 짧은 코드 기본값(ids 없음)은 그려지는 페이지에 붙은 첨부를, id 속성은 그 글에 붙은 첨부를 그린다.
				$pages[ (int) $attachment->post_parent ] = true;
				$needles[]                               = (string) $attachment->post_parent;
			}
		}
		foreach ( Fingerprint::pagesObserving( $kind, $id ) as $page_id ) {
			$pages[ $page_id ] = true; // 승인 때 관찰한 의존성(수정 10 결정 2).
		}
		$seen     = array();
		$patterns = array();
		foreach ( self::mentioning( array_values( array_unique( $needles ) ) ) as $row ) {
			self::sortCandidate( $row, $pages, $patterns );
		}
		while ( array() !== $patterns ) {
			$pattern = array_shift( $patterns );
			if ( isset( $seen[ $pattern ] ) ) {
				continue;
			}
			$seen[ $pattern ] = true;
			foreach ( self::mentioning( array( (string) $pattern ) ) as $row ) {
				self::sortCandidate( $row, $pages, $patterns );
			}
		}
		return array_keys( $pages );
	}

	private static function sortCandidate( object $row, array &$pages, array &$patterns ): void {
		if ( PageMeta::PATTERN_TYPE === $row->post_type ) {
			$patterns[] = (int) $row->ID;
		} else {
			$pages[ (int) $row->ID ] = true;
		}
	}

	/** @return object[] 본문에 $needles 중 하나가 있는 고정 페이지·패턴(ID, post_type) — 자동 초안·수정본 제외. */
	private static function mentioning( array $needles ): array {
		global $wpdb;
		$likes = array_map( static fn( string $n ): string => '%' . $wpdb->esc_like( $n ) . '%', $needles );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 자리표시자 수를 맞춤.
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_type FROM {$wpdb->posts}
				WHERE post_type IN (%s, %s) AND post_status NOT IN ('auto-draft', 'inherit')
				AND ( " . implode( ' OR ', array_fill( 0, count( $likes ), 'post_content LIKE %s' ) ) . ' )',
				PageMeta::POST_TYPE,
				PageMeta::PATTERN_TYPE,
				...$likes
			)
		);
		// phpcs:enable
	}

	/**
	 * 본문 하나(페이지·패턴)에서 직접 보이는 참조.
	 *
	 * @return array{refs: int[], ids: int[], paths: string[], parents: int[], external: string[]}
	 */
	private static function scan( string $content ): array {
		$refs     = array();
		$ids      = array();
		$external = array();
		$nested   = array(); // 블록 속성 안의 문자열·주소가 읽는 것(FAQ — 수정 9 결정 2): scan() 결과 모양.
		$walk     = static function ( array $blocks ) use ( &$walk, &$refs, &$ids, &$external, &$nested ): void {
			foreach ( $blocks as $block ) {
				$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array();
				$block_name = $block['blockName'] ?? null;
				if ( null !== $block_name ) {
					// 검토 불가 원천(수정 8 결정 2): 목록 밖 서버 렌더 블록, 패턴 덮어쓰기 밖 블록 연결.
					$reason = self::unsealableBlock( (string) $block_name );
					if ( null !== $reason ) {
						$external[] = $reason;
					}
					$bindings = $attrs['metadata']['bindings'] ?? null;
					foreach ( is_array( $bindings ) ? $bindings : array() as $binding ) {
						$source = is_array( $binding ) && is_string( $binding['source'] ?? null ) ? $binding['source'] : '';
						if ( ! in_array( $source, self::SEALABLE_BINDINGS, true ) ) {
							$external[] = "binding:$source";
						}
					}
				}
				if ( self::FAQ_BLOCK === ( $block['blockName'] ?? '' ) ) {
					$nested[] = self::faqReads( $attrs );
				}
				if ( 'core/block' === ( $block['blockName'] ?? '' ) ) {
					if ( isset( $attrs['ref'] ) && is_numeric( $attrs['ref'] ) ) {
						$refs[] = (int) $attrs['ref'];
					}
				} elseif ( null !== ( $block['blockName'] ?? null ) ) {
					foreach ( self::ID_ATTRS as $name ) {
						if ( isset( $attrs[ $name ] ) && is_numeric( $attrs[ $name ] ) ) {
							$ids[] = (int) $attrs[ $name ];
						}
					}
					foreach ( self::LIST_ATTRS as $name ) {
						foreach ( is_array( $attrs[ $name ] ?? null ) ? $attrs[ $name ] : array() as $value ) {
							if ( is_numeric( $value ) ) {
								$ids[] = (int) $value;
							}
						}
					}
				}
				if ( ! empty( $block['innerBlocks'] ) ) {
					$walk( $block['innerBlocks'] );
				}
			}
		};
		if ( str_contains( $content, '<!--' ) ) {
			$walk( parse_blocks( $content ) );
		}
		if ( preg_match_all( '/\bwp-image-(\d+)\b/', $content, $m ) ) {
			$ids = array_merge( $ids, array_map( 'intval', $m[1] ) );
		}
		$parents = array();
		if ( str_contains( $content, '[' ) && preg_match_all( '/' . get_shortcode_regex( self::MEDIA_SHORTCODES ) . '/', $content, $sets, PREG_SET_ORDER ) ) {
			foreach ( $sets as $sc ) {
				if ( '[' === $sc[1] && ']' === $sc[6] ) {
					continue; // [[gallery …]] — 글자 그대로 출력(do_shortcode_tag).
				}
				$atts = shortcode_parse_atts( $sc[3] );
				$atts = is_array( $atts ) ? $atts : array();
				$list = (string) ( $atts['ids'] ?? $atts['include'] ?? '' );
				if ( '' !== trim( $list ) ) {
					$ids = array_merge( $ids, array_map( 'intval', array_filter( array_map( 'trim', explode( ',', $list ) ), 'is_numeric' ) ) );
				} else {
					$parents[] = absint( $atts['id'] ?? 0 );
				}
			}
		}
		$paths    = self::uploadPaths( $content );
		$external = array_merge( $external, self::externalShortcodes( $content ) );
		foreach ( $nested as $found ) {
			$refs     = array_merge( $refs, $found['refs'] );
			$ids      = array_merge( $ids, $found['ids'] );
			$paths    = array_merge( $paths, $found['paths'] );
			$parents  = array_merge( $parents, $found['parents'] );
			$external = array_merge( $external, $found['external'] );
		}
		return array(
			'refs'     => array_values( array_unique( $refs ) ),
			'ids'      => array_values( array_unique( array_filter( $ids, static fn( int $id ): bool => $id > 0 ) ) ),
			'paths'    => array_values( array_unique( $paths ) ),
			'parents'  => array_values( array_unique( $parents ) ),
			'external' => array_values( array_unique( $external ) ),
		);
	}

	/**
	 * Rank Math FAQ 블록이 공개 출력에서 읽는 것(수정 9 결정 2 — Codex 재확인 5 F2). blocks/faq/class-block-faq.php markup():
	 *   - questions[].imageUrl 이 있으면 그 주소의 img, 없으면 questions[].imageID 첨부(Block::get_image → wp_get_attachment_image — 대체 글·파일·크기 메타를
	 *     그때그때 읽음) → 둘 다 첨부 의존성(imageUrl 은 업로드 파일 주소일 때 _wp_attached_file 로). 보이지 않는 질문 것도 넣는다(닫힌 쪽 — 저장된 값만).
	 *   - questions[].title·content 는 속성 JSON 안의 문자열이라 원문 스캔이 따옴표·슬래시의 JSON 이스케이프(\u0022·\/) 때문에 놓칠 수 있다 — 화면에서는 wp_kses_post·wpautop 뒤
	 *     the_content 의 do_shortcode 가, JSON-LD 에서는 add_graph 의 do_shortcode 가 그린다 → 풀린 문자열을 본문과 같은 규칙(scan)으로 본다
	 *     (wp-image-{id}·업로드 주소·짧은 코드 — 짧은 코드는 검토 불가).
	 * 그 밖의 속성(listStyle·titleWrapper·sizeSlug·클래스·textAlign)은 저장된 값(본문 지문 안). 크기 이름 목록은 테마 설정(범위 밖).
	 *
	 * @return array{refs: int[], ids: int[], paths: string[], parents: int[], external: string[]}
	 */
	private static function faqReads( array $attrs ): array {
		$out       = array(
			'refs'     => array(),
			'ids'      => array(),
			'paths'    => array(),
			'parents'  => array(),
			'external' => array(),
		);
		$questions = $attrs['questions'] ?? null;
		foreach ( is_array( $questions ) ? $questions : array() as $question ) {
			if ( ! is_array( $question ) ) {
				continue;
			}
			if ( isset( $question['imageID'] ) && is_numeric( $question['imageID'] ) ) {
				$out['ids'][] = absint( $question['imageID'] );
			}
			$texts = array();
			if ( is_string( $question['imageUrl'] ?? null ) && '' !== $question['imageUrl'] ) {
				$texts[] = $question['imageUrl'];
			}
			foreach ( array( 'title', 'content' ) as $key ) {
				if ( is_string( $question[ $key ] ?? null ) && '' !== $question[ $key ] ) {
					$texts[] = $question[ $key ];
				}
			}
			foreach ( $texts as $text ) {
				foreach ( self::scan( $text ) as $kind => $values ) {
					$out[ $kind ] = array_merge( $out[ $kind ], $values );
				}
			}
		}
		return $out;
	}

	/**
	 * 본문에서 실제로 실행될 등록된 짧은 코드 가운데 검토할 수 없는 것(수정 8 결정 2) — the_content 의 do_shortcode 는 블록 렌더 뒤 본문 전체(패턴 출력 포함)에
	 * 돈다. 이스케이프한 [[…]] 는 글자 그대로라 제외.
	 *
	 * @return string[] 'shortcode:{이름}'
	 */
	private static function externalShortcodes( string $content ): array {
		global $shortcode_tags;
		if ( ! str_contains( $content, '[' ) || ! is_array( $shortcode_tags ) ) {
			return array();
		}
		$tags = array_values( array_diff( array_keys( $shortcode_tags ), self::SEALABLE_SHORTCODES ) );
		if ( array() === $tags || ! preg_match_all( '/' . get_shortcode_regex( $tags ) . '/', $content, $sets, PREG_SET_ORDER ) ) {
			return array();
		}
		$found = array();
		foreach ( $sets as $sc ) {
			if ( '[' === $sc[1] && ']' === $sc[6] ) {
				continue;
			}
			$found[] = (string) self::unsealableShortcode( $sc[2] ); // $tags 가 이미 허용 목록 밖이라 언제나 사유가 있다.
		}
		return $found;
	}

	/** @return string[] 본문의 업로드 폴더 파일 주소 → 업로드 기준 상대 경로 후보(크기 변형 -{w}x{h} 를 뗀 것·-scaled 붙인 것 포함). */
	private static function uploadPaths( string $content ): array {
		$base = (string) wp_parse_url( (string) wp_get_upload_dir()['baseurl'], PHP_URL_PATH );
		if ( '' === $base || ! str_contains( $content, $base . '/' ) ) {
			return array();
		}
		if ( ! preg_match_all( '#' . preg_quote( $base, '#' ) . '/([^\s"\'<>()\[\]?\#\\\\]+\.[A-Za-z0-9]{2,5})#', $content, $m ) ) {
			return array();
		}
		$paths = array();
		foreach ( array_unique( $m[1] ) as $rel ) {
			$rel           = rawurldecode( $rel );
			$full          = (string) preg_replace( '/-\d+x\d+(?=\.[^.\/]+$)/', '', $rel );
			$paths[ $rel ] = true;
			$paths[ $full ] = true;
			$paths[ (string) preg_replace( '/(\.[^.\/]+)$/', '-scaled$1', $full ) ] = true;
		}
		return array_keys( $paths );
	}

	/** @return int[] _wp_attached_file 이 $paths 중 하나인 첨부. */
	private static function attachmentsByPath( array $paths ): array {
		if ( array() === $paths ) {
			return array();
		}
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 자리표시자 수를 맞춤.
		return array_map(
			'intval',
			$wpdb->get_col(
				$wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value IN (" . implode( ',', array_fill( 0, count( $paths ), '%s' ) ) . ')',
					...$paths
				)
			)
		);
		// phpcs:enable
	}

	/** @return int[] $parents 에 붙은 첨부(gallery·playlist 짧은 코드에 ids 가 없을 때 그리는 것). */
	private static function attachmentsOf( array $parents ): array {
		$parents = array_values( array_filter( array_map( 'intval', $parents ), static fn( int $id ): bool => $id > 0 ) );
		if ( array() === $parents ) {
			return array();
		}
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 자리표시자 수를 맞춤.
		return array_map(
			'intval',
			$wpdb->get_col(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_parent IN (" . implode( ',', array_fill( 0, count( $parents ), '%d' ) ) . ')',
					...$parents
				)
			)
		);
		// phpcs:enable
	}
}
