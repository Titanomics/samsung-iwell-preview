<?php
/**
 * 워드프레스 기본 댓글·핑백 닫기(코디네이터 지시 2026-11-25 — 근거: 병원 확인 최소화 요약 §2 "댓글 기본 허용 끄기").
 *
 * 왜: 화면에 댓글 양식이 없어도 봇이 wp-comments-post.php·REST /wp/v2/comments·XML-RPC 핑백으로 이름·이메일·IP 를 보낼 수 있다.
 * 이 사이트는 워드프레스 댓글을 쓰지 않으므로(공지·칼럼·고정 페이지 모두) 개인정보가 들어올 통로를 닫는다.
 * 상담 게시판 댓글(KBoard — 자체 표 kboard_comments, Consult\CommentLock)은 워드프레스 댓글이 아니라 이 설정과 무관하다.
 *
 * 하는 일 — 설정 → 토론 화면 값·글마다 저장된 comment_status 와 상관없이 늘:
 *  - comments_open·pings_open → false: 기존 글·페이지·첨부까지 댓글·핑백이 닫힌다
 *    (wp-comments-post.php = wp_handle_comment_submission 'comment_closed' 403, REST 댓글 만들기 'rest_comment_closed' 403, 핑백 거부).
 *  - default_comment_status·default_ping_status 옵션 → 'closed': 새 글·페이지가 닫힌 채 저장되고, 설정 → 토론 화면에도 닫힘으로 보인다.
 *  - XML-RPC 핑백 메서드(pingback.ping·pingback.extensions.getPingbacks)를 뺀다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class Comments {
	/** 빼는 XML-RPC 핑백 메서드. */
	public const XMLRPC_PINGBACK = array( 'pingback.ping', 'pingback.extensions.getPingbacks' );

	public static function register(): void {
		add_filter( 'comments_open', '__return_false', 100 );
		add_filter( 'pings_open', '__return_false', 100 );
		add_filter( 'pre_option_default_comment_status', array( self::class, 'closed' ) );
		add_filter( 'pre_option_default_ping_status', array( self::class, 'closed' ) );
		add_filter( 'xmlrpc_methods', array( self::class, 'xmlrpcMethods' ) );
	}

	/** pre_option_default_comment_status·default_ping_status → 늘 'closed'. */
	public static function closed(): string {
		return 'closed';
	}

	/** XML-RPC 메서드 목록에서 핑백을 뺀다(배열이 아니면 그대로). */
	public static function xmlrpcMethods( mixed $methods ): mixed {
		if ( is_array( $methods ) ) {
			foreach ( self::XMLRPC_PINGBACK as $method ) {
				unset( $methods[ $method ] );
			}
		}
		return $methods;
	}
}
