<?php
/**
 * 원장 칼럼 글 메타 계약(Task 8 — 값 쓰기는 Task 12 네이버 블로그 칼럼 자동 등록).
 *
 * 글(post) 메타 2개 — register_post_meta, REST 노출(show_in_rest), 쓰기 권한 = 관리자(manage_options)·칼럼 봇(iwell_columnbot)만(직원·원장 편집기·
 * 사용자 지정 필드로는 못 쓴다 — 원문 링크·정리일을 손으로 지어 넣지 못하게). Task 12 서버 수신 API(POST /iwell/v1/columns/import)는 update_post_meta 로
 * 직접 쓴다(권한 콜백을 거치지 않는 서버 경로).
 *   - iwell_naver_log_no  네이버 블로그 글 번호(숫자 문자열, 예 '224012345678'). 원문 주소 = https://blog.naver.com/{BLOG_ID}/{logNo}.
 *                         숫자가 아니면 빈 값으로 저장. 같은 번호 중복 방지·잠금은 Task 12.
 *   - iwell_imported_at   홈페이지 정리일 'Y-m-d'(KST — 칼럼을 가져와 이 사이트에 처음 올린 날, Task 12 가 가져올 때 기록). 없는 날짜는 빈 값.
 * 화면(테마 iwell/post-meta — single.html): 칼럼이고 원문 번호가 있으면 "원문 게시 {post_date} · 홈페이지 정리 {imported_at}" + "네이버 블로그 원문" 링크
 * (정리일 없으면 원문 게시만). 구조화 데이터(Graph::column): BlogPosting datePublished = post_date, dateModified = 정리일(있으면)·없으면 post_modified,
 * isBasedOn·sameAs = 원문 주소. Task 12 계약: post_date = 원문 게시 시각(RSS pubDate, 계획 Task 12 "date = 원문 pubDate"), 위 메타 2개를 함께 쓴다.
 */

namespace Iwell\Core\Columns;

use Iwell\Core\PageMeta;
use Iwell\Core\Roles;

defined( 'ABSPATH' ) || exit;

final class Meta {
	public const LOG_NO      = 'iwell_naver_log_no';
	public const IMPORTED_AT = 'iwell_imported_at';

	/** 원장 칼럼 네이버 블로그(계획 Global Constraints — HS columns sync.ts 값). */
	public const BLOG_ID = 'gfph';

	public const ORIGIN = 'https://blog.naver.com/';

	public static function register(): void {
		add_action( 'init', array( self::class, 'registerMeta' ) );
	}

	public static function registerMeta(): void {
		$auth = static function ( $allowed, $meta_key, $post_id, $user_id = 0 ): bool {
			$user_id = (int) ( $user_id ?: get_current_user_id() );
			$user    = $user_id > 0 ? get_userdata( $user_id ) : false;
			if ( ! $user || ! user_can( $user, 'edit_post', (int) $post_id ) ) {
				return false;
			}
			return user_can( $user, 'manage_options' ) || in_array( Roles::COLUMNBOT, (array) $user->roles, true );
		};
		register_post_meta(
			'post',
			self::LOG_NO,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'show_in_rest'      => array(
					'schema' => array(
						'type'    => 'string',
						'pattern' => '^\d*$',
					),
				),
				'sanitize_callback' => array( self::class, 'sanitizeLogNo' ),
				'auth_callback'     => $auth,
			)
		);
		register_post_meta(
			'post',
			self::IMPORTED_AT,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'show_in_rest'      => array(
					'schema' => array(
						'type'    => 'string',
						'pattern' => '^(\d{4}-\d{2}-\d{2})?$',
					),
				),
				'sanitize_callback' => array( PageMeta::class, 'sanitizeDate' ),
				'auth_callback'     => $auth,
			)
		);
	}

	/** 숫자만(앞뒤 공백 제거), 아니면 ''. */
	public static function sanitizeLogNo( $value ): string {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';
		return 1 === preg_match( '/^\d{1,20}$/', $value ) ? $value : '';
	}

	/** 원문 주소 — 원문 번호가 없으면 ''. */
	public static function originalUrl( int $post_id ): string {
		$log_no = self::sanitizeLogNo( get_post_meta( $post_id, self::LOG_NO, true ) );
		return '' === $log_no ? '' : self::ORIGIN . self::BLOG_ID . '/' . $log_no;
	}

	/** 홈페이지 정리일 'Y-m-d' — 없으면 ''. */
	public static function importedAt( int $post_id ): string {
		return PageMeta::sanitizeDate( get_post_meta( $post_id, self::IMPORTED_AT, true ) );
	}
}
