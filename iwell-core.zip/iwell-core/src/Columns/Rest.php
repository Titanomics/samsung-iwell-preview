<?php
/**
 * 칼럼 수신 REST 경로 4개(Task 12 — 계획 src/Rest.php 의 칼럼 몫, 동시 작업 충돌을 피해 Columns/Rest.php 로 둠. 주소는 계획 그대로).
 *   GET  /wp-json/iwell/v1/columns/state    → { imported: string[], attempts: { logNo: ISO } }
 *   POST /wp-json/iwell/v1/columns/attempt  { logNo, reason } → { ok: true }
 *   POST /wp-json/iwell/v1/media/import     { sourceUrl, alt } → 201 { id, url, existing:false } / 200 { …, existing:true }
 *   POST /wp-json/iwell/v1/columns/import   { logNo, title, contentHtml, date, mediaIds } → 201 { id, link, existing:false } / 200 { …, existing:true }
 * 권한: 칼럼 봇(iwell_columnbot) 또는 관리자 — 비로그인 401, 그 밖 403. 인증은 워드프레스 응용 프로그램 비밀번호(도구 tools/column-sync — GitHub Secrets).
 * 동작·중복 방지는 Import.php.
 */

namespace Iwell\Core\Columns;

use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

final class Rest {
	public const NS = 'iwell/v1';

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function routes(): void {
		$permission = array( self::class, 'permission' );
		register_rest_route(
			self::NS,
			'/columns/state',
			array(
				'methods'             => 'GET',
				'callback'            => array( self::class, 'state' ),
				'permission_callback' => $permission,
			)
		);
		register_rest_route(
			self::NS,
			'/columns/attempt',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'attempt' ),
				'permission_callback' => $permission,
			)
		);
		register_rest_route(
			self::NS,
			'/media/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'media' ),
				'permission_callback' => $permission,
			)
		);
		register_rest_route(
			self::NS,
			'/columns/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( self::class, 'column' ),
				'permission_callback' => $permission,
			)
		);
	}

	/** @return true|WP_Error */
	public static function permission() {
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'rest_not_logged_in', '칼럼 봇 응용 프로그램 비밀번호로 인증해야 한다.', array( 'status' => 401 ) );
		}
		return Import::canImport() ? true : new WP_Error( 'rest_forbidden', '칼럼 봇·관리자만 쓸 수 있다.', array( 'status' => 403 ) );
	}

	public static function state(): WP_REST_Response {
		$state = Import::state();
		return new WP_REST_Response(
			array(
				'imported' => $state['imported'],
				// 빈 목록도 JSON 객체({})로(도구는 Record<logNo, ISO> 로 읽는다).
				'attempts' => array() === $state['attempts'] ? new \stdClass() : $state['attempts'],
			),
			200
		);
	}

	/** @return WP_REST_Response|WP_Error */
	public static function attempt( WP_REST_Request $request ) {
		$log_no = Import::logNo( $request->get_param( 'logNo' ) );
		$reason = $request->get_param( 'reason' );
		if ( '' === $log_no || ! is_string( $reason ) || '' === trim( $reason ) ) {
			return new WP_Error( 'iwell_column_attempt', 'logNo(숫자)·reason 이 필요하다.', array( 'status' => 400 ) );
		}
		Import::recordAttempt( $log_no, $reason );
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/** @return WP_REST_Response|WP_Error */
	public static function media( WP_REST_Request $request ) {
		$done = Import::importMedia( $request->get_param( 'sourceUrl' ), $request->get_param( 'alt' ) );
		if ( is_wp_error( $done ) ) {
			return $done;
		}
		return new WP_REST_Response( $done, $done['existing'] ? 200 : 201 );
	}

	/** @return WP_REST_Response|WP_Error */
	public static function column( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		$params = is_array( $params ) ? $params : $request->get_params();
		$done   = Import::importColumn( $params );
		if ( is_wp_error( $done ) ) {
			return $done;
		}
		return new WP_REST_Response( $done, $done['existing'] ? 200 : 201 );
	}
}
