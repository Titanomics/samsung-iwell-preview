<?php
/**
 * 네이버 블로그 칼럼 수신(Task 12) — 사진 등록·글 등록·실패 기록·상태. 상태는 워드프레스 DB 에 영속(글 메타·첨부 메타·옵션).
 * REST 경로는 Rest.php(/wp-json/iwell/v1/columns/state·attempt·import, /media/import). 칼럼 = 원문 그대로(AI 재작성 없음 — 본문은 도구가 만든 블록 마크업 그대로 저장).
 *
 * 중복 방지(계획 Review Focus 4 — 재실행·부분 실패·동시 실행에서 글·사진 중복 0):
 *   - 사진: 서버가 sha256(sourceUrl) 잠금(옵션 iwell_media_lock_{hash}) 안에서 첨부 메타 iwell_source_hash 가 같은 첨부를 찾고, 없을 때만 내려받아
 *     등록(media_sideload_image — 허용 호스트 = 도구 naver.ts 의 IMAGE_HOSTS, https 만). 부분 실패(사진만 올라가고 글 등록 실패) 뒤 재실행은 같은 첨부를 돌려준다.
 *   - 글: 잠금(옵션 iwell_column_lock_{logNo}) 안에서 글 메타 iwell_naver_log_no 가 같은 글(모든 상태 — 휴지통 포함)을 찾고, 없을 때만 넣는다.
 *   - 잠금 = 옵션 행 INSERT IGNORE(워드프레스 WP_Upgrader::create_lock 과 같은 방식). add_option() 은 INSERT … ON DUPLICATE KEY UPDATE 라 두 요청이
 *     겹치면 둘 다 "잡았다"가 될 수 있어(값이 다르면 영향 행 2) 쓰지 않는다. 값 = 잡은 시각(초), TTL 이 지나면 넘겨받는다(죽은 요청 대비).
 *   - 잠금을 못 잡은 쪽은 잠깐 기다리며 상대가 만든 첨부·글을 찾는다(찾으면 existing). 상대가 실패해 잠금이 풀리면 자기가 잡고 한다. 끝내 못 잡으면 409.
 *   - 찾기는 $wpdb 직접 조회(객체 캐시를 거치지 않음 — 다른 요청이 방금 넣은 행을 본다).
 *
 * 글 계약(Task 8 Columns\Meta): post_date = 원문 pubDate(KST, Asia/Seoul) · post_date_gmt = UTC · 카테고리 columns · 공개 · 메타 iwell_naver_log_no ·
 * iwell_imported_at = 가져와 처음 올린 날 'Y-m-d'(KST). 이미 있는 글(existing)은 아무것도 바꾸지 않는다(정리일 포함).
 * 실패 기록: 옵션 iwell_column_attempts = { logNo: { at: ISO UTC, reason } } — 도구가 24시간 재시도 금지에 쓴다. 등록에 성공하면 그 글의 기록을 지운다.
 */

namespace Iwell\Core\Columns;

use DateTimeImmutable;
use DateTimeZone;
use Iwell\Core\Roles;
use WP_Error;

defined( 'ABSPATH' ) || exit;

final class Import {
	public const MEDIA_LOCK_PREFIX  = 'iwell_media_lock_';
	public const COLUMN_LOCK_PREFIX = 'iwell_column_lock_';
	public const ATTEMPTS_OPTION    = 'iwell_column_attempts';
	public const SOURCE_HASH        = 'iwell_source_hash';
	public const SOURCE_URL         = 'iwell_source_url';

	/** 사진 허용 호스트 — 도구 tools/column-sync/src/naver.ts IMAGE_HOSTS(HS naver.ts 그대로)와 같은 값. https 만. */
	public const IMAGE_HOSTS = array( 'postfiles.pstatic.net', 'blogfiles.pstatic.net', 'mblogthumb-phinf.pstatic.net' );

	/** 잠금 수명(초) — 이보다 오래된 잠금은 죽은 요청으로 보고 넘겨받는다. 사진은 내려받기(시한 60초)가 있어 길게. */
	public const MEDIA_LOCK_TTL  = 300;
	public const COLUMN_LOCK_TTL = 120;

	/** 잠금을 못 잡았을 때 기다리는 상한(초)·간격(마이크로초). */
	public const WAIT_SECONDS = 30;
	private const POLL_US     = 250000;

	public const TIMEZONE = 'Asia/Seoul';

	/** 사진 내려받기 UA — 도구 naver.ts·HS images.ts 와 같은 모바일 UA. */
	private const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)';

	/** 정리일 'Y-m-d'(KST) — 가져와 처음 올린 날. */
	public static function importedAtFor( DateTimeImmutable $now ): string {
		return $now->setTimezone( new DateTimeZone( self::TIMEZONE ) )->format( 'Y-m-d' );
	}

	/** 칼럼 봇 또는 관리자(manage_options). */
	public static function canImport(): bool {
		$user = wp_get_current_user();
		return $user->exists() && ( user_can( $user, 'manage_options' ) || in_array( Roles::COLUMNBOT, (array) $user->roles, true ) );
	}

	/**
	 * @return array{imported: list<string>, attempts: array<string, string>}
	 */
	public static function state(): array {
		global $wpdb;
		$imported = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE pm.meta_key = %s AND pm.meta_value <> '' AND p.post_type = 'post' AND p.post_status <> 'auto-draft'",
				Meta::LOG_NO
			)
		);
		$attempts = array();
		foreach ( self::attempts() as $log_no => $row ) {
			$attempts[ (string) $log_no ] = (string) $row['at'];
		}
		return array(
			'imported' => array_values( array_map( 'strval', $imported ) ),
			'attempts' => $attempts,
		);
	}

	/** @return array<string, array{at: string, reason: string}> */
	private static function attempts(): array {
		wp_cache_delete( self::ATTEMPTS_OPTION, 'options' );
		$raw = get_option( self::ATTEMPTS_OPTION, array() );
		return is_array( $raw ) ? $raw : array();
	}

	public static function recordAttempt( string $log_no, string $reason, ?DateTimeImmutable $now = null ): void {
		$now                 ??= new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		$attempts            = self::attempts();
		$attempts[ $log_no ] = array(
			'at'     => $now->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d\TH:i:s\Z' ),
			'reason' => substr( sanitize_key( $reason ), 0, 40 ),
		);
		update_option( self::ATTEMPTS_OPTION, $attempts, false );
	}

	public static function clearAttempt( string $log_no ): void {
		$attempts = self::attempts();
		if ( isset( $attempts[ $log_no ] ) ) {
			unset( $attempts[ $log_no ] );
			update_option( self::ATTEMPTS_OPTION, $attempts, false );
		}
	}

	/** 숫자 logNo(1~20자리)면 그 값, 아니면 ''. */
	public static function logNo( $value ): string {
		return is_string( $value ) || is_int( $value ) ? Meta::sanitizeLogNo( (string) $value ) : '';
	}

	/** https 이고 허용 호스트인 사진 주소인가. */
	public static function allowedImage( $url ): bool {
		if ( ! is_string( $url ) || '' === $url || strlen( $url ) > 2048 || preg_match( '/[\s\x00-\x1f]/', $url ) ) {
			return false;
		}
		$parts = wp_parse_url( $url );
		return is_array( $parts ) && 'https' === strtolower( (string) ( $parts['scheme'] ?? '' ) ) && empty( $parts['user'] ) && empty( $parts['pass'] ) && empty( $parts['port'] )
			&& in_array( strtolower( (string) ( $parts['host'] ?? '' ) ), self::IMAGE_HOSTS, true );
	}

	/**
	 * 잠금 잡기 — 옵션 행 INSERT IGNORE(원자적). 이미 있고 TTL 이 지났으면 그 값일 때만 지우고(조건부 삭제) 다시 한 번 잡는다.
	 */
	public static function acquireLock( string $name, int $ttl ): bool {
		global $wpdb;
		$insert = static fn(): bool => 1 === (int) $wpdb->query(
			$wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'off') /* LOCK */", $name, (string) time() )
		);
		if ( $insert() ) {
			wp_cache_delete( $name, 'options' );
			return true;
		}
		$held = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		if ( null === $held ) {
			return $insert();
		}
		if ( (int) $held > time() - $ttl ) {
			return false;
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $name, $held ) );
		$ok = $insert();
		wp_cache_delete( $name, 'options' );
		return $ok;
	}

	public static function releaseLock( string $name ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		wp_cache_delete( $name, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}

	/** 출처 해시가 같은 첨부 id(가장 작은 id) — 없으면 0. 캐시를 거치지 않는다. */
	private static function findMedia( string $hash ): int {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MIN(p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
				WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = 'attachment'",
				self::SOURCE_HASH,
				$hash
			)
		);
	}

	/** 원문 번호가 같은 글 id(모든 상태 — 휴지통 포함, 자동 초안 제외, 가장 작은 id) — 없으면 0. 캐시를 거치지 않는다. */
	private static function findColumn( string $log_no ): int {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MIN(p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
				WHERE pm.meta_key = %s AND pm.meta_value = %s AND p.post_type = 'post' AND p.post_status <> 'auto-draft'",
				Meta::LOG_NO,
				$log_no
			)
		);
	}

	/**
	 * 잠금 안에서 find → 없으면 make. 잠금을 못 잡으면 기다리며 find(찾으면 existing). 상대가 실패해 잠금이 풀리면 자기가 잡는다.
	 *
	 * @param callable(): int                 $find
	 * @param callable(): (int|WP_Error)      $make
	 * @return array{id: int, existing: bool}|WP_Error
	 */
	private static function once( string $lock, int $ttl, callable $find, callable $make, int $wait_seconds ) {
		$deadline = microtime( true ) + max( 0, $wait_seconds );
		while ( true ) {
			$found = $find();
			if ( $found > 0 ) {
				return array( 'id' => $found, 'existing' => true );
			}
			if ( self::acquireLock( $lock, $ttl ) ) {
				try {
					$found = $find();
					if ( $found > 0 ) {
						return array( 'id' => $found, 'existing' => true );
					}
					$made = $make();
					return is_wp_error( $made ) ? $made : array( 'id' => (int) $made, 'existing' => false );
				} finally {
					self::releaseLock( $lock );
				}
			}
			if ( microtime( true ) >= $deadline ) {
				return new WP_Error( 'iwell_import_busy', '같은 항목을 다른 실행이 등록하는 중이다. 다음 실행에서 다시 시도한다.', array( 'status' => 409 ) );
			}
			usleep( self::POLL_US );
		}
	}

	/**
	 * 사진 등록 — 같은 sourceUrl 이면 같은 첨부.
	 *
	 * @return array{id: int, url: string, existing: bool}|WP_Error
	 */
	public static function importMedia( $source_url, $alt, int $wait_seconds = self::WAIT_SECONDS ) {
		if ( ! self::allowedImage( $source_url ) ) {
			return new WP_Error( 'iwell_media_source', '사진 주소는 네이버 블로그 사진 서버(https)만 받는다.', array( 'status' => 400 ) );
		}
		$alt  = is_string( $alt ) ? sanitize_text_field( $alt ) : '';
		$hash = hash( 'sha256', $source_url );
		$done = self::once(
			self::MEDIA_LOCK_PREFIX . $hash,
			self::MEDIA_LOCK_TTL,
			static fn(): int => self::findMedia( $hash ),
			static fn() => self::sideload( $source_url, $alt, $hash ),
			$wait_seconds
		);
		if ( is_wp_error( $done ) ) {
			return $done;
		}
		return array(
			'id'       => $done['id'],
			'url'      => (string) wp_get_attachment_url( $done['id'] ),
			'existing' => $done['existing'],
		);
	}

	/** @return int|WP_Error 새 첨부 id */
	private static function sideload( string $source_url, string $alt, string $hash ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		// 네이버 사진 서버 요청만: 도구(HS images.ts)와 같은 모바일 UA·image/* · 시한 30초(download_url 기본 300초 대신).
		$args = static function ( $parsed, $url ) {
			if ( is_array( $parsed ) && self::allowedImage( $url ) ) {
				$parsed['user-agent']        = self::UA;
				$parsed['timeout']           = 30;
				$parsed['headers']           = is_array( $parsed['headers'] ?? null ) ? $parsed['headers'] : array();
				$parsed['headers']['Accept'] = 'image/*';
			}
			return $parsed;
		};
		add_filter( 'http_request_args', $args, 10, 2 );
		try {
			$id = media_sideload_image( $source_url, 0, null, 'id' );
		} finally {
			remove_filter( 'http_request_args', $args, 10 );
		}
		if ( is_wp_error( $id ) ) {
			return new WP_Error( 'iwell_media_download', '사진을 내려받지 못했다: ' . $id->get_error_message(), array( 'status' => 502 ) );
		}
		$id = (int) $id;
		update_post_meta( $id, self::SOURCE_HASH, $hash );
		update_post_meta( $id, self::SOURCE_URL, esc_url_raw( $source_url ) );
		if ( '' !== $alt ) {
			update_post_meta( $id, '_wp_attachment_image_alt', $alt );
		}
		return $id;
	}

	/**
	 * 글 등록 — 같은 logNo 이면 그 글(existing, 아무것도 바꾸지 않음).
	 *
	 * @param array $payload { logNo, title, contentHtml, date, mediaIds }
	 * @return array{id: int, link: string, existing: bool}|WP_Error
	 */
	public static function importColumn( array $payload, int $wait_seconds = self::WAIT_SECONDS, ?DateTimeImmutable $now = null ) {
		$log_no  = self::logNo( $payload['logNo'] ?? null );
		$title   = is_string( $payload['title'] ?? null ) ? trim( $payload['title'] ) : '';
		$content = is_string( $payload['contentHtml'] ?? null ) ? $payload['contentHtml'] : '';
		$date    = self::parseDate( $payload['date'] ?? null );
		$media   = self::mediaIds( $payload['mediaIds'] ?? array() );
		if ( '' === $log_no ) {
			return self::bad( 'logNo 는 숫자여야 한다.' );
		}
		if ( '' === $title ) {
			return self::bad( 'title 이 비었다.' );
		}
		if ( '' === trim( $content ) ) {
			return self::bad( 'contentHtml 이 비었다.' );
		}
		if ( null === $date ) {
			return self::bad( 'date 는 ISO 8601 시각이어야 한다(원문 pubDate).' );
		}
		if ( null === $media ) {
			return self::bad( 'mediaIds 는 첨부 id 목록이어야 한다.' );
		}
		$category = get_term_by( 'slug', Roles::COLUMNS, 'category' );
		if ( ! $category ) {
			return new WP_Error( 'iwell_columns_category', '원장 칼럼(columns) 카테고리가 없다 — iwell-core 활성화를 확인한다.', array( 'status' => 500 ) );
		}
		$now  ??= new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		$kst    = new DateTimeZone( self::TIMEZONE );
		$utc    = new DateTimeZone( 'UTC' );
		$done   = self::once(
			self::COLUMN_LOCK_PREFIX . $log_no,
			self::COLUMN_LOCK_TTL,
			static fn(): int => self::findColumn( $log_no ),
			static function () use ( $log_no, $title, $content, $date, $media, $category, $now, $kst, $utc ) {
				/** 잠금 안·넣기 직전(로컬 시험이 동시 실행을 겹치게 하는 자리 — dev/mu-plugins/iwell-column-fixtures.php). */
				do_action( 'iwell_columns_before_insert', $log_no, $title );
				$id = wp_insert_post(
					array(
						'post_type'     => 'post',
						'post_status'   => 'publish',
						'post_title'    => $title,
						'post_content'  => $content,
						'post_date'     => $date->setTimezone( $kst )->format( 'Y-m-d H:i:s' ),
						'post_date_gmt' => $date->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
						'post_category' => array( (int) $category->term_id ),
						'post_author'   => get_current_user_id(),
						'meta_input'    => array(
							Meta::LOG_NO      => $log_no,
							Meta::IMPORTED_AT => self::importedAtFor( $now ),
						),
					),
					true
				);
				if ( is_wp_error( $id ) || 0 === (int) $id ) {
					return new WP_Error( 'iwell_column_insert', '칼럼 글을 만들지 못했다.', array( 'status' => 500 ) );
				}
				foreach ( $media as $attachment ) {
					if ( 0 === (int) get_post( $attachment )->post_parent ) {
						wp_update_post(
							array(
								'ID'          => $attachment,
								'post_parent' => (int) $id,
							)
						);
					}
				}
				self::clearAttempt( $log_no );
				return (int) $id;
			},
			$wait_seconds
		);
		if ( is_wp_error( $done ) ) {
			return $done;
		}
		return array(
			'id'       => $done['id'],
			'link'     => (string) get_permalink( $done['id'] ),
			'existing' => $done['existing'],
		);
	}

	/** ISO 8601(시간대 포함) → 시각, 아니면 null. */
	private static function parseDate( $value ): ?DateTimeImmutable {
		if ( ! is_string( $value ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})$/', $value ) ) {
			return null;
		}
		try {
			return new DateTimeImmutable( $value );
		} catch ( \Exception $e ) {
			return null;
		}
	}

	/** @return list<int>|null 모두 첨부 id 이면 그 목록, 아니면 null. */
	private static function mediaIds( $value ): ?array {
		if ( ! is_array( $value ) ) {
			return null;
		}
		$out = array();
		foreach ( $value as $id ) {
			if ( ! is_int( $id ) || $id <= 0 || 'attachment' !== get_post_type( $id ) ) {
				return null;
			}
			$out[] = $id;
		}
		return array_values( array_unique( $out ) );
	}

	private static function bad( string $message ): WP_Error {
		return new WP_Error( 'iwell_column_payload', $message, array( 'status' => 400 ) );
	}
}
