<?php
/**
 * 진료시간 관리자 화면(Task 5) — 메뉴 `진료시간`(권한 iwell_manage_hours: 직원·원장·관리자, Roles.php).
 *
 * 하는 일: 날짜별 예외(임시 휴진 + 사유, 또는 임시 진료시간) 추가·삭제. 저장값 = 옵션 iwell_hours 의 `exceptions`
 * (그 밖의 키는 그대로 둔다). 요일별 진료시간은 이 화면에서 바꾸지 않는다(병원 확인값, config/hours.php) — 화면에는 표로만 보인다.
 *
 * 저장 요청(admin-post.php, action iwell_hours_add·iwell_hours_delete) 검사 순서:
 *  1) POST 만(그 밖 405) 2) 권한 iwell_manage_hours(없으면 403) 3) nonce(Admin::NONCE, 틀리거나 없으면 403 — check_admin_referer).
 *  비로그인 요청은 admin-post.php 가 400 으로 끝낸다(nopriv 처리기를 걸지 않음).
 * 입력 검사 = Store::exceptions()(Store::config()와 같은 규칙 — 날짜 'YYYY-MM-DD' 실제 날짜, 시간 'HH:MM' 00:00~23:59, 시작 < 끝,
 *  사유 제어문자 정리). 통과 못 하면 저장하지 않고 고정 문구 오류 안내(입력값을 되비추지 않음). 화면 쪽 추가 규칙: 사유 100자 이내, 세션 4개 이내.
 *  날짜·종류·사유·세션 값이 문자열이 아니면(reason[]=x 등) 거부하고 기존 값을 그대로 둔다. 사유 칸이 아예 없으면 사유 없는 휴진(선택 항목).
 * 저장할 때 옵션에 이미 있던 예외도 같은 검사를 다시 거친다(틀린 항목은 버림).
 * 임시 휴진 공지 글은 자동으로 만들지 않는다 — 바·표에 바로 반영되고, 공지는 직원이 필요할 때 따로 쓴다(계획 Task 5 Step 3).
 */

namespace Iwell\Core\Hours;

use DateTimeImmutable;
use DateTimeZone;

defined( 'ABSPATH' ) || exit;

final class Admin {
	public const CAPABILITY = 'iwell_manage_hours';
	public const PAGE       = 'iwell-hours';
	public const NONCE      = 'iwell_hours_exceptions';

	private const REASON_MAX   = 100;
	private const SESSIONS_MAX = 4;

	/** 알림 코드 → 고정 문구(성공 여부). */
	private const NOTICES = array(
		'added'           => array( true, '저장했습니다. 오늘 진료 바·진료시간 표에 바로 반영됩니다.' ),
		'deleted'         => array( true, '삭제했습니다.' ),
		'invalid'         => array( false, '저장하지 않았습니다 — 날짜(YYYY-MM-DD)와 시간(HH:MM, 시작이 끝보다 앞)을 확인해 주세요.' ),
		'reason_too_long' => array( false, '저장하지 않았습니다 — 휴진 사유는 100자 이내로 써 주세요.' ),
		'not_found'       => array( false, '삭제할 예외가 없습니다(이미 삭제되었을 수 있습니다).' ),
	);

	private const WEEKDAY_NAMES = array( 1 => '월', 2 => '화', 3 => '수', 4 => '목', 5 => '금', 6 => '토', 7 => '일' );

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		add_action( 'admin_post_iwell_hours_add', array( self::class, 'add' ) );
		add_action( 'admin_post_iwell_hours_delete', array( self::class, 'delete' ) );
	}

	public static function menu(): void {
		add_menu_page( '진료시간', '진료시간', self::CAPABILITY, self::PAGE, array( self::class, 'page' ), 'dashicons-clock', 30 );
	}

	/** admin-post.php?action=iwell_hours_add */
	public static function add(): void {
		self::guard();
		$date = self::field( 'date' );
		$type = self::field( 'type' );
		if ( null === $date || null === $type ) {
			self::back( 'invalid' );
		}
		if ( 'closed' === $type ) {
			$reason = self::field( 'reason' );
			if ( null === $reason ) {
				self::back( 'invalid' ); // 문자열이 아닌 사유 — Store 와 같이 거부, 기존 값 그대로.
			}
			if ( mb_strlen( $reason, 'UTF-8' ) > self::REASON_MAX ) {
				self::back( 'reason_too_long' );
			}
			$entry = array(
				'closed' => true,
				'reason' => $reason,
			);
		} elseif ( 'hours' === $type ) {
			$entry = self::postedSessions();
			if ( null === $entry ) {
				self::back( 'invalid' );
			}
		} else {
			self::back( 'invalid' );
		}

		$valid = Store::exceptions( array( $date => $entry ) );
		if ( ! isset( $valid[ $date ] ) ) {
			self::back( 'invalid' );
		}
		$option                        = self::option();
		$option['exceptions'][ $date ] = $valid[ $date ];
		ksort( $option['exceptions'], SORT_STRING );
		update_option( Store::OPTION, $option );
		self::back( 'added' );
	}

	/** admin-post.php?action=iwell_hours_delete */
	public static function delete(): void {
		self::guard();
		$date = self::field( 'date' );
		if ( null === $date ) {
			self::back( 'invalid' );
		}
		$option = self::option();
		if ( '' === $date || ! isset( $option['exceptions'][ $date ] ) ) {
			self::back( 'not_found' );
		}
		unset( $option['exceptions'][ $date ] );
		update_option( Store::OPTION, $option );
		self::back( 'deleted' );
	}

	/** 관리 화면(admin.php?page=iwell-hours). */
	public static function page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html( '진료시간을 바꿀 권한이 없습니다.' ), '', array( 'response' => 403 ) );
		}
		$config = Store::config();
		$today  = Rules::today();
		$code   = isset( $_GET['iwell_hours_notice'] ) && is_string( $_GET['iwell_hours_notice'] ) ? sanitize_key( wp_unslash( $_GET['iwell_hours_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- 표시 전용(고정 문구 선택).
		$post   = esc_url( admin_url( 'admin-post.php' ) );
		$nonce  = wp_create_nonce( self::NONCE );
		$dates  = array_keys( $config['exceptions'] );
		sort( $dates, SORT_STRING );

		echo '<div class="wrap"><h1>진료시간</h1>';
		if ( isset( self::NOTICES[ $code ] ) ) {
			[ $ok, $message ] = self::NOTICES[ $code ];
			printf( '<div class="notice %s"><p>%s</p></div>', $ok ? 'notice-success' : 'notice-error', esc_html( $message ) );
		}

		echo '<h2>요일별 진료시간</h2>';
		echo Render::weeklyTableHtml( $config ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Render 가 글자를 모두 esc_html 한다.
		echo '<p class="description">요일별 시간은 병원 확인값입니다. 바꾸려면 홈페이지 관리 담당에게 요청하세요.</p>';

		echo '<h2>날짜별 예외(임시 휴진·임시 진료시간)</h2>';
		echo '<p>여기 등록한 날은 홈페이지의 오늘 진료 바·진료시간 표에 바로 반영됩니다. 공지 글은 자동으로 만들지 않으니, 필요하면 공지사항에 따로 쓰세요.</p>';
		echo '<table class="widefat striped" id="iwell-hours-exceptions"><thead><tr><th scope="col">날짜</th><th scope="col">내용</th><th scope="col">삭제</th></tr></thead><tbody>';
		if ( array() === $dates ) {
			echo '<tr><td colspan="3">등록된 예외가 없습니다.</td></tr>';
		}
		$tz = new DateTimeZone( Rules::TIMEZONE );
		foreach ( $dates as $ymd ) {
			$date = new DateTimeImmutable( $ymd, $tz );
			$past = $date < $today ? ' (지남)' : '';
			printf(
				'<tr><td>%s</td><td>%s</td><td><form method="post" action="%s"><input type="hidden" name="action" value="iwell_hours_delete"><input type="hidden" name="_wpnonce" value="%s"><input type="hidden" name="date" value="%s"><button type="submit" class="button-link button-link-delete" aria-label="%s">삭제</button></form></td></tr>',
				esc_html( $ymd . ' (' . self::WEEKDAY_NAMES[ (int) $date->format( 'N' ) ] . ')' . $past ),
				esc_html( Render::describe( Rules::forDate( $date, $config ) ) ),
				$post, // esc_url 완료.
				esc_attr( $nonce ),
				esc_attr( $ymd ),
				esc_attr( $ymd . ' 예외 삭제' )
			);
		}
		echo '</tbody></table>';

		echo '<h2>예외 추가</h2>';
		printf( '<form method="post" action="%s">', $post ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- esc_url 완료.
		echo '<input type="hidden" name="action" value="iwell_hours_add">';
		wp_nonce_field( self::NONCE );
		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row"><label for="iwell-hours-date">날짜</label></th><td><input type="date" id="iwell-hours-date" name="date" required></td></tr>';
		echo '<tr><th scope="row">종류</th><td><fieldset><legend class="screen-reader-text">종류</legend>'
			. '<label><input type="radio" name="type" value="closed" checked> 임시 휴진</label><br>'
			. '<label><input type="radio" name="type" value="hours"> 임시 진료시간</label></fieldset></td></tr>';
		printf(
			'<tr><th scope="row"><label for="iwell-hours-reason">휴진 사유</label></th><td><input type="text" id="iwell-hours-reason" name="reason" class="regular-text" maxlength="%d"><p class="description">임시 휴진일 때만. 예: 원장님 학회 참석 — 홈페이지에 \'오늘 휴진 · 사유\'로 보입니다.</p></td></tr>',
			(int) self::REASON_MAX
		);
		echo '<tr><th scope="row">진료시간</th><td><p class="description">임시 진료시간일 때만. 점심시간이 있으면 두 칸으로 나눠 씁니다(예: 09:00~13:00, 14:00~18:00).</p>';
		for ( $i = 0; $i < 2; $i++ ) {
			printf(
				'<p><input type="time" name="from[%1$d]" aria-label="시작 %2$d"> ~ <input type="time" name="to[%1$d]" aria-label="끝 %2$d"></p>',
				(int) $i,
				(int) ( $i + 1 )
			);
		}
		echo '</td></tr></tbody></table>';
		submit_button( '예외 추가' );
		echo '</form></div>';
	}

	/** POST 만 → 권한 → nonce. 하나라도 아니면 여기서 끝낸다. */
	private static function guard(): void {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			wp_die( esc_html( 'POST 요청만 받습니다.' ), '', array( 'response' => 405 ) );
		}
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html( '진료시간을 바꿀 권한이 없습니다.' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( self::NONCE );
	}

	/** 옵션 iwell_hours(배열이 아니면 빈 배열) — exceptions 는 Store::exceptions()로 다시 검사한 값. */
	private static function option(): array {
		$option = get_option( Store::OPTION, array() );
		if ( ! is_array( $option ) ) {
			$option = array();
		}
		$option['exceptions'] = Store::exceptions( $option['exceptions'] ?? null );
		return $option;
	}

	/**
	 * POST 문자열 필드: 없으면 ''(선택 항목 생략 — 예: 사유 없는 휴진), 있는데 문자열이 아니면(reason[]=x 등) null — 부르는 쪽이 거부한다
	 * (빈 값으로 바꿔 저장하면 기존 사유를 지우게 된다 — Codex L1). 다듬지 않는다 — 검사는 Store 가 한다.
	 */
	private static function field( string $name ): ?string {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard()에서 확인.
		if ( ! array_key_exists( $name, $_POST ) ) {
			return '';
		}
		$value = $_POST[ $name ]; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		return is_string( $value ) ? (string) wp_unslash( $value ) : null;
	}

	/**
	 * from[i]·to[i] → 세션 목록(둘 다 빈 칸인 줄은 건너뜀, 한쪽만 빈 칸이면 그대로 넘겨 Store 가 거부).
	 * 세션이 없거나, 4개를 넘거나, 값이 문자열이 아니면 null. 시간 형식 검사는 Store.
	 */
	private static function postedSessions(): ?array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard()에서 확인.
		$from = $_POST['from'] ?? array();
		$to   = $_POST['to'] ?? array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( ! is_array( $from ) || ! is_array( $to ) ) {
			return null;
		}
		$keys = array_keys( $from + $to );
		sort( $keys );
		$sessions = array();
		foreach ( $keys as $key ) {
			$f = $from[ $key ] ?? '';
			$t = $to[ $key ] ?? '';
			if ( ! is_string( $f ) || ! is_string( $t ) ) {
				return null;
			}
			$f = (string) wp_unslash( $f );
			$t = (string) wp_unslash( $t );
			if ( '' === $f && '' === $t ) {
				continue;
			}
			$sessions[] = array(
				'from' => $f,
				'to'   => $t,
			);
		}
		return array() === $sessions || count( $sessions ) > self::SESSIONS_MAX ? null : $sessions;
	}

	private static function back( string $code ): never {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'               => self::PAGE,
					'iwell_hours_notice' => $code,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
