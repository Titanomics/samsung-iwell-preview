<?php
/**
 * 진료시간 화면(Task 5) — 블록 iwell/today-bar(오늘 진료 바)·iwell/hours-table(진료시간 표).
 * 서버 렌더: 자바스크립트 없이 HTML 에 문구가 들어 있다. 데이터는 Store::config()와 Rules 만 쓴다. 오늘 = Rules::today()(서울 날짜, 필터 iwell_now).
 *
 * 문구(코디네이터 결정 2026-11-12):
 *  - 바, 진료일: '오늘 진료 {첫 시작}~{마지막 끝}' + 세션 사이 빈 시간이 1개면 ' (점심 {끝}~{다음 시작})'.
 *    빈 시간이 2개 이상이면 ' (휴게 a~b · c~d)' — 모두 점심이라 부를 수 없어서(클로드 판단, 지금 설정에는 없는 경우).
 *  - 바, 휴진일: '오늘 휴진 · {reason}'. 사유 없는 휴진(Rules 가 기본 사유 '휴진'을 채운 경우)은 '오늘 휴진'.
 *    공휴일 진료일의 reason(공휴일 이름)은 쓰지 않는다 — 사유는 휴진일에만 붙인다.
 *  - 표: 진료 요일을 같은 세션끼리 묶는다(연속 3일 이상 '화~금', 그 밖에는 '토·일'). 공휴일 시간이 어느 묶음과 같으면 그 묶음 이름에
 *    '·공휴일'을 붙이고, 다르면 '공휴일' 줄을 따로, 공휴일 휴진이면 휴진 줄에 넣는다.
 *    휴진 줄 = '매주 {요일}요일'(closedWeekdays + 세션 없는 요일 — 공휴일 진료가 있는 사이트에서 공휴일에도 쉬면 '(공휴일 포함)', HOLIDAY_TOO)
 *    · '매월 마지막주 일요일'(closeLastSunday, 일요일이 매주 휴진이면 생략) · '공휴일'.
 *    쉬는 요일 중 Rules 상 공휴일이면 공휴일 시간으로 여는 요일(mondayHolidayPolicy='open'인 월요일, 휴진 요일이 아니고 세션만 빈 요일)은
 *    따로 '매주 {요일}요일(공휴일이면 공휴일 진료시간)'으로 쓴다(Codex M1 — 표와 오늘 진료 바가 어긋나지 않게).
 *    일요일 진료 원장(설정 sundayDoctor — 매주 일요일 같은 원장, 대표 2026-11-26)이 있고 일요일이 진료 요일이면 휴진 줄 바로 앞에
 *    '일요일 진료 | 매주 일요일 {원장} · 매월 마지막주 일요일 휴진' 줄(tableRows). 비어 있으면 줄을 내지 않는다.
 *    그 아래 표에 오늘 이후의 날짜별 예외(임시 휴진·임시 진료시간)를 날짜순으로 — '12월 31일(목) 휴진 · 사유' / '12월 24일(목) 09:00~13:00'.
 *    (임시 휴진 공지 글은 만들지 않는다 — 바·표에 자동 반영, 공지는 직원이 필요할 때 따로. 계획 Task 5 Step 3)
 *  - 세션은 시작 시각순으로 정렬하고 겹치거나 맞닿은 것은 합쳐서 보인다(Store 는 세션 사이 순서·겹침을 검사하지 않는다).
 * 모든 글자는 esc_html 로 내보낸다(사유는 관리자 입력).
 *
 * 캐시 주의: 서버 렌더라 페이지 캐시가 자정을 넘겨 HTML 을 들고 있으면 바가 전날 기준으로 보인다 — 운영 캐시 설정은 Task 14 에서.
 */

namespace Iwell\Core\Hours;

use DateTimeImmutable;
use DateTimeZone;

defined( 'ABSPATH' ) || exit;

final class Render {
	private const WEEKDAY_NAMES = array( 1 => '월', 2 => '화', 3 => '수', 4 => '목', 5 => '금', 6 => '토', 7 => '일' );

	/** Rules 가 사유 없는 휴진에 채우는 기본 사유 — 바·표에서는 사유 없음으로 본다. */
	private const DEFAULT_CLOSED_REASON = '휴진';

	/**
	 * 공휴일에도 쉬는 정기 휴진 요일 표시(공휴일 진료 사이트에서만). 표·llms·맨 위 띠·홈 히어로가 같은 글자를 쓴다 — 원고(지역 안내·FAQ·홈 FAQ)도
	 * "매주 월요일(공휴일 포함) 휴진" 한 표현으로 맞췄다(agy Neon P2, 2026-11-25).
	 */
	public const HOLIDAY_TOO = '(공휴일 포함)';

	/**
	 * 쉬는 요일 → [공휴일에도 쉬는 요일, 공휴일이면 공휴일 시간으로 여는 요일] — Rules 와 같은 판정(표·요약·llms 가 한 함수로):
	 * 정기 휴진 요일(closedWeekdays)은 공휴일이어도 휴진(단 월요일 + mondayHolidayPolicy='open' 이면 공휴일 진료), 세션만 빈 요일은 공휴일 판정이
	 * 요일 시간보다 먼저라 공휴일이면 공휴일 진료. 공휴일 시간이 없으면(공휴일 휴진) 어느 요일도 공휴일에 열지 않는다.
	 *
	 * @param list<int> $days
	 * @return array{0: list<int>, 1: list<int>}
	 */
	private static function splitByHoliday( array $config, array $days ): array {
		$holiday         = array() !== self::merge( $config['holidayHours'] ?? array() );
		$closed_weekdays = array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) );
		$monday_open     = 'open' === ( $config['mondayHolidayPolicy'] ?? 'closed' );
		$always          = array();
		$open            = array();
		foreach ( $days as $day ) {
			$by_closed_weekday = in_array( $day, $closed_weekdays, true );
			if ( $holiday && ( ! $by_closed_weekday || ( 1 === $day && $monday_open ) ) ) {
				$open[] = $day;
			} else {
				$always[] = $day;
			}
		}
		return array( $always, $open );
	}

	public static function register(): void {
		add_action( 'init', array( self::class, 'registerBlocks' ) );
	}

	public static function registerBlocks(): void {
		register_block_type(
			'iwell/today-bar',
			array(
				'api_version'     => 3,
				'title'           => '오늘 진료',
				'description'     => '오늘 진료 시간 또는 휴진 사유(진료시간 설정에서 자동 계산).',
				'category'        => 'widgets',
				'icon'            => 'clock',
				'supports'        => array( 'html' => false ),
				'render_callback' => array( self::class, 'todayBarBlock' ),
			)
		);
		register_block_type(
			'iwell/hours-table',
			array(
				'api_version'     => 3,
				'title'           => '진료시간 표',
				'description'     => '요일별 진료시간·정기 휴진·예정된 임시 휴진(진료시간 설정에서 자동 계산).',
				'category'        => 'widgets',
				'icon'            => 'calendar-alt',
				'supports'        => array( 'html' => false ),
				'render_callback' => array( self::class, 'hoursTableBlock' ),
			)
		);
	}

	/** 블록 iwell/today-bar 렌더. */
	public static function todayBarBlock(): string {
		$today = Rules::today();
		$day   = Rules::forDate( $today, Store::config() );
		$attrs = get_block_wrapper_attributes(
			array(
				'class'     => 'iwell-today-bar ' . ( $day['open'] ? 'is-open' : 'is-closed' ),
				'data-date' => $today->format( 'Y-m-d' ),
			)
		);
		return sprintf( '<div %s><p class="iwell-today-bar__text">%s</p></div>', $attrs, esc_html( self::todayText( $day ) ) );
	}

	/** 블록 iwell/hours-table 렌더. */
	public static function hoursTableBlock(): string {
		return sprintf( '<div %s>%s</div>', get_block_wrapper_attributes( array( 'class' => 'iwell-hours' ) ), self::tablesHtml( Store::config(), Rules::today() ) );
	}

	/** 진료시간 표 + (있으면) 예정된 날짜별 예외 표. */
	public static function tablesHtml( array $config, DateTimeImmutable $today ): string {
		$html     = self::weeklyTableHtml( $config );
		$upcoming = self::upcomingRows( $config, $today );
		if ( array() !== $upcoming ) {
			$html .= '<table class="iwell-hours-exceptions"><caption>임시 휴진·진료시간 변경</caption><tbody>' . self::rowsHtml( $upcoming ) . '</tbody></table>';
		}
		return $html;
	}

	/** 요일별 진료시간 표(관리 화면도 이것을 보여 준다). */
	public static function weeklyTableHtml( array $config ): string {
		return '<table class="iwell-hours-table"><caption>진료시간</caption><tbody>' . self::rowsHtml( self::tableRows( $config ) ) . '</tbody></table>';
	}

	/**
	 * 진료시간 표 줄 = weeklyRows + 일요일 진료 원장 줄(sundayDoctorRow — 있으면 휴진 줄 바로 앞, 휴진 줄이 없으면 맨 뒤).
	 * 표 블록·관리 화면·llms.txt 가 같은 줄을 쓴다.
	 *
	 * @return list<array{0: string, 1: string}>
	 */
	public static function tableRows( array $config ): array {
		$rows   = self::weeklyRows( $config );
		$doctor = self::sundayDoctorRow( $config );
		if ( null === $doctor ) {
			return $rows;
		}
		$last = count( $rows ) - 1;
		if ( $last >= 0 && '휴진' === $rows[ $last ][0] ) {
			array_splice( $rows, $last, 0, array( $doctor ) );
		} else {
			$rows[] = $doctor;
		}
		return $rows;
	}

	/**
	 * ['일요일 진료', '매주 일요일 {원장} · 매월 마지막주 일요일 휴진'] — sundayDoctor 가 비어 있지 않고 일요일이 진료 요일(정기 휴진 요일이 아니고 세션이 있음)일 때만.
	 * 아니면 null. 마지막주 휴진(closeLastSunday)이 꺼져 있으면 뒤 문구는 붙이지 않는다.
	 * 대표 2026-11-26 "매주 일요일 / 정헌종 원장", "마지막주 일요일은 휴진입니다" — 일요일 진료 원장은 매주 같은 원장(월마다 바뀌는 값이 아님)이라
	 * 진료 원장과 휴진 주를 한 줄에서 한눈에 보이게 한다.
	 *
	 * @return array{0: string, 1: string}|null
	 */
	public static function sundayDoctorRow( array $config ): ?array {
		$name   = trim( (string) ( $config['sundayDoctor'] ?? '' ) );
		$closed = in_array( 7, array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) ), true );
		if ( '' === $name || $closed || array() === self::merge( $config['weekly'][7] ?? array() ) ) {
			return null;
		}
		return array( '일요일 진료', '매주 일요일 ' . $name . ( empty( $config['closeLastSunday'] ) ? '' : ' · 매월 마지막주 일요일 휴진' ) );
	}

	/** Rules::forDate() 결과 → 바 문구. */
	public static function todayText( array $day ): string {
		return '오늘 ' . ( ! empty( $day['open'] ) ? '진료 ' : '' ) . self::describe( $day );
	}

	/** Rules::forDate() 결과 → '09:00~18:00 (점심 13:00~14:00)' / '휴진' / '휴진 · {사유}'(공휴일 진료일의 공휴일 이름은 쓰지 않음). */
	public static function describe( array $day ): string {
		return ! empty( $day['open'] ) ? self::span( $day['sessions'] ?? array() ) : self::closedText( $day['reason'] ?? null );
	}

	/** 세션 목록 → '09:00~18:00 (점심 13:00~14:00)'. 빈 목록이면 ''. */
	public static function span( array $sessions ): string {
		$merged = self::merge( $sessions );
		if ( array() === $merged ) {
			return '';
		}
		$text = $merged[0]['from'] . '~' . $merged[ count( $merged ) - 1 ]['to'];
		$gaps = array();
		for ( $i = 1, $n = count( $merged ); $i < $n; $i++ ) {
			$gaps[] = $merged[ $i - 1 ]['to'] . '~' . $merged[ $i ]['from'];
		}
		if ( 1 === count( $gaps ) ) {
			$text .= ' (점심 ' . $gaps[0] . ')';
		} elseif ( array() !== $gaps ) {
			$text .= ' (휴게 ' . implode( ' · ', $gaps ) . ')';
		}
		return $text;
	}

	/**
	 * 진료 안내 한 줄(맨 위 띠·홈 히어로 체크 목록 — 테마 iwell/topbar-note): 설정에서 계산.
	 * '일요일·공휴일 진료'(일요일·공휴일 세션이 있을 때) · '매주 {요일}요일 휴진'(정기 휴진 요일 + 세션 없는 요일) · '매월 마지막주 일요일 휴진'
	 * (일요일 진료일 때만 — content-inventory C49: "일요일·공휴일 진료"는 반드시 마지막주 일요일 휴진과 함께).
	 * 수정 1차(병원 의견 2026-11-19 "월요일 휴진도 빠졌음"): 정기 휴진 요일을 넣는다(예전 테마 계산에는 없었다).
	 */
	public static function summary( array $config ): string {
		$closed_weekdays = array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) );
		$closed          = array();
		for ( $weekday = 1; $weekday <= 7; $weekday++ ) {
			if ( in_array( $weekday, $closed_weekdays, true ) || array() === self::merge( $config['weekly'][ $weekday ] ?? array() ) ) {
				$closed[] = $weekday;
			}
		}
		$sunday  = ! in_array( 7, $closed, true );
		$holiday = array() !== self::merge( $config['holidayHours'] ?? array() );
		$parts   = array();
		if ( $sunday && $holiday ) {
			$parts[] = '일요일·공휴일 진료';
		} elseif ( $sunday ) {
			$parts[] = '일요일 진료';
		} elseif ( $holiday ) {
			$parts[] = '공휴일 진료';
		}
		// 표(weeklyRows)와 같은 판정으로 나눈다 — 공휴일에도 쉬는 요일만 '(공휴일 포함)', 공휴일이면 여는 요일은 따로(agy Neon P2 2026-11-25).
		[ $always_closed, $holiday_open ] = self::splitByHoliday( $config, $closed );
		$off                              = array(); // 첫 요일 → 문구(표처럼 요일순).
		if ( array() !== $always_closed ) {
			$off[ $always_closed[0] ] = '매주 ' . self::daysLabel( $always_closed ) . '요일' . ( $holiday ? self::HOLIDAY_TOO : '' ) . ' 휴진';
		}
		if ( array() !== $holiday_open ) {
			$off[ $holiday_open[0] ] = '매주 ' . self::daysLabel( $holiday_open ) . '요일 휴진';
		}
		ksort( $off );
		array_push( $parts, ...array_values( $off ) );
		if ( $sunday && ! empty( $config['closeLastSunday'] ) ) {
			$parts[] = '매월 마지막주 일요일 휴진';
		}
		return implode( ' · ', $parts );
	}

	/**
	 * 진료시간 표 줄(설정에서 계산): list<[요일 묶음, 시간]> + 마지막에 ['휴진', …](있으면).
	 *
	 * @return list<array{0: string, 1: string}>
	 */
	public static function weeklyRows( array $config ): array {
		$closed_weekdays = array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) );
		$groups          = array(); // 세션 열쇠 → {days, sessions}, 처음 나온 요일 순.
		$closed_days     = array();
		for ( $weekday = 1; $weekday <= 7; $weekday++ ) {
			$sessions = self::merge( $config['weekly'][ $weekday ] ?? array() );
			if ( array() === $sessions || in_array( $weekday, $closed_weekdays, true ) ) {
				$closed_days[] = $weekday;
				continue;
			}
			$key              = self::key( $sessions );
			$groups[ $key ] ??= array(
				'days'     => array(),
				'sessions' => $sessions,
			);
			$groups[ $key ]['days'][] = $weekday;
		}

		$holiday        = self::merge( $config['holidayHours'] ?? array() );
		$holiday_placed = array() === $holiday;
		$rows           = array();
		foreach ( $groups as $key => $group ) {
			$label = self::daysLabel( $group['days'] );
			if ( ! $holiday_placed && self::key( $holiday ) === $key ) {
				$label         .= '·공휴일';
				$holiday_placed = true;
			}
			$rows[] = array( $label, self::span( $group['sessions'] ) );
		}
		if ( ! $holiday_placed ) {
			$rows[] = array( '공휴일', self::span( $holiday ) );
		}

		// 쉬는 요일을 Rules 의 공휴일 판정으로 둘로 나눈다(Codex M1): 공휴일이어도 쉬는 요일 / 공휴일이면 공휴일 시간으로 여는 요일.
		// Rules: 휴진 요일(closedWeekdays)은 공휴일이어도 휴진 — 단 월요일 + mondayHolidayPolicy='open'이면 공휴일 시간 진료.
		//        세션만 빈 요일(휴진 요일 아님)은 공휴일 판정이 요일 시간보다 먼저라 공휴일이면 공휴일 시간 진료.
		// 공휴일 시간이 없으면(공휴일 휴진) 어느 요일도 공휴일에 열지 않는다.
		[ $always_closed, $holiday_open ] = self::splitByHoliday( $config, $closed_days );

		$off = array(); // 첫 요일 → 문구(요일순으로 내보낸다).
		if ( array() !== $always_closed ) {
			// 공휴일에 진료하는 사이트에서 공휴일이어도 쉬는 요일 = '(공휴일 포함)'(대표 결정 2026-11-25 — 월요일은 공휴일이어도 휴진, 표기 통일).
			$off[ $always_closed[0] ] = '매주 ' . self::daysLabel( $always_closed ) . '요일' . ( array() !== $holiday ? self::HOLIDAY_TOO : '' );
		}
		if ( array() !== $holiday_open ) {
			$off[ $holiday_open[0] ] = '매주 ' . self::daysLabel( $holiday_open ) . '요일(공휴일이면 공휴일 진료시간)';
		}
		ksort( $off );
		$off = array_values( $off );
		// 마지막주 일요일은 공휴일이어도 휴진(Rules 3번) — 일요일이 공휴일에도 쉬는 요일이면 '매주 일요일'에 이미 들어 있다.
		if ( ! empty( $config['closeLastSunday'] ) && ! in_array( 7, $always_closed, true ) ) {
			$off[] = '매월 마지막주 일요일';
		}
		if ( array() === $holiday ) {
			$off[] = '공휴일';
		}
		if ( array() !== $off ) {
			$rows[] = array( '휴진', implode( ' · ', $off ) );
		}
		return $rows;
	}

	/**
	 * 오늘(서울 날짜) 이후의 날짜별 예외 줄, 날짜순: ['12월 31일(목)', '휴진 · 사유'] / ['12월 24일(목)', '09:00~13:00'].
	 *
	 * @return list<array{0: string, 1: string}>
	 */
	public static function upcomingRows( array $config, DateTimeImmutable $today ): array {
		$from  = Rules::today( $today )->format( 'Y-m-d' );
		$tz    = new DateTimeZone( Rules::TIMEZONE );
		$dates = array_filter(
			array_keys( (array) ( $config['exceptions'] ?? array() ) ),
			static fn( $ymd ): bool => is_string( $ymd ) && strcmp( $ymd, $from ) >= 0
		);
		sort( $dates, SORT_STRING );

		$rows = array();
		foreach ( $dates as $ymd ) {
			$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $ymd, $tz );
			if ( false === $date || $date->format( 'Y-m-d' ) !== $ymd ) {
				continue;
			}
			$rows[] = array(
				sprintf( '%d월 %d일(%s)', (int) $date->format( 'n' ), (int) $date->format( 'j' ), self::WEEKDAY_NAMES[ (int) $date->format( 'N' ) ] ),
				self::describe( Rules::forDate( $date, $config ) ),
			);
		}
		return $rows;
	}

	/** '휴진' 또는 '휴진 · {사유}'(사유가 비었거나 기본 사유면 '휴진'). */
	private static function closedText( ?string $reason ): string {
		$reason = trim( (string) $reason );
		return '' === $reason || self::DEFAULT_CLOSED_REASON === $reason ? '휴진' : '휴진 · ' . $reason;
	}

	/** @param list<array{0: string, 1: string}> $rows */
	private static function rowsHtml( array $rows ): string {
		$html = '';
		foreach ( $rows as [ $label, $text ] ) {
			$html .= sprintf( '<tr><th scope="row">%s</th><td>%s</td></tr>', esc_html( $label ), esc_html( $text ) );
		}
		return $html;
	}

	/** ISO 요일 목록 → '화~금'(연속 3일 이상) / '토·일' / '화·목·금'. */
	private static function daysLabel( array $days ): string {
		sort( $days );
		$runs = array();
		foreach ( $days as $day ) {
			$last = count( $runs ) - 1;
			if ( $last >= 0 && end( $runs[ $last ] ) === $day - 1 ) {
				$runs[ $last ][] = $day;
			} else {
				$runs[] = array( $day );
			}
		}
		$parts = array();
		foreach ( $runs as $run ) {
			$names   = array_map( static fn( int $d ): string => self::WEEKDAY_NAMES[ $d ], $run );
			$parts[] = count( $run ) >= 3 ? $names[0] . '~' . $names[ count( $names ) - 1 ] : implode( '·', $names );
		}
		return implode( '·', $parts );
	}

	/**
	 * {from, to} 세션 목록 → 시작순 정렬 + 겹치거나 맞닿은 세션 합침. 형식이 틀린 항목은 뺀다(Store 가 이미 검사한 값을 받는다).
	 * 구조화 데이터(Schema\Graph, Task 6)도 이 함수로 세션을 정리한다 — 화면 표·바와 같은 시간을 내보내려고.
	 *
	 * @return list<array{from: string, to: string}>
	 */
	public static function merge( mixed $sessions ): array {
		$list = array();
		foreach ( is_array( $sessions ) ? $sessions : array() as $s ) {
			if ( is_array( $s ) && is_string( $s['from'] ?? null ) && is_string( $s['to'] ?? null ) ) {
				$list[] = array( 'from' => $s['from'], 'to' => $s['to'] );
			}
		}
		usort( $list, static fn( array $a, array $b ): int => array( $a['from'], $a['to'] ) <=> array( $b['from'], $b['to'] ) );
		$merged = array();
		foreach ( $list as $s ) {
			$last = count( $merged ) - 1;
			if ( $last >= 0 && strcmp( $s['from'], $merged[ $last ]['to'] ) <= 0 ) {
				if ( strcmp( $s['to'], $merged[ $last ]['to'] ) > 0 ) {
					$merged[ $last ]['to'] = $s['to'];
				}
				continue;
			}
			$merged[] = $s;
		}
		return $merged;
	}

	private static function key( array $merged ): string {
		return implode( ',', array_map( static fn( array $s ): string => $s['from'] . '-' . $s['to'], $merged ) );
	}
}
