<?php
/**
 * 진료시간 규칙(Task 4) — 날짜 하나의 진료 여부·세션을 설정(Store::config())에서 계산한다. 워드프레스에 기대지 않는 순수 계산
 * (예외: now()·인자 없는 today()는 필터 iwell_now 를 거친다 — Task 5).
 *
 * 날짜는 언제나 Asia/Seoul 달력 날짜로 판정한다(서버 시간대가 UTC여도, 다른 시간대의 시각을 받아도 서울 날짜로 바꿔서).
 *
 * 판정 순서(앞이 우선):
 *  1. exceptions[날짜]        — 세션 목록이면 그 시간으로 진료, {closed: true, reason}이면 휴진(사유 없으면 '휴진').
 *  2. closedWeekdays          — '정기 휴진(월요일)' 등. 단 월요일이 공휴일이고 mondayHolidayPolicy='open'이면 공휴일 시간으로 진료.
 *  3. closeLastSunday         — 매월 마지막 일요일 '정기 휴진(마지막주 일요일)'. 그날이 공휴일이어도 휴진(정기 휴진이 공휴일 진료보다 우선 —
 *                               2번의 월요일 공휴일 기본값 'closed'와 같은 원칙. 바꾸려면 exceptions 로 그날만 연다).
 *  4. holidays[날짜]          — holidayHours 로 진료.
 *  5. weekly[ISO 요일]        — 빈 목록이면 '정기 휴진(○요일)'.
 *
 * 반환: {open, reason, sessions, doctor}
 *  - reason: 그날의 특별 사유 — 휴진이면 휴진 사유, 공휴일 진료일이면 공휴일 이름(예: '기독탄신일'), 평일 진료는 null.
 *    (휴진 여부는 open 으로만 판단한다. reason 이 있다고 휴진이 아니다.)
 *  - sessions: 진료 세션 목록(휴진이면 빈 목록). doctor: 진료일의 doctorsByDate[날짜](없으면 null), 휴진이면 null.
 */

namespace Iwell\Core\Hours;

use DateTimeImmutable;
use DateTimeZone;

defined( 'ABSPATH' ) || exit;

final class Rules {
	public const TIMEZONE = 'Asia/Seoul';

	private const WEEKDAY_NAMES = array( 1 => '월', 2 => '화', 3 => '수', 4 => '목', 5 => '금', 6 => '토', 7 => '일' );

	/** @return array{open: bool, reason: ?string, sessions: list<array{from: string, to: string}>, doctor: ?string} */
	public static function forDate( DateTimeImmutable $date, array $config ): array {
		$day     = self::local( $date );
		$ymd     = $day->format( 'Y-m-d' );
		$weekday = (int) $day->format( 'N' );
		$holiday = isset( $config['holidays'][ $ymd ] ) ? (string) $config['holidays'][ $ymd ] : null;
		$doctor  = isset( $config['doctorsByDate'][ $ymd ] ) ? (string) $config['doctorsByDate'][ $ymd ] : null;

		$exception = $config['exceptions'][ $ymd ] ?? null;
		if ( is_array( $exception ) ) {
			if ( array_is_list( $exception ) ) {
				return self::sessionsOrClosed( $exception, '휴진', $holiday, $doctor );
			}
			if ( ! empty( $exception['closed'] ) ) {
				$reason = isset( $exception['reason'] ) ? trim( (string) $exception['reason'] ) : '';
				return self::closed( '' !== $reason ? $reason : '휴진' );
			}
		}

		$closed_weekdays = array_map( 'intval', (array) ( $config['closedWeekdays'] ?? array() ) );
		if ( in_array( $weekday, $closed_weekdays, true ) ) {
			$monday_holiday_open = 1 === $weekday && null !== $holiday && 'open' === ( $config['mondayHolidayPolicy'] ?? 'closed' );
			if ( ! $monday_holiday_open ) {
				return self::closed( self::weekdayClosedReason( $weekday ) );
			}
			return self::sessionsOrClosed( $config['holidayHours'] ?? array(), "공휴일 휴진($holiday)", $holiday, $doctor );
		}

		if ( ! empty( $config['closeLastSunday'] ) && self::isLastSundayOfMonth( $day ) ) {
			return self::closed( '정기 휴진(마지막주 일요일)' );
		}

		if ( null !== $holiday ) {
			return self::sessionsOrClosed( $config['holidayHours'] ?? array(), "공휴일 휴진($holiday)", $holiday, $doctor );
		}

		return self::sessionsOrClosed( $config['weekly'][ $weekday ] ?? array(), self::weekdayClosedReason( $weekday ), null, $doctor );
	}

	public static function isLastSundayOfMonth( DateTimeImmutable $d ): bool {
		$day = self::local( $d );
		return '7' === $day->format( 'N' ) && $day->modify( '+7 days' )->format( 'm' ) !== $day->format( 'm' );
	}

	/** 서울 기준 오늘(자정, Asia/Seoul). $now 를 주면 그 시각의 서울 날짜, 없으면 now()(필터 iwell_now 반영). */
	public static function today( ?DateTimeImmutable $now = null ): DateTimeImmutable {
		return self::local( $now ?? self::now() )->setTime( 0, 0 );
	}

	/**
	 * 지금 시각(Task 5). 필터 `iwell_now`(DateTimeImmutable 반환)로 바꿀 수 있다 — 시험에서 날짜를 고정하려는 것.
	 * 이 플러그인은 요청 값(쿼리·헤더·쿠키)으로 이 필터를 걸지 않는다. 요청과 잇는 것은 로컬 전용 시험 도우미(dev/mu-plugins/iwell-hours-test.php)뿐.
	 * 필터 값이 DateTimeImmutable 이 아니면 실제 시각.
	 */
	public static function now(): DateTimeImmutable {
		$real = new DateTimeImmutable( 'now' );
		$now  = apply_filters( 'iwell_now', $real );
		return $now instanceof DateTimeImmutable ? $now : $real;
	}

	private static function local( DateTimeImmutable $d ): DateTimeImmutable {
		return $d->setTimezone( new DateTimeZone( self::TIMEZONE ) );
	}

	private static function weekdayClosedReason( int $weekday ): string {
		return '정기 휴진(' . self::WEEKDAY_NAMES[ $weekday ] . '요일)';
	}

	private static function sessionsOrClosed( mixed $sessions, string $closed_reason, ?string $open_reason, ?string $doctor ): array {
		$list = array();
		foreach ( is_array( $sessions ) ? $sessions : array() as $s ) {
			if ( is_array( $s ) && isset( $s['from'], $s['to'] ) ) {
				$list[] = array( 'from' => (string) $s['from'], 'to' => (string) $s['to'] );
			}
		}
		if ( array() === $list ) {
			return self::closed( $closed_reason );
		}
		return array( 'open' => true, 'reason' => $open_reason, 'sessions' => $list, 'doctor' => $doctor );
	}

	private static function closed( string $reason ): array {
		return array( 'open' => false, 'reason' => $reason, 'sessions' => array(), 'doctor' => null );
	}
}
