<?php
/**
 * 진료시간 글자 번역(외국어 쪽 — 대표 결정 2026-11-26: 영어·베트남어·중국어 간체) — Render 가 만든 한국어 글자(표 줄·오늘 바·요약)를
 * 정해진 낱말 표(LEX)로 옮긴다. 시간·요일·휴진·일요일 원장 값은 한 곳(진료시간 설정 → Render)에서만 계산하고 여기서는 글자만 바꾼다
 * → 직원이 관리 화면에서 시간을 바꾸면 외국어 표도 함께 바뀐다. 외국어 원고에는 시간을 따로 적지 않는다.
 * 낱말 표에 없는 글자(관리자가 쓴 휴진 사유는 괄호 안에 원문 그대로 둔다, 이름 표에 없는 원장)가 남으면 null → 부르는 쪽이 한국어 원문을 쓴다.
 */

namespace Iwell\Core\Hours;

defined( 'ABSPATH' ) || exit;

final class Translate {
	/** 원장 이름 — 대표 결정(2026-11-26) 영문 표기 그대로(중국어·베트남어 쪽도 같은 표기, 한자·베트남식으로 짓지 않는다). */
	public const NAMES = array(
		'고시환' => 'Go Sihwan',
		'정헌종' => 'Jeong Heonjong',
	);

	private const ORDER = array( '월', '화', '수', '목', '금', '토', '일' );

	/** 언어별 낱말 표. %s 자리에 값이 들어간다. */
	private const LEX = array(
		'en' => array(
			'short'        => array( 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun' ),
			'long'         => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday' ),
			'plural'       => array( 'Mondays', 'Tuesdays', 'Wednesdays', 'Thursdays', 'Fridays', 'Saturdays', 'Sundays' ),
			'range'        => '–',
			'sep'          => ', ',
			'join'         => ' & ',
			'holidays'     => 'Public holidays',
			'and_holidays' => '%s & public holidays',
			'closed'       => 'Closed',
			'sunday_row'   => 'Sunday doctor',
			'lunch'        => '%1$s (lunch break %2$s)',
			'breaks'       => '%1$s (breaks %2$s)',
			'every'        => 'Every %s',
			'incl'         => '%s (including public holidays)',
			'hol_hours'    => '%s (holiday hours if it is a public holiday)',
			'last_sun'     => 'Last Sunday of each month',
			'closed_last'  => 'Closed on the last Sunday of each month',
			'every_sun_dr' => 'Every Sunday: %s',
			'dr'           => 'Dr. %s',
			'open_today'   => 'Open today %s',
			'closed_today' => 'Closed today',
			'closed_why'   => 'Closed (%s)',
			'today_why'    => 'Closed today (%s)',
			'date'         => '%2$s %1$d (%3$s)',
			'months'       => array( 1 => 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ),
			'cap_hours'    => 'Opening hours',
			'cap_exc'      => 'Upcoming changes',
			'sum_sun_hol'  => 'Open Sundays & holidays',
			'sum_sun'      => 'Open Sundays',
			'sum_hol'      => 'Open on public holidays',
			'sum_closed'   => 'Closed %s',
			'sum_incl'     => '%s (incl. holidays)',
			'sum_last'     => 'Closed last Sunday of the month',
			'list'         => '; ',
		),
		'vi' => array(
			'short'        => array( 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật' ),
			'long'         => array( 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật' ),
			'plural'       => array( 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy', 'Chủ Nhật' ),
			'range'        => ' – ',
			'sep'          => ', ',
			'join'         => ', ',
			'holidays'     => 'Ngày lễ',
			'and_holidays' => '%s và ngày lễ',
			'closed'       => 'Nghỉ',
			'sunday_row'   => 'Bác sĩ khám Chủ Nhật',
			'lunch'        => '%1$s (nghỉ trưa %2$s)',
			'breaks'       => '%1$s (nghỉ giữa giờ %2$s)',
			'every'        => '%s hằng tuần',
			'incl'         => '%s (kể cả ngày lễ)',
			'hol_hours'    => '%s (nếu trùng ngày lễ thì khám theo giờ ngày lễ)',
			'last_sun'     => 'Chủ Nhật cuối cùng của mỗi tháng',
			'closed_last'  => 'Nghỉ vào Chủ Nhật cuối cùng của mỗi tháng',
			'every_sun_dr' => 'Chủ Nhật hằng tuần: %s',
			'dr'           => 'BS. %s',
			'open_today'   => 'Hôm nay khám %s',
			'closed_today' => 'Hôm nay nghỉ',
			'closed_why'   => 'Nghỉ (%s)',
			'today_why'    => 'Hôm nay nghỉ (%s)',
			'date'         => '%1$d/%4$d (%3$s)',
			'months'       => array(),
			'cap_hours'    => 'Giờ khám',
			'cap_exc'      => 'Thay đổi sắp tới',
			'sum_sun_hol'  => 'Khám Chủ Nhật và ngày lễ',
			'sum_sun'      => 'Khám Chủ Nhật',
			'sum_hol'      => 'Khám ngày lễ',
			'sum_closed'   => 'Nghỉ %s hằng tuần',
			'sum_incl'     => '%s (kể cả ngày lễ)',
			'sum_last'     => 'Nghỉ Chủ Nhật cuối tháng',
			'list'         => '; ',
		),
		'zh' => array(
			'short'        => array( '周一', '周二', '周三', '周四', '周五', '周六', '周日' ),
			'long'         => array( '周一', '周二', '周三', '周四', '周五', '周六', '周日' ),
			'plural'       => array( '周一', '周二', '周三', '周四', '周五', '周六', '周日' ),
			'range'        => '至',
			'sep'          => '、',
			'join'         => '、',
			'holidays'     => '法定节假日',
			'and_holidays' => '%s及法定节假日',
			'closed'       => '休诊',
			'sunday_row'   => '周日出诊医生',
			'lunch'        => '%1$s（午休 %2$s）',
			'breaks'       => '%1$s（休息 %2$s）',
			'every'        => '每%s',
			'incl'         => '%s（含法定节假日）',
			'hol_hours'    => '%s（如逢法定节假日，按节假日时间门诊）',
			'last_sun'     => '每月最后一个周日',
			'closed_last'  => '每月最后一个周日休诊',
			'every_sun_dr' => '每周日：%s',
			'dr'           => '%s 医生',
			'open_today'   => '今日门诊 %s',
			'closed_today' => '今日休诊',
			'closed_why'   => '休诊（%s）',
			'today_why'    => '今日休诊（%s）',
			'date'         => '%4$d月%1$d日（%3$s）',
			'months'       => array(),
			'cap_hours'    => '门诊时间',
			'cap_exc'      => '近期变更',
			'sum_sun_hol'  => '周日及法定节假日门诊',
			'sum_sun'      => '周日门诊',
			'sum_hol'      => '法定节假日门诊',
			'sum_closed'   => '每%s休诊',
			'sum_incl'     => '%s（含节假日）',
			'sum_last'     => '每月最后一个周日休诊',
			'list'         => '；',
		),
	);

	/** 이 언어 낱말 표가 있나. */
	public static function supports( string $lang ): bool {
		return isset( self::LEX[ $lang ] );
	}

	private static function lex( string $lang ): ?array {
		return self::LEX[ $lang ] ?? null;
	}

	/** 요일 글자 → 그 언어 이름(short·long·plural). */
	private static function day( string $ko, array $l, string $kind = 'short' ): string {
		return $l[ $kind ][ (int) array_search( $ko, self::ORDER, true ) ];
	}

	/** 표 제목. */
	public static function caption( string $which, string $lang ): string {
		$l = self::lex( $lang );
		if ( null === $l ) {
			return 'hours' === $which ? '진료시간' : '임시 휴진·진료시간 변경';
		}
		return 'hours' === $which ? $l['cap_hours'] : $l['cap_exc'];
	}

	/** 오늘 바: '오늘 진료 {시간}' / '오늘 휴진' / '오늘 휴진 · {사유}'(사유는 원문 그대로 괄호 안 — 관리자 입력). */
	public static function today( string $ko, string $lang ): ?string {
		$l = self::lex( $lang );
		if ( null === $l ) {
			return null;
		}
		if ( 1 === preg_match( '/^오늘 진료 (.+)$/u', $ko, $m ) ) {
			$span = self::span( $m[1], $l );
			return null === $span ? null : sprintf( $l['open_today'], $span );
		}
		if ( '오늘 휴진' === $ko ) {
			return $l['closed_today'];
		}
		if ( 1 === preg_match( '/^오늘 휴진 · (.+)$/u', $ko, $m ) ) {
			return sprintf( $l['today_why'], $m[1] );
		}
		return null;
	}

	/** 표 왼쪽 칸(요일 묶음·공휴일·휴진·일요일 진료·날짜). */
	public static function label( string $ko, string $lang ): ?string {
		$l = self::lex( $lang );
		if ( null === $l ) {
			return null;
		}
		$fixed = array(
			'공휴일'    => $l['holidays'],
			'휴진'     => $l['closed'],
			'일요일 진료' => $l['sunday_row'],
		);
		if ( isset( $fixed[ $ko ] ) ) {
			return $fixed[ $ko ];
		}
		if ( 1 === preg_match( '/^(\d{1,2})월 (\d{1,2})일\(([월화수목금토일])\)$/u', $ko, $m ) ) {
			return sprintf( $l['date'], (int) $m[2], $l['months'][ (int) $m[1] ] ?? '', self::day( $m[3], $l ), (int) $m[1] );
		}
		$holiday = str_ends_with( $ko, '·공휴일' );
		$days    = self::days( $holiday ? substr( $ko, 0, -strlen( '·공휴일' ) ) : $ko, $l );
		if ( null === $days ) {
			return null;
		}
		return $holiday ? sprintf( $l['and_holidays'], $days ) : $days;
	}

	/** 표 오른쪽 칸(시간·휴진 목록·일요일 원장 줄·'휴진 · 사유'). */
	public static function value( string $ko, string $lang ): ?string {
		$l = self::lex( $lang );
		if ( null === $l ) {
			return null;
		}
		if ( '휴진' === $ko ) {
			return $l['closed'];
		}
		if ( 1 === preg_match( '/^휴진 · (.+)$/u', $ko, $m ) && 1 !== preg_match( '/^(매주|매월|공휴일)/u', $m[1] ) ) {
			return sprintf( $l['closed_why'], $m[1] ); // 날짜별 예외의 사유(관리자 입력 — 원문 그대로).
		}
		$span = self::span( $ko, $l );
		if ( null !== $span ) {
			return $span;
		}
		$parts = array();
		foreach ( explode( ' · ', $ko ) as $part ) {
			$t = self::part( $part, $l );
			if ( null === $t ) {
				return null;
			}
			$parts[] = $t;
		}
		return self::clean( implode( $l['list'], $parts ) );
	}

	/** 일요일 진료 원장 줄의 값만(의료진 쪽 — Render::sundayDoctorRow). 줄이 없으면 null. */
	public static function sundayLine( array $config, string $lang ): ?string {
		$row = Render::sundayDoctorRow( $config );
		return null === $row ? null : self::value( $row[1], $lang );
	}

	/** 목록 한 조각: 휴진 요일 · 마지막주 일요일 · 공휴일 · '매주 일요일 {원장}' · '매월 마지막주 일요일 휴진'. */
	private static function part( string $part, array $l ): ?string {
		if ( '매월 마지막주 일요일' === $part ) {
			return $l['last_sun'];
		}
		if ( '매월 마지막주 일요일 휴진' === $part ) {
			return $l['closed_last'];
		}
		if ( '공휴일' === $part ) {
			return $l['holidays'];
		}
		if ( 1 === preg_match( '/^매주 일요일 (\S+) 원장$/u', $part, $m ) ) {
			$dr = self::doctor( $m[1], $l );
			return null === $dr ? null : sprintf( $l['every_sun_dr'], $dr );
		}
		if ( 1 === preg_match( '/^매주 ([월화수목금토일](?:·[월화수목금토일])*)요일(\(공휴일 포함\)|\(공휴일이면 공휴일 진료시간\))?$/u', $part, $m ) ) {
			$every = sprintf( $l['every'], implode( $l['join'], array_map( static fn( string $d ): string => self::day( $d, $l, 'long' ), explode( '·', $m[1] ) ) ) );
			$note  = $m[2] ?? '';
			if ( '(공휴일 포함)' === $note ) {
				return sprintf( $l['incl'], $every );
			}
			return '' === $note ? $every : sprintf( $l['hol_hours'], $every );
		}
		return null;
	}

	/** 원장 이름 → 'Dr. Go Sihwan' 등(이름 표에 없으면 null). */
	private static function doctor( string $name, array $l ): ?string {
		return isset( self::NAMES[ $name ] ) ? sprintf( $l['dr'], self::NAMES[ $name ] ) : null;
	}

	/** '09:00~18:00' / '09:00~18:00 (점심 13:00~14:00)' / '… (휴게 a~b · c~d)'. */
	private static function span( string $ko, array $l ): ?string {
		if ( 1 !== preg_match( '/^(\d\d:\d\d)~(\d\d:\d\d)(?: \((점심|휴게) (.+)\))?$/u', $ko, $m ) ) {
			return null;
		}
		$out = $m[1] . '–' . $m[2];
		if ( isset( $m[3] ) && '' !== $m[3] ) {
			$gaps = array();
			foreach ( explode( ' · ', $m[4] ) as $gap ) {
				if ( 1 !== preg_match( '/^(\d\d:\d\d)~(\d\d:\d\d)$/', $gap, $g ) ) {
					return null;
				}
				$gaps[] = $g[1] . '–' . $g[2];
			}
			$out = sprintf( '점심' === $m[3] ? $l['lunch'] : $l['breaks'], $out, implode( ', ', $gaps ) );
		}
		return $out;
	}

	/** '화~금' → 'Tue–Fri', '토·일' → 'Sat, Sun'. 요일 글자 밖의 글자가 있으면 null. */
	private static function days( string $ko, array $l ): ?string {
		if ( 1 !== preg_match( '/^[월화수목금토일](?:[~·][월화수목금토일])*$/u', $ko ) ) {
			return null;
		}
		$out = '';
		foreach ( preg_split( '//u', $ko, -1, PREG_SPLIT_NO_EMPTY ) as $ch ) {
			$out .= '~' === $ch ? $l['range'] : ( '·' === $ch ? $l['sep'] : self::day( $ch, $l ) );
		}
		return $out;
	}

	/** 한글이 남았으면 null(번역 못 함). */
	private static function clean( string $text ): ?string {
		return 1 === preg_match( '/\p{Hangul}/u', $text ) ? null : $text;
	}

	/**
	 * 요약 한 줄(Render::summary — 맨 위 띠·히어로): '일요일·공휴일 진료 · 매주 월요일(공휴일 포함) 휴진 · 매월 마지막주 일요일 휴진'.
	 * 띠가 휴대폰에서 두 줄 안에 들도록 표보다 짧게 쓴다.
	 */
	public static function summary( string $ko, string $lang ): ?string {
		$l = self::lex( $lang );
		if ( null === $l ) {
			return null;
		}
		$map   = array(
			'일요일·공휴일 진료'      => $l['sum_sun_hol'],
			'일요일 진료'          => $l['sum_sun'],
			'공휴일 진료'          => $l['sum_hol'],
			'매월 마지막주 일요일 휴진' => $l['sum_last'],
		);
		$parts = array();
		foreach ( explode( ' · ', $ko ) as $part ) {
			if ( isset( $map[ $part ] ) ) {
				$parts[] = $map[ $part ];
				continue;
			}
			if ( 1 === preg_match( '/^매주 ([월화수목금토일](?:·[월화수목금토일])*)요일(\(공휴일 포함\))? 휴진$/u', $part, $m ) ) {
				$days    = implode( $l['join'], array_map( static fn( string $d ): string => self::day( $d, $l, 'plural' ), explode( '·', $m[1] ) ) );
				$closed  = sprintf( $l['sum_closed'], $days );
				$parts[] = isset( $m[2] ) && '' !== $m[2] ? sprintf( $l['sum_incl'], $closed ) : $closed;
				continue;
			}
			return null;
		}
		return self::clean( implode( ' · ', $parts ) );
	}
}
