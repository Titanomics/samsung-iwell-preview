<?php
/**
 * 진료시간 단일 조회(Task 4). 화면(Task 5)·구조화 데이터(Task 6·9)·llms.txt 는 진료시간을 이 함수로만 읽는다.
 *
 * config() = config/hours.php 기본값 + config/holidays.php(키 `holidays`) 위에 관리자 옵션 `iwell_hours`를 얹은 값.
 * 옵션은 키별로 형식을 검사해 맞는 부분만 반영하고, 잘못된 부분은 기본값을 그대로 둔다(경고 없이). 모르는 키는 버린다.
 *  - weekly          요일(정수 1~7)별로: 세션 목록이 맞으면 그 요일을 통째로 교체(빈 목록 = 그 요일 휴진). 틀린 요일만 기본값.
 *  - holidayHours    세션 목록이면 교체(빈 목록 = 공휴일 휴진).
 *  - closedWeekdays  1~7 정수 목록이면 교체(빈 목록 = 정기 휴진 요일 없음, 중복 제거).
 *  - closeLastSunday bool 이면 교체(false 보존).
 *  - mondayHolidayPolicy 'closed' | 'open' 과 정확히 같을 때만 교체(엄격 비교 — 'open\n'·' open' 은 오류).
 *  - exceptions      'Y-m-d' → 세션 목록 또는 {closed: true, reason?: string} — 맞는 날짜 항목만 더한다(reason 없으면 '').
 *                    이 검사는 공개 메서드 exceptions() — 관리자 화면(Admin, Task 5)도 저장 전에 같은 검사를 거친다.
 *  - doctorsByDate·holidays  'Y-m-d' → 비어 있지 않은 문자열 — 맞는 항목만 더한다(holidays 는 날짜순 정렬).
 * 날짜 키 = ASCII 'YYYY-MM-DD' 정확히(\z 끝 앵커 — NUL·끝 줄바꿈·공백·전각 숫자 거부) + 실제 있는 날짜.
 * 세션 = list<{from: 'HH:MM', to: 'HH:MM'}>, 00:00~23:59(\z 끝 앵커), from < to. 하나라도 틀리면 그 목록 전체를 버린다(일부만 남겨 시간을 바꾸지 않는다).
 * 표시 문자열(reason·의사·공휴일 이름) = text(): 제어문자는 공백으로 바꾸고 앞뒤 공백 제거. 비거나 UTF-8 이 아니면 이름 항목은 버리고,
 *   예외 사유는 ''로 둔다(휴진은 유지).
 * 옵션이 배열이 아니면 무시한다.
 */

namespace Iwell\Core\Hours;

use DateTimeImmutable;
use ValueError;

defined( 'ABSPATH' ) || exit;

final class Store {
	public const OPTION = 'iwell_hours';

	private const MONDAY_HOLIDAY_POLICIES = array( 'closed', 'open' );

	/** @return array{weekly: array<int, list<array{from: string, to: string}>>, holidayHours: list<array{from: string, to: string}>, closedWeekdays: list<int>, closeLastSunday: bool, mondayHolidayPolicy: string, exceptions: array<string, list<array{from: string, to: string}>|array{closed: true, reason: string}>, doctorsByDate: array<string, string>, holidays: array<string, string>} */
	public static function config(): array {
		$config = self::defaults();
		$option = get_option( self::OPTION, array() );
		if ( ! is_array( $option ) ) {
			return $config;
		}

		if ( is_array( $option['weekly'] ?? null ) ) {
			foreach ( $option['weekly'] as $weekday => $value ) {
				$sessions = self::sessions( $value );
				if ( is_int( $weekday ) && $weekday >= 1 && $weekday <= 7 && null !== $sessions ) {
					$config['weekly'][ $weekday ] = $sessions;
				}
			}
		}

		$holiday_hours = self::sessions( $option['holidayHours'] ?? null );
		if ( null !== $holiday_hours ) {
			$config['holidayHours'] = $holiday_hours;
		}

		$closed_weekdays = self::weekdays( $option['closedWeekdays'] ?? null );
		if ( null !== $closed_weekdays ) {
			$config['closedWeekdays'] = $closed_weekdays;
		}

		if ( is_bool( $option['closeLastSunday'] ?? null ) ) {
			$config['closeLastSunday'] = $option['closeLastSunday'];
		}

		if ( in_array( $option['mondayHolidayPolicy'] ?? null, self::MONDAY_HOLIDAY_POLICIES, true ) ) {
			$config['mondayHolidayPolicy'] = $option['mondayHolidayPolicy'];
		}

		foreach ( self::exceptions( $option['exceptions'] ?? null ) as $ymd => $exception ) {
			$config['exceptions'][ $ymd ] = $exception;
		}

		foreach ( array( 'doctorsByDate', 'holidays' ) as $key ) {
			foreach ( self::dateMap( $option[ $key ] ?? null ) as $ymd => $value ) {
				$name = self::text( $value );
				if ( null !== $name && '' !== $name ) {
					$config[ $key ][ $ymd ] = $name;
				}
			}
		}
		ksort( $config['holidays'], SORT_STRING );

		return $config;
	}

	/**
	 * 날짜 예외 맵 검사 — config()와 관리자 화면 저장(Admin, Task 5)이 같은 규칙을 쓰려고 공개한다.
	 * 키가 실제 날짜이고 값이 세션 목록 또는 {closed: true, reason: string} 인 항목만, 정리한 값으로 남긴다(틀린 항목은 버림).
	 *
	 * @return array<string, list<array{from: string, to: string}>|array{closed: true, reason: string}>
	 */
	public static function exceptions( mixed $value ): array {
		$out = array();
		foreach ( self::dateMap( $value ) as $ymd => $item ) {
			$exception = self::exception( $item );
			if ( null !== $exception ) {
				$out[ $ymd ] = $exception;
			}
		}
		return $out;
	}

	private static function defaults(): array {
		$dir                  = dirname( __DIR__, 2 ) . '/config';
		$defaults             = require $dir . '/hours.php';
		$defaults['holidays'] = require $dir . '/holidays.php';
		return $defaults;
	}

	/** 세션 목록이면 {from, to}만 남긴 목록(빈 목록 포함), 아니면 null. */
	private static function sessions( mixed $value ): ?array {
		if ( ! is_array( $value ) || ! array_is_list( $value ) ) {
			return null;
		}
		$list = array();
		foreach ( $value as $session ) {
			$from = is_array( $session ) ? ( $session['from'] ?? null ) : null;
			$to   = is_array( $session ) ? ( $session['to'] ?? null ) : null;
			if ( ! self::isTime( $from ) || ! self::isTime( $to ) || strcmp( $from, $to ) >= 0 ) {
				return null;
			}
			$list[] = array( 'from' => $from, 'to' => $to );
		}
		return $list;
	}

	private static function isTime( mixed $value ): bool {
		return is_string( $value ) && 1 === preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d\z/', $value );
	}

	/**
	 * 표시용 문자열: 문자열이 아니거나 UTF-8 이 아니면 null, 아니면 제어문자(\p{Cc}: NUL·줄바꿈·탭·DEL·C1) 묶음을 공백 하나로 바꾸고 앞뒤 공백을 뗀 값.
	 * (잘못된 UTF-8 은 update_option 이 저장을 거부하지만 객체 캐시·필터로 들어올 수 있다.)
	 */
	private static function text( mixed $value ): ?string {
		if ( ! is_string( $value ) || 1 !== preg_match( '//u', $value ) ) {
			return null;
		}
		return trim( (string) preg_replace( '/\p{Cc}+/u', ' ', $value ) );
	}

	/** 1~7 정수 목록이면 중복을 뺀 목록, 아니면 null. */
	private static function weekdays( mixed $value ): ?array {
		if ( ! is_array( $value ) || ! array_is_list( $value ) ) {
			return null;
		}
		foreach ( $value as $weekday ) {
			if ( ! is_int( $weekday ) || $weekday < 1 || $weekday > 7 ) {
				return null;
			}
		}
		return array_values( array_unique( $value ) );
	}

	/** 키가 실제 날짜('Y-m-d', ASCII 숫자, 앞뒤 문자·NUL·줄바꿈 없음)인 항목만 남긴 맵. 배열이 아니면 빈 맵. */
	private static function dateMap( mixed $value ): array {
		$map = array();
		foreach ( is_array( $value ) ? $value : array() as $ymd => $item ) {
			if ( is_string( $ymd ) && self::isDate( $ymd ) ) {
				$map[ $ymd ] = $item;
			}
		}
		return $map;
	}

	private static function isDate( string $ymd ): bool {
		if ( 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}\z/', $ymd ) ) {
			return false;
		}
		try {
			$date = DateTimeImmutable::createFromFormat( '!Y-m-d', $ymd );
		} catch ( ValueError $e ) {
			return false;
		}
		return false !== $date && $date->format( 'Y-m-d' ) === $ymd;
	}

	/**
	 * 날짜 예외: 세션 목록 또는 {closed: true, reason: string}, 아니면 null.
	 * reason 이 문자열이 아니면 항목을 버린다. 문자열이면 text()로 정리하고, UTF-8 이 아니면 ''(사유 없는 휴진) — 휴진 자체는 지킨다
	 * (항목을 버리면 그날이 진료로 보인다).
	 */
	private static function exception( mixed $value ): ?array {
		$sessions = self::sessions( $value );
		if ( null !== $sessions ) {
			return $sessions;
		}
		if ( ! is_array( $value ) || true !== ( $value['closed'] ?? null ) ) {
			return null;
		}
		$reason = $value['reason'] ?? '';
		return is_string( $reason ) ? array( 'closed' => true, 'reason' => self::text( $reason ) ?? '' ) : null;
	}
}
