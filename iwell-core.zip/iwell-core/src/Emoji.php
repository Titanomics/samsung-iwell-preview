<?php
/**
 * 워드프레스 코어 이모지 끄기(교차 확인 agy Gemini 4 Neon P1 — 2026-11-25).
 *
 * 왜: 개인정보처리방침 제10조·제11조와 게시 전 조건 3("외부 요청·쿠키 없음")의 전제. 코어 기본값은 모든 화면 머리에 이모지 감지 스크립트를 넣고,
 * 이모지를 직접 못 그리는 브라우저에서는 s.w.org(워드프레스닷오그)에서 그림을 불러오며, 자원 힌트(dns-prefetch)로 s.w.org 를 미리 연결한다.
 * 이 사이트 화면은 이모지 그림이 필요 없다(브라우저 글꼴로 그린다).
 *
 * 하는 일(공개 화면·관리 화면·임베드·피드·메일): 감지 스크립트·이모지 스타일 훅을 떼고, 피드·메일의 이모지 그림 바꾸기를 떼고,
 * 자원 힌트에서 s.w.org 를 빼고, 이모지 그림 주소(emoji_svg_url)를 끈다. 코어 판마다 훅 이름이 달라(6.4 이전 print_emoji_styles,
 * 이후 wp_enqueue_emoji_styles) 둘 다 뗀다 — 없는 훅을 떼는 것은 아무 일도 하지 않는다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class Emoji {
	/** 떼는 [훅, 함수, 우선순위]. */
	public const HOOKS = array(
		array( 'wp_head', 'print_emoji_detection_script', 7 ),
		array( 'admin_print_scripts', 'print_emoji_detection_script', 10 ),
		array( 'embed_head', 'print_emoji_detection_script', 10 ),
		array( 'embed_head', 'print_emoji_styles', 10 ),
		array( 'enqueue_embed_scripts', 'wp_enqueue_emoji_styles', 10 ),
		array( 'wp_print_styles', 'print_emoji_styles', 10 ),
		array( 'admin_print_styles', 'print_emoji_styles', 10 ),
		array( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles', 10 ),
		array( 'admin_enqueue_scripts', 'wp_enqueue_emoji_styles', 10 ),
		array( 'the_content_feed', 'wp_staticize_emoji', 10 ),
		array( 'comment_text_rss', 'wp_staticize_emoji', 10 ),
		array( 'wp_mail', 'wp_staticize_emoji_for_email', 10 ),
	);

	public static function register(): void {
		self::unhook();
		add_action( 'init', array( self::class, 'unhook' ), 99 ); // 다른 플러그인이 init(기본 10)에서 다시 건 경우까지 — 그 뒤에 뗀다.
		add_filter( 'emoji_svg_url', '__return_false' );
		add_filter( 'wp_resource_hints', array( self::class, 'resourceHints' ), 10, 2 );
	}

	public static function unhook(): void {
		foreach ( self::HOOKS as [ $hook, $callback, $priority ] ) {
			remove_action( $hook, $callback, $priority );
			remove_filter( $hook, $callback, $priority );
		}
	}

	/** 자원 힌트(dns-prefetch 등)에서 s.w.org 를 뺀다. 문자열 주소와 ['href' => …] 꼴 둘 다. */
	public static function resourceHints( mixed $urls, mixed $relation = '' ): mixed {
		if ( ! is_array( $urls ) ) {
			return $urls;
		}
		$out = array();
		foreach ( $urls as $url ) {
			$href = is_array( $url ) ? (string) ( $url['href'] ?? '' ) : (string) $url;
			if ( str_contains( $href, 's.w.org' ) ) {
				continue;
			}
			$out[] = $url;
		}
		return $out;
	}
}
