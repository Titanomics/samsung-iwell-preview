<?php
/**
 * 페이지 메타(Task 6) — 의학 페이지의 기준일·검토자·검토일·출처·의료진·용어와 Rank Math SEO 제목·설명.
 *
 * 메타(고정 페이지, single, REST 노출 show_in_rest, 수정 이력 wp_post_revision_meta_keys 등록):
 *   iwell_data_asof    'Y-m-d'  기준일(편집기 패널에서 입력)               쓰기 = edit_post
 *   iwell_reviewed_by  int      검토자 사용자 ID(자동 기록)                쓰기 = 누구도 직접 못 씀(아래)
 *   iwell_reviewed_at  'Y-m-d'  검토일 KST(자동 기록)                      쓰기 = 누구도 직접 못 씀
 *   iwell_sources      list<{title, url, accessed}>  출처(편집기 패널)     쓰기 = edit_post
 *   iwell_physician    {name, jobTitle, medicalSpecialty, alumniOf[], sameAs[]}  의료진 페이지   쓰기 = edit_post
 *   iwell_terms        list<{term, description}>  용어 사전 페이지         쓰기 = edit_post
 *   rank_math_title · rank_math_description  Rank Math 1.0.282 가 스스로 수정 이력에 등록하지 않아(docs/compat-gate.md 1-2) 여기서 등록,
 *                      REST 노출(Task 13 시드가 /wp/v2/pages 로 넣는다)    쓰기 = edit_post(계획 Task 6)
 * edit_post 판정이라 직원은 초안·자기 수정안만 고치고, 게시된 페이지 메타는 수정안 → 원장 승인으로만 바뀐다(Review Focus 5).
 *
 * 검토 자동 기록 — "원장이 승인·게시하는 순간"(계획 Task 6):
 *   - 원장 역할(iwell_director) 사용자가 고정 페이지를 게시 상태로 저장하면(새로 게시·게시본 수정) wp_after_insert_post 우선순위 5
 *     (워드프레스 수정본 저장 wp_save_post_revision_on_insert 9 보다 먼저 → 그 수정본에도 새 검토 값이 담긴다).
 *   - PublishPress Revisions 승인(revision_approved — 메타 복사 rvy_apply_revision 뒤): 게시본에 기록. 승인되어 워드프레스 수정본이 된
 *     수정안에도 같은 값을 넣는다(그 판을 되돌리면 그 승인 기록이 돌아오게). 예약 승인(future-revision)은 수정안에 넣는다 → 예약 게시 때
 *     PublishPress 가 메타를 복사하며 함께 반영.
 *   - 예약 발행(Task 6 수정 M1): 원장이 고정 페이지를 예약(future)으로 저장하는 순간 = 승인 → 승인자·승인일을 보호 내부 메타
 *     _iwell_pending_review {by, at} 에 둔다. future → publish 때 로그인 사용자가 없거나(wp-cron) 원장이 아니면, 그 승인이 있고 승인자가
 *     지금도 원장일 때만 iwell_reviewed_by·iwell_reviewed_at = 승인자·승인일(검토일 = 예약한 날, 공개한 날 아님). 원장이 직접 공개하면
 *     원장·그날. 예약에서 빠지면(초안·검토 대기 등) 승인 끝 → 내부 메타 삭제. 원장 아닌 계정이 예약한 페이지는 기록 없음.
 *     내부 메타는 show_in_rest 없음(REST 로 보내도 무시)·auth 거짓·밑줄 보호 메타 → 직원이 미리 심을 수 없다.
 *   - 승인 뒤 변경(Task 6 수정 2): 원장 아닌 계정(관리자·로그인 없는 코드 포함)이 승인된 예약 페이지의 본문·제목·발췌·검토 대상 메타
 *     (REVIEWED_META)를 바꾸면 승인 삭제 + 검토 대기(pending) → cron 이 공개하지 않고 원장이 다시 예약해야 한다. 원장이 고치면 승인자·
 *     승인일 = 그 원장·오늘. 날짜만 바꾸는 등 검토 대상 밖 변경은 승인 유지. 직원·봇은 예약 페이지를 아예 고칠 수 없다(Roles).
 *   - 승인된 예약 수정안(Task 6 수정 3): PublishPress 가 예약 승인한 수정안(post_mime_type future-revision)도 같다 — 원장 아닌 계정이
 *     검토 대상을 바꾸면 예약 승인 취소(제출 상태 pending-revision 으로, 반영 작업·_rvy_approved_by 삭제, 수정안 검토 정보 0·''),
 *     원장이 고치면 승인자·승인일 = 그 원장·오늘. 직원·봇은 승인 수정안을 고칠 수 없다(Roles). 제출 전 수정안은 그대로(원장이 승인할 때의 내용이 기준).
 *   - 같은 값(정리 뒤)을 다시 쓰는 것은 변경이 아니다 — 저장 안 된 메타는 등록 기본값(빈 문자열·빈 배열)과 같다(수정 3 M2).
 *   - 날짜 = Rules::today()(서울 날짜, 필터 iwell_now — 진료시간 바와 같은 "오늘").
 *   - 관리자(administrator)·편집자 게시는 기록하지 않는다(의학적 검토자는 원장 — 클로드 판단, 유지보수 계정이 검토자로 찍히지 않게).
 *   - 원장 검토 기록은 원장이 승인한 내용에만 붙는다(Task 6 수정 4 — 코디네이터 결정, M1 판정과 같은 원칙):
 *     ① PublishPress 수정안을 원장 아닌 계정이 바로 승인·반영하면 게시본 검토 기록 0·''(revision_applied), 예약 승인하면 수정안 검토 정보
 *        0·''(revision_approved → 반영 때 게시본으로 복사). 예약 수정안의 cron 반영은 수정안이 가진 승인 기록 그대로(위 수정 1·3 경로).
 *     ② 원장 아닌 계정(관리자·편집자·로그인 없는 코드)이 검토 기록 있는 고정 페이지의 검토 대상(REVIEWED_FIELDS·REVIEWED_META)을 직접
 *        바꾸거나 수정 이력을 되돌리면 검토 기록 0·'' — 상태는 그대로(내리지 않음). 검토 대상 밖·같은 값 재저장은 유지. PublishPress 메타
 *        복사(반영·미리보기 미러)는 사람의 변경으로 보지 않는다(①의 규칙만).
 *     ③ 원장이 다시 저장·승인·되돌리면 원장·오늘.
 *   - 반영 내용 = 승인 내용(Task 6 수정 5 — 코디네이터 결정, 같은 원칙):
 *     F1 PublishPress 가 수정안을 반영할 때(바로·예약) 게시본의 검토 대상 메타(REVIEWED_META — 수정 6 부터 각주 포함 7개) = 수정안 값 — 수정안에 없는 키는 게시본에서
 *        지운다(PublishPress 삭제 허용 키 필터 revisionary_deletable_postmeta_keys — 반영 복사 때만). 반영 뒤 공개 내용(제목·본문·발췌·검토 대상 메타)이
 *        승인 내용(반영한 수정안)과 다르면 원장 기록을 붙이지 않는다(0·''). 예약 수정안 반영 때 승인자가 지금 원장이 아니면 0·''(예약 페이지와 같은 규칙).
 *     F2 원장 아닌 계정이 동기화 패턴(wp_block)의 화면 출력(본문·공개 상태·비밀번호)을 바꾸거나 지우면 그 패턴을 쓰는(중첩 포함) 고정 페이지에
 *        수정 2·3·4 와 같은 규칙(검토 기록 0·'' · 원장 예약 페이지 검토 대기 · 원장 예약 승인 수정안 승인 취소). 직원·봇은 패턴을 못 고친다(Roles).
 *        첨부: 게시·예약된 고정 페이지(승인 수정안 포함)가 쓰는 첨부는 직원·봇이 못 고치고 못 지운다(attachmentInApprovedUse → Roles).
 *   - 같은 원칙의 확장(Task 6 수정 6 — 수정 5 보고 §8 코디네이터 결정):
 *     ② 원장 아닌 계정(관리자·편집자·로그인 없는 코드)이 그 첨부(pagesUsingAttachment — attachmentInApprovedUse 와 같은 조회)의
 *        대체 글·캡션·제목·설명(공개 alt·캡션·JSON-LD ImageObject caption 이 그때그때 읽는 값)을 바꾸면 그 첨부를 쓰는 고정 페이지에
 *        F2 ② 와 같은 lapse()(수정 2·3·4 규칙). 원장 변경·같은 값 재저장은 유지. 첨부 삭제는 범위 밖(보고만 — 삭제 중 메타 정리는 보지 않는다).
 *     ④ ① 각주 메타 footnotes(core/footnotes 블록이 그때그때 읽는 값 — wp-includes/blocks/footnotes.php:29)도 검토 대상 메타(REVIEWED_META):
 *        원장 아닌 계정 변경 → 수정 2~4 규칙, 수정안 반영 때 F1 동기화(삭제 허용 키·승인 내용 대조).
 *   - 원칙을 출력 시점에 직접 검사(Task 6 수정 7 — Codex 재확인 3 뒤 코디네이터 결정):
 *     결정 1 승인 지문(Seal): 원장 승인 순간(record·approve — 게시·예약·수정안 승인·되돌리기·예약 반영)마다 해석된 공개 원천의 지문을 남기고, 출력
 *        (get()·badgeText — 배지·JSON-LD, rest_prepare_page — 편집 패널·REST 메타) 때 verifiedReview 가 다시 계산해 다르면 검토 기록을 내보내지 않고
 *        그 자리에서 lapse(). 원장 예약 페이지는 cron 공개 직전(publish_future_post 5)에, 예약 승인 수정안은 반영 작업 직전(PublishPress 반영 훅 5)에도
 *        확인한다. 원장의 변경(패턴·첨부·페이지 메타·부모 제목)은 변경 직전 지문이 맞던 글에 다시 남긴다(holdSealed·resealHeld) — 원장 검토 범위.
 *     결정 2 의존성 해석기 하나(Sources): 직원·봇 첨부 차단, 관리자 패턴·첨부 변경 lapse, 지문이 같은 해석을 쓴다 — 패턴 안 첨부(C1)·"ref": 공백(C2)·
 *        평문 ids= 제외(C4). 관리자 첨부 삭제(A)는 삭제 전에 쓰던 페이지를 잡아 두고 삭제 뒤 lapse, 같은 첨부 파일 교체(B — _wp_attached_file·
 *        _wp_attachment_metadata 의 폭·높이·파일 이름)는 바뀌기 전·뒤 쓰는 페이지 모두 lapse.
 *     C3 대표 이미지(_thumbnail_id)도 검토 대상 메타(REVIEWED_META — 즉시·예약 수정안 복사·비교, 게시 페이지 무효화, 같은 값 재저장 유지).
 *   - 해석 불완전·검토 불가 원천은 닫힌 쪽(Task 6 수정 8 — Codex 재확인 4 F1 뒤 코디네이터 결정):
 *     결정 1 Sources 는 중첩 패턴을 워드프레스가 그리는 만큼(안전 상한 64) 따라가고, 상한을 넘으면 해석 불완전 → 검토 기록 없음(record·approve 가 남기지
 *        않고, 출력 때 verifiedReview 가 lapse), 그 페이지가 후보인 첨부는 "사용 중"(attachmentInApprovedUse → 직원·봇 403, 관리자 변경 lapse).
 *     결정 2 다른 글·댓글·사용자 프로필·사이트 설정·외부 주소를 그리는 블록·짧은 코드·블록 연결이 있는 페이지도 검토 기록 없음(Seal::sealable 거짓).
 *     결정 3 검토 대상 SEO 값 = 실제로 출력되는 값(Seal — 전역 템플릿·사이트 이름·구분자·%userid% 펼침) → 관리자 전역 변경은 다음 출력에서 lapse.
 *     결정 4 원장 검토 범위 = 페이지 본문(패턴 포함)·각주·쓰는 첨부·대표 이미지·검토 대상 메타·실제 출력 SEO 제목·설명. 테마 템플릿·템플릿 파트는 범위 밖.
 * 검토자·검토일을 사람이 못 바꾸게:
 *   - auth_callback 거짓 → 사용자 지정 필드 상자·XML-RPC 등 권한을 묻는 모든 경로가 거부(edit_post_meta 거짓).
 *   - REST(편집기·봇): rest_pre_insert_page 에서 요청의 meta 에서 두 키를 뺀다 → 보내도 무시(오류 없이 200 — 블록 편집기는 메타 객체를
 *     통째로 보내므로 오류로 막으면 저장 자체가 실패한다).
 *   - 편집기 패널(assets/editor-panel.js)은 읽기 전용 글자로만 보이고, 저장 요청에서도 뺀다.
 *
 * 그 밖에: 편집기 읽기 전용 REST 필드 iwell_review{by, name, at}(edit 문맥), 블록 iwell/review-badge,
 * GET /wp-json/iwell/v1/pages/by-path?path=a/b → {id, status, parent} | 404 (고정 페이지 권한 edit_pages 필요 — 비로그인 401, Task 13 시드).
 */

namespace Iwell\Core;

use Iwell\Core\Hours\Rules;
use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class PageMeta {
	public const POST_TYPE = 'page';

	public const KEYS           = array( 'iwell_data_asof', 'iwell_reviewed_by', 'iwell_reviewed_at', 'iwell_sources', 'iwell_physician', 'iwell_terms' );
	public const READONLY_KEYS  = array( 'iwell_reviewed_by', 'iwell_reviewed_at' );
	public const RANK_MATH_KEYS = array( 'rank_math_title', 'rank_math_description' );

	/** 예약 승인(내부 보호 메타, REST·편집기 노출 없음): 원장이 예약한 순간의 {by: 승인자 ID, at: 승인일 'Y-m-d' KST}. */
	public const PENDING_KEY = '_iwell_pending_review';

	/**
	 * 원장 검토 대상(Task 6 수정 2) — 예약 승인 뒤 원장 아닌 계정이 바꾸면 승인 무효 → 검토 대기. 글 필드와 메타.
	 * footnotes(워드프레스 코어 각주 메타 — register_block_core_footnotes_post_meta, wp-includes/blocks/footnotes.php:86-107)는 Task 6 수정 6 ④ ①.
	 * _thumbnail_id(대표 이미지 — 테마 post-featured-image·Rank Math JSON-LD ImageObject·og:image 가 읽는다)는 Task 6 수정 7 C3.
	 */
	public const REVIEWED_FIELDS = array( 'post_title', 'post_content', 'post_excerpt' );
	public const REVIEWED_META   = array( 'iwell_data_asof', 'iwell_sources', 'iwell_physician', 'iwell_terms', 'rank_math_title', 'rank_math_description', 'footnotes', '_thumbnail_id' );

	/** 첨부의 공개 값(수정 6 ②): 대체 글 메타 + 글 필드(제목·캡션 = 발췌·설명 = 본문). */
	public const ATTACHMENT_ALT    = '_wp_attachment_image_alt';
	private const ATTACHMENT_FIELDS = array( 'post_title', 'post_excerpt', 'post_content' );

	/** 첨부의 공개 값 메타(수정 6 ② 대체 글 + 수정 7 B 파일 — 이미지 편집기 저장·복원이 바꾼다: wp-admin/includes/image-edit.php update_attached_file·wp_update_attachment_metadata). */
	private const ATTACHMENT_META = array( self::ATTACHMENT_ALT, '_wp_attached_file', '_wp_attachment_metadata' );

	/** @var array<string, int[]> 원장 아닌 계정의 첨부 변경 직전에 그 첨부를 쓰던 페이지(바뀌기 전 파일 주소 포함 — 수정 7 A·B). */
	private static array $usersBefore = array();

	/** @var array<string, int[]> 원장 변경 직전에 승인 지문이 맞던 글(변경 뒤 지문을 다시 남긴다 — 수정 7 결정 1, 원장 변경은 원장 검토 범위). */
	private static array $sealedBefore = array();

	/** @var array<int, bool> 반영 중인 수정안의 원장 승인 지문이 맞는가 — 게시본 id → 값(수정 7 결정 1, beginCopy). */
	private static array $sealedApply = array();

	/** @var array<int, true> 지우는 중인 글(wp_delete_post 가 메타를 지울 때 승인 무효 처리를 하지 않게). */
	private static array $deleting = array();

	/**
	 * PublishPress Revisions 4.3.2 예약 승인 수정안(수정 3) — 승인(예약) 때 post_mime_type 이 이 값이 된다(revision-action_rvy.php:512-517,
	 * post_status 는 pending). 승인 취소 때는 제출 상태(SUBMITTED_REVISION — rvy_revision_submit 과 같은 저장, revision-action_rvy.php:185-189)로
	 * 되돌린다 → 원장 승인 대기열에 다시 오르고, 반영 처리기(rvy_publish_scheduled_revisions, :1666·:1676)는 future-revision 만 반영한다.
	 */
	public const SCHEDULED_REVISION = 'future-revision';
	public const SUBMITTED_REVISION = 'pending-revision';

	/** PublishPress 반영 작업 훅(Action Scheduler·옛 wp-cron — rvy_init.php:84·87). */
	private const RVY_AS_HOOK   = 'publish_revision_rvy_action_scheduler';
	private const RVY_CRON_HOOK = 'publish_revision_rvy';

	/** @var array<int, true> REST meta 사전 판정에서 검토 대상이 바뀌는 승인 수정안(→ 이어지는 wp_insert_post_data 에서 승인 취소). */
	private static array $revokeOnSave = array();

	/** @var array<int, true> 저장 직전에 제출 상태로 바꾼 수정안(→ 저장 뒤 wp_after_insert_post 에서 반영 작업·승인 정보 정리). */
	private static array $revoked = array();

	/** @var array<string, mixed> 검토 대상 메타 쓰기 직전 값(정리값) — "글 id:키" → 값. 같은 값 다시 쓰기·빈 기본값 재전송 구분(수정 3 M2). */
	private static array $metaBefore = array();

	/** @var array<int, true> 저장 직전 원장 아닌 계정이 검토 대상을 바꾼 검토 기록 있는 페이지(→ 저장 뒤 recordOnSave 에서 검토 기록 0·'', 수정 4 ②). */
	private static array $unreviewOnSave = array();

	/** @var array<int, int> PublishPress 가 메타를 복사하는 중인 대상 글(revisionary_copy_postmeta — 사람의 변경이 아니다, 수정 4). */
	private static array $copying = array();

	/** @var list<bool> 진행 중인 PublishPress 메타 복사마다 "수정안 → 게시본 반영인가"(중첩 복사 대비 스택, 수정 5 F1). */
	private static array $copyIsApply = array();

	/** @var array<int, array<string, mixed>> 반영 중인 수정안의 승인 내용(검토 대상 글 필드·메타 정리값) — 게시본 id → 값(수정 5 F1). */
	private static array $approvedContent = array();

	/** @var array<int, true> 원장이 바로 승인했지만 반영 뒤 공개 내용 ≠ 승인 내용인 게시본(→ recordOnApproval 이 기록하지 않는다, 수정 5 F1). */
	private static array $applyMismatch = array();

	/** 동기화 패턴 글 종류 — 화면 출력은 본문·공개 상태·비밀번호로 정해진다(render_block_core_block — wp-includes/blocks/block.php:26-50). */
	public const PATTERN_TYPE   = 'wp_block';
	private const PATTERN_FIELDS = array( 'post_content', 'post_status', 'post_password' );

	public const REST_NAMESPACE = 'iwell/v1';

	/** PublishPress Revisions 수정안(post_type 은 원본과 같은 page, post_mime_type 으로 구분). */
	public const REVISION_MIME_TYPES = array( 'draft-revision', 'pending-revision', 'future-revision' );

	private const MAX_ITEMS = 50;

	public static function register(): void {
		add_action( 'init', array( self::class, 'registerMeta' ) );
		add_action( 'init', array( self::class, 'registerBlock' ) );
		add_filter( 'wp_post_revision_meta_keys', array( self::class, 'revisionMetaKeys' ) );
		add_filter( 'rest_pre_insert_' . self::POST_TYPE, array( self::class, 'ignoreReadonlyMeta' ), 10, 2 );
		add_filter( 'rest_pre_insert_' . self::POST_TYPE, array( self::class, 'holdUnreviewedRestMeta' ), 20, 2 );
		add_filter( 'wp_insert_post_data', array( self::class, 'holdUnreviewedChange' ), 20, 3 );
		// 승인 수정안: PublishPress 가 우선순위 100(flt_regulate_revision_status — revisionary_main.php:388·1781-1835)에서 예약 수정안의
		// post_mime_type·post_status 변경을 되돌리므로(:1820-1831) 그 뒤(999 fltRemoveInvalidPostDataKeys 보다도 뒤)에 바꾼다.
		add_filter( 'wp_insert_post_data', array( self::class, 'revokeUnreviewedRevision' ), 1000, 3 );
		add_filter( 'wp_insert_post_data', array( self::class, 'markUnreviewedChange' ), 1000, 3 );
		// PublishPress 메타 복사(수정안 만들기·미리보기 미러·반영·되돌리기 — functions.php:141·144·237)는 사람의 검토 대상 변경이 아니다.
		add_action( 'revisionary_pre_copy_postmeta', array( self::class, 'beginCopy' ), 10, 2 );
		add_action( 'revisionary_post_copy_postmeta', array( self::class, 'endCopy' ), 10, 2 );
		// 반영 때 수정안에 없는 검토 메타는 게시본에서 지운다(수정 5 F1 — functions.php:221-231 의 삭제 허용 키).
		add_filter( 'revisionary_deletable_postmeta_keys', array( self::class, 'deletableOnApply' ) );
		// 동기화 패턴 변경·삭제 → 그 패턴을 쓰는 페이지(수정 5 F2 ②).
		add_action( 'wp_after_insert_post', array( self::class, 'onPatternSaved' ), 10, 4 );
		add_action( 'before_delete_post', array( self::class, 'onPatternDeleted' ), 10, 2 );
		// 승인 페이지가 쓰는 첨부의 공개 값 변경 → 그 첨부를 쓰는 페이지(수정 6 ②). 첨부는 wp_insert_post 의 첨부 분기에서 끝난다
		// (wp-includes/post.php:5175-5213 — wp_after_insert_post 없음, attachment_updated :5199).
		add_action( 'attachment_updated', array( self::class, 'onAttachmentUpdated' ), 10, 3 );
		add_action( 'add_post_meta', array( self::class, 'rememberMetaBeforeAdd' ), 10, 2 );
		foreach ( array( 'update_post_meta', 'delete_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'rememberMetaBeforeChange' ), 10, 3 );
		}
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'onReviewedMetaChange' ), 10, 3 );
			add_action( $hook, array( self::class, 'onAttachmentMetaChange' ), 10, 3 );
		}
		add_action( 'before_delete_post', array( self::class, 'markDeleting' ) );
		// 첨부 삭제(wp_delete_attachment — before_delete_post 없이 delete_attachment :6875 뒤 메타를 지운다 :6894)의 메타 정리는 대체 글 변경이 아니다.
		add_action( 'delete_attachment', array( self::class, 'markDeleting' ) );
		// 첨부 삭제(수정 7 A): 지우기 전에 쓰던 페이지를 잡아 두고(delete_attachment — 행·메타·파일이 아직 있다) 지운 뒤(deleted_post) lapse.
		add_action( 'delete_attachment', array( self::class, 'beforeAttachmentDelete' ) );
		add_action( 'deleted_post', array( self::class, 'afterDelete' ) );
		add_action( 'deleted_post', array( self::class, 'unmarkDeleting' ) );
		// 원장 변경 직전 지문(수정 7 결정 1): 패턴·첨부·고정 페이지 글 필드 저장 직전(wp_insert_post — pre_post_update), 메타는 rememberMeta*.
		add_action( 'pre_post_update', array( self::class, 'beforePostUpdate' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'resealAfterMeta' ), 20, 3 );
		}
		add_action( 'wp_after_insert_post', array( self::class, 'afterPostSaved' ), 20, 1 );
		add_action( 'wp_after_insert_post', array( self::class, 'recordOnSave' ), 5, 4 );
		// 출력 때 지문 확인(수정 7 결정 1): 편집 패널·REST 응답의 검토 값, 원장 예약 페이지 cron 공개 직전, 원장 예약 승인 수정안 반영 작업 직전.
		add_filter( 'rest_prepare_' . self::POST_TYPE, array( self::class, 'restReview' ), 10, 2 );
		add_action( 'publish_future_post', array( self::class, 'holdUnsealedFuture' ), 5 );
		add_action( self::RVY_AS_HOOK, array( self::class, 'revokeUnsealedRevision' ), 5 );
		add_action( self::RVY_CRON_HOOK, array( self::class, 'revokeUnsealedRevision' ), 5 );
		add_action( 'revision_approved', array( self::class, 'recordOnApproval' ), 10, 2 );
		add_action( 'revision_applied', array( self::class, 'clearOnApply' ), 10, 2 );
		// 워드프레스 수정 이력 되돌리기 — 코어가 수정 이력 메타(검토 기록 포함)를 되돌린 뒤(wp_restore_post_revision_meta 10).
		add_action( 'wp_restore_post_revision', array( self::class, 'recordOnRestore' ), 20, 2 );
		add_action( 'rest_api_init', array( self::class, 'registerRest' ) );
	}

	public static function registerMeta(): void {
		$edit_post = static fn( $allowed, $meta_key, $post_id ): bool => current_user_can( 'edit_post', (int) $post_id );
		$nobody    = static fn(): bool => false;
		$date      = array(
			'type'    => 'string',
			'pattern' => '^(\d{4}-\d{2}-\d{2})?$',
		);

		$meta = array(
			'iwell_data_asof'   => array( 'string', '', $date, array( self::class, 'sanitizeDate' ), $edit_post ),
			'iwell_reviewed_by' => array( 'integer', 0, array( 'type' => 'integer' ), 'absint', $nobody ),
			'iwell_reviewed_at' => array( 'string', '', $date, array( self::class, 'sanitizeDate' ), $nobody ),
			'iwell_sources'     => array(
				'array',
				array(),
				array(
					'type'  => 'array',
					'items' => array(
						'type'                 => 'object',
						'properties'           => array(
							'title'    => array( 'type' => 'string' ),
							'url'      => array( 'type' => 'string' ),
							'accessed' => array( 'type' => 'string' ),
						),
						'additionalProperties' => false,
					),
				),
				array( self::class, 'sanitizeSources' ),
				$edit_post,
			),
			'iwell_physician'   => array(
				'object',
				array(),
				array(
					'type'                 => 'object',
					'properties'           => array(
						'name'             => array( 'type' => 'string' ),
						'jobTitle'         => array( 'type' => 'string' ),
						'medicalSpecialty' => array( 'type' => 'string' ),
						'alumniOf'         => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
						'sameAs'           => array(
							'type'  => 'array',
							'items' => array( 'type' => 'string' ),
						),
					),
					'additionalProperties' => false,
				),
				array( self::class, 'sanitizePhysician' ),
				$edit_post,
			),
			'iwell_terms'       => array(
				'array',
				array(),
				array(
					'type'  => 'array',
					'items' => array(
						'type'                 => 'object',
						'properties'           => array(
							'term'        => array( 'type' => 'string' ),
							'description' => array( 'type' => 'string' ),
						),
						'additionalProperties' => false,
					),
				),
				array( self::class, 'sanitizeTerms' ),
				$edit_post,
			),
		);
		foreach ( $meta as $key => list( $type, $default, $schema, $sanitize, $auth ) ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => $type,
					'single'            => true,
					'default'           => $default,
					'show_in_rest'      => array( 'schema' => $schema ),
					'sanitize_callback' => $sanitize,
					'auth_callback'     => $auth,
				)
			);
		}

		// 예약 승인 내부 메타: REST 에 등록하지 않는다(요청 meta 로 보내도 무시) + 쓰기 권한 거짓(밑줄 보호 메타 — 사용자 지정 필드·XML-RPC 거부).
		register_post_meta(
			self::POST_TYPE,
			self::PENDING_KEY,
			array(
				'type'              => 'object',
				'single'            => true,
				'show_in_rest'      => false,
				'sanitize_callback' => array( self::class, 'sanitizePending' ),
				'auth_callback'     => $nobody,
			)
		);

		// Rank Math 메타: 값 정리는 Rank Math 에 맡긴다(sanitize_text_field 는 %date% 같은 Rank Math 변수를 깨뜨린다 — %da 를 퍼센트 인코딩으로 봄).
		foreach ( self::RANK_MATH_KEYS as $key ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'          => 'string',
					'single'        => true,
					'show_in_rest'  => true,
					'auth_callback' => $edit_post,
				)
			);
		}
	}

	/** 필터 wp_post_revision_meta_keys — 기존 키 뒤에 우리 키 8개를 중복 없이. */
	public static function revisionMetaKeys( $keys ): array {
		return array_values( array_unique( array_merge( (array) $keys, self::KEYS, self::RANK_MATH_KEYS ) ) );
	}

	/**
	 * REST 저장(블록 편집기·봇): 검토자·검토일은 보내도 무시. 워드프레스는 이 필터 뒤에 $request['meta'] 로 메타를 쓴다
	 * (WP_REST_Posts_Controller::create_item·update_item, 자동 저장 컨트롤러도 이 준비 단계를 거친다).
	 *
	 * @param \stdClass|WP_Error $prepared
	 * @return \stdClass|WP_Error
	 */
	public static function ignoreReadonlyMeta( $prepared, WP_REST_Request $request ) {
		$meta = $request->get_param( 'meta' );
		if ( is_array( $meta ) && array() !== array_intersect_key( $meta, array_flip( self::READONLY_KEYS ) ) ) {
			$request->set_param( 'meta', array_diff_key( $meta, array_flip( self::READONLY_KEYS ) ) );
		}
		return $prepared;
	}

	/**
	 * wp_after_insert_post(우선순위 5 — 워드프레스 수정본 저장 9 보다 먼저). 수정안(PublishPress)·다른 글 종류는 건너뛴다.
	 *   - publish: 원장이 저장하면 원장·오늘로 기록(새 게시·게시본 수정). 원장 아닌 계정·로그인 없음(cron)이 future → publish 로 바꾸면
	 *     예약 승인(내부 메타)이 있을 때만 그 승인자·승인일로 기록. 내부 메타는 어느 쪽이든 지운다.
	 *   - future: 원장이 저장하면(예약하는 순간·예약 상태로 다시 저장) 승인자·승인일을 내부 메타에 새로 쓴다(수정 2 ③). 원장 아닌 계정의
	 *     저장은 검토 대상이 그대로일 때만 여기까지 future 로 온다(날짜·슬러그만 바꿈 등) → 승인 유지. 검토 대상을 바꾸면 저장 전에
	 *     holdUnreviewedChange·holdUnreviewedRestMeta 가 상태를 pending 으로 바꿔 아래 default 로 간다(수정 2 ②).
	 *   - 그 밖의 상태(초안·검토 대기·비공개·휴지통): 예약에서 빠졌으므로 승인 끝 → 내부 메타를 지운다(원장 아닌 계정이 다시 예약해도 옛 승인이 쓰이지 않게).
	 *
	 * @param int          $post_id
	 * @param WP_Post      $post
	 * @param bool         $update
	 * @param WP_Post|null $post_before 저장 전 글(wp_publish_post·REST·wp_insert_post 가 넘긴다).
	 */
	public static function recordOnSave( $post_id, $post, $update = false, $post_before = null ): void {
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type ) {
			return;
		}
		$user = wp_get_current_user();
		if ( isset( self::$unreviewOnSave[ $post->ID ] ) ) {
			// 원장 아닌 계정이 검토 대상(글 필드·meta_input)을 바꿈 → 검토 기록 0·''(수정 4 ②) — 우선순위 5 라 이어지는 워드프레스 수정본(9)에도 0·''.
			unset( self::$unreviewOnSave[ $post->ID ] );
			self::unreview( $post->ID );
		}
		if ( isset( self::$revoked[ $post->ID ] ) ) {
			// 저장 직전 revokeUnreviewedRevision 이 제출 상태로 바꾼 승인 수정안 — 이제 저장됐으니 반영 작업·승인 정보를 지운다(수정 3 ②).
			unset( self::$revoked[ $post->ID ] );
			self::clearRevisionApproval( $post->ID );
			return;
		}
		if ( self::isRevisionDraft( $post ) ) {
			// 승인 수정안을 원장이 저장 = 다시 승인 → 승인자·승인일 = 그 원장·오늘(수정 3 ③). 원장 아닌 계정의 저장은 검토 대상이 그대로일
			// 때만 여기까지 예약 수정안으로 온다(날짜만 바꿈 등 — 승인 유지, ④).
			if ( self::isScheduledRevision( $post ) && self::isReviewer( $user ) ) {
				self::approveRevision( $post->ID, $user->ID );
			}
			return;
		}
		if ( self::hasReview( $post->ID ) && ! Seal::sealable( $post ) ) {
			// 검토 기록이 있는데 지금 검토할 수 없는 본문(목록 밖 블록·짧은 코드·해석 불완전)으로 저장됨 → 저장 시점에 0·''(수정 9 결정 3 — Codex 재확인 5 F5).
			// 원장·관리자·로그인 없는 cron(wp_publish_post) 모든 경로, 상태 무관(게시·예약·초안). 공개 렌더 때 해제(verifiedReview)에만 기대지 않는다.
			self::unreview( $post->ID );
		}
		switch ( $post->post_status ) {
			case 'publish':
				if ( self::isReviewer( $user ) ) {
					self::record( $post->ID, $user->ID, self::today() );
				} elseif ( $post_before instanceof WP_Post && 'future' === $post_before->post_status ) {
					// 예약 승인 지문 = 지금 공개 원천일 때만(수정 7 결정 1 — 승인 뒤 이벤트가 못 잡은 변경이 있으면 원장 기록 없이 공개).
					$pending = self::pendingReview( $post->ID );
					if ( null !== $pending && Seal::valid( $post ) ) {
						self::record( $post->ID, $pending['by'], $pending['at'] );
					}
				}
				delete_post_meta( $post->ID, self::PENDING_KEY );
				return;
			case 'future':
				if ( self::isReviewer( $user ) ) {
					self::approve( $post->ID, $user->ID );
				}
				return;
			default:
				delete_post_meta( $post->ID, self::PENDING_KEY );
		}
	}

	/**
	 * 예약 승인 기록(원장·오늘) + 그 순간의 승인 지문(수정 7 결정 1). 검토할 수 없는 페이지는 예약 승인을 남기지 않고(수정 8 — cron 공개도 기록 없음),
	 * 이미 승인된 페이지를 검토 불가 본문으로 다시 예약하면 예전 검토 기록도 그 자리에서 0·''(수정 9 결정 3 — F5; 검토 메타 변경 경로 onReviewedMetaChange 도 여기로 온다).
	 */
	private static function approve( int $post_id, int $user_id ): void {
		$post = get_post( $post_id );
		if ( $post instanceof WP_Post && ! Seal::sealable( $post ) ) {
			delete_post_meta( $post_id, self::PENDING_KEY );
			if ( self::hasReview( $post_id ) ) {
				self::unreview( $post_id );
			}
			return;
		}
		update_post_meta(
			$post_id,
			self::PENDING_KEY,
			array(
				'by' => $user_id,
				'at' => self::today(),
			)
		);
		Seal::stamp( $post_id );
	}

	// ── 예약 승인 뒤 검토 대상 변경 → 승인 무효·검토 대기(Task 6 수정 2 ②) ──────────────────
	// 원장이 예약(승인)한 고정 페이지를 원장 아닌 계정(관리자·편집자·로그인 없는 코드 포함)이 본문·제목·발췌·검토 대상 메타를 바꾸면
	// 승인을 지우고 상태를 pending 으로 내린다 → 상태 전환이 cron 예약(publish_future_post)을 지우고(_transition_post_status), cron 이
	// 공개하지 않는다. 원장이 다시 예약하면 새 승인. 바꾸는 경로마다 저장 전에 잡는다(공개 상태로 한 번이라도 저장되지 않게):
	//   - 글 필드(모든 wp_insert_post 경로 — REST·편집기·빠른 편집·코드): wp_insert_post_data, meta_input 도 같이
	//   - REST 메타(/wp/v2/pages 의 meta — 글을 저장한 뒤 쓰이므로 미리): rest_pre_insert_page
	//   - 그 밖의 메타 쓰기(Rank Math updateMeta·update_post_meta 직접): 쓰인 직후 added/updated/deleted_post_meta → 상태만 바꾼다
	// 날짜·슬러그·메뉴 순서·템플릿 같은 검토 대상 밖 변경, 같은 값 다시 저장은 승인 유지. 원장 승인이 없는 예약 페이지(관리자 예약)는
	// 지킬 승인이 없으므로 그대로 둔다. 직원·봇은 예약 페이지를 아예 고칠 수 없다(Roles::map_meta_cap).

	/** 저장 전 글 필드·meta_input 비교 — 승인이 걸린 예약 페이지의 검토 대상이 바뀌면 공개·예약 대신 검토 대기로 저장. */
	public static function holdUnreviewedChange( $data, $postarr, $unsanitized_postarr = array() ) {
		if ( ! is_array( $data ) || self::POST_TYPE !== ( $data['post_type'] ?? '' ) || ! in_array( $data['post_status'] ?? '', array( 'future', 'publish' ), true ) || empty( $postarr['ID'] ) ) {
			return $data;
		}
		$before = get_post( (int) $postarr['ID'] );
		if ( ! $before instanceof WP_Post || ! self::approvalAtStake( $before ) ) {
			return $data;
		}
		if ( self::reviewedChange( $before, $data, $postarr, $unsanitized_postarr ) ) {
			$data['post_status'] = 'pending';
		}
		return $data;
	}

	/** 저장 직전 값($data·meta_input)이 저장된 글과 검토 대상(글 필드·검토 대상 메타)에서 다른가. */
	private static function reviewedChange( WP_Post $before, array $data, $postarr, $unsanitized_postarr ): bool {
		foreach ( self::REVIEWED_FIELDS as $field ) {
			// $data 는 정리(sanitize_post·kses)를 마친 저장 직전 값(슬래시 붙음) — 저장된 값과 같은 형태로 비교한다.
			if ( wp_unslash( (string) ( $data[ $field ] ?? '' ) ) !== (string) $before->$field ) {
				return true;
			}
		}
		$meta_input = ( is_array( $unsanitized_postarr ) ? ( $unsanitized_postarr['meta_input'] ?? null ) : null ) ?? ( is_array( $postarr ) ? ( $postarr['meta_input'] ?? array() ) : array() );
		return is_array( $meta_input ) && self::metaChanges( $before->ID, wp_unslash( $meta_input ) );
	}

	// ── 원장 아닌 계정의 검토 대상 직접 변경 → 검토 기록 0·''(Task 6 수정 4 ②) ──────────────────────────
	// 원장 검토 기록은 원장이 승인한 내용에만 붙는다. 원장 아닌 계정(관리자·편집자·로그인 없는 코드)이 검토 기록이 있는 고정 페이지(수정안 제외)의
	// 제목·본문·발췌·검토 대상 메타를 바꾸면 iwell_reviewed_by·at = 0·'' — 상태는 그대로(게시본은 게시 유지, M1 판정 "관리자 게시 = 검토 기록 없이
	// 공개"와 같은 원칙). 원장이 다시 저장하면 recordOnSave 가 원장·오늘. 바꾸는 경로마다:
	//   - 글 필드·meta_input(REST·편집기·빠른 편집·코드): 저장 직전 markUnreviewedChange 가 표시 → 저장 뒤 recordOnSave(5)
	//   - 메타 쓰기(REST meta·Rank Math updateMeta·update_post_meta): onReviewedMetaChange
	//   - 수정 이력 되돌리기: recordOnRestore
	// 검토 대상 밖(날짜·슬러그·메뉴 순서)·같은 값(빈 기본값 포함) 재저장은 유지. PublishPress 반영은 승인 경로 규칙만 따른다(clearOnApply·
	// recordOnApproval — 반영 중 메타 복사는 beginCopy·endCopy 로 이 규칙에서 뺀다).

	/** 저장 직전(wp_insert_post_data 1000): 원장 아닌 계정이 검토 기록 있는 페이지의 검토 대상을 바꾸는가 → 저장 뒤 0·''. */
	public static function markUnreviewedChange( $data, $postarr, $unsanitized_postarr = array() ) {
		if ( ! is_array( $data ) || ! is_array( $postarr ) || empty( $postarr['ID'] ) || self::POST_TYPE !== ( $data['post_type'] ?? '' ) ) {
			return $data;
		}
		$id = (int) $postarr['ID'];
		unset( self::$unreviewOnSave[ $id ] );
		$before = get_post( $id );
		if ( ! $before instanceof WP_Post || self::POST_TYPE !== $before->post_type || self::isRevisionDraft( $before ) || ! self::hasReview( $id ) || self::isReviewer( wp_get_current_user() ) ) {
			return $data;
		}
		if ( self::reviewedChange( $before, $data, $postarr, $unsanitized_postarr ) ) {
			self::$unreviewOnSave[ $id ] = true;
		}
		return $data;
	}

	/** 검토 기록이 있는가(검토자 또는 검토일). */
	private static function hasReview( int $post_id ): bool {
		return absint( get_post_meta( $post_id, 'iwell_reviewed_by', true ) ) > 0 || '' !== (string) get_post_meta( $post_id, 'iwell_reviewed_at', true );
	}

	/**
	 * 검토 기록 0·'' — 키를 지우지 않고 값을 비운다: PublishPress 는 반영할 때 수정안에 없는 메타를 게시본에서 지우지 않으므로
	 * (revisionary_copy_postmeta — functions.php:221-229) 수정안에도 빈 값이 있어야 반영 때 게시본이 비워진다(수정 3 clearRevisionApproval 과 같은 값).
	 */
	private static function unreview( int $post_id ): void {
		update_post_meta( $post_id, 'iwell_reviewed_by', 0 );
		update_post_meta( $post_id, 'iwell_reviewed_at', '' );
	}

	/**
	 * revisionary_pre_copy_postmeta — PublishPress 가 $to_post_id 로 메타를 복사하기 시작(functions.php:141).
	 * 수정안 → 게시본 반영(rvy_apply_revision — revision-action_rvy.php:1087)이면 승인 내용(수정안의 검토 대상 글 필드·메타)을 잡아 둔다:
	 * 이 시점의 수정안이 원장이 승인한 내용이다(승인 뒤 바뀌면 수정 3 이 예약 승인을 취소했다). 게시본 글 필드는 이미 갱신됐다(:981).
	 */
	public static function beginCopy( $from_post, $to_post_id ): void {
		$id                    = (int) $to_post_id;
		self::$copying[ $id ] = ( self::$copying[ $id ] ?? 0 ) + 1;
		$apply                 = self::isApplyCopy( $from_post, $id );
		self::$copyIsApply[]   = $apply;
		if ( $apply ) {
			self::$approvedContent[ $id ] = self::reviewedContent( $from_post );
			// 원장이 승인한 수정안이면 그 승인 지문 = 수정안의 지금 공개 원천인가(수정 7 결정 1 — 승인 뒤 이벤트가 못 잡은 변경).
			self::$sealedApply[ $id ] = ! self::hasReview( $from_post->ID ) || Seal::valid( $from_post );
			return;
		}
		// 미리보기 미러(게시본 → 예약 승인 수정안, 수정안에 없는 키만 — front_rvy.php:434)는 사람의 변경이 아니다(수정 4): 복사 원본(게시본)이 원장 승인
		// 그대로일 때만(지문이 맞음 — 원장 승인 값이 채워진다) 복사 전에 지문이 맞던 수정안에 복사 뒤 지문을 다시 남긴다. 관리자가 바꾼 게시본 값이 채워지면
		// 그대로 어긋나 반영 직전에 예약 승인 취소(수정 7 결정 1).
		$to = get_post( $id );
		if ( $from_post instanceof WP_Post && $to instanceof WP_Post && self::isScheduledRevision( $to ) && self::POST_TYPE === $from_post->post_type
			&& self::sealedApproval( $from_post ) && Seal::valid( $from_post ) ) {
			self::holdSealed( "copy:$id", array( $id ) );
		}
	}

	/** 수정안(PublishPress, 고정 페이지) → 게시본(수정안 아님) 메타 복사 = 반영. 미리보기 미러·수정안 만들기(게시본 → 수정안)·되돌리기(수정본 → 게시본)는 아니다. */
	private static function isApplyCopy( $from_post, int $to_id ): bool {
		if ( ! $from_post instanceof WP_Post || self::POST_TYPE !== $from_post->post_type || ! self::isRevisionDraft( $from_post ) ) {
			return false;
		}
		$to = get_post( $to_id );
		return $to instanceof WP_Post && self::POST_TYPE === $to->post_type && ! self::isRevisionDraft( $to );
	}

	/**
	 * 필터 revisionary_deletable_postmeta_keys(functions.php:223) — PublishPress 는 반영 때 수정안에 없는 메타를 게시본에서 지우지 않는다
	 * (:221-231, 이 목록·apply_deletions·상수만 지운다). 반영 복사일 때만 검토 대상 메타(REVIEWED_META)를 더한다 → 게시본 = 수정안 값
	 * (수정안에 없는 키는 삭제 = 빈 기본값). 검토 기록 2개는 승인 경로가 정한다(원장·관리자 승인 모두 수정안·게시본에 값을 쓴다).
	 * 그 밖의 복사(수정안 만들기·되돌리기·미리보기 미러 — empty_target_only 라 삭제 단계 없음)는 그대로.
	 */
	public static function deletableOnApply( $keys ): array {
		$keys = is_array( $keys ) ? $keys : array();
		if ( array() !== self::$copyIsApply && true === self::$copyIsApply[ count( self::$copyIsApply ) - 1 ] ) {
			$keys = array_values( array_unique( array_merge( $keys, self::REVIEWED_META ) ) );
		}
		return $keys;
	}

	/** @return array<string, mixed> 검토 대상 글 필드(문자열 그대로)·검토 대상 메타(정리값, 저장 안 된 키는 등록 기본값). */
	private static function reviewedContent( WP_Post $post ): array {
		$out = array();
		foreach ( self::REVIEWED_FIELDS as $field ) {
			$out[ $field ] = (string) $post->$field;
		}
		foreach ( self::REVIEWED_META as $key ) {
			$out[ $key ] = self::normalizeReviewed( $key, get_post_meta( $post->ID, $key, true ) );
		}
		return $out;
	}

	/** 반영 뒤 게시본의 검토 대상 = 반영 때 잡아 둔 승인 내용인가(잡아 둔 것을 쓰고 지운다). 반영 복사가 없었으면(지난 수정본 적용 등) 참. */
	private static function appliedAsApproved( int $published_id ): bool {
		$approved = self::$approvedContent[ $published_id ] ?? null;
		unset( self::$approvedContent[ $published_id ] );
		if ( null === $approved ) {
			return true;
		}
		clean_post_cache( $published_id );
		$published = get_post( $published_id );
		return $published instanceof WP_Post && $approved === self::reviewedContent( $published );
	}

	/**
	 * revisionary_post_copy_postmeta — 복사 끝. 복사 원본이 지난 수정본(워드프레스 revision)이면 PublishPress 가 그 판을 게시본에 되돌린 것이다
	 * (rvy_revision_restore — revision-action_rvy.php:779-782 코어 되돌림 뒤 메타 복사, 비교 화면 적용 — visual-post-compare 의 rvy_apply_revision):
	 * 메타 복사가 그 판의 옛 검토 기록도 되돌리므로 되돌리기 규칙(recordOnRestore)을 복사 뒤에 다시 적용한다.
	 * 수정안(post_type page) 반영은 승인 경로 규칙(clearOnApply·recordOnApproval)이 정한다.
	 */
	public static function endCopy( $from_post, $to_post_id ): void {
		$id = (int) $to_post_id;
		array_pop( self::$copyIsApply );
		if ( isset( self::$copying[ $id ] ) && --self::$copying[ $id ] <= 0 ) {
			unset( self::$copying[ $id ] );
		}
		self::resealHeld( "copy:$id" );
		if ( ! isset( self::$copying[ $id ] ) && $from_post instanceof WP_Post && 'revision' === $from_post->post_type && (int) $from_post->post_parent === $id ) {
			self::recordOnRestore( $id, $from_post->ID );
		}
	}

	/**
	 * wp_restore_post_revision(우선순위 20): 코어가 수정 이력의 본문·메타(검토 기록 포함 — wp_post_revision_meta_keys)를 되돌린 뒤.
	 * 되돌림도 검토 대상을 바꾸는 저장이다 — 원장이 게시된 페이지를 되돌리면 원장·오늘, 원장 아닌 계정이면 0·''(되돌린 옛 검토 기록을 쓰지 않는다).
	 * 수정 이력 메타를 지웠다 다시 쓰는 순서(검토 기록 뒤에 바뀌는 메타가 있는지)와 상관없이 같은 결과가 되게 마지막에 정한다.
	 */
	public static function recordOnRestore( $post_id, $revision_id = 0 ): void {
		$post = get_post( (int) $post_id );
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || self::isRevisionDraft( $post ) ) {
			return;
		}
		$user = wp_get_current_user();
		if ( self::isReviewer( $user ) ) {
			if ( 'publish' === $post->post_status ) {
				self::record( $post->ID, $user->ID, self::today() );
			}
			return;
		}
		if ( self::hasReview( $post->ID ) ) {
			self::unreview( $post->ID );
		}
	}

	/**
	 * revision_applied(rvy_apply_revision — 게시본 갱신·메타 복사 뒤, revision-action_rvy.php:1331). 원장 아닌 계정이 수정안을 바로 승인·반영하면
	 * 게시본 검토 기록 0·''(수정 4 ①) — 수정안은 만들 때 게시본 메타(이전 원장 검토 값)를 복사해 가지므로 PublishPress 복사가 그 값을 새 내용에 붙인다.
	 * 승인되어 워드프레스 수정본이 된 수정안(PublishPress 수정안이었던 것)도 0·''(원장 승인 때 recordOnApproval 이 그 판에 원장 기록을 넣는 것과 짝).
	 *   - 예약 수정안 반영(로그인 없는 cron·"지금 반영" — 원래 상태 future-revision): 수정안이 가진 승인 기록(원장 예약 승인·승인 뒤 원장 수정 =
	 *     원장·승인일, 원장 아닌 계정의 예약 승인·승인 뒤 변경 = 0·'')을 PublishPress 가 이미 복사했다 → 그대로(수정 1·3 경로).
	 *   - 원장이 바로 승인: 이어지는 revision_approved(recordOnApproval)가 원장·오늘.
	 * 반영 내용 = 승인 내용(수정 5 F1): 반영 뒤 게시본의 검토 대상(제목·본문·발췌·검토 대상 메타)이 반영 때 잡아 둔 승인 내용(beginCopy)과 다르면
	 * — 다른 플러그인이 반영 데이터(revisionary_apply_revision_data)·메타 쓰기를 바꾼 경우, PublishPress 가 일부 항목을 반영하지 않는 설정 등 —
	 * 원장 기록을 붙이지 않는다: 예약 반영은 0·'', 원장 바로 승인도 recordOnApproval 이 기록하지 않고 0·''. 예약 반영은 승인자(수정안이 가진
	 * 검토자)가 지금도 원장일 때만 그 기록을 남긴다(예약 페이지 pendingReview 와 같은 규칙).
	 *
	 * @param int          $published_id
	 * @param WP_Post|null $revision 반영 전 수정안(원래 post_mime_type).
	 */
	public static function clearOnApply( $published_id, $revision = null ): void {
		$mime      = is_object( $revision ) ? (string) ( $revision->post_mime_type ?? '' ) : '';
		$published = get_post( (int) $published_id );
		if ( ! $published instanceof WP_Post || self::POST_TYPE !== $published->post_type ) {
			return;
		}
		$as_approved = self::appliedAsApproved( $published->ID );
		$sealed      = self::$sealedApply[ $published->ID ] ?? true;
		unset( self::$sealedApply[ $published->ID ] );
		if ( self::SCHEDULED_REVISION === $mime ) {
			$approver = get_userdata( absint( get_post_meta( $published->ID, 'iwell_reviewed_by', true ) ) );
			if ( self::hasReview( $published->ID ) ) {
				if ( ! $as_approved || ! $sealed || ! self::isReviewer( $approver ) ) {
					self::unreview( $published->ID );
				} else {
					Seal::stamp( $published->ID ); // 승인 내용 그대로 반영 — 게시본의 승인 지문(수정 7 결정 1).
				}
			}
			return;
		}
		if ( self::isReviewer( wp_get_current_user() ) ) {
			if ( $as_approved ) {
				return;
			}
			self::$applyMismatch[ $published->ID ] = true;
		}
		self::unreview( $published->ID );
		$archived = is_object( $revision ) && in_array( $mime, self::REVISION_MIME_TYPES, true ) ? get_post( (int) $revision->ID ) : null;
		if ( $archived instanceof WP_Post && 'revision' === $archived->post_type && (int) $archived->post_parent === $published->ID ) {
			// update_post_meta 는 수정본 id 를 부모로 바꾸므로 update_metadata 로(recordOnApproval 과 같은 방식).
			update_metadata( 'post', $archived->ID, 'iwell_reviewed_by', 0 );
			update_metadata( 'post', $archived->ID, 'iwell_reviewed_at', '' );
		}
	}

	// ── 승인된 예약 수정안(PublishPress future-revision)을 승인 뒤 고치면 예약 승인 취소(Task 6 수정 3 ②) ──────────────
	// 원장 승인(예약) 뒤 원장 아닌 계정(관리자·편집자·로그인 없는 코드)이 수정안의 검토 대상을 바꾸면, 그 수정안을 제출 상태
	// (pending-revision — 원장 승인 대기열)로 되돌리고 반영 작업(Action Scheduler·wp-cron)·승인자(_rvy_approved_by)·검토 정보를 지운다.
	// 실측(t6-fix3-probe-before.log): 반영은 쿠키 없는 페이지 로드가 띄운 wp-cron(사용자 0) → action_scheduler_run_queue →
	// publish_revision_rvy_action_scheduler → rvy_publish_scheduled_revisions 이고, 그 처리기는 post_mime_type = future-revision 인 행만
	// 반영한다(revision-action_rvy.php:1666·1676) → 제출 상태로 바꾸면 남은 작업이 있어도 반영되지 않는다(작업도 함께 지운다).
	//   - 글 필드·meta_input(REST·편집기·빠른 편집·코드): wp_insert_post_data 1000 에서 저장 직전에 상태를 바꾼다
	//   - REST meta(글 저장 뒤 쓰인다): rest_pre_insert_page 에서 미리 판정 → 같은 요청의 wp_insert_post_data 에서 바꾼다
	//   - 그 밖의 메타 쓰기(Rank Math updateMeta·update_post_meta 직접): 쓰인 직후 onReviewedMetaChange → 바로 바꾼다
	// 원장이 고치면 승인자·승인일 = 그 원장·오늘(③). 날짜만·검토 대상 밖·같은 값 다시 저장은 승인 유지(④). 직원·봇은 아예 못 고친다(Roles).

	/** 저장 직전(PublishPress 상태 정리 뒤): 승인 수정안의 검토 대상이 바뀌면 제출 상태로 저장한다. */
	public static function revokeUnreviewedRevision( $data, $postarr, $unsanitized_postarr = array() ) {
		if ( ! is_array( $data ) || ! is_array( $postarr ) || empty( $postarr['ID'] ) ) {
			return $data;
		}
		$id      = (int) $postarr['ID'];
		$flagged = isset( self::$revokeOnSave[ $id ] );
		unset( self::$revokeOnSave[ $id ] );
		$before = get_post( $id );
		if ( ! $before instanceof WP_Post || ! self::revisionApprovalAtStake( $before ) || self::SCHEDULED_REVISION !== ( $data['post_mime_type'] ?? '' ) ) {
			return $data;
		}
		if ( $flagged || self::reviewedChange( $before, $data, $postarr, $unsanitized_postarr ) ) {
			$data['post_mime_type'] = self::SUBMITTED_REVISION;
			$data['post_status']    = self::submittedStatus();
			self::$revoked[ $id ]   = true;
		}
		return $data;
	}

	/** 승인 수정안 예약 승인 취소(글 저장 밖의 메타 쓰기 뒤) — rvy_revision_submit 과 같은 저장(revision-action_rvy.php:185-189)으로. */
	private static function revokeRevision( WP_Post $revision ): void {
		global $wpdb;
		$wpdb->update(
			$wpdb->posts,
			array(
				'post_mime_type' => self::SUBMITTED_REVISION,
				'post_status'    => self::submittedStatus(),
			),
			array( 'ID' => $revision->ID )
		);
		clean_post_cache( $revision->ID );
		self::clearRevisionApproval( $revision->ID );
	}

	/**
	 * 승인 취소된 수정안의 반영 작업·승인 정보를 지운다.
	 *   - 반영 작업: rvy_clear_revision_publication_events(revision-action_rvy.php:1931-1943)와 같은 4가지 + 다음 예약 시각 옵션 다시 계산.
	 *   - 승인자 _rvy_approved_by(승인 때 PublishPress 가 씀 — :536) 삭제.
	 *   - 검토 정보 iwell_reviewed_by·at(예약 승인 때 recordOnApproval 이 씀)은 지우지 않고 0·'' 으로 덮는다: PublishPress 는 반영할 때
	 *     수정안에 없는 메타를 게시본에서 지우지 않는다(revisionary_copy_postmeta — functions.php:221-229, apply_deletions 기본 false) →
	 *     키를 지우면 관리자가 그대로 승인·게시할 때 게시본의 이전 원장 검토 기록이 이 내용에 붙는다. 빈 값이면 함께 비워진다.
	 */
	private static function clearRevisionApproval( int $revision_id ): void {
		wp_clear_scheduled_hook( self::RVY_CRON_HOOK, array( $revision_id ) );
		wp_clear_scheduled_hook( self::RVY_CRON_HOOK, array( 'revision_id' => $revision_id ) );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( self::RVY_AS_HOOK, array( $revision_id ), 'revisionary' );
			as_unschedule_all_actions( self::RVY_AS_HOOK, array( 'revision_id' => $revision_id ), 'revisionary' );
		}
		if ( function_exists( 'rvy_update_next_publish_date' ) ) {
			rvy_update_next_publish_date();
		}
		delete_post_meta( $revision_id, '_rvy_approved_by' );
		update_post_meta( $revision_id, 'iwell_reviewed_by', 0 );
		update_post_meta( $revision_id, 'iwell_reviewed_at', '' );
	}

	/** 원장이 승인 수정안을 고침 = 다시 승인(수정 3 ③): 승인자·승인일 = 그 원장·오늘(반영 때 PublishPress 가 게시본으로 복사). */
	private static function approveRevision( int $revision_id, int $user_id ): void {
		self::record( $revision_id, $user_id, self::today() );
		update_post_meta( $revision_id, '_rvy_approved_by', $user_id );
	}

	/** 제출 상태의 post_status — PublishPress 권한 호환 모드면 'pending-revision', 기본 'pending'(revision-action_rvy.php:186). */
	private static function submittedStatus(): string {
		return function_exists( 'rvy_get_option' ) && rvy_get_option( 'permissions_compat_mode' ) ? self::SUBMITTED_REVISION : 'pending';
	}

	/** PublishPress 가 예약 승인한 수정안(아직 반영 전)인가. */
	private static function isScheduledRevision( WP_Post $post ): bool {
		return self::POST_TYPE === $post->post_type && self::SCHEDULED_REVISION === $post->post_mime_type && ! in_array( $post->post_status, array( 'inherit', 'trash' ), true );
	}

	/** 승인 수정안을 원장 아닌 계정이 저장하는가. */
	private static function revisionApprovalAtStake( WP_Post $before ): bool {
		return self::isScheduledRevision( $before ) && ! self::isReviewer( wp_get_current_user() );
	}

	/**
	 * REST 저장 전 meta 비교(워드프레스는 글을 저장한 뒤 메타를 쓴다 — 미리 상태를 정해 공개·예약으로 한 번도 저장되지 않게).
	 *
	 * @param \stdClass|WP_Error $prepared
	 * @return \stdClass|WP_Error
	 */
	public static function holdUnreviewedRestMeta( $prepared, WP_REST_Request $request ) {
		if ( is_wp_error( $prepared ) || empty( $prepared->ID ) ) {
			return $prepared;
		}
		$before = get_post( (int) $prepared->ID );
		if ( ! $before instanceof WP_Post || self::POST_TYPE !== $before->post_type ) {
			return $prepared;
		}
		$meta = $request->get_param( 'meta' );
		if ( self::revisionApprovalAtStake( $before ) ) {
			// 승인 수정안(수정 3): 상태는 PublishPress 정리(우선순위 100) 뒤 revokeUnreviewedRevision 이 바꾼다 — 여기서는 표시만.
			if ( is_array( $meta ) && self::metaChanges( $before->ID, $meta ) ) {
				self::$revokeOnSave[ $before->ID ] = true;
			}
			return $prepared;
		}
		if ( ! self::approvalAtStake( $before ) ) {
			return $prepared;
		}
		$target = $prepared->post_status ?? $before->post_status;
		if ( in_array( $target, array( 'future', 'publish' ), true ) && is_array( $meta ) && self::metaChanges( $before->ID, $meta ) ) {
			$prepared->post_status = 'pending';
		}
		return $prepared;
	}

	/**
	 * 글 저장 밖의 메타 쓰기(added/updated/deleted_post_meta): 승인이 걸린 예약 페이지면 원장 아닌 계정 → 승인 삭제·검토 대기,
	 * 원장 → 승인일 갱신(수정 2 ③). 승인 수정안(future-revision)이면 원장 아닌 계정 → 예약 승인 취소, 원장 → 다시 승인(수정 3).
	 * 검토 기록이 있는 페이지(수정안 제외)면 원장 아닌 계정 → 검토 기록 0·''(수정 4 ②, 상태 그대로).
	 * 쓰기 직전 값(rememberMeta*)과 정리값이 같으면 변경이 아니다(수정 3 M2): 저장 안 된 메타는 등록 기본값(빈 문자열·빈 배열)과 같게
	 * 본다 — 편집기·봇이 GET 으로 받은 미저장 기본값을 그대로 다시 보내면 워드프레스는 새로 추가(added_post_meta)하지만 실질 같은 값이다.
	 * PublishPress 메타 복사 중(beginCopy~endCopy — 수정안 만들기·미리보기 미러·반영)은 사람의 변경이 아니므로 보지 않는다: 반영은 승인 경로
	 * 규칙(clearOnApply·recordOnApproval)이 정하고, 미리보기 미러는 수정안에 없던 키를 게시본 값으로 채울 뿐이다(반영 결과가 같다).
	 *
	 * @param int|int[] $meta_id
	 */
	public static function onReviewedMetaChange( $meta_id, $object_id, $meta_key ): void {
		if ( ! in_array( $meta_key, self::REVIEWED_META, true ) ) {
			return;
		}
		$slot = (int) $object_id . ':' . $meta_key;
		$was  = array_key_exists( $slot, self::$metaBefore ) ? self::$metaBefore[ $slot ] : self::normalizeReviewed( $meta_key, null );
		unset( self::$metaBefore[ $slot ] );
		// 글 0 = 값으로 여러 글의 메타를 지움(delete_metadata delete_all — 첨부 삭제 때 _thumbnail_id 정리, 첨부 삭제 규칙이 정한다): get_post(0) 은 전역 글이다.
		if ( (int) $object_id <= 0 || isset( self::$deleting[ (int) $object_id ] ) || isset( self::$copying[ (int) $object_id ] ) ) {
			return;
		}
		$post = get_post( (int) $object_id );
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type ) {
			return;
		}
		$revision = self::isScheduledRevision( $post );
		$held     = ! $revision && 'future' === $post->post_status && ! self::isRevisionDraft( $post ) && metadata_exists( 'post', $post->ID, self::PENDING_KEY );
		$live     = ! $revision && ! self::isRevisionDraft( $post ) && self::hasReview( $post->ID );
		if ( ! $revision && ! $held && ! $live ) {
			return;
		}
		if ( $was === self::normalizeReviewed( $meta_key, get_post_meta( $post->ID, $meta_key, true ) ) ) {
			return;
		}
		$user = wp_get_current_user();
		if ( self::isReviewer( $user ) ) {
			if ( $revision ) {
				self::approveRevision( $post->ID, $user->ID );
			} elseif ( $held ) {
				self::approve( $post->ID, $user->ID );
			}
			return;
		}
		self::lapse( $post );
	}

	/**
	 * 원장 아닌 계정이 이 고정 페이지(또는 수정안)에 보이는 검토 대상을 바꿨다 — 수정 2·3·4 규칙:
	 * 원장이 예약 승인한 수정안 → 예약 승인 취소(수정 3), 검토 기록 있는 페이지(수정안 제외) → 0·''(수정 4 ②),
	 * 원장이 예약(승인)한 페이지 → 승인 삭제·검토 대기(수정 2). 제출 전 수정안은 그대로(원장이 승인할 때의 내용이 기준).
	 */
	private static function lapse( WP_Post $post ): void {
		if ( self::isScheduledRevision( $post ) ) {
			self::revokeRevision( $post );
			return;
		}
		if ( self::isRevisionDraft( $post ) ) {
			return;
		}
		if ( self::hasReview( $post->ID ) ) {
			self::unreview( $post->ID );
		}
		if ( 'future' === $post->post_status && metadata_exists( 'post', $post->ID, self::PENDING_KEY ) ) {
			self::hold( $post );
		}
	}

	// ── 동기화 패턴(wp_block)을 원장 아닌 계정이 바꿈 → 그 패턴을 쓰는 페이지(Task 6 수정 5 F2 ②) ─────────────────────
	// 페이지 본문의 <!-- wp:block {"ref":ID} /--> 는 공개 화면에서 그 패턴의 지금 본문을 그린다(render_block_core_block — 공개 상태·비밀번호가
	// 맞을 때만). 패턴이 바뀌면 그 페이지의 공개 HTML 이 원장 승인 없이 바뀐다 → 원장 아닌 계정(관리자·편집자·로그인 없는 코드)의 변경이면
	// 그 패턴을 쓰는 고정 페이지(다른 패턴 안에 넣어 쓰는 것 포함)에 lapse(). 원장 변경은 그대로(원장 검토 범위). 직원·봇은 패턴을 못 고친다(Roles).
	// 화면에 안 나오는 제목·같은 값 재저장은 변경이 아니다. 새로 만든 패턴도 본다(그 ID 를 이미 가리키던 페이지).

	/** wp_after_insert_post — 패턴 저장(만들기·고치기·휴지통·되살리기 — wp_trash_post 도 wp_update_post). 원장 변경은 지문만 다시(afterPostSaved). */
	public static function onPatternSaved( $post_id, $post, $update = false, $post_before = null ): void {
		if ( ! $post instanceof WP_Post || self::PATTERN_TYPE !== $post->post_type || self::isReviewer( wp_get_current_user() ) ) {
			return;
		}
		if ( $update && $post_before instanceof WP_Post ) {
			$changed = false;
			foreach ( self::PATTERN_FIELDS as $field ) {
				if ( (string) $post_before->$field !== (string) $post->$field ) {
					$changed = true;
					break;
				}
			}
			if ( ! $changed ) {
				return;
			}
		}
		self::lapsePagesUsingPattern( $post->ID );
	}

	/** before_delete_post — 패턴 영구 삭제(공개 화면에서 그 자리가 빈다). 원장이 지우면 지금 지문이 맞는 페이지를 잡아 두고 지운 뒤 지문만 다시(afterDelete). */
	public static function onPatternDeleted( $post_id, $post = null ): void {
		$post = $post instanceof WP_Post ? $post : get_post( (int) $post_id );
		if ( ! $post instanceof WP_Post || self::PATTERN_TYPE !== $post->post_type ) {
			return;
		}
		if ( self::isReviewer( wp_get_current_user() ) ) {
			self::holdSealed( 'delete:' . $post->ID, self::dependents( 'block', $post->ID ) );
			return;
		}
		self::lapsePagesUsingPattern( $post->ID );
	}

	private static function lapsePagesUsingPattern( int $pattern_id ): void {
		self::lapsePages( self::pagesUsingPattern( $pattern_id ) );
	}

	/** @return int[] 패턴 $pattern_id 를 쓰는 고정 페이지(수정안 포함) — 중첩·JSON 공백·순환 포함(Sources — 수정 7 결정 2). */
	public static function pagesUsingPattern( int $pattern_id ): array {
		return Sources::pagesUsing( 'block', $pattern_id );
	}

	/** $page_ids 에 lapse()(지금 상태로 다시 읽는다). */
	private static function lapsePages( array $page_ids ): void {
		foreach ( array_unique( array_map( 'intval', $page_ids ) ) as $page_id ) {
			clean_post_cache( $page_id );
			$page = get_post( $page_id );
			if ( $page instanceof WP_Post && self::POST_TYPE === $page->post_type ) {
				self::lapse( $page );
			}
		}
	}

	// ── 승인된 페이지가 쓰는 첨부(Task 6 수정 5 F2 ③ — 같은 종류, 수정 7 결정 2 의존성 해석기 하나) ─────────────────────────
	// 공개 화면이 첨부를 그때그때 읽는 자리: 대표 이미지(대체 글 — 테마 post-featured-image, Rank Math JSON-LD ImageObject caption),
	// [gallery]·[playlist](캡션·대체 글·제목·설명), 파일 자체(지우면 본문 이미지가 깨진다). 직원·봇이 이 첨부를 고치거나 지우면 원장 승인 없이
	// 의학 페이지 공개 HTML 이 바뀐다(실측 t6-fix5-probe-before*.log) → 게시·예약·비공개 고정 페이지(수정안 제외)와 원장이 예약 승인한
	// 수정안이 쓰는 첨부는 직원·봇의 edit_post·delete_post 를 거부한다(Roles::map_meta_cap — 이미지 편집기도 edit_post).
	// "쓰는지"는 Sources::of 하나가 정한다(동기화 패턴 안·중첩 포함 — C1, 평문 ids= 는 아님 — C4).

	/** 게시·예약·비공개 고정 페이지(수정안 제외)나 원장이 예약 승인한 수정안이 이 첨부를 쓰는가. */
	public static function attachmentInApprovedUse( int $attachment_id ): bool {
		return array() !== self::pagesUsingAttachment( $attachment_id, true );
	}

	/**
	 * @return int[] 이 첨부를 쓰는 게시·예약·비공개 고정 페이지(수정안 제외)와 원장이 예약 승인한 수정안. $first_only 면 하나 찾으면 멈춘다.
	 */
	public static function pagesUsingAttachment( int $attachment_id, bool $first_only = false ): array {
		return 'attachment' === get_post_type( $attachment_id ) ? Sources::pagesUsing( 'attachment', $attachment_id, true, $first_only ) : array();
	}

	/**
	 * attachment_updated(wp-includes/post.php:5199) — 원장 아닌 계정이 첨부의 제목·캡션(발췌)·설명(본문)을 바꾸면 그 첨부를 쓰는 고정 페이지에
	 * lapse()(수정 6 ② — F2 ② 와 같은 방식). 같은 값 재저장은 그대로. 원장 변경은 지문만 다시(afterPostSaved 는 첨부에 오지 않으므로 여기서).
	 * 직원·봇은 쓰이는 첨부를 아예 못 고친다(Roles).
	 */
	public static function onAttachmentUpdated( $post_id, $post_after = null, $post_before = null ): void {
		if ( ! $post_after instanceof WP_Post || ! $post_before instanceof WP_Post || 'attachment' !== $post_after->post_type ) {
			return;
		}
		if ( self::isReviewer( wp_get_current_user() ) ) {
			self::resealHeld( 'post:' . $post_after->ID );
			return;
		}
		foreach ( self::ATTACHMENT_FIELDS as $field ) {
			if ( (string) $post_before->$field !== (string) $post_after->$field ) {
				self::lapsePages( Sources::pagesUsing( 'attachment', $post_after->ID ) );
				return;
			}
		}
	}

	/**
	 * added/updated/deleted_post_meta — 원장 아닌 계정이 첨부의 대체 글(수정 6 ②)·파일(_wp_attached_file)·크기 메타의 폭·높이·파일 이름
	 * (_wp_attachment_metadata — 수정 7 B: 이미지 편집기 회전·자르기·크기 변경·원본 복원)을 바꾸면(지움 포함) 바뀌기 전·뒤에 그 첨부를 쓰는
	 * 페이지(바뀌기 전 파일 주소만 쓰는 페이지 포함)에 lapse(). 같은 값·의미 없는 메타(파일 크기·변형 목록)만 다르면 그대로. 첨부 삭제 중의 메타 정리는
	 * 삭제 규칙(afterDelete)이 정한다.
	 */
	public static function onAttachmentMetaChange( $meta_id, $object_id, $meta_key ): void {
		if ( ! in_array( $meta_key, self::ATTACHMENT_META, true ) ) {
			return;
		}
		$slot   = (int) $object_id . ':' . $meta_key;
		$was    = array_key_exists( $slot, self::$metaBefore ) ? self::$metaBefore[ $slot ] : self::normalizeAttachmentMeta( $meta_key, null );
		$before = self::$usersBefore[ $slot ] ?? array();
		unset( self::$metaBefore[ $slot ], self::$usersBefore[ $slot ] );
		if ( (int) $object_id <= 0 || isset( self::$deleting[ (int) $object_id ] ) || 'attachment' !== get_post_type( (int) $object_id ) || self::isReviewer( wp_get_current_user() ) ) {
			return;
		}
		if ( $was === self::normalizeAttachmentMeta( $meta_key, get_post_meta( (int) $object_id, $meta_key, true ) ) ) {
			return;
		}
		self::lapsePages( array_merge( $before, Sources::pagesUsing( 'attachment', (int) $object_id ) ) );
	}

	/** 첨부 공개 값 메타 → 비교값(대체 글 문자열, 파일 경로, 크기 메타는 폭·높이·파일 이름만 — Seal 과 같은 값). */
	private static function normalizeAttachmentMeta( string $key, $value ) {
		return '_wp_attachment_metadata' === $key ? Seal::imageMeta( $value ) : ( is_scalar( $value ) ? (string) $value : '' );
	}

	/** delete_attachment(지우기 전 — 행·메타·파일이 아직 있다): 원장 아닌 계정이면 그 첨부를 쓰는 페이지를, 원장이면 지금 지문이 맞는 그 페이지를 잡아 둔다(수정 7 A). */
	public static function beforeAttachmentDelete( $post_id ): void {
		$id = (int) $post_id;
		if ( 'attachment' !== get_post_type( $id ) ) {
			return;
		}
		if ( self::isReviewer( wp_get_current_user() ) ) {
			self::holdSealed( "delete:$id", self::dependents( 'attachment', $id ) );
			return;
		}
		self::$usersBefore[ "delete:$id" ] = Sources::pagesUsing( 'attachment', $id );
	}

	/** deleted_post — 지운 첨부를 쓰던 페이지에 lapse()(원장 아닌 계정), 원장이 지운 패턴·첨부면 그 전에 지문이 맞던 페이지에 지문만 다시. */
	public static function afterDelete( $post_id ): void {
		$slot = 'delete:' . (int) $post_id;
		if ( ! isset( self::$usersBefore[ $slot ] ) && ! isset( self::$sealedBefore[ $slot ] ) ) {
			return;
		}
		// 워드프레스는 deleted_post 뒤에야 지운 글의 캐시를 비운다(wp_delete_post·wp_delete_attachment) — 지문이 그 글을 '없음'으로 보게 먼저 비운다.
		clean_post_cache( (int) $post_id );
		if ( isset( self::$usersBefore[ $slot ] ) ) {
			$pages = self::$usersBefore[ $slot ];
			unset( self::$usersBefore[ $slot ] );
			self::lapsePages( $pages );
		}
		self::resealHeld( $slot );
	}

	/** add_post_meta(쓰기 직전) — 저장 안 된 키의 지금 값(등록 기본값)을 정리값으로 기억한다. */
	public static function rememberMetaBeforeAdd( $object_id, $meta_key ): void {
		self::rememberMeta( (int) $object_id, (string) $meta_key );
	}

	/** update_post_meta·delete_post_meta(쓰기 직전) — 지금 저장된 값을 정리값으로 기억한다. */
	public static function rememberMetaBeforeChange( $meta_id, $object_id, $meta_key ): void {
		self::rememberMeta( (int) $object_id, (string) $meta_key );
	}

	/**
	 * 메타 쓰기 직전: 검토 대상 메타·첨부 공개 값 메타의 지금 정리값. 첨부 공개 값 메타는 지금 그 첨부를 쓰는 페이지도(원장 아닌 계정 — 바뀌기 전 파일
	 * 주소로 쓰는 페이지 포함, 수정 7 B), 원장이면 지금 지문이 맞는 그 페이지를(수정 7 결정 1). 원장이 고정 페이지의 지문 원천 메타를 바꾸면 그 페이지.
	 */
	private static function rememberMeta( int $object_id, string $meta_key ): void {
		if ( $object_id <= 0 ) {
			return;
		}
		$slot = $object_id . ':' . $meta_key;
		if ( in_array( $meta_key, self::REVIEWED_META, true ) ) {
			self::$metaBefore[ $slot ] = self::normalizeReviewed( $meta_key, get_post_meta( $object_id, $meta_key, true ) );
		}
		$type = get_post_type( $object_id );
		if ( 'attachment' === $type && in_array( $meta_key, self::ATTACHMENT_META, true ) ) {
			self::$metaBefore[ $slot ] = self::normalizeAttachmentMeta( $meta_key, get_post_meta( $object_id, $meta_key, true ) );
			if ( self::isReviewer( wp_get_current_user() ) ) {
				self::holdSealed( "meta:$slot", self::dependents( 'attachment', $object_id ) );
			} elseif ( ! isset( self::$deleting[ $object_id ] ) ) {
				self::$usersBefore[ $slot ] = Sources::pagesUsing( 'attachment', $object_id );
			}
		} elseif ( self::POST_TYPE === $type && self::isReviewer( wp_get_current_user() ) && in_array( $meta_key, self::sealInputKeys( $object_id ), true ) ) {
			self::holdSealed( "meta:$slot", array( $object_id ) );
		}
	}

	/** 고정 페이지 지문이 읽는 그 페이지 메타 키: 검토 대상 메타·Rank Math 초점 키워드·Rank Math 템플릿의 %customfield(키)%. */
	private static function sealInputKeys( int $post_id ): array {
		$keys = array_merge( self::REVIEWED_META, array( 'rank_math_focus_keyword' ) );
		foreach ( self::RANK_MATH_KEYS as $key ) {
			if ( preg_match_all( '/%customfield\(([^)]*)\)%/', (string) get_post_meta( $post_id, $key, true ), $m ) ) {
				$keys = array_merge( $keys, array_map( static fn( string $k ): string => trim( wp_specialchars_decode( $k ) ), $m[1] ) );
			}
		}
		return $keys;
	}

	// ── 원장 변경은 원장 검토 범위 — 변경 직전에 승인 지문이 맞던 글은 변경 뒤 지문을 다시 남긴다(Task 6 수정 7 결정 1) ─────────────────
	// 원장이 패턴·첨부(대체 글·캡션·파일·삭제)·고정 페이지(지문 원천 메타·글 필드 — 자식 페이지의 %parent_title%)를 바꾸면, 그것을 쓰는 글 가운데 바로
	// 전에 지문이 맞던 것(원장 승인 기록이 있고 그 뒤 미승인 변경이 없던 것)만 다시 남긴다 — 그 전에 이미 어긋난 글(관리자의 미검토 변경)은 그대로
	// 어긋나 출력 때 lapse 된다(원장 변경이 다른 미검토 변경을 덮어 승인하지 않게).

	/** pre_post_update(wp_insert_post 의 갱신 직전): 원장이 패턴·첨부·고정 페이지를 저장하면 그것을 쓰는(또는 그 자체·자식 페이지) 지문 맞는 글을 잡아 둔다. */
	public static function beforePostUpdate( $post_id ): void {
		$post = get_post( (int) $post_id );
		if ( ! $post instanceof WP_Post || ! self::isReviewer( wp_get_current_user() ) ) {
			return;
		}
		$kind = array(
			self::PATTERN_TYPE => 'block',
			'attachment'       => 'attachment',
			self::POST_TYPE    => 'page',
		)[ $post->post_type ] ?? null;
		if ( null !== $kind ) {
			self::holdSealed( 'post:' . $post->ID, self::dependents( $kind, $post->ID ) );
		}
	}

	/** wp_after_insert_post(20 — recordOnSave 5·onPatternSaved 10 뒤): 원장이 저장한 패턴·고정 페이지 — 잡아 둔 글에 지문만 다시. */
	public static function afterPostSaved( $post_id ): void {
		if ( self::isReviewer( wp_get_current_user() ) ) {
			self::resealHeld( 'post:' . (int) $post_id );
		}
	}

	/** added/updated/deleted_post_meta(20): 원장의 메타 쓰기 직전에 잡아 둔 글에 지문만 다시. */
	public static function resealAfterMeta( $meta_id, $object_id, $meta_key ): void {
		self::resealHeld( 'meta:' . (int) $object_id . ':' . $meta_key );
	}

	/**
	 * 원장이 바꾸는 대상에 기대는 글.
	 *
	 * @return int[]
	 */
	private static function dependents( string $kind, int $id ): array {
		if ( 'page' !== $kind ) {
			return Sources::pagesUsing( $kind, $id );
		}
		$children = get_posts(
			array(
				'post_type'        => self::POST_TYPE,
				'post_parent'      => $id,
				'post_status'      => 'any',
				'fields'           => 'ids',
				'posts_per_page'   => -1,
				'suppress_filters' => true,
			)
		);
		return array_merge( array( $id ), array_map( 'intval', $children ) );
	}

	/** 변경 직전: $post_ids 가운데 원장 승인 기록이 걸려 있고 지금 승인 지문이 맞는 글을 기억한다(같은 칸은 새로 덮는다 — 남은 옛 칸이 나중 변경을 승인하지 않게). */
	private static function holdSealed( string $slot, array $post_ids ): void {
		$ok = array();
		foreach ( array_unique( array_map( 'intval', $post_ids ) ) as $id ) {
			$post = get_post( $id );
			if ( $post instanceof WP_Post && self::POST_TYPE === $post->post_type && self::sealedApproval( $post ) && Seal::valid( $post ) ) {
				$ok[] = $id;
			}
		}
		self::$sealedBefore[ $slot ] = array_values( array_unique( $ok ) );
	}

	/** 변경 뒤: 잡아 둔 글에 지금 공개 원천의 지문을 다시 남긴다. */
	private static function resealHeld( string $slot ): void {
		$ids = self::$sealedBefore[ $slot ] ?? array();
		unset( self::$sealedBefore[ $slot ] );
		foreach ( $ids as $id ) {
			clean_post_cache( $id );
			Seal::stamp( $id );
		}
	}

	/** 원장 승인 기록이 걸린 글: 검토 기록 있는 고정 페이지(수정안 제외)·원장 예약 페이지(내부 승인 메타)·검토 기록 있는 예약 승인 수정안. */
	private static function sealedApproval( WP_Post $post ): bool {
		if ( self::isScheduledRevision( $post ) ) {
			return self::hasReview( $post->ID );
		}
		if ( self::isRevisionDraft( $post ) ) {
			return false;
		}
		return self::hasReview( $post->ID ) || ( 'future' === $post->post_status && metadata_exists( 'post', $post->ID, self::PENDING_KEY ) );
	}

	// ── 출력 때 승인 지문 확인(Task 6 수정 7 결정 1) ─────────────────────────────────────────────────────────

	/**
	 * 출력할 검토 기록 [검토자 ID, 검토일]: 원장 승인 기록이 걸린 글이면 승인 지문을 다시 계산해 대조하고, 다르면 그 자리에서 lapse()(검토 기록
	 * 0·'', 원장 예약 페이지 검토 대기, 예약 승인 수정안 승인 취소) 뒤 [0, '']. 제출 전 수정안·기록 없는 글은 저장된 값 그대로.
	 * 수정 14(C10-2): 그 자리 해제는 권한 있는 요청(trusted — edit_post·cron·WP-CLI)만. 그 밖은 그 응답만 [0, ''](저장 기록 그대로 + 공개 차이 알림 한 줄).
	 *
	 * @return array{0: int, 1: string}
	 */
	public static function verifiedReview( int $post_id ): array {
		$by   = absint( get_post_meta( $post_id, 'iwell_reviewed_by', true ) );
		$at   = self::sanitizeDate( get_post_meta( $post_id, 'iwell_reviewed_at', true ) );
		if ( Fingerprint::busy() ) {
			return array( $by, $at ); // 지문 렌더 중(출처 템플릿 블록 등) — 검토 기록은 지문 밖(배지는 가림), 확인·lapse 하지 않는다(순환 방지, 수정 10).
		}
		if ( LiveSeal::front() ) {
			// 공개 화면 요청(수정 12): 보이는 검토 표시(배지·JSON-LD 검토 필드)는 실제로 보낸 응답의 판정(LiveSeal)만 정한다 — 여기서 따로 렌더한 지문으로
			// 정하지 않는다(Ruling 1·4). 판정을 거치지 않는 출력에는 배지 블록·JSON-LD 가 검토 표시를 내지 않는다(Ruling 2).
			return array( $by, $at );
		}
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || ! self::sealedApproval( $post ) || Seal::valid( $post ) ) {
			return array( $by, $at );
		}
		if ( self::trusted( $post_id ) ) {
			self::lapseUnsealed( $post );
		} else {
			// 수정 14 C10-2(Ruling 2): 권한 없는 요청(익명·편집 권한 없는 로그인)의 승인 계산이 다르면 그 응답만 닫는다(검토 값 0·'' — REST 메타·iwell_review·
			// JSON-LD 검토 필드·getHead) — 저장 기록은 그대로. 방문자가 고른 요청 환경(고정 문맥이 못 되돌리는 플러그인 정적 상태 등)이 원장 승인을 지우지 못하게.
			// 점검 화면에는 수정 13 알림 규칙으로 한 줄(페이지당 10분에 한 번·빈 자리 행 비교-교체만).
			Fingerprint::noteLive( $post_id, Seal::diff( $post ), LiveSeal::requestUrl() );
		}
		return array( 0, '' );
	}

	/**
	 * 승인 계산 결과로 저장 기록을 바꾸고 지문 캐시를 쓸 수 있는 요청인가(수정 14 C10-2 — Ruling 2): 그 글의 편집 권한(edit_post)·cron·WP-CLI.
	 * 그 밖(익명·편집 권한 없는 로그인)은 계산이 같으면 저장값, 다르면 그 응답만 닫는다(verifiedReview) — 캐시도 쓰지 않는다(Fingerprint::of: 권한 없는 요청의
	 * 결과가 캐시를 거쳐 원장·직원 편집 패널의 해제로 이어지지 않게). 예약 공개 관문(holdUnsealedFuture·revokeUnsealedRevision)은 응답이 아니라 공개 여부를
	 * 정하므로 이 조건 밖이다(해제를 막으면 승인과 다른 내용이 공개된다 — 닫힌 쪽 그대로, 코디네이터 판단 Q2). 점검 화면은 관리자·WP-CLI 만 연다.
	 */
	public static function trusted( int $post_id ): bool {
		return wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || current_user_can( 'edit_post', $post_id );
	}

	/** 승인 지문이 지금 결과와 다르다 → 어떤 조각이 바뀌었는지 남기고(운영 — 재승인 필요 목록, 수정 10 결정 5) lapse(). */
	private static function lapseUnsealed( WP_Post $post ): void {
		self::lapseFound( $post, Seal::diff( $post ) );
	}

	/**
	 * 승인 계산(고정 문맥)이 다른 조각 $parts 를 찾았다 → 해제 기록을 남기고 lapse()(수정 2·3·4 규칙). 편집 패널 REST·배지·cron·수정안 반영(verifiedReview)과
	 * 점검 화면(ReviewAudit — 수정 13 Ruling 2 ②: 다름을 찾으면 그 자리에서)이 쓴다. 공개 응답(LiveSeal)은 쓰지 않는다(수정 13 Ruling 1).
	 *
	 * @param string[] $parts
	 */
	public static function lapseFound( WP_Post $post, array $parts ): void {
		Fingerprint::noteLapse( $post->ID, $parts );
		self::lapse( $post );
	}

	/** 원장 승인 기록이 걸린 글인가(ReviewAudit — 재승인 필요 목록, LiveSeal — 공개 판정 대상). */
	public static function hasSealedApproval( WP_Post $post ): bool {
		return self::sealedApproval( $post );
	}

	/**
	 * rest_prepare_page — 편집 패널·REST 응답의 검토 값(meta.iwell_reviewed_by·at, iwell_review)을 지문 확인 뒤 값으로. 워드프레스는 meta 를
	 * 덧붙인 필드(iwell_review)보다 먼저 읽으므로 응답을 고친다.
	 *
	 * @param mixed $response
	 * @param mixed $post
	 * @return mixed
	 */
	public static function restReview( $response, $post ) {
		if ( ! $response instanceof WP_REST_Response || ! $post instanceof WP_Post ) {
			return $response;
		}
		$data = $response->get_data();
		if ( ! is_array( $data ) ) {
			return $response;
		}
		$in_meta   = isset( $data['meta'] ) && is_array( $data['meta'] ) && array_key_exists( 'iwell_reviewed_by', $data['meta'] );
		$in_review = isset( $data['iwell_review'] ) && is_array( $data['iwell_review'] );
		if ( ! $in_meta && ! $in_review ) {
			return $response; // 검토 값을 싣지 않는 응답(_fields 로 고른 목록 등) — 지문을 계산하지 않는다.
		}
		list( $by, $at ) = self::verifiedReview( $post->ID );
		if ( $in_meta ) {
			$data['meta']['iwell_reviewed_by'] = $by;
			$data['meta']['iwell_reviewed_at'] = $at;
		}
		if ( $in_review ) {
			$data['iwell_review'] = array(
				'by'   => $by,
				'name' => self::reviewerName( $by ),
				'at'   => $at,
			);
		}
		$response->set_data( $data );
		return $response;
	}

	/** publish_future_post(5 — check_and_publish_future_post 10 보다 먼저): 원장 예약 페이지의 승인 지문이 다르면 검토 대기로(cron 이 공개하지 않는다). */
	public static function holdUnsealedFuture( $post_id ): void {
		$post = get_post( (int) $post_id );
		if ( $post instanceof WP_Post && self::POST_TYPE === $post->post_type && 'future' === $post->post_status && self::sealedApproval( $post ) && ! Seal::valid( $post ) ) {
			self::lapseUnsealed( $post );
		}
	}

	/** PublishPress 반영 작업(5 — 처리기 10 보다 먼저): 원장 예약 승인 수정안의 승인 지문이 다르면 예약 승인 취소(처리기는 future-revision 만 반영한다). */
	public static function revokeUnsealedRevision( $revision_id = 0 ): void {
		$id   = is_array( $revision_id ) ? absint( $revision_id['revision_id'] ?? reset( $revision_id ) ) : absint( $revision_id );
		$post = $id > 0 ? get_post( $id ) : null;
		if ( $post instanceof WP_Post && self::isScheduledRevision( $post ) && self::sealedApproval( $post ) && ! Seal::valid( $post ) ) {
			self::lapseUnsealed( $post );
		}
	}

	/**
	 * 승인 삭제 + 상태만 pending 으로(wp_publish_post 와 같은 방식 — wp_update_post 는 본문을 다시 정리(kses)하고 저장 훅을 모두 다시 돌린다).
	 * wp_transition_post_status → _transition_post_status 가 cron 예약 publish_future_post 를 지운다.
	 */
	private static function hold( WP_Post $post ): void {
		global $wpdb;
		delete_post_meta( $post->ID, self::PENDING_KEY );
		$wpdb->update( $wpdb->posts, array( 'post_status' => 'pending' ), array( 'ID' => $post->ID ) );
		clean_post_cache( $post->ID );
		$held = get_post( $post->ID );
		if ( $held instanceof WP_Post ) {
			wp_transition_post_status( 'pending', $post->post_status, $held );
		}
	}

	/** 승인이 걸린 예약 페이지를 원장 아닌 계정이 저장하는가(수정안·다른 글 종류 제외). */
	private static function approvalAtStake( WP_Post $before ): bool {
		return self::POST_TYPE === $before->post_type
			&& 'future' === $before->post_status
			&& ! self::isRevisionDraft( $before )
			&& metadata_exists( 'post', $before->ID, self::PENDING_KEY )
			&& ! self::isReviewer( wp_get_current_user() );
	}

	/** $meta(키 → 새 값, null = 삭제) 가운데 검토 대상 메타가 지금 저장된 값과 다른가(값 정리 뒤 비교 — 같은 값 다시 저장은 변경 아님). */
	private static function metaChanges( int $post_id, array $meta ): bool {
		foreach ( self::REVIEWED_META as $key ) {
			if ( array_key_exists( $key, $meta ) && self::normalizeReviewed( $key, $meta[ $key ] ) !== self::normalizeReviewed( $key, get_post_meta( $post_id, $key, true ) ) ) {
				return true;
			}
		}
		return false;
	}

	/** 검토 대상 메타 값 → 비교용 정리값(등록한 sanitize_callback 과 같은 함수; Rank Math·각주(JSON 문자열)는 문자열 그대로, 대표 이미지는 양의 ID 문자열·없으면 ''). */
	public static function normalizeReviewed( string $key, $value ) {
		switch ( $key ) {
			case '_thumbnail_id':
				return is_scalar( $value ) && absint( $value ) > 0 ? (string) absint( $value ) : '';
			case 'iwell_data_asof':
				return self::sanitizeDate( $value );
			case 'iwell_sources':
				return self::sanitizeSources( $value );
			case 'iwell_physician':
				return self::sanitizePhysician( $value );
			case 'iwell_terms':
				return self::sanitizeTerms( $value );
			default:
				return is_scalar( $value ) ? (string) $value : '';
		}
	}

	/** before_delete_post — 지우는 글의 메타 삭제는 "검토 대상 변경"이 아니다. */
	public static function markDeleting( $post_id ): void {
		self::$deleting[ (int) $post_id ] = true;
	}

	public static function unmarkDeleting( $post_id ): void {
		unset( self::$deleting[ (int) $post_id ] );
	}

	/** 예약 승인(내부 메타) — 승인자가 지금도 원장이고 승인일이 날짜일 때만 {by, at}, 아니면 null(심어진 값·역할이 빠진 계정). */
	private static function pendingReview( int $post_id ): ?array {
		$pending = self::sanitizePending( get_post_meta( $post_id, self::PENDING_KEY, true ) );
		if ( array() === $pending || ! self::isReviewer( get_userdata( $pending['by'] ) ) ) {
			return null;
		}
		return $pending;
	}

	/** 내부 승인 메타 값 정리 — {by: 양의 정수, at: 'Y-m-d'} 둘 다 맞으면 그 값, 아니면 빈 배열. */
	public static function sanitizePending( $value ): array {
		$by = is_array( $value ) ? absint( $value['by'] ?? 0 ) : 0;
		$at = is_array( $value ) ? self::sanitizeDate( $value['at'] ?? '' ) : '';
		if ( $by <= 0 || '' === $at ) {
			return array();
		}
		return array(
			'by' => $by,
			'at' => $at,
		);
	}

	/**
	 * PublishPress Revisions 승인(revision_approved: 게시본 id, 수정안 id). rvy_revision_approve 가 수정안을 반영(또는 예약)한 뒤 부른다.
	 * 원장 아닌 계정의 예약 승인(수정 4 ①): 수정안 검토 정보 0·'' — 반영 때(로그인 없는 cron) PublishPress 가 이 값을 게시본으로 복사한다.
	 * 원장 아닌 계정의 바로 승인·반영은 그 앞의 revision_applied(clearOnApply)가 게시본을 0·'' 으로 했다.
	 */
	public static function recordOnApproval( $published_id, $revision_id ): void {
		$user     = wp_get_current_user();
		$revision = get_post( (int) $revision_id );
		if ( ! self::isReviewer( $user ) ) {
			if ( $revision instanceof WP_Post && self::isScheduledRevision( $revision ) ) {
				self::unreview( $revision->ID );
			}
			return;
		}
		if ( $revision instanceof WP_Post && 'future-revision' === $revision->post_mime_type ) {
			// 예약: 반영 때(로그인 없는 Action Scheduler·cron) PublishPress 가 이 메타를 게시본으로 복사한다(rvy_apply_revision →
			// revisionary_copy_postmeta) — 검토일 = 승인일. E2E '예약 수정안' 시험으로 확인.
			self::record( $revision->ID, $user->ID, self::today() );
			return;
		}
		$published = get_post( (int) $published_id );
		if ( ! $published instanceof WP_Post || self::POST_TYPE !== $published->post_type ) {
			return;
		}
		if ( isset( self::$applyMismatch[ $published->ID ] ) ) {
			// 반영 뒤 공개 내용 ≠ 승인 내용(수정 5 F1) — clearOnApply 가 이미 0·'' 으로 했다. 원장 기록을 붙이지 않는다.
			unset( self::$applyMismatch[ $published->ID ] );
			return;
		}
		$recorded = self::record( $published->ID, $user->ID, self::today() );
		// 승인된 수정안은 워드프레스 수정본(post_type revision)이 된다 — update_post_meta 는 수정본 id 를 부모로 바꾸므로 update_metadata 로.
		// 검토할 수 없는 페이지(record 거짓 — 수정 8)면 수정안이 게시본에서 복사해 온 옛 검토 값도 남기지 않는다(관리자 승인 clearOnApply 와 같은 0·'').
		if ( $revision instanceof WP_Post && 'revision' === $revision->post_type && (int) $revision->post_parent === $published->ID ) {
			update_metadata( 'post', $revision->ID, 'iwell_reviewed_by', $recorded ? $user->ID : 0 );
			update_metadata( 'post', $revision->ID, 'iwell_reviewed_at', $recorded ? self::today() : '' );
		}
	}

	/** 의학적 검토자 = 원장 역할. */
	public static function isReviewer( $user ): bool {
		return $user instanceof WP_User && $user->exists() && in_array( Roles::DIRECTOR, (array) $user->roles, true );
	}

	/**
	 * 원장 검토 기록 + 그 순간 공개 원천의 승인 지문(수정 7 결정 1 — 출력 때 verifiedReview 가 대조한다). 검토할 수 없는 페이지(의존성 해석이 안전 상한에서
	 * 멈춤·다른 글 등을 그리는 블록 — Seal::sealable, 수정 8 결정 1·2)는 원장 승인이어도 기록하지 않고 0·''(수정안이면 반영 때 게시본도 0·'').
	 *
	 * @return bool 기록했는가.
	 */
	private static function record( int $post_id, int $user_id, string $date ): bool {
		$post = get_post( $post_id );
		if ( $post instanceof WP_Post && ! Seal::sealable( $post ) ) {
			self::unreview( $post_id );
			return false;
		}
		update_post_meta( $post_id, 'iwell_reviewed_by', $user_id );
		update_post_meta( $post_id, 'iwell_reviewed_at', $date );
		Seal::stamp( $post_id );
		return true;
	}

	/** 지금 공개 원천을 이 글의 원장 승인 지문으로 남긴다 — 원장 승인 기록을 다른 길로 심을 때(시험 도우미 — 원장 승인과 같은 값). */
	public static function seal( int $post_id ): void {
		Seal::stamp( $post_id );
	}

	private static function today(): string {
		return Rules::today()->format( 'Y-m-d' );
	}

	private static function isRevisionDraft( WP_Post $post ): bool {
		return in_array( $post->post_mime_type, self::REVISION_MIME_TYPES, true );
	}

	/**
	 * 정리된 메타(구조화 데이터·배지는 이것만 읽는다).
	 *
	 * @return array{asof: string, reviewedBy: int, reviewedAt: string, sources: list<array{title: string, url: string, accessed: string}>, physician: array, terms: list<array{term: string, description: string}>}
	 */
	public static function get( int $post_id ): array {
		$raw             = static fn( string $key ) => get_post_meta( $post_id, $key, true );
		list( $by, $at ) = self::verifiedReview( $post_id ); // 검토 기록은 승인 지문이 맞을 때만(수정 7 결정 1 — 배지·JSON-LD·편집 패널 필드가 여기서 읽는다).
		return array(
			'asof'       => self::sanitizeDate( $raw( 'iwell_data_asof' ) ),
			'reviewedBy' => $by,
			'reviewedAt' => $at,
			'sources'    => self::sanitizeSources( $raw( 'iwell_sources' ) ),
			'physician'  => self::sanitizePhysician( $raw( 'iwell_physician' ) ),
			'terms'      => self::sanitizeTerms( $raw( 'iwell_terms' ) ),
		);
	}

	/** 의료진 메타만(정리값) — 의료진 노드(Graph::physicians)는 검토 기록을 읽지 않는다(get() 의 지문 확인을 의료진 페이지마다 하지 않게). */
	public static function physician( int $post_id ): array {
		return self::sanitizePhysician( get_post_meta( $post_id, 'iwell_physician', true ) );
	}

	/** 검토자 표시 이름(사용자 display_name). 검토자가 없거나 지워진 계정이면 ''. 배지·구조화 데이터가 같은 값을 쓴다. */
	public static function reviewerName( int $user_id ): string {
		$user = $user_id > 0 ? get_userdata( $user_id ) : false;
		return $user ? trim( (string) $user->display_name ) : '';
	}

	/** 배지 문구 '의학적 검토: {이름} · 기준일 {Y.m.d}'(기준일 없으면 앞부분만). 검토자가 없으면 ''. */
	public static function badgeText( int $post_id ): string {
		$meta = self::get( $post_id );
		$name = self::reviewerName( $meta['reviewedBy'] );
		if ( '' === $name ) {
			return '';
		}
		return '의학적 검토: ' . $name . ( '' !== $meta['asof'] ? ' · 기준일 ' . str_replace( '-', '.', $meta['asof'] ) : '' );
	}

	// ── 값 정리(sanitize_callback — 모든 저장 경로에 걸린다: REST·update_post_meta·PublishPress 복사·수정 이력 되돌리기) ──

	/** 실제 있는 날짜 'Y-m-d' 만, 아니면 ''. */
	public static function sanitizeDate( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}
		$value = trim( $value );
		if ( 1 !== preg_match( '/^(\d{4})-(\d{2})-(\d{2})\z/', $value, $m ) ) {
			return '';
		}
		return checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $value : '';
	}

	/** 제목·http(s) 주소가 모두 있는 항목만(최대 50). 확인일은 날짜가 아니면 ''. */
	public static function sanitizeSources( $value ): array {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$title = self::text( $item['title'] ?? null );
			$url   = self::url( $item['url'] ?? null );
			if ( '' === $title || '' === $url ) {
				continue;
			}
			$out[] = array(
				'title'    => $title,
				'url'      => $url,
				'accessed' => self::sanitizeDate( $item['accessed'] ?? '' ),
			);
			if ( count( $out ) >= self::MAX_ITEMS ) {
				break;
			}
		}
		return $out;
	}

	/** 이름이 있으면 {name, jobTitle?, medicalSpecialty?, alumniOf?, sameAs?}, 없으면 빈 배열. */
	public static function sanitizePhysician( $value ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}
		$name = self::text( $value['name'] ?? null );
		if ( '' === $name ) {
			return array();
		}
		$out = array( 'name' => $name );
		foreach ( array( 'jobTitle', 'medicalSpecialty' ) as $key ) {
			$text = self::text( $value[ $key ] ?? null );
			if ( '' !== $text ) {
				$out[ $key ] = $text;
			}
		}
		$alumni = array_values( array_filter( array_map( array( self::class, 'text' ), self::listOf( $value['alumniOf'] ?? null ) ), 'strlen' ) );
		if ( array() !== $alumni ) {
			$out['alumniOf'] = array_slice( $alumni, 0, self::MAX_ITEMS );
		}
		$same_as = array_values( array_filter( array_map( array( self::class, 'url' ), self::listOf( $value['sameAs'] ?? null ) ), 'strlen' ) );
		if ( array() !== $same_as ) {
			$out['sameAs'] = array_slice( $same_as, 0, self::MAX_ITEMS );
		}
		return $out;
	}

	/** 용어·설명이 모두 있는 항목만(최대 500 — 용어 사전 한 페이지). */
	public static function sanitizeTerms( $value ): array {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$term        = self::text( $item['term'] ?? null );
			$description = is_string( $item['description'] ?? null ) ? trim( sanitize_textarea_field( $item['description'] ) ) : '';
			if ( '' !== $term && '' !== $description ) {
				$out[] = array(
					'term'        => $term,
					'description' => $description,
				);
			}
			if ( count( $out ) >= 500 ) {
				break;
			}
		}
		return $out;
	}

	private static function text( $value ): string {
		return is_string( $value ) ? trim( sanitize_text_field( $value ) ) : '';
	}

	private static function url( $value ): string {
		return is_string( $value ) ? esc_url_raw( trim( $value ), array( 'http', 'https' ) ) : '';
	}

	private static function listOf( $value ): array {
		return is_array( $value ) ? array_values( $value ) : array();
	}

	// ── 블록·REST ─────────────────────────────────────────────────────

	public static function registerBlock(): void {
		register_block_type(
			'iwell/review-badge',
			array(
				'api_version'     => 3,
				'title'           => '의학적 검토 배지',
				'description'     => '의학적 검토자·기준일(페이지 속성에서 자동 — 원장이 승인·게시하면 기록).',
				'category'        => 'text',
				'icon'            => 'yes-alt',
				'uses_context'    => array( 'postId' ),
				'supports'        => array( 'html' => false ),
				'render_callback' => array( self::class, 'badgeBlock' ),
			)
		);
	}

	/**
	 * 블록 iwell/review-badge 렌더 — 실제로 보낸 공개 응답의 판정(LiveSeal — 수정 12 Ruling 1·2) 안에서만 보이지 않는 자리표시를 내고, 판정이 통과하면 그
	 * 자리에 배지가 들어간다. 판정을 거치지 않는 출력(REST content.rendered·피드·oEmbed·미리보기·발췌·편집기 서버 렌더)에는 아무것도 없다. 검토자가 없으면 없다.
	 */
	public static function badgeBlock( $attributes = array(), $content = '', $block = null ): string {
		$post_id = is_object( $block ) && isset( $block->context['postId'] ) ? (int) $block->context['postId'] : (int) get_the_ID();
		if ( $post_id <= 0 ) {
			return '';
		}
		return LiveSeal::badge(
			$post_id,
			static function () use ( $post_id ): string {
				$text = self::badgeText( $post_id );
				return '' === $text ? '' : sprintf( '<p %s>%s</p>', get_block_wrapper_attributes( array( 'class' => 'iwell-review-badge' ) ), esc_html( $text ) );
			}
		);
	}

	public static function registerRest(): void {
		register_rest_field(
			self::POST_TYPE,
			'iwell_review',
			array(
				'get_callback' => static function ( array $item ): array {
					$meta = self::get( (int) $item['id'] );
					return array(
						'by'   => $meta['reviewedBy'],
						'name' => self::reviewerName( $meta['reviewedBy'] ),
						'at'   => $meta['reviewedAt'],
					);
				},
				'schema'       => array(
					'description' => '의학적 검토(자동 기록, 읽기 전용).',
					'type'        => 'object',
					'context'     => array( 'edit' ),
					'readonly'    => true,
					'properties'  => array(
						'by'   => array( 'type' => 'integer' ),
						'name' => array( 'type' => 'string' ),
						'at'   => array( 'type' => 'string' ),
					),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/pages/by-path',
			array(
				'methods'             => 'GET',
				'permission_callback' => static fn(): bool => current_user_can( 'edit_pages' ),
				'args'                => array(
					'path' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
				'callback'            => static function ( WP_REST_Request $request ) {
					$post = self::byPath( (string) $request['path'] );
					if ( ! $post ) {
						return new WP_Error( 'iwell_page_not_found', '그 경로의 고정 페이지가 없습니다.', array( 'status' => 404 ) );
					}
					return new WP_REST_Response(
						array(
							'id'     => $post->ID,
							'status' => $post->post_status,
							'parent' => (int) $post->post_parent,
						),
						200
					);
				},
			)
		);
	}

	/**
	 * 'growth/precocious-puberty' → 그 계층의 고정 페이지(모든 상태: 게시·초안·검토 대기·비공개·예약). 휴지통·자동 초안·PublishPress 수정안은 제외.
	 * 같은 부모 아래 같은 slug 가 여럿이면(초안은 slug 중복이 허용된다) 게시본 → 작은 ID 순으로 하나.
	 */
	public static function byPath( string $path ): ?WP_Post {
		$segments = array_values( array_filter( explode( '/', trim( $path, "/ \t\n\r\0\x0B" ) ), static fn( string $s ): bool => '' !== $s ) );
		if ( array() === $segments || count( $segments ) > 20 ) {
			return null;
		}
		$parent = 0;
		$found  = null;
		foreach ( $segments as $segment ) {
			$slug = sanitize_title( $segment );
			if ( '' === $slug ) {
				return null;
			}
			$found = self::childPage( $parent, $slug );
			if ( ! $found ) {
				return null;
			}
			$parent = $found->ID;
		}
		return $found;
	}

	private static function childPage( int $parent, string $slug ): ?WP_Post {
		global $wpdb;
		$mimes = implode( ',', array_fill( 0, count( self::REVISION_MIME_TYPES ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- 자리표시자 수를 위에서 맞춤.
		$id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = %s AND post_name = %s AND post_parent = %d
					AND post_status NOT IN ('trash', 'auto-draft', 'inherit')
					AND post_mime_type NOT IN ($mimes)
				ORDER BY (post_status = 'publish') DESC, ID ASC
				LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::POST_TYPE,
				$slug,
				$parent,
				...self::REVISION_MIME_TYPES
			)
		);
		return $id ? get_post( (int) $id ) : null;
	}
}
