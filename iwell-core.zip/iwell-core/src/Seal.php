<?php
/**
 * 승인 지문(Task 6 수정 7 결정 1 — 코디네이터 결정: 원칙을 출력 시점에 직접 검사한다).
 *
 * 원칙: 원장 검토 기록(배지·JSON-LD reviewedBy/lastReviewed·편집 패널)은 원장이 승인한 내용에만 붙는다.
 * 수정 2~6 은 공개 값을 바꾸는 경로(이벤트)를 하나씩 막았다. 이 장치는 그 위에 겹으로: 원장이 승인하는 순간 그 페이지의 "해석된 공개 원천"을
 * 정규화해 지문으로 남기고(보호 내부 메타 _iwell_approval), 출력할 때 다시 계산해 다르면 검토 기록을 내보내지 않는다(PageMeta::verifiedReview —
 * 그 자리에서 lapse: 검토 기록 0·'', 원장 예약 페이지 검토 대기, 원장 예약 승인 수정안 승인 취소). 이벤트는 기록을 남기고, 지문은 놓친 경로를 잡는다.
 *
 * 지문에 넣는 것(parts — 조각마다 sha256 앞 20자, 조각 이름으로 정렬) — 지문 형식 2(수정 10, 대표 결정 2026-11-15 "화면 결과"):
 *   out:{body|title|sources|featured}  공개 화면 결과의 정규화 추출물(Fingerprint — 본문 the_content·검토 대상 메타를 그리는 템플릿 블록·대표 이미지 출력값,
 *                               오늘 진료 바·진료시간 표·검토 배지는 고정 토큰으로 가림). 어떤 입력 경로로 바뀌든 사람이 보는 결과가 바뀌면 잡힌다.
 *   post                        제목·본문(원문 — 렌더 HTML 아님)·발췌 — 검토 대상 그 자체(겹)
 *   meta:{키}                   검토 대상 메타 PageMeta::REVIEWED_META(정리값 — 기준일·출처·의료진·용어·Rank Math 제목·설명·각주·대표 이미지)
 *   expand:{rank_math_title|rank_math_description}  실제로 출력되는 SEO 제목·설명(수정 8 결정 3 — seoTemplate()·expand()): 페이지 전용 값이 비면
 *                               Rank Math 와 같은 순서의 대체값(제목 = 전역 템플릿 pt_page_title, 설명 = 발췌 → 전역 템플릿 pt_page_description)을 쓰고,
 *                               내용·사이트 설정 변수(%sitename%·%sitedesc%·%sep%·%org_*%·%userid%·작성자 변수·%customfield()%·%parent_title%·
 *                               %focuskw%)를 펼친다
 *   attachment:{ID}             쓰는 첨부(기존 해석기 Sources ∪ 지문 렌더가 관찰한 첨부) 하나하나의 파일·크기 메타 중 폭·높이·파일 이름·대체 글·제목·캡션·설명·
 *                               MIME·상태, 없으면 missing — 화면에 안 그려지는 캡션(JSON-LD)·제목도 원장 검토 범위로 남긴다(겹)
 * 수정 10 에서 지운 입력 해시: block:{ID}(동기화 패턴 본문·공개 상태·비밀번호 — 패턴 출력이 out:body 안이고, 렌더된 패턴은 관찰 목록으로 직원 차단·lapse 에 쓴다).
 * 넣지 않는 것(지금 검토를 지우지 않는 값과 같게): 날짜·수정 시각·슬러그·메뉴 순서·부모·템플릿·작성자, 같은 값 재저장(정리값이 같다), 시간에 따라
 * 바뀌는 동적 블록 출력(오늘 진료 바·진료시간 표 — 가림 토큰만 들어간다), 마크업만의 변화(클래스·스타일·래퍼·lazy — 정규화), 첨부 크기 메타의 그 밖의
 * 값(파일 크기·EXIF — 하위 크기 파일이 화면에 쓰이면 out:* 의 srcset·src 로 잡힌다), Rank Math 의 시간·주소·쪽 번호·요청 문맥 변수와 이미 지문에 든
 * 원천의 변수(%title%·%excerpt%·%seo_title% 등 — 템플릿 글자 그대로, expand()).
 *
 * 지문 형식 1(수정 7~9 — out:* 없음)로 남은 승인 기록은 형식이 달라 첫 출력에서 무효(valid 거짓 → lapse — 재확인 4 "레거시 지문 없음 = 통과"와 같은 닫힌 쪽).
 *
 * 검토할 수 없는 페이지(수정 8 결정 1·2 — sealable()): 의존성 해석이 안전 상한에서 멈췄거나(Sources::TOO_DEEP) 다른 글·댓글·사용자 프로필·사이트 설정·
 * 외부 주소를 그리는 블록·짧은 코드·블록 연결이 있으면(Sources::of 'unresolved') 지문이 맞지 않는 것으로 본다(valid() 거짓 — 출력 때 lapse, 원장 승인
 * 때도 PageMeta 가 검토 기록을 남기지 않는다). 수정 11(C7-2): 지문 렌더 중 실제로 짧은 코드가 실행되거나 목록 밖 서버 렌더 블록이 그려져도 같다
 * (Fingerprint::of 'unresolved' — unresolved() 가 둘을 합친다).
 *
 * 테마 템플릿·템플릿 파트(머리·바닥글 등)는 원장 검토 범위 밖이다(수정 8 결정 4 — 지문에 넣지 않는다, 직원·봇은 고칠 수 없다).
 *
 * 수정안(PublishPress)은 지문을 복사해 가지 않는다(revisionary_unrevisioned_postmeta) — 지문은 그 글이 원장 승인을 받은 순간 그 글에서 계산한다.
 */

namespace Iwell\Core;

use Iwell\Core\Schema\Graph;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Seal {
	public const KEY     = '_iwell_approval';
	public const VERSION = 2;

	/**
	 * Rank Math 변수 중 펼쳐서 지문에 넣는 것(내용 원천·사이트 설정을 읽는 것) — 수정 7 결정 3: 작성자 변수는 병원으로 펼친다(Graph::clinicAuthorVariables
	 * 와 같은 값). 수정 8 결정 3: 사이트 설정(%sitename%·%sitedesc%·%sep%·%org_name%·%org_logo%·%org_url%)과 %userid%(작성자 ID)도 펼친다.
	 */
	private const EXPANDED = '/%customfield\(([^)]*)\)%|%(name|post_author|user_description|parent_title|focuskw|keywords|sitename|sitedesc|sep|org_name|org_logo|org_url|userid)%/';

	/** Rank Math 사이트 설정(Titles & Meta) 옵션 — 전역 템플릿·구분자·조직 정보(includes/class-settings.php:43). */
	private const RANK_MATH_TITLES = 'rank-math-options-titles';

	/** 지문이 읽는 사이트 옵션 — 바뀌면 요청 안 기억을 비운다(관리자 저장 뒤 같은 요청의 출력도 새 값으로). */
	private const OPTIONS = array( self::RANK_MATH_TITLES, 'blogname', 'blogdescription', 'home' );

	/** @var array<int, array<string, string>> 요청 안 기억(Sources::flush 와 같이 비움). */
	private static array $memo = array();

	public static function register(): void {
		add_action( 'init', array( self::class, 'registerMeta' ) );
		add_filter( 'revisionary_unrevisioned_postmeta', array( self::class, 'keepOwn' ) );
		add_action( 'clean_post_cache', array( self::class, 'flush' ) );
		add_action( 'deleted_post', array( self::class, 'flush' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( self::class, 'flush' ) );
		}
		foreach ( self::OPTIONS as $option ) {
			foreach ( array( 'add_option_', 'update_option_', 'delete_option_' ) as $prefix ) {
				add_action( $prefix . $option, array( self::class, 'flush' ) );
			}
		}
	}

	/** 보호 내부 메타: REST 에 등록하지 않고(요청 meta 로 보내도 무시) 쓰기 권한 거짓(사용자 지정 필드·XML-RPC 거부) — 직원이 미리 심을 수 없다. */
	public static function registerMeta(): void {
		register_post_meta(
			PageMeta::POST_TYPE,
			self::KEY,
			array(
				'type'              => 'object',
				'single'            => true,
				'show_in_rest'      => false,
				'auth_callback'     => static fn(): bool => false,
				'sanitize_callback' => static fn( $value ) => is_array( $value ) ? $value : array(),
			)
		);
	}

	public static function flush(): void {
		self::$memo = array();
	}

	/** PublishPress 메타 복사에서 지문을 뺀다(수정안 만들기·반영 — functions.php:10-19 의 복사 제외 목록). */
	public static function keepOwn( $exclude ): array {
		$exclude              = is_array( $exclude ) ? $exclude : array();
		foreach ( array( self::KEY, Fingerprint::CACHE_KEY, Fingerprint::DEP_KEY, Fingerprint::LAPSE_KEY, Fingerprint::LIVE_KEY ) as $key ) {
			$exclude[ $key ] = true;
		}
		return $exclude;
	}

	/** 지금 공개 원천의 지문을 이 글의 승인 지문으로 남긴다(원장 승인 순간). */
	public static function stamp( int $post_id ): void {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$parts = self::parts( $post );
		$deps  = Fingerprint::of( $post );
		// update_metadata — update_post_meta 는 워드프레스 수정본 id 를 부모로 바꾼다(여기 대상은 고정 페이지·PublishPress 수정안).
		update_metadata(
			'post',
			$post->ID,
			self::KEY,
			array(
				'v'     => self::VERSION,
				'parts' => $parts,
			)
		);
		// 관찰한 의존성(결정 2) — 직원·봇 차단·관리자 변경 lapse 가 기존 해석기 결과와 합쳐 쓴다. 다시 승인했으니 해제 기록은 지운다.
		Fingerprint::index( $post->ID, $deps['attachments'], $deps['blocks'] );
		delete_metadata( 'post', $post->ID, Fingerprint::LAPSE_KEY );
		Fingerprint::resetLive( $post->ID ); // 공개 차이 알림도 새로(빈 자리 — 수정 13 Ruling 3: 공개 요청의 쓰기는 모두 비교-교체).
	}

	/** 남긴 지문이 있는가. */
	public static function stamped( int $post_id ): bool {
		$stored = get_post_meta( $post_id, self::KEY, true );
		return is_array( $stored ) && is_array( $stored['parts'] ?? null );
	}

	/** 남긴 승인 지문 = 지금 공개 원천의 지문인가(없으면 거짓). 검토할 수 없는 페이지(sealable() 거짓)는 언제나 거짓(수정 8 — 닫힌 쪽). */
	public static function valid( WP_Post $post ): bool {
		$stored = get_post_meta( $post->ID, self::KEY, true );
		return is_array( $stored ) && self::VERSION === ( $stored['v'] ?? null ) && is_array( $stored['parts'] ?? null )
			&& self::sealable( $post ) && $stored['parts'] === self::parts( $post );
	}

	/**
	 * 남긴 승인 지문과 다른 조각 이름(운영 기록 — 어떤 결과가 바뀌었나). 형식이 다르거나 없으면 ['format'], 검토 불가면 ['unresolved'].
	 *
	 * @return string[]
	 */
	public static function diff( WP_Post $post ): array {
		$stored = get_post_meta( $post->ID, self::KEY, true );
		if ( ! is_array( $stored ) || self::VERSION !== ( $stored['v'] ?? null ) || ! is_array( $stored['parts'] ?? null ) ) {
			return array( 'format' );
		}
		if ( ! self::sealable( $post ) ) {
			return array( 'unresolved' );
		}
		$now  = self::parts( $post );
		$keys = array_unique( array_merge( array_keys( $now ), array_keys( $stored['parts'] ) ) );
		sort( $keys );
		return array_values( array_filter( $keys, static fn( string $k ): bool => ( $now[ $k ] ?? null ) !== ( $stored['parts'][ $k ] ?? null ) ) );
	}

	/**
	 * 검토 기록을 붙일 수 있는 페이지인가(수정 8 결정 1·2): 의존성 해석이 끝까지 됐고(안전 상한 안) 다른 글·댓글·사용자 프로필·사이트 설정·외부 주소를
	 * 그리는 블록·짧은 코드·블록 연결이 없다(Sources::of 'unresolved' 가 빔) — 그리고 지문 렌더 중에도 짧은 코드가 실행되거나 허용 목록 밖 서버 렌더 블록이
	 * 그려지지 않았다(Fingerprint::of 'unresolved' 가 빔 — 수정 11 C7-2, 원본 검사가 못 보는 각주 JSON·이스케이프한 덮어쓰기 등). 원본 검사가 먼저 걸리면 렌더하지 않는다.
	 */
	public static function sealable( WP_Post $post ): bool {
		return array() === Sources::of( $post )['unresolved'] && array() === Fingerprint::of( $post )['unresolved'];
	}

	/**
	 * 검토 불가 사유 전부(정렬): 원본 검사(Sources::of — TOO_DEEP·block:·shortcode:·binding:) ∪ 지문 렌더 중 실행 감시(Fingerprint::of — block:·shortcode:, 수정 11).
	 *
	 * @return string[]
	 */
	public static function unresolved( WP_Post $post ): array {
		$all = array_values( array_unique( array_merge( Sources::of( $post )['unresolved'], Fingerprint::of( $post )['unresolved'] ) ) );
		sort( $all );
		return $all;
	}

	/**
	 * 해석된 공개 원천의 지문 조각.
	 *
	 * @return array<string, string>
	 */
	public static function parts( WP_Post $post ): array {
		if ( isset( self::$memo[ $post->ID ] ) ) {
			return self::$memo[ $post->ID ];
		}
		$out   = Fingerprint::of( $post ); // 공개 화면 결과(결정 1) + 그 렌더가 관찰한 의존성(결정 2).
		$parts = self::partsWith( $post, $out['parts'], array_merge( Sources::of( $post )['attachments'], $out['attachments'] ) );
		self::$memo[ $post->ID ] = $parts;
		return $parts;
	}

	/**
	 * 지문 조각 — 화면 결과 조각 $out(out:* → 해시)은 받은 값으로, 나머지(post·meta·expand·attachment — 렌더 없이 원천에서)는 여기서. 승인 지문(parts — 승인
	 * 렌더의 out:*)과 공개 판정(LiveSeal — 실제로 보낸 응답의 out:*)이 같은 함수를 쓴다(수정 12).
	 *
	 * @param array<string, string> $out
	 * @param int[]                 $attachments
	 * @return array<string, string>
	 */
	public static function partsWith( WP_Post $post, array $out, array $attachments ): array {
		$parts = array( 'post' => self::hash( array( (string) $post->post_title, (string) $post->post_content, (string) $post->post_excerpt ) ) );
		foreach ( PageMeta::REVIEWED_META as $key ) {
			$parts[ "meta:$key" ] = self::hash( PageMeta::normalizeReviewed( $key, get_post_meta( $post->ID, $key, true ) ) );
		}
		foreach ( PageMeta::RANK_MATH_KEYS as $key ) {
			$parts[ "expand:$key" ] = self::hash( self::expand( self::seoTemplate( $post, $key ), $post ) );
		}
		foreach ( $out as $key => $hash ) {
			$parts[ (string) $key ] = (string) $hash;
		}
		foreach ( array_unique( array_map( 'intval', $attachments ) ) as $id ) {
			$parts[ "attachment:$id" ] = self::hash( self::attachmentSource( (int) $id ) );
		}
		ksort( $parts );
		return $parts;
	}

	/**
	 * 남긴 승인 지문 조각(지금 형식일 때만 — 아니면 null). 공개 판정(LiveSeal)이 실제 응답과 비교한다.
	 *
	 * @return array<string, string>|null
	 */
	public static function approved( WP_Post $post ): ?array {
		$stored = get_post_meta( $post->ID, self::KEY, true );
		return is_array( $stored ) && self::VERSION === ( $stored['v'] ?? null ) && is_array( $stored['parts'] ?? null ) ? $stored['parts'] : null;
	}

	/**
	 * 공개 화면이 실제로 쓰는 SEO 제목·설명 템플릿(수정 8 결정 3 — Rank Math 1.0.282 frontend/paper/class-singular.php:192-241 과 같은 순서):
	 *   제목 = 페이지 전용 rank_math_title, 비면 전역 pt_{글 종류}_title(비면 '%title% %sep% %sitename%')
	 *   설명 = 페이지 전용 rank_math_description, 비면 발췌(비밀번호 없는 글), 비면 전역 pt_{글 종류}_description
	 * (전역 템플릿의 %seo_title%·%seo_description% 을 Rank Math 는 %title%·%excerpt% 로 바꾸지만 — class-paper.php:465-477 — 넷 다 지문에서는 글자 그대로라
	 * 바꾸지 않아도 같은 변화를 잡는다.) 사이트 설정은 옵션을 직접 읽는다(Rank Math 설정 객체는 요청 처음 값을 기억한다).
	 */
	private static function seoTemplate( WP_Post $post, string $key ): string {
		$own = (string) get_post_meta( $post->ID, $key, true );
		if ( '' !== $own ) {
			return $own;
		}
		$is_title = 'rank_math_title' === $key;
		if ( ! $is_title && '' !== (string) $post->post_excerpt && '' === (string) $post->post_password ) {
			return (string) $post->post_excerpt;
		}
		$global = self::rankMathTitles()[ 'pt_' . $post->post_type . ( $is_title ? '_title' : '_description' ) ] ?? '';
		$global = is_string( $global ) ? $global : '';
		return '' === $global && $is_title ? '%title% %sep% %sitename%' : $global;
	}

	/** @return array<string, mixed> Rank Math 사이트 설정(Titles & Meta). */
	private static function rankMathTitles(): array {
		$titles = get_option( self::RANK_MATH_TITLES );
		return is_array( $titles ) ? $titles : array();
	}

	/**
	 * Rank Math 템플릿에서 내용 원천·사이트 설정을 읽는 변수를 펼친다(Rank Math 치환기는 요청 안에서 템플릿 문자열 기준으로 값을 기억해 여러 글을 비교하는 데
	 * 쓸 수 없다 — replace-variables/class-replacer.php set_up_replacements 캐시): %customfield(키)% = 그 글의 메타, %parent_title% = 부모 글 제목,
	 * %focuskw%·%keywords% = Rank Math 초점 키워드 메타, %name%·%post_author% = 병원 이름·%user_description% = 빈 값(수정 7 결정 3 — 고정 페이지).
	 * 수정 8 결정 3(Rank Math 값과 같은 원천 — class-basic-variables.php:253-293·413-433, class-author-variables.php:93-100):
	 * %sitename%·%sitedesc% = 사이트 이름·설명, %sep% = 구분자 설정, %org_name%·%org_logo%·%org_url% = 조직 설정, %userid% = 작성자 ID.
	 * 그 밖의 변수(%title%·%excerpt%·%seo_title% 등 이미 지문에 든 값, 날짜·현재 시각·주소·쪽 번호·검색어 같은 시간·요청 문맥)는 템플릿 글자 그대로 둔다
	 * (펼치면 시간이 지나기만 해도 검토가 내려간다).
	 */
	public static function expand( string $template, WP_Post $post ): string {
		if ( '' === $template || ! str_contains( $template, '%' ) ) {
			return $template;
		}
		return (string) preg_replace_callback(
			self::EXPANDED,
			static function ( array $m ) use ( $post ): string {
				if ( '' !== ( $m[1] ?? '' ) ) {
					return self::scalar( get_post_meta( $post->ID, trim( wp_specialchars_decode( $m[1] ) ), true ) );
				}
				switch ( $m[2] ) {
					case 'name':
					case 'post_author':
						return Graph::clinicInfo()['name'];
					case 'user_description':
						return '';
					case 'parent_title':
						$parent = (int) $post->post_parent > 0 ? get_post( (int) $post->post_parent ) : null;
						return $parent instanceof WP_Post ? (string) $parent->post_title : '';
					case 'sitename':
						return wp_strip_all_tags( (string) get_bloginfo( 'name' ), true );
					case 'sitedesc':
						return wp_strip_all_tags( (string) get_bloginfo( 'description' ) );
					case 'sep':
						return htmlentities( self::scalar( apply_filters( 'rank_math/settings/title_separator', self::rankMathTitles()['title_separator'] ?? '' ) ), ENT_COMPAT, 'UTF-8', false );
					case 'org_name':
						return self::scalar( self::rankMathTitles()['knowledgegraph_name'] ?? get_bloginfo( 'name' ) );
					case 'org_logo':
						return self::scalar( self::rankMathTitles()['knowledgegraph_logo'] ?? '' );
					case 'org_url':
						return self::scalar( self::rankMathTitles()['url'] ?? home_url() );
					case 'userid':
						return (string) (int) $post->post_author;
					default:
						return self::scalar( get_post_meta( $post->ID, 'rank_math_focus_keyword', true ) );
				}
			},
			$template
		);
	}

	/** 첨부의 공개 원천: 파일·폭·높이·파일 이름(크기 메타의 의미 있는 값)·대체 글·제목·캡션·설명·MIME·상태. */
	private static function attachmentSource( int $id ) {
		$attachment = get_post( $id );
		if ( ! $attachment instanceof WP_Post || 'attachment' !== $attachment->post_type ) {
			return 'missing';
		}
		return array(
			(string) get_post_meta( $id, '_wp_attached_file', true ),
			self::imageMeta( get_post_meta( $id, '_wp_attachment_metadata', true ) ),
			self::scalar( get_post_meta( $id, PageMeta::ATTACHMENT_ALT, true ) ),
			(string) $attachment->post_title,
			(string) $attachment->post_excerpt,
			(string) $attachment->post_content,
			(string) $attachment->post_mime_type,
			(string) $attachment->post_status,
		);
	}

	/** 첨부 크기 메타에서 공개 화면을 바꾸는 값 — 폭·높이·파일 이름(파일 크기·변형 크기 목록·EXIF 는 뺀다). */
	public static function imageMeta( $meta ): array {
		$meta = is_array( $meta ) ? $meta : array();
		return array(
			'width'  => (int) ( $meta['width'] ?? 0 ),
			'height' => (int) ( $meta['height'] ?? 0 ),
			'file'   => (string) ( $meta['file'] ?? '' ),
		);
	}

	private static function scalar( $value ): string {
		return is_scalar( $value ) ? (string) $value : ( null === $value ? '' : (string) wp_json_encode( $value ) );
	}

	private static function hash( $value ): string {
		return substr( hash( 'sha256', serialize( $value ) ), 0, 20 ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- 비교용 지문(되돌려 읽지 않음).
	}
}
