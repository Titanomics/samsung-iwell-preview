<?php
/**
 * 외국어 쪽 — 대표 결정(2026-11-26): 한국어(정본)·영어·베트남어·중국어(간체), 자체 구현(번역 플러그인·외부 번역 서비스 없음 — 외부 요청 0·쿠키 0),
 * 넓게 10쪽 × 3언어. 참고 demo.verata.kr/iwell-clinic/(조사 docs/i18n-research-2026-11-26.md).
 *
 *  - 언어마다 최상위 고정 페이지 하나가 그 언어의 홈이다(/en/·/vi/·/zh/). 그 아래 자식 페이지가 번역 쪽(/en/hours/).
 *    언어 홈이 게시되지 않은 언어는 전환 단추에서 "준비 중"(링크 없음 — 메뉴에 404 링크를 내지 않는다). 외국어가 하나도 열리지 않았으면 단추가 없다.
 *  - 쪽 짝 = PAGES 한 표(외국어 slug → 한국어 경로, 한국어 짝이 없는 쪽은 null). 짝이 게시돼 있을 때만 전환 단추·hreflang 이 그 쪽을 가리킨다.
 *    hreflang = 게시된 짝끼리(ko-KR·en·vi·zh-Hans) + x-default(한국어 짝이 있을 때 그 한국어 쪽).
 *  - 외국어 쪽 템플릿 = page-lang(테마, 주소로 정함 — 직원이 고를 수 없다). 원장 검토 배지·출처·브레드크럼·탭을 그리지 않는다(외국어 쪽은 검토 배지 없음).
 *  - 바뀌는 값(진료시간·휴진·일요일 원장·예방접종·비급여·제증명 금액)은 외국어 원고에 숫자로 적지 않는다: 진료시간 블록(Hours\Translate)과
 *    한국어 원천 표 블록 iwell/source-table(I18n\Cells — 게시된 한국어 쪽의 표를 읽어 칸 글자만 번역)이 한국어와 같은 원천에서 그린다.
 *  - 머리·바닥글 블록(테마)은 current() 로 언어를 보고 UI 사전 t() 로 그린다. 한국어 쪽은 지금과 똑같다(html lang 만 ko-KR).
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class I18n {
	public const DEFAULT = 'ko';

	/** 언어 — 코드 → [단추 글자, 원어 이름, hreflang·html lang, og:locale]. 순서 = 전환 단추 순서(대표 "한국어 / English / Tiếng Việt / 中文"). */
	public const LANGS = array(
		'ko' => array(
			'short'  => 'KO',
			'name'   => '한국어',
			'tag'    => 'ko-KR',
			'locale' => 'ko_KR',
		),
		'en' => array(
			'short'  => 'EN',
			'name'   => 'English',
			'tag'    => 'en',
			'locale' => 'en_US',
		),
		'vi' => array(
			'short'  => 'VI',
			'name'   => 'Tiếng Việt',
			'tag'    => 'vi',
			'locale' => 'vi_VN',
		),
		'zh' => array(
			'short'  => '中文',
			'name'   => '中文',
			'tag'    => 'zh-Hans',
			'locale' => 'zh_CN',
		),
	);

	/**
	 * 쪽 짝 — 외국어 slug('' = 언어 홈) → 한국어 경로('' = 홈, null = 한국어 짝 없음). 세 언어가 같은 slug 를 쓴다(/en/hours/·/vi/hours/·/zh/hours/).
	 * 원고 = content/i18n/{lang}/{slug 또는 home}.html, 제목·SEO = content/i18n/pages.json(이 표와 같은 slug — 단위 시험 i18n-pages.test.ts).
	 */
	public const PAGES = array(
		''               => '',
		'about'          => 'about',
		'doctors'        => 'about/doctors',
		'services'       => null,
		'hours'          => 'guide/hours',
		'vaccinations'   => 'checkup/vaccination-schedule',
		'infant-checkup' => 'checkup/infant-checkup',
		'fees'           => 'guide/fees',
		'certificates'   => 'guide/certificates',
		'consult'        => 'consult',
	);

	/** 외국어 쪽 머리 메뉴(나머지는 바닥글 목록). */
	public const MENU = array( 'about', 'doctors', 'services', 'hours', 'consult' );

	/** 외국어 쪽 템플릿(테마 templates/page-lang.html). */
	public const TEMPLATE = 'page-lang';

	public static function register(): void {
		add_filter( 'language_attributes', array( self::class, 'languageAttributes' ), 20 );
		add_action( 'wp_head', array( self::class, 'printAlternates' ), 2 );
		add_filter( 'page_template_hierarchy', array( self::class, 'templateHierarchy' ) );
		add_filter( 'rank_math/opengraph/facebook/og_locale', array( self::class, 'ogLocale' ) );
		add_filter( 'rank_math/json_ld', array( self::class, 'jsonLdLanguage' ), 99 );
		// 브레드크럼(BreadcrumbList) — Nav::rankMathCrumbs(10) 뒤에 외국어 쪽만 "홈"을 그 언어 홈으로.
		add_filter( 'rank_math/frontend/breadcrumb/items', array( self::class, 'crumbs' ), 20 );
		// 진료시간 블록(Hours\Render)의 글자 — 외국어 쪽에서만 바꾼다(한국어 쪽은 필터가 받은 값 그대로).
		add_filter( 'iwell/hours/today_text', array( self::class, 'hoursTodayText' ) );
		add_filter( 'iwell/hours/table_html', array( self::class, 'hoursTableHtml' ), 10, 3 );
		add_action( 'init', array( I18n\Cells::class, 'registerBlocks' ) );
	}

	/** 외국어 코드 목록(한국어 뺌). @return list<string> */
	public static function foreign(): array {
		return array_values( array_filter( array_keys( self::LANGS ), static fn( string $l ): bool => self::DEFAULT !== $l ) );
	}

	/** 경로(앞뒤 / 무관)의 언어 — 첫 단계가 외국어 코드면 그 언어, 아니면 한국어. */
	public static function langOfPath( string $path ): string {
		$first = explode( '/', trim( $path, '/' ) )[0];
		return in_array( $first, self::foreign(), true ) ? $first : self::DEFAULT;
	}

	/** 최상위 언어 홈 경로인가('en'·'vi'·'zh'). 바닥글·llms 의 최상위 페이지 목록에서 뺀다(Nav::footerPages). */
	public static function isRoot( string $path ): bool {
		return in_array( trim( $path, '/' ), self::foreign(), true );
	}

	/** 지금 요청의 언어 — 고정 페이지면 그 경로로, 그 밖(홈·글·목록·404)은 한국어. */
	public static function current(): string {
		if ( ! function_exists( 'is_page' ) || ! is_page() ) {
			return self::DEFAULT;
		}
		return self::langOfPath( Nav::pathOf( (int) get_queried_object_id() ) );
	}

	/** 외국어 slug → 그 언어 경로('' → 'en', 'hours' → 'en/hours'). */
	public static function langPath( string $slug, string $lang ): string {
		return '' === $slug ? $lang : $lang . '/' . $slug;
	}

	/** 한국어 경로 → 그 언어 짝의 경로(짝이 없으면 null). 한국어는 그대로. */
	public static function pathFor( string $ko_path, string $lang ): ?string {
		$ko_path = trim( $ko_path, '/' );
		if ( self::DEFAULT === $lang ) {
			return $ko_path;
		}
		if ( ! isset( self::LANGS[ $lang ] ) ) {
			return null;
		}
		$slug = array_search( $ko_path, self::PAGES, true );
		return false === $slug ? null : self::langPath( (string) $slug, $lang );
	}

	/** 어느 경로든 → 짝 표의 slug(외국어 쪽이면 그 slug, 한국어 쪽이면 짝 slug). 표에 없으면 null. */
	public static function slugOf( string $path ): ?string {
		$path = trim( $path, '/' );
		$lang = self::langOfPath( $path );
		if ( self::DEFAULT === $lang ) {
			$slug = array_search( $path, self::PAGES, true );
			return false === $slug ? null : (string) $slug;
		}
		$rest = (string) substr( $path, strlen( $lang ) + 1 );
		return array_key_exists( $rest, self::PAGES ) ? $rest : null;
	}

	/** 어느 언어 경로든 → 짝의 한국어 경로(한국어 짝이 없거나 표에 없으면 null). */
	public static function koPathOf( string $path ): ?string {
		$slug = self::slugOf( $path );
		return null === $slug ? null : self::PAGES[ $slug ];
	}

	/** 그 언어 홈이 열렸나(한국어는 늘 열림, 외국어는 언어 홈 페이지가 게시됐을 때). */
	public static function isOpen( string $lang ): bool {
		return self::DEFAULT === $lang || ( isset( self::LANGS[ $lang ] ) && Nav::isPublic( $lang ) );
	}

	/** 게시된 경로의 주소(홈 ''·한국어·외국어 모두). 공개가 아니면 null. */
	private static function publicUrl( string $path ): ?string {
		$path = trim( $path, '/' );
		if ( '' === $path ) {
			return home_url( '/' );
		}
		return Nav::isPublic( $path ) ? Nav::publicUrl( $path ) : null;
	}

	/** 지금 쪽의 경로(홈 = '', 고정 페이지 = 계층 경로, 그 밖 = null — 짝이 없는 화면). */
	public static function currentPath(): ?string {
		if ( function_exists( 'is_front_page' ) && is_front_page() && ! is_page() ) {
			return '';
		}
		if ( function_exists( 'is_page' ) && is_page() ) {
			$path = Nav::pathOf( (int) get_queried_object_id() );
			return '' === $path ? null : $path;
		}
		return null;
	}

	/**
	 * 같은 내용의 게시된 쪽들 — 언어 → 주소(LANGS 순). 짝 표에 없는 쪽이면 빈 목록.
	 *
	 * @return array<string, string>
	 */
	public static function alternates( ?string $path = null ): array {
		$path ??= self::currentPath();
		$slug = null === $path ? null : self::slugOf( $path );
		if ( null === $slug ) {
			return array();
		}
		$out = array();
		foreach ( array_keys( self::LANGS ) as $lang ) {
			$p = self::DEFAULT === $lang ? self::PAGES[ $slug ] : self::langPath( $slug, $lang );
			if ( null === $p || ! self::isOpen( $lang ) ) {
				continue;
			}
			$url = self::publicUrl( $p );
			if ( null !== $url ) {
				$out[ $lang ] = $url;
			}
		}
		return $out;
	}

	/**
	 * 전환 단추 항목 — 언어마다 {lang, short, name, tag, url|null, current}. 주소 = 게시된 짝 → 그 언어 홈 → null(준비 중).
	 *
	 * @return list<array{lang: string, short: string, name: string, tag: string, url: ?string, current: bool}>
	 */
	public static function switcher(): array {
		$current = self::current();
		$alts    = self::alternates();
		$out     = array();
		foreach ( self::LANGS as $lang => $l ) {
			$url   = $alts[ $lang ] ?? ( self::isOpen( $lang ) ? self::publicUrl( self::DEFAULT === $lang ? '' : $lang ) : null );
			$out[] = array(
				'lang'    => $lang,
				'short'   => $l['short'],
				'name'    => $l['name'],
				'tag'     => $l['tag'],
				'url'     => $url,
				'current' => $lang === $current,
			);
		}
		return $out;
	}

	/**
	 * 외국어 쪽 목록 — 그 언어의 게시된 쪽(PAGES 순, 언어 홈 제외). $only = 머리 메뉴처럼 일부 slug 만.
	 *
	 * @param list<string>|null $only
	 * @return list<array{path: string, slug: string, title: string, url: string}>
	 */
	public static function menu( string $lang, ?array $only = null ): array {
		$out = array();
		foreach ( array_keys( self::PAGES ) as $slug ) {
			$slug = (string) $slug;
			if ( '' === $slug || ( null !== $only && ! in_array( $slug, $only, true ) ) ) {
				continue;
			}
			$path = self::langPath( $slug, $lang );
			$url  = self::publicUrl( $path );
			if ( null !== $url ) {
				$out[] = array(
					'path'  => $path,
					'slug'  => $slug,
					'title' => Nav::title( $path ),
					'url'   => $url,
				);
			}
		}
		if ( null !== $only ) {
			usort( $out, static fn( array $a, array $b ): int => array_search( $a['slug'], $only, true ) <=> array_search( $b['slug'], $only, true ) );
		}
		return $out;
	}

	/** 한국어 경로를 그 언어의 공개 주소로(짝이 없거나 비공개면 그 언어 홈 → 한국어 같은 쪽). 앵커(#map)는 그대로. */
	public static function url( string $ko_path, string $lang ): string {
		$anchor = '';
		$hash   = strpos( $ko_path, '#' );
		if ( false !== $hash ) {
			$anchor  = substr( $ko_path, $hash );
			$ko_path = substr( $ko_path, 0, $hash );
		}
		$p   = self::pathFor( $ko_path, $lang );
		$url = null === $p ? null : self::publicUrl( $p );
		if ( null !== $url ) {
			return $url . $anchor;
		}
		$home = self::DEFAULT === $lang ? null : self::publicUrl( $lang );
		return $home ?? Nav::publicUrl( $ko_path . $anchor );
	}

	/** 외국어 slug → 그 언어의 공개 주소(비공개면 null). */
	public static function slugUrl( string $slug, string $lang ): ?string {
		return array_key_exists( $slug, self::PAGES ) ? self::publicUrl( self::langPath( $slug, $lang ) ) : null;
	}

	/** <html lang> — 외국어 쪽은 그 언어, 한국어 쪽은 ko-KR(관리 화면은 건드리지 않는다). */
	public static function languageAttributes( $output ) {
		if ( is_admin() || ! is_string( $output ) ) {
			return $output;
		}
		$tag = self::LANGS[ self::current() ]['tag'];
		$new = preg_replace( '/\blang="[^"]*"/', 'lang="' . esc_attr( $tag ) . '"', $output, 1, $count );
		return 1 === $count ? (string) $new : trim( $output . ' lang="' . esc_attr( $tag ) . '"' );
	}

	/** <link rel="alternate" hreflang> — 게시된 짝이 둘 이상일 때만, + x-default(한국어 짝이 있을 때 그 한국어 쪽). */
	public static function printAlternates(): void {
		$alts = self::alternates();
		if ( count( $alts ) < 2 ) {
			return;
		}
		foreach ( $alts as $lang => $url ) {
			printf( '<link rel="alternate" hreflang="%s" href="%s" />' . "\n", esc_attr( self::LANGS[ $lang ]['tag'] ), esc_url( $url ) );
		}
		if ( isset( $alts[ self::DEFAULT ] ) ) {
			printf( '<link rel="alternate" hreflang="x-default" href="%s" />' . "\n", esc_url( $alts[ self::DEFAULT ] ) );
		}
	}

	/** 외국어 쪽(언어 홈 아래 — 언어 홈 포함)은 템플릿 page-lang 을 먼저 찾는다. */
	public static function templateHierarchy( $templates ) {
		$templates = is_array( $templates ) ? $templates : array();
		if ( self::DEFAULT !== self::current() ) {
			array_unshift( $templates, self::TEMPLATE . '.php' );
		}
		return $templates;
	}

	/** og:locale — 외국어 쪽만 그 언어(한국어 쪽은 사이트 언어 그대로). */
	public static function ogLocale( $locale ) {
		$lang = self::current();
		return self::DEFAULT === $lang ? $locale : self::LANGS[ $lang ]['locale'];
	}

	/** Rank Math JSON-LD 의 inLanguage — 외국어 쪽만 그 언어로. */
	public static function jsonLdLanguage( $data ) {
		$lang = self::current();
		if ( self::DEFAULT === $lang || ! is_array( $data ) ) {
			return $data;
		}
		$tag  = self::LANGS[ $lang ]['tag'];
		$walk = static function ( $node ) use ( &$walk, $tag ) {
			if ( ! is_array( $node ) ) {
				return $node;
			}
			foreach ( $node as $k => $v ) {
				$node[ $k ] = 'inLanguage' === $k && is_string( $v ) ? $tag : $walk( $v );
			}
			return $node;
		};
		return $walk( $data );
	}

	/**
	 * 외국어 쪽 브레드크럼: [한국어 홈, 언어 홈, …] → [그 언어 "Home"(언어 홈), …]. 한국어 쪽은 그대로.
	 *
	 * @param mixed $crumbs Rank Math 항목 list<[0 => 이름, 1 => 주소, 'hide_in_schema' => bool]>.
	 */
	public static function crumbs( $crumbs ) {
		$lang = self::current();
		if ( self::DEFAULT === $lang || ! is_array( $crumbs ) || count( $crumbs ) < 2 ) {
			return $crumbs;
		}
		return array_merge(
			array(
				array(
					self::t( 'home', $lang ),
					self::url( '', $lang ),
					'hide_in_schema' => false,
				),
			),
			array_slice( $crumbs, 2 )
		);
	}

	/** 오늘 진료 바 글자(외국어 쪽 — 번역하지 못하면 한국어 그대로). */
	public static function hoursTodayText( $text ) {
		$lang = self::current();
		if ( self::DEFAULT === $lang || ! is_string( $text ) ) {
			return $text;
		}
		return Hours\Translate::today( $text, $lang ) ?? $text;
	}

	/**
	 * 진료시간 표 HTML(외국어 쪽) — 한국어 표와 같은 줄(Render::tableRows·upcomingRows)을 줄마다 번역. 번역하지 못한 칸은 한국어 그대로(lang="ko").
	 *
	 * @param mixed $html null(한국어 표를 그대로 쓴다) 또는 앞 필터가 만든 HTML.
	 */
	public static function hoursTableHtml( $html, $config, $today ) {
		$lang = self::current();
		if ( self::DEFAULT === $lang || ! is_array( $config ) || ! $today instanceof \DateTimeImmutable ) {
			return $html;
		}
		$rows     = static function ( array $rows ) use ( $lang ): string {
			$out = '';
			foreach ( $rows as [ $label, $value ] ) {
				$out .= sprintf( '<tr><th scope="row">%s</th><td>%s</td></tr>', self::cell( Hours\Translate::label( $label, $lang ), $label ), self::cell( Hours\Translate::value( $value, $lang ), $value ) );
			}
			return $out;
		};
		$table    = '<table class="iwell-hours-table"><caption>' . esc_html( Hours\Translate::caption( 'hours', $lang ) ) . '</caption><tbody>' . $rows( Hours\Render::tableRows( $config ) ) . '</tbody></table>';
		$upcoming = Hours\Render::upcomingRows( $config, $today );
		if ( array() !== $upcoming ) {
			$table .= '<table class="iwell-hours-exceptions"><caption>' . esc_html( Hours\Translate::caption( 'exceptions', $lang ) ) . '</caption><tbody>' . $rows( $upcoming ) . '</tbody></table>';
		}
		return $table;
	}

	/** 번역된 칸 또는 한국어 원문(lang="ko-KR" 표시). */
	public static function cell( ?string $translated, string $ko ): string {
		return null !== $translated ? esc_html( $translated ) : '<span lang="ko-KR">' . esc_html( $ko ) . '</span>';
	}

	/** 전화 국제 표기 — 병원 기본 정보(config/clinic.php telephone)에서 계산: '031-322-7799' → '+82-31-322-7799'. */
	public static function phoneIntl(): string {
		$tel = class_exists( Schema\Graph::class ) ? (string) ( Schema\Graph::clinicInfo()['telephone'] ?? '' ) : '';
		return '' === $tel ? '' : '+82-' . ltrim( $tel, '0' );
	}

	/**
	 * 머리·바닥글 UI 글자 — 키 → 언어별 글. 한국어 쪽은 테마가 원래 글자를 그대로 쓰므로 여기에 없다.
	 * 병원·원장 이름은 대표 결정(2026-11-26) 영문 표기 그대로(중국어·베트남어 쪽도), 주소는 도로명주소 안내시스템(juso.go.kr) 영문 표기
	 * "113 Pogok-ro, Pogok-eup, Cheoin-gu, Yongin-si, Gyeonggi-do"(2026-11-26 조회) + 2층.
	 */
	private const UI = array(
		'en' => array(
			'name'             => 'Samsung I Well Pediatrics',
			'menu'             => 'Main menu',
			'menu_open'        => 'Open menu',
			'menu_close'       => 'Close menu',
			'home'             => 'Home',
			'call'             => 'Call',
			'hours'            => 'Hours',
			'directions'       => 'Directions',
			'top'              => 'Top',
			'quick'            => 'Quick links',
			'lang'             => 'Language',
			'pending'          => 'coming soon',
			'address'          => 'Address',
			'phone'            => 'Phone',
			'parking'          => 'Parking',
			'parking_text'     => 'Large parking lot behind the building.',
			'address_text'     => '2F, 113 Pogok-ro, Pogok-eup, Cheoin-gu, Yongin-si, Gyeonggi-do, Republic of Korea',
			'map_naver'        => 'Open in Naver Map',
			'map_google'       => 'Open in Google Maps',
			'korean_site'      => 'Korean website (한국어)',
			'privacy'          => 'Privacy policy (in Korean)',
			'translation_note' => 'This page is a translation of our Korean website, provided for convenience. If anything differs, the Korean page is correct.',
			'korean_page'      => 'View this page in Korean',
			'korean_home'      => 'Go to our Korean website',
			'legal_name'       => 'Registered name',
			'pages'            => 'Pages',
		),
		'vi' => array(
			'name'             => 'Samsung I Well Pediatrics',
			'menu'             => 'Menu chính',
			'menu_open'        => 'Mở menu',
			'menu_close'       => 'Đóng menu',
			'home'             => 'Trang chủ',
			'call'             => 'Gọi',
			'hours'            => 'Giờ khám',
			'directions'       => 'Đường đi',
			'top'              => 'Lên đầu',
			'quick'            => 'Liên kết nhanh',
			'lang'             => 'Ngôn ngữ',
			'pending'          => 'sắp có',
			'address'          => 'Địa chỉ',
			'phone'            => 'Điện thoại',
			'parking'          => 'Bãi đỗ xe',
			'parking_text'     => 'Bãi đỗ xe lớn phía sau tòa nhà.',
			'address_text'     => 'Tầng 2, 113 Pogok-ro, Pogok-eup, Cheoin-gu, Yongin-si, Gyeonggi-do, Hàn Quốc',
			'map_naver'        => 'Mở trên Naver Map',
			'map_google'       => 'Mở trên Google Maps',
			'korean_site'      => 'Trang web tiếng Hàn (한국어)',
			'privacy'          => 'Chính sách bảo mật (tiếng Hàn)',
			'translation_note' => 'Trang này là bản dịch từ trang web tiếng Hàn của chúng tôi để tiện tham khảo. Nếu có điểm khác nhau, nội dung trên trang tiếng Hàn là chính xác.',
			'korean_page'      => 'Xem trang này bằng tiếng Hàn',
			'korean_home'      => 'Xem trang web tiếng Hàn',
			'legal_name'       => 'Tên đăng ký',
			'pages'            => 'Các trang',
		),
		'zh' => array(
			'name'             => 'Samsung I Well Pediatrics',
			'menu'             => '主菜单',
			'menu_open'        => '打开菜单',
			'menu_close'       => '关闭菜单',
			'home'             => '首页',
			'call'             => '致电',
			'hours'            => '门诊时间',
			'directions'       => '交通指南',
			'top'              => '回到顶部',
			'quick'            => '快速链接',
			'lang'             => '语言',
			'pending'          => '即将推出',
			'address'          => '地址',
			'phone'            => '电话',
			'parking'          => '停车',
			'parking_text'     => '大楼后方设有大型停车场。',
			'address_text'     => '2F, 113 Pogok-ro, Pogok-eup, Cheoin-gu, Yongin-si, Gyeonggi-do, Republic of Korea（韩国）',
			'map_naver'        => '在 Naver 地图中打开',
			'map_google'       => '在 Google 地图中打开',
			'korean_site'      => '韩语网站（한국어）',
			'privacy'          => '隐私政策（韩语）',
			'translation_note' => '本页面是我们韩语网站的译文，仅供参考。如有不一致，以韩语页面为准。',
			'korean_page'      => '查看本页韩语版',
			'korean_home'      => '查看韩语网站',
			'legal_name'       => '注册名称',
			'pages'            => '页面',
		),
	);

	/** UI 글자(없는 언어·키는 영어 → 키 그대로). */
	public static function t( string $key, ?string $lang = null ): string {
		$lang ??= self::current();
		return self::UI[ $lang ][ $key ] ?? self::UI['en'][ $key ] ?? $key;
	}

	/**
	 * llms.txt 외국어 줄(Crawl) — 게시된 외국어 쪽: "## Other languages" 아래 언어마다 "- {이름} ({tag}): 제목 — 주소".
	 *
	 * @return list<string>
	 */
	public static function llmsLines(): array {
		$lines = array();
		foreach ( self::foreign() as $lang ) {
			if ( ! self::isOpen( $lang ) ) {
				continue;
			}
			$lines[] = sprintf( '- %s (%s): %s — %s', self::LANGS[ $lang ]['name'], self::LANGS[ $lang ]['tag'], Nav::title( $lang ), (string) self::publicUrl( $lang ) );
			foreach ( self::menu( $lang ) as $page ) {
				$lines[] = sprintf( '  - %s — %s', $page['title'], $page['url'] );
			}
		}
		return $lines;
	}
}
