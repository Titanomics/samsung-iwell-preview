<?php
/**
 * robots.txt·llms.txt(Task 9 — 설계서 §8 LLMO, 계획 Task 9 Interfaces).
 *
 * robots.txt: 코어 robots_txt 필터, 우선순위 100(Rank Math robots 편집기 10·사이트맵 줄 0 보다 늦게 — 그 결과를 덮는다).
 *   = 맨 위 '# llms.txt: {home}/llms.txt'(표준 지시어가 아니라 주석 — 대표 결정 2026-11-13, 코디네이터 ① a)
 *   + config/robots.txt('#' 주석 줄 뺌 — 명시 허용 봇 11개·관리자·상담 글 보기·쓰기 차단)
 *   + 'Sitemap: {home}/sitemap_index.xml'·'Sitemap: {home}/feed/'. 사이트가 검색 엔진 차단(blog_public 0 — 코어가 bool false 로 넘김)이면
 *   들어온 값을 그대로 둔다(Task 9 수정 1 C02). 공개 때 blog_public=1 이어야 11봇 허용이 나간다(Task 14 운영 입력).
 * llms.txt: 재작성 ^llms\.txt$ → iwell_llms=1(Routes::addRules), parse_request 에서 바로 낸다(redirect_canonical·Rank Math llms 모듈보다 먼저).
 *   text/plain; charset=utf-8. 내용 = 병원 이름·정의 문장(Graph::clinicSentence — 홈과 같은 원천)·갱신일·인용 안내(코디네이터 ① b)
 *   · 병원 정보(주소·전화 — Graph::clinicInfo = config/clinic.php) · 진료시간(Store::config() → Render::tableRows·upcomingRows — 화면 표와 같은 문구, 일요일 진료 원장 줄 포함)
 *   · 메뉴(Nav::tree() 의 공개 노드만 — 게시 페이지 제목+주소, 열린 게시판 목록) · 바닥글 페이지(Nav::footerPages). 비밀번호 페이지는 뺀다(C03).
 *   [미확인]·근거 확인 대상 문구는 넣지 않는다(이 원천들에 없다). 일요일 진료 원장은 대표 결정(2026-11-25)으로 진료시간 설정 값(sundayDoctor)이 되어
 *   위 진료시간 줄(Render::tableRows — '매주 일요일 {원장} · 매월 마지막주 일요일 휴진', 대표 2026-11-26)에 들어간다. 검사별 시간·금식·금액은 원고 쪽(검사 안내·비급여 진료비) 정보라 여기서 따로 쓰지 않는다.
 * 갱신일 = 게시 고정 페이지·게시 공지·칼럼의 가장 늦은 수정 시각과 진료시간 설정 저장 시각(HOURS_CHANGED) 중 늦은 것, KST 날짜.
 */

namespace Iwell\Core;

use DateTimeImmutable;
use DateTimeZone;
use Iwell\Core\Hours\Render;
use Iwell\Core\Hours\Rules;
use Iwell\Core\Hours\Store;
use Iwell\Core\Schema\Graph;
use WP;

defined( 'ABSPATH' ) || exit;

final class Crawl {
	public const QUERY_VAR = 'iwell_llms';

	/** 진료시간 설정(옵션 iwell_hours)을 마지막으로 바꾼 시각(유닉스 초). */
	public const HOURS_CHANGED = 'iwell_hours_changed_at';

	public const CITATION = '인용할 때는 해당 페이지 주소를 함께 적어 주세요.';

	public static function register(): void {
		add_filter( 'robots_txt', array( self::class, 'robots' ), 100, 2 );
		add_action( 'parse_request', array( self::class, 'serveLlms' ), 0 );
		add_action( 'add_option_' . Store::OPTION, array( self::class, 'hoursChanged' ) );
		add_action( 'update_option_' . Store::OPTION, array( self::class, 'hoursChanged' ) );
		add_action( 'delete_option_' . Store::OPTION, array( self::class, 'hoursChanged' ) );
		// 통합 2(코디네이터 승인 A): Rank Math XML·HTML 사이트맵 캐시를 끈다. Rank Math 1.0.282 는 저장 때 캐시를 비우는 Cache_Watcher 를
		// 관리 화면·크론 요청에서만 만든다(includes/modules/sitemap/class-sitemap.php:47) → REST 저장(칼럼 자동 등록 columns/import·편집기·
		// 그 저장 안의 허브 자동 공개)은 캐시를 비우지 않아 새 글·허브가 사이트맵에 늦게 나온다. 판정 = class-sitemap.php:273 이 필터 하나.
		// 사이트가 작아(고정 페이지 ~70·글 수백) 요청마다 만들어도 된다 — 생성 시간은 runbook §4 운영 입력(카페24 에서 다시 잼).
		add_filter( 'rank_math/sitemap/enable_caching', '__return_false' );
	}

	/**
	 * @param mixed $output 지금까지의 robots.txt.
	 * @param mixed $public 코어 do_robots() 는 (bool) blog_public 을 넘긴다(WP 7.1 functions.php). 거짓 값(false·0·'0'·''·null)이면
	 *                      관리 화면 '검색 엔진 차단'이므로 들어온 출력을 그대로 돌려준다(봇 허용 그룹으로 바꾸지 않음 — Task 9 수정 1 C02).
	 */
	public static function robots( $output, $public ): string {
		if ( ! $public ) {
			return (string) $output;
		}
		$raw   = (string) file_get_contents( dirname( __DIR__ ) . '/config/robots.txt' ); // phpcs:ignore WordPress.WP.AlternativeFunctions -- 플러그인 안 설정 파일.
		$lines = array_filter( preg_split( '/\r\n|\r|\n/', $raw ), static fn( string $l ): bool => ! str_starts_with( ltrim( $l ), '#' ) );
		$body  = trim( preg_replace( "/\n{3,}/", "\n\n", implode( "\n", $lines ) ) );
		// 다음 웹마스터도구 인증 줄(설정 → iwell-core 설정, DaumVerify — 형식 검사로 '#' 주석 한 줄만, 비우면 없음 — 2026-11-26).
		$daum = DaumVerify::line();
		return ( '' === $daum ? '' : $daum . "\n" ) . '# llms.txt: ' . home_url( '/llms.txt' ) . "\n\n" . $body . "\n\nSitemap: " . home_url( '/sitemap_index.xml' ) . "\nSitemap: " . home_url( '/feed/' ) . "\n";
	}

	/** parse_request(0): /llms.txt 면 내고 끝. */
	public static function serveLlms( $wp ): void {
		if ( ! $wp instanceof WP ) {
			return;
		}
		if ( empty( $wp->query_vars[ self::QUERY_VAR ] ) && 'llms.txt' !== (string) $wp->request ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo self::llms(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 일반 글(text/plain).
		exit;
	}

	public static function hoursChanged(): void {
		update_option( self::HOURS_CHANGED, time(), false );
	}

	/** llms.txt 본문(Markdown — llmstxt.org 형식: H1 이름 → 요약 인용 → 섹션별 링크 목록). */
	public static function llms(): string {
		$info   = Graph::clinicInfo();
		$config = Store::config();
		$out    = array( '# ' . $info['name'], '' );
		$define = Graph::clinicSentence( $info );
		if ( '' !== $define ) {
			array_push( $out, '> ' . $define, '' );
		}
		array_push( $out, '갱신 ' . self::updatedAt(), self::CITATION, '' );

		array_push( $out, '## 병원 정보', '', '- 주소: ' . $info['addressText'], '- 전화: ' . $info['telephone'], '- 홈페이지: ' . home_url( '/' ), '' );

		$out[] = '## 진료시간';
		$out[] = '';
		foreach ( Render::tableRows( $config ) as list( $label, $text ) ) {
			$out[] = "- $label: $text";
		}
		$upcoming = Render::upcomingRows( $config, Rules::today() );
		if ( array() !== $upcoming ) {
			array_push( $out, '', '### 날짜별 변경(오늘 이후)', '' );
			foreach ( $upcoming as list( $label, $text ) ) {
				$out[] = "- $label: $text";
			}
		}
		$out[] = '';

		$locked = self::lockedPages();
		foreach ( Nav::tree() as $hub ) {
			$items = array();
			$show  = $hub['public'] && ! self::isLocked( $hub, $locked );
			if ( $show ) {
				$items[] = self::item( $hub, 0 );
			}
			foreach ( self::publicNodes( $hub['children'], $show ? 1 : 0, $locked ) as $line ) {
				$items[] = $line;
			}
			if ( array() === $items ) {
				continue;
			}
			array_push( $out, '## ' . self::text( $hub['title'] ), '', ...$items );
			$out[] = '';
		}

		$footer = array_values( array_filter( Nav::footerPages(), static fn( array $page ): bool => ! self::isLocked( $page, $locked ) ) );
		if ( array() !== $footer ) {
			array_push( $out, '## 그 밖의 안내', '' );
			foreach ( $footer as $page ) {
				$out[] = self::item( $page, 0 );
			}
			$out[] = '';
		}

		// 외국어 쪽(2026-11-26 — 영어·베트남어·중국어 간체, 한국어 쪽의 번역 — 게시된 쪽만).
		$other = I18n::llmsLines();
		if ( array() !== $other ) {
			array_push( $out, '## 다른 언어(Other languages — 한국어 쪽의 번역, 한국어가 정본)', '', ...$other );
			$out[] = '';
		}
		return implode( "\n", $out );
	}

	/**
	 * @param array<int, true> $locked 비밀번호 걸린 고정 페이지 ID.
	 * @return list<string> 공개 노드만(재귀, 들여쓰기 2칸). 비밀번호 페이지는 그 줄만 빼고 그 아래 공개 하위는 같은 깊이로 남긴다(허브가 비공개일 때와 같다).
	 */
	private static function publicNodes( array $nodes, int $depth, array $locked ): array {
		$out = array();
		foreach ( $nodes as $node ) {
			if ( empty( $node['public'] ) ) {
				continue;
			}
			$show = ! self::isLocked( $node, $locked );
			if ( $show ) {
				$out[] = self::item( $node, $depth );
			}
			foreach ( self::publicNodes( $node['children'] ?? array(), $show ? $depth + 1 : $depth, $locked ) as $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/**
	 * 비밀번호가 걸린(post_password <> '') 게시 고정 페이지 ID — 공개 근거가 아니다(Task 9 수정 1 C03). 머리 메뉴(Nav)의 표시는 Task 7 범위라 그대로 두고
	 * llms 링크에서만 뺀다.
	 *
	 * @return array<int, true>
	 */
	private static function lockedPages(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- 읽기 1건(llms 요청마다 — 고정 페이지 몇십 개).
		$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_password <> ''" );
		return array_fill_keys( array_map( 'intval', (array) $ids ), true );
	}

	/** 노드가 비밀번호 페이지를 가리키나(게시판 목록 고정 항목은 페이지가 아니다 — 열림은 Routes::boardOpen). */
	private static function isLocked( array $node, array $locked ): bool {
		$id = (int) ( $node['id'] ?? 0 );
		return $id > 0 && isset( $locked[ $id ] ) && ! in_array( (string) ( $node['path'] ?? '' ), Routes::BOARDS, true );
	}

	private static function item( array $node, int $depth ): string {
		return str_repeat( '  ', $depth ) . '- [' . self::text( $node['title'] ) . '](' . $node['url'] . ')';
	}

	/** 한 줄 글자(줄바꿈 없음, 링크 글자의 [ ] 이스케이프). */
	private static function text( string $s ): string {
		$s = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $s ) ) );
		return str_replace( array( '[', ']' ), array( '\\[', '\\]' ), $s );
	}

	/** 갱신일(KST 'Y-m-d'). */
	public static function updatedAt(): string {
		global $wpdb;
		$boards = "'" . implode( "','", Routes::BOARDS ) . "'";
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- 상수 목록만, 읽기 2건.
		$pages = $wpdb->get_var( $wpdb->prepare( "SELECT MAX(post_modified_gmt) FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_mime_type NOT LIKE %s", '%-revision' ) );
		$posts = $wpdb->get_var(
			"SELECT MAX(p.post_modified_gmt) FROM {$wpdb->posts} p
			INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'category'
			INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id AND t.slug IN ($boards)
			WHERE p.post_type = 'post' AND p.post_status = 'publish'"
		);
		// phpcs:enable
		$times = array( (int) get_option( self::HOURS_CHANGED, 0 ) );
		foreach ( array( $pages, $posts ) as $gmt ) {
			if ( is_string( $gmt ) && '' !== $gmt && '0000-00-00 00:00:00' !== $gmt ) {
				$times[] = (int) strtotime( $gmt . ' UTC' );
			}
		}
		$max = max( $times );
		$tz  = new DateTimeZone( Rules::TIMEZONE );
		return ( $max > 0 ? ( new DateTimeImmutable( '@' . $max ) )->setTimezone( $tz ) : new DateTimeImmutable( 'now', $tz ) )->format( 'Y-m-d' );
	}
}
