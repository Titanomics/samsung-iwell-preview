<?php
/**
 * 외국어 쪽의 "한국어 원천" 블록(대표 결정 2026-11-26 — 가격·일정 값은 한국어와 같은 원천에서, 외국어 원고에 숫자를 따로 적지 않는다).
 *
 *  - iwell/source-table {path, head, filter}: 게시된 한국어 쪽(path)의 표 가운데 첫 머리 칸이 head 인 표를 읽어, 칸 글자만 이 언어로 옮겨 그린다.
 *    금액·나이·횟수의 숫자는 한국어 표 글자에서 그대로 가져온다(형식만 — '60,000원' → 'KRW 60,000'). filter 를 주면 첫 칸이 그 값인 줄만,
 *    첫 칸은 빼고 그린다(예: 비급여 표에서 '예방접종' 줄만). 한국어 쪽이 게시되지 않았거나 표가 없으면 아무것도 내지 않는다.
 *    낱말 표(TERMS)에 없는 칸은 한국어 원문 그대로(lang="ko-KR") — 직원이 한국어 표에 새 항목을 넣으면 외국어 표에도 곧바로(한국어로) 보인다.
 *  - iwell/hours-line {which: "sunday"}: 진료시간 설정의 일요일 진료 원장 줄(Render::sundayDoctorRow)을 이 언어로(의료진 쪽).
 * 한국어 쪽(언어 ko)에서는 두 블록 모두 아무것도 내지 않는다(외국어 원고 전용).
 */

namespace Iwell\Core\I18n;

use DOMDocument;
use DOMXPath;
use Iwell\Core\Hours\Store;
use Iwell\Core\Hours\Translate;
use Iwell\Core\I18n;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Cells {
	/**
	 * 칸 낱말 표 — 한국어 칸 글자 → [en, vi, zh]. agy Gemini 4 Neon 교차 검수(2026-11-26) 지적 반영. 상표명은 제조사·허가 영문 표기(2026-11-27 확인): Prevenar 13(화이자)·Vaxneuvance(MSD)·SKYZoster(SK바이오사이언스 제품 쪽)·Shingrix·Menveo(GSK — 의약품 정보 health.kr 영문명)·Imojev(사노피 — health.kr)·BARYCELA(GC녹십자 배리셀라주 — WHO 사전적격성 등록명 BARYCELA inj.). '바리셀라코박스'는 공식 영문 표기를 찾지 못해 일반명(varicella vaccine)으로 쓴다(대표 결정: 확인 안 되는 이름은 일반명). 한국어 원천: content/pages/guide__fees.md·guide__certificates.md·checkup__vaccination-schedule.md·
	 * checkup__infant-checkup.md 의 표. 상표명은 제조사 영문 표기(Prevenar 13·Vaxneuvance·SKYZoster·Shingrix·Imojev·Menveo).
	 */
	private const TERMS = array(
		// 표 머리
		'구분'                                 => array( 'Category', 'Loại', '类别' ),
		'항목'                                 => array( 'Item', 'Hạng mục', '项目' ),
		'금액'                                 => array( 'Fee', 'Chi phí', '费用' ),
		'증명서'                                => array( 'Document', 'Giấy tờ', '证明文件' ),
		'대상 감염병'                             => array( 'Disease', 'Bệnh', '目标疾病' ),
		'횟수'                                 => array( 'Doses', 'Số mũi', '剂次' ),
		'접종 시기'                              => array( 'When', 'Thời điểm tiêm', '接种时间' ),
		'차수'                                 => array( 'Check-up', 'Lần khám', '次数' ),
		'시기'                                 => array( 'Age', 'Độ tuổi', '时间' ),
		'주요 건강교육'                            => array( 'Main health education', 'Nội dung giáo dục sức khỏe chính', '主要健康教育' ),
		'함께 하는 것'                            => array( 'Also included', 'Thực hiện kèm theo', '同时进行' ),
		// 비급여(구분·항목)
		'예방접종'                               => array( 'Vaccination', 'Tiêm chủng', '疫苗接种' ),
		'검사'                                 => array( 'Test', 'Xét nghiệm', '检查' ),
		'A형간염(2회 접종)'                        => array( 'Hepatitis A (2 doses)', 'Viêm gan A (2 mũi)', '甲型肝炎（2剂）' ),
		'폐렴구균(프리베나13)'                      => array( 'Pneumococcal (Prevenar 13)', 'Phế cầu (Prevenar 13)', '肺炎球菌（Prevenar 13）' ),
		'폐렴구균(박스뉴반스 15가)'                   => array( 'Pneumococcal (Vaxneuvance, 15-valent)', 'Phế cầu (Vaxneuvance, 15 chủng)', '肺炎球菌（Vaxneuvance，15价）' ),
		'대상포진(스카이조스터, 1회 접종)'               => array( 'Shingles (SKYZoster, 1 dose)', 'Zona thần kinh (SKYZoster, 1 mũi)', '带状疱疹（SKYZoster，1剂）' ),
		'대상포진(싱그릭스, 2회 접종)'                 => array( 'Shingles (Shingrix, 2 doses)', 'Zona thần kinh (Shingrix, 2 mũi)', '带状疱疹（Shingrix，2剂）' ),
		'파상풍·디프테리아·백일해(Tdap)'               => array( 'Tetanus, diphtheria, pertussis (Tdap)', 'Uốn ván, bạch hầu, ho gà (Tdap)', '破伤风、白喉、百日咳（Tdap）' ),
		'홍역·볼거리·풍진(MMR)'                     => array( 'Measles, mumps, rubella (MMR)', 'Sởi, quai bị, rubella (MMR)', '麻疹、腮腺炎、风疹（MMR）' ),
		'일본뇌염(이모젭)'                          => array( 'Japanese encephalitis (Imojev)', 'Viêm não Nhật Bản (Imojev)', '日本脑炎/乙脑（Imojev）' ),
		'수두(바리셀라코박스/배리셀라)'                  => array( 'Chickenpox (varicella vaccine / BARYCELA)', 'Thủy đậu (vắc-xin thủy đậu / BARYCELA)', '水痘（水痘疫苗 / BARYCELA）' ),
		'수막구균(멘비오)'                          => array( 'Meningococcal (Menveo)', 'Não mô cầu (Menveo)', '脑膜炎球菌（Menveo）' ),
		'독감(해당 연도 백신)'                       => array( 'Flu (vaccine for the current season)', 'Cúm (vắc-xin của mùa hiện tại)', '流感（当季疫苗）' ),
		'성장검사+판독료'                           => array( 'Growth test + reading fee', 'Kiểm tra tăng trưởng + phí đọc kết quả', '生长检查＋判读费' ),
		'알러지검사(MAST)'                        => array( 'Allergy test (MAST)', 'Xét nghiệm dị ứng (MAST)', '过敏原检测（MAST）' ),
		'비타민 D'                              => array( 'Vitamin D', 'Vitamin D', '维生素D' ),
		'잠복결핵검사'                             => array( 'Latent tuberculosis test', 'Xét nghiệm lao tiềm ẩn', '潜伏结核检查' ),
		'독감+코로나검사'                           => array( 'Flu + COVID-19 test', 'Xét nghiệm cúm + COVID-19', '流感＋新冠检测' ),
		'성조숙증'                               => array( 'Precocious puberty', 'Dậy thì sớm', '性早熟' ),
		'해당 연도 정책에 따라 변동'                    => array( "Varies with each year's policy", 'Thay đổi theo chính sách từng năm', '根据当年政策而定' ),
		'접수에서 안내'                            => array( 'Ask at reception', 'Vui lòng hỏi tại quầy tiếp nhận', '请咨询前台' ),
		// 제증명
		'진단서'                                => array( 'Medical certificate (diagnosis)', 'Giấy chẩn đoán', '诊断书' ),
		'소견서'                                => array( "Doctor's opinion letter", 'Giấy ý kiến của bác sĩ', '医生意见书' ),
		'진료확인서(질병코드 있음)'                     => array( 'Certificate of visit (with diagnosis code)', 'Giấy xác nhận khám bệnh (có mã bệnh)', '就诊确认书（含疾病代码）' ),
		'진료확인서(질병코드 없음)'                     => array( 'Certificate of visit (without diagnosis code)', 'Giấy xác nhận khám bệnh (không có mã bệnh)', '就诊确认书（不含疾病代码）' ),
		'독감·코로나 확인서'                         => array( 'Flu / COVID-19 confirmation', 'Giấy xác nhận cúm / COVID-19', '流感／新冠确认书' ),
		'진료기록(차트) 사본 1~5매(1매당)'              => array( 'Copy of medical records, pages 1–5 (per page)', 'Bản sao hồ sơ bệnh án, trang 1–5 (mỗi trang)', '病历复印件第1–5页（每页）' ),
		'진료기록(차트) 사본 6매부터(1매당)'              => array( 'Copy of medical records, from page 6 (per page)', 'Bản sao hồ sơ bệnh án, từ trang 6 (mỗi trang)', '病历复印件第6页起（每页）' ),
		// 표준 예방접종(대상 감염병)
		'결핵'                                 => array( 'Tuberculosis', 'Lao', '结核病' ),
		'B형간염'                               => array( 'Hepatitis B', 'Viêm gan B', '乙型肝炎' ),
		'디프테리아·파상풍·백일해'                      => array( 'Diphtheria, tetanus, pertussis', 'Bạch hầu, uốn ván, ho gà', '白喉、破伤风、百日咳' ),
		'폴리오'                                => array( 'Polio', 'Bại liệt', '脊髓灰质炎' ),
		'b형헤모필루스인플루엔자'                       => array( 'Haemophilus influenzae type b (Hib)', 'Haemophilus influenzae týp b (Hib)', 'b型流感嗜血杆菌（Hib）' ),
		'폐렴구균 감염증'                           => array( 'Pneumococcal disease', 'Bệnh do phế cầu', '肺炎球菌感染' ),
		'폐렴구균 감염증(고위험군)'                     => array( 'Pneumococcal disease (high-risk groups)', 'Bệnh do phế cầu (nhóm nguy cơ cao)', '肺炎球菌感染（高危人群）' ),
		'로타바이러스 감염증(RV1)'                    => array( 'Rotavirus (RV1)', 'Rotavirus (RV1)', '轮状病毒感染（RV1）' ),
		'로타바이러스 감염증(RV5)'                    => array( 'Rotavirus (RV5)', 'Rotavirus (RV5)', '轮状病毒感染（RV5）' ),
		'홍역·유행성이하선염·풍진'                      => array( 'Measles, mumps, rubella', 'Sởi, quai bị, rubella', '麻疹、流行性腮腺炎、风疹' ),
		'수두'                                 => array( 'Chickenpox (varicella)', 'Thủy đậu', '水痘' ),
		'A형간염'                               => array( 'Hepatitis A', 'Viêm gan A', '甲型肝炎' ),
		'일본뇌염(불활성화 백신)'                      => array( 'Japanese encephalitis (inactivated vaccine)', 'Viêm não Nhật Bản (vắc-xin bất hoạt)', '日本脑炎/乙脑（灭活疫苗）' ),
		'일본뇌염(약독화 생백신)'                      => array( 'Japanese encephalitis (live attenuated vaccine)', 'Viêm não Nhật Bản (vắc-xin sống giảm độc lực)', '日本脑炎/乙脑（减毒活疫苗）' ),
		'사람유두종바이러스감염증'                       => array( 'Human papillomavirus (HPV)', 'Vi-rút u nhú ở người (HPV)', '人乳头瘤病毒（HPV）感染' ),
		'인플루엔자'                              => array( 'Influenza', 'Cúm', '流感' ),
		'매년'                                 => array( 'Every year', 'Hằng năm', '每年' ),
		'4주 이내'                              => array( 'Within 4 weeks', 'Trong vòng 4 tuần', '4周内' ),
		'출생 시'                               => array( 'At birth', 'Khi sinh', '出生时' ),
		'고위험군에 한하여 접종(세부 일정은 진료 때 확인)'       => array( 'high-risk groups only (schedule confirmed at the visit)', 'chỉ dành cho nhóm nguy cơ cao (lịch cụ thể xác nhận khi khám)', '仅限高危人群（具体日程在就诊时确认）' ),
		// 영유아 건강검진(주요 건강교육·함께 하는 것)
		'영양(모유수유)'                           => array( 'Nutrition (breastfeeding)', 'Dinh dưỡng (nuôi con bằng sữa mẹ)', '营养（母乳喂养）' ),
		'수면(영아돌연사증후군 예방)'                    => array( 'Sleep (preventing sudden infant death syndrome)', 'Giấc ngủ (phòng ngừa hội chứng đột tử ở trẻ sơ sinh)', '睡眠（预防婴儿猝死综合征）' ),
		'안전사고 예방'                            => array( 'Injury prevention', 'Phòng ngừa tai nạn', '预防意外伤害' ),
		'영양'                                 => array( 'Nutrition', 'Dinh dưỡng', '营养' ),
		'수면'                                 => array( 'Sleep', 'Giấc ngủ', '睡眠' ),
		'전자미디어 노출'                           => array( 'Screen time', 'Tiếp xúc thiết bị điện tử', '电子屏幕使用' ),
		'구강(치아 발육)'                          => array( 'Oral health (tooth development)', 'Răng miệng (sự phát triển của răng)', '口腔（牙齿发育）' ),
		'정서 및 사회성'                           => array( 'Emotional and social development', 'Cảm xúc và kỹ năng xã hội', '情绪与社会性' ),
		'대소변 가리기'                            => array( 'Toilet training', 'Tập đi vệ sinh', '如厕训练' ),
		'개인위생'                               => array( 'Personal hygiene', 'Vệ sinh cá nhân', '个人卫生' ),
		'취학 전 준비'                            => array( 'Getting ready for school', 'Chuẩn bị trước khi đi học', '入学准备' ),
		'발달평가 시작'                            => array( 'Developmental screening begins', 'Bắt đầu đánh giá phát triển', '开始发育评估' ),
		'발달평가'                               => array( 'Developmental screening', 'Đánh giá phát triển', '发育评估' ),
		'체질량지수 측정 시작'                        => array( 'BMI measurement begins', 'Bắt đầu đo chỉ số khối cơ thể (BMI)', '开始测量体质指数（BMI）' ),
		'가정에서 귓속말 검사'                        => array( 'Whisper hearing test at home', 'Kiểm tra nghe tiếng thì thầm tại nhà', '在家进行耳语听力测试' ),
		'예방접종 확인'                            => array( 'Vaccination record check', 'Kiểm tra hồ sơ tiêm chủng', '核查疫苗接种记录' ),
		'-'                                  => array( '–', '–', '–' ),
	);

	private const COL = array(
		'en' => 0,
		'vi' => 1,
		'zh' => 2,
	);

	public static function registerBlocks(): void {
		register_block_type(
			'iwell/source-table',
			array(
				'api_version'     => 3,
				'title'           => '외국어 쪽 — 한국어 원천 표',
				'description'     => '게시된 한국어 쪽의 표(가격·일정)를 이 언어로 — 숫자는 한국어 표 그대로.',
				'category'        => 'widgets',
				'attributes'      => array(
					'path'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'head'   => array(
						'type'    => 'string',
						'default' => '',
					),
					'filter' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
				'supports'        => array( 'html' => false ),
				'render_callback' => static fn( $attrs = array() ): string => self::sourceTable( (array) $attrs, I18n::current() ),
			)
		);
		register_block_type(
			'iwell/hours-line',
			array(
				'api_version'     => 3,
				'title'           => '외국어 쪽 — 진료시간 한 줄',
				'description'     => '진료시간 설정의 일요일 진료 원장 줄을 이 언어로.',
				'category'        => 'widgets',
				'attributes'      => array(
					'which' => array(
						'type'    => 'string',
						'default' => 'sunday',
					),
				),
				'supports'        => array( 'html' => false ),
				'render_callback' => static fn( $attrs = array() ): string => self::hoursLine( (array) $attrs, I18n::current() ),
			)
		);
	}

	/** 일요일 진료 원장 줄(번역 못 하면 한국어 원문). 한국어 쪽·줄 없음 → ''. */
	public static function hoursLine( array $attrs, string $lang ): string {
		if ( I18n::DEFAULT === $lang || 'sunday' !== ( $attrs['which'] ?? 'sunday' ) ) {
			return '';
		}
		$row = \Iwell\Core\Hours\Render::sundayDoctorRow( Store::config() );
		if ( null === $row ) {
			return '';
		}
		return '<p class="iwell-hours-line">' . I18n::cell( Translate::value( $row[1], $lang ), $row[1] ) . '</p>';
	}

	/** 블록 iwell/source-table 렌더. */
	public static function sourceTable( array $attrs, string $lang ): string {
		if ( ! isset( self::COL[ $lang ] ) ) {
			return '';
		}
		$path   = trim( (string) ( $attrs['path'] ?? '' ), '/' );
		$head   = (string) ( $attrs['head'] ?? '' );
		$filter = (string) ( $attrs['filter'] ?? '' );
		$post   = '' === $path ? null : self::published( $path );
		$table  = null === $post ? null : self::findTable( (string) $post->post_content, $head );
		if ( null === $table ) {
			return self::pending( $lang );
		}
		[ $th, $rows ] = $table;
		if ( '' !== $filter ) {
			$rows = array_values( array_map( static fn( array $r ): array => array_slice( $r, 1 ), array_filter( $rows, static fn( array $r ): bool => ( $r[0] ?? '' ) === $filter ) ) );
			$th   = array_slice( $th, 1 );
			if ( array() === $rows ) {
				return self::pending( $lang );
			}
		}
		$html = '<figure class="wp-block-table iwell-table iwell-source-table"><table>';
		if ( array() !== $th ) {
			$html .= '<thead><tr>' . implode( '', array_map( static fn( string $c ): string => '<th>' . I18n::cell( self::translate( $c, $lang ), $c ) . '</th>', $th ) ) . '</tr></thead>';
		}
		$html .= '<tbody>';
		foreach ( $rows as $row ) {
			$html .= '<tr>' . implode( '', array_map( static fn( string $c ): string => '<td>' . I18n::cell( self::translate( $c, $lang ), $c ) . '</td>', $row ) ) . '</tr>';
		}
		return $html . '</tbody></table></figure>';
	}

	/**
	 * 원천 표를 아직 못 그릴 때(한국어 쪽이 초안·비공개 — 운영 설치 직후 seed-pages 초안이 원장 승인 전인 동안, 또는 표가 없음) 빈 자리 대신 그리는 안내:
	 * "아직 게시 전 — 전화로 문의" + 전화 링크(병원 기본 정보에서 계산). 한국어 쪽이 게시되면 다음 요청부터 표가 그려진다(설치 단계 추가 없음).
	 */
	public static function pending( string $lang ): string {
		$text = array(
			'en' => 'This table will appear here once the Korean page is published. For details, please call us:',
			'vi' => 'Bảng này sẽ hiển thị khi trang tiếng Hàn được đăng. Để biết chi tiết, vui lòng gọi cho chúng tôi:',
			'zh' => '韩语页面发布后，此处将显示表格。详情请致电：',
		)[ $lang ] ?? '';
		$tel   = I18n::phoneIntl();
		$digit = preg_replace( '/[^0-9+]/', '', $tel );
		return '' === $text ? '' : sprintf(
			'<p class="iwell-source-pending">%s <a href="tel:%s">%s</a></p>',
			esc_html( $text ),
			esc_attr( (string) $digit ),
			esc_html( $tel )
		);
	}

	/** 게시된 한국어 고정 페이지(계층 경로). 초안·비공개·비밀번호 페이지는 null. */
	private static function published( string $path ): ?WP_Post {
		$posts = get_posts(
			array(
				'post_type'        => 'page',
				'pagename'         => $path,
				'post_status'      => 'publish',
				'numberposts'      => 1,
				'suppress_filters' => false,
			)
		);
		$post  = $posts[0] ?? null;
		return $post instanceof WP_Post && '' === $post->post_password ? $post : null;
	}

	/**
	 * 본문 HTML 의 표 가운데 첫 머리 칸 글자가 $head 인 첫 표 → [머리 칸 list, 줄 list<list>]. $head 가 '' 면 첫 표. 없으면 null.
	 *
	 * @return array{0: list<string>, 1: list<list<string>>}|null
	 */
	public static function findTable( string $html, string $head ): ?array {
		if ( false === stripos( $html, '<table' ) ) {
			return null;
		}
		$doc = new DOMDocument();
		$old = libxml_use_internal_errors( true );
		$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . $html . '</div>' );
		libxml_clear_errors();
		libxml_use_internal_errors( $old );
		$xp = new DOMXPath( $doc );
		foreach ( $xp->query( '//table' ) as $table ) {
			$th = array();
			foreach ( $xp->query( './thead/tr/th', $table ) as $cell ) {
				$th[] = trim( $cell->textContent );
			}
			if ( '' !== $head && ( $th[0] ?? '' ) !== $head ) {
				continue;
			}
			$rows = array();
			foreach ( $xp->query( './tbody/tr', $table ) as $tr ) {
				$row = array();
				foreach ( $xp->query( './th|./td', $tr ) as $cell ) {
					$row[] = trim( $cell->textContent );
				}
				$rows[] = $row;
			}
			return array( $th, $rows );
		}
		return null;
	}

	/** 한국어 칸 글자 → 이 언어(낱말 표 → 금액·나이·횟수 형식 → 쉼표 목록). 못 옮기면 null. */
	public static function translate( string $ko, string $lang ): ?string {
		if ( ! isset( self::COL[ $lang ] ) ) {
			return null;
		}
		$i = self::COL[ $lang ];
		if ( isset( self::TERMS[ $ko ] ) ) {
			return self::TERMS[ $ko ][ $i ];
		}
		$money = self::money( $ko, $lang );
		if ( null !== $money ) {
			return $money;
		}
		$one = self::pattern( $ko, $lang );
		if ( null !== $one ) {
			return $one;
		}
		// 쉼표 목록(접종 시기·건강교육): 조각마다.
		if ( str_contains( $ko, ', ' ) ) {
			$parts = array();
			foreach ( explode( ', ', $ko ) as $part ) {
				$t = self::TERMS[ $part ][ $i ] ?? self::pattern( $part, $lang );
				if ( null === $t ) {
					return null;
				}
				$parts[] = $t;
			}
			return implode( 'zh' === $lang ? '、' : ', ', $parts );
		}
		return null;
	}

	/** 숫자 형식 — 베트남어는 천 단위 점(60.000). */
	private static function num( string $n, string $lang ): string {
		return 'vi' === $lang ? str_replace( ',', '.', $n ) : $n;
	}

	/** 금액: 'N원' · '1회 N원' · '진료 후 검사 항목에 따라 차이가 생김(A~B만원)'. */
	private static function money( string $ko, string $lang ): ?string {
		if ( 1 === preg_match( '/^([\d,]+)원$/u', $ko, $m ) ) {
			return array(
				'en' => 'KRW ' . $m[1],
				'vi' => self::num( $m[1], $lang ) . ' won',
				'zh' => $m[1] . ' 韩元',
			)[ $lang ];
		}
		if ( 1 === preg_match( '/^1회 ([\d,]+)원$/u', $ko, $m ) ) {
			return array(
				'en' => 'KRW ' . $m[1] . ' per dose',
				'vi' => self::num( $m[1], $lang ) . ' won/mũi',
				'zh' => '每剂 ' . $m[1] . ' 韩元',
			)[ $lang ];
		}
		if ( 1 === preg_match( '/^진료 후 검사 항목에 따라 차이가 생김\((\d+)~(\d+)만원\)$/u', $ko, $m ) ) {
			$a = number_format( (int) $m[1] * 10000 );
			$b = number_format( (int) $m[2] * 10000 );
			return array(
				'en' => "Depends on the tests chosen after consultation (KRW {$a}–{$b})",
				'vi' => 'Tùy theo các xét nghiệm được chỉ định sau khi khám (' . self::num( $a, $lang ) . '–' . self::num( $b, $lang ) . ' won)',
				'zh' => "视就诊后所做的检查项目而定（{$a}–{$b} 韩元）",
			)[ $lang ];
		}
		return null;
	}

	/** 나이·횟수·차수 형식 한 조각. */
	private static function pattern( string $ko, string $lang ): ?string {
		$rules = array(
			// 횟수 'N회'
			'/^(\d+)회$/u'                         => array( '%1$s doses', '%1$s mũi', '%1$s剂' ),
			// 영유아 검진 차수 'N차'
			'/^(\d+)차$/u'                         => array( 'Check-up %1$s', 'Lần %1$s', '第%1$s次' ),
			// '생후 A~B일' · '생후 A~B개월'
			'/^생후 (\d+)~(\d+)일$/u'                 => array( 'Age %1$s–%2$s days', '%1$s–%2$s ngày tuổi', '出生后%1$s–%2$s天' ),
			'/^생후 (\d+)~(\d+)개월$/u'                => array( 'Age %1$s–%2$s months', '%1$s–%2$s tháng tuổi', '出生后%1$s–%2$s个月' ),
			// 접종 시기
			'/^(\d+)개월$/u'                        => array( '%1$s months', '%1$s tháng', '%1$s个月' ),
			'/^(\d+)~(\d+)개월$/u'                  => array( '%1$s–%2$s months', '%1$s–%2$s tháng', '%1$s–%2$s个月' ),
			'/^(\d+)세$/u'                         => array( 'age %1$s', '%1$s tuổi', '%1$s岁' ),
			'/^(\d+)~(\d+)세$/u'                   => array( 'ages %1$s–%2$s', '%1$s–%2$s tuổi', '%1$s–%2$s岁' ),
			'/^(\d+)~(\d+)개월\((\d+)·(\d+)차\)$/u'    => array( '%1$s–%2$s months (doses %3$s, %4$s)', '%1$s–%2$s tháng (mũi %3$s, %4$s)', '%1$s–%2$s个月（第%3$s、%4$s剂）' ),
			'/^(\d+)~(\d+)개월\((\d+)차\)$/u'         => array( '%1$s–%2$s months (dose %3$s)', '%1$s–%2$s tháng (mũi %3$s)', '%1$s–%2$s个月（第%3$s剂）' ),
			'/^(\d+)세\((\d+)차\)$/u'               => array( 'age %1$s (dose %2$s)', '%1$s tuổi (mũi %2$s)', '%1$s岁（第%2$s剂）' ),
			'/^(\d+)개월 이후$/u'                    => array( 'From %1$s months', 'Từ %1$s tháng', '%1$s个月以后' ),
			'/^(\d+)개월부터 매년$/u'                  => array( 'Every year from %1$s months', 'Hằng năm từ %1$s tháng tuổi', '%1$s个月起每年' ),
		);
		foreach ( $rules as $re => $out ) {
			if ( 1 === preg_match( $re, $ko, $m ) ) {
				$t = vsprintf( $out[ self::COL[ $lang ] ], array_slice( $m, 1 ) );
				// 영어 단수(agy Neon P1 2026-11-26): '1 doses'·'1 months' → '1 dose'·'1 month'.
				return 'en' === $lang ? (string) preg_replace( array( '/^1 doses$/', '/\b1 months\b/' ), array( '1 dose', '1 month' ), $t ) : $t;
			}
		}
		return null;
	}
}
