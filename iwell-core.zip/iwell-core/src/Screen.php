<?php
/**
 * 실제 화면 영역 표식(Task 6 수정 12 — Codex 재확인 8 C8-1 뒤 코디네이터 Ruling).
 *
 * 수정 10·11 의 지문은 따로 돌린 렌더(본문 the_content 만, 루프 밖)로 쟀고, 실제 공개 화면은 메인 루프 안·로그인 여부·요청 종류가 다른 문맥에서 그려져
 * (공급 Rank Math HTML 사이트맵 — 메인 루프의 the_content 필터) 직원 변경이 승인 페이지 본문을 바꿔도 검토 표시가 남았다. 그래서 두 곳이 같은 코드로
 * 검토 범위 영역을 자른다:
 *   - 승인 지문(Fingerprint::extract): 그 화면이 실제로 쓰는 블록 템플릿을(template-loader 와 같은 순서로 고름) 실제 화면과 같은 메인 질의·루프로
 *     get_the_block_template_html() 로 그린 HTML
 *   - 공개 판정(LiveSeal): 실제로 보내는 응답(출력 버퍼)
 *
 * 영역(REGIONS) = 검토 범위의 출력 자리: 본문 core/post-content(out:body)·제목 iwell/page-title(out:title)·출처 iwell/sources(out:sources) — 바깥쪽 것만
 * (영역 안의 core/post-content 는 자기 본문 재귀라 가림). 영역 안의 가림 블록(Fingerprint::MASKED — 오늘 진료 바·진료시간 표·검토 배지, 그리고 영역 안
 * core/post-content)은 고정 토큰으로 바꿔 정규화한다(수정 10 결정 1 가림 그대로).
 *
 * 표식은 보이지 않는 HTML 주석(요청마다 새 nonce — 본문 글자로 위조할 수 없다)이다. render_block_data(PHP_INT_MAX — 실제로 그려지는 블록마다 한 번)에서
 * 블록 쌓기를 열고 render_block(PHP_INT_MAX — 다른 필터 다음, 그 블록의 최종 HTML)에서 닫으며 영역·가림 블록의 출력을 감싼다. 두 필터는 그려지는 블록마다
 * 짝으로 불린다(다른 필터가 pre_render_block 으로 대신 그린 블록은 둘 다 불리지 않는다 — 감시만 Fingerprint 가 pre_render_block 에서 한다). 예외: 동기화
 * 패턴 core/block 은 render_block 이 두 번 온다 — 열린 블록과 이름이 같을 때만 닫는다. 짝이 끝까지 안 맞으면 판정할 수 없다(닫힌 쪽).
 * 영역 안에 있는지(inRegion)는 관찰(첨부·패턴)·렌더 감시(짧은 코드·목록 밖 블록)가 쓴다 — 머리·바닥글·메뉴 같은 템플릿(검토 범위 밖)은 보지 않는다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class Screen {
	/** 검토 범위 영역 블록 → 지문 조각 이름. */
	public const REGIONS = array(
		'core/post-content' => 'out:body',
		'iwell/page-title'  => 'out:title',
		'iwell/sources'     => 'out:sources',
	);

	/**
	 * @var array{nonce: string, seq: int, depth: int, stack: list<array{0: string, 1: int, 2: string}>, broken: bool}|null 진행 중인 표식 —
	 *      stack 항목 = [종류 'r'(영역)·'m'(가림)·''(그 밖), 순번, 블록 이름].
	 */
	private static ?array $run = null;

	/** 표식을 건다(승인 렌더·공개 응답 시작). 이미 걸려 있으면(중첩) 바깥 것을 돌려받아 끝날 때 되돌린다. @return array|null 바깥 표식 */
	public static function start(): ?array {
		$outer     = self::$run;
		self::$run = array(
			'nonce'  => strtolower( wp_generate_password( 16, false, false ) ),
			'seq'    => 0,
			'depth'  => 0,
			'stack'  => array(),
			'broken' => false,
		);
		if ( null === $outer ) {
			add_filter( 'render_block_data', array( self::class, 'enter' ), PHP_INT_MAX, 1 );
			add_filter( 'render_block', array( self::class, 'leave' ), PHP_INT_MAX, 2 );
		}
		return $outer;
	}

	/** 표식을 뗀다. @param array|null $outer start() 가 돌려준 바깥 표식. @return array{nonce: string, broken: bool} 이번 표식 */
	public static function stop( ?array $outer = null ): array {
		$run       = self::$run ?? array(
			'nonce'  => '',
			'broken' => true,
			'stack'  => array(),
		);
		self::$run = $outer;
		if ( null === $outer ) {
			remove_filter( 'render_block_data', array( self::class, 'enter' ), PHP_INT_MAX );
			remove_filter( 'render_block', array( self::class, 'leave' ), PHP_INT_MAX );
		}
		return array(
			'nonce'  => (string) $run['nonce'],
			'broken' => (bool) $run['broken'] || array() !== $run['stack'],
		);
	}

	/** 지금 표식이 걸려 있나. */
	public static function active(): bool {
		return null !== self::$run;
	}

	/** 지금 검토 범위 영역(본문·제목·출처) 안을 그리는 중인가 — 관찰·렌더 감시가 쓴다. */
	public static function inRegion(): bool {
		return null !== self::$run && self::$run['depth'] > 0;
	}

	/** 이번 표식의 nonce(공개 응답의 자리표시 — LiveSeal). */
	public static function nonce(): string {
		return null === self::$run ? '' : self::$run['nonce'];
	}

	/** 다음 순번(자리표시 — LiveSeal 배지). */
	public static function next(): int {
		return null === self::$run ? 0 : ++self::$run['seq'];
	}

	/**
	 * render_block_data(PHP_INT_MAX) — 실제로 그려지는 블록 하나가 시작된다. 영역 밖에서 영역 블록이면 영역을 열고, 영역 안의 가림 블록이면 가림을 연다.
	 *
	 * @param mixed $parsed
	 * @return mixed
	 */
	public static function enter( $parsed ) {
		if ( null === self::$run || ! is_array( $parsed ) ) {
			return $parsed;
		}
		$name = (string) ( $parsed['blockName'] ?? '' );
		$kind = '';
		if ( self::$run['depth'] > 0 ) {
			// 영역 안에서 실제로 그려지는 블록(render_block_data 가 바꾼 뒤) — 관찰(동기화 패턴)·렌더 감시(수정 11 C7-2 ②). 영역 블록 자신은 아니다.
			Fingerprint::noteRendered( $name, $parsed );
			if ( self::masked( $name ) ) {
				$kind = 'm';
			}
		} elseif ( isset( self::REGIONS[ $name ] ) ) {
			$kind = 'r';
			++self::$run['depth'];
		}
		self::$run['stack'][] = array( $kind, '' === $kind ? 0 : ++self::$run['seq'], $name );
		return $parsed;
	}

	/**
	 * render_block(PHP_INT_MAX) — 그 블록의 최종 HTML. 영역·가림 블록이면 표식으로 감싼다.
	 *
	 * @param mixed $html
	 * @param mixed $parsed
	 * @return mixed
	 */
	public static function leave( $html, $parsed = null ) {
		if ( null === self::$run ) {
			return $html;
		}
		$top  = end( self::$run['stack'] );
		$name = is_array( $parsed ) ? (string) ( $parsed['blockName'] ?? '' ) : '';
		if ( false === $top || $top[2] !== $name ) {
			// 이미 닫은 블록의 render_block 이 한 번 더 불림 — 동기화 패턴 core/block 은 자기 인스턴스를 render( dynamic=false )로 다시 그려
			// (wp-includes/blocks/block.php render_block_core_block) render_block 이 두 번 온다. 열린 블록과 이름이 다르면 닫지 않는다.
			return $html;
		}
		array_pop( self::$run['stack'] );
		list( $kind, $seq ) = $top;
		if ( '' === $kind ) {
			return $html;
		}
		$n = self::$run['nonce'];
		if ( 'r' === $kind ) {
			--self::$run['depth'];
			return "<!--iwell:$n:$seq:r:" . self::REGIONS[ $name ] . '-->' . (string) $html . "<!--/iwell:$n:$seq-->";
		}
		return "<!--iwell:$n:$seq:m:$name-->" . (string) $html . "<!--/iwell:$n:$seq-->";
	}

	/** 영역 안에서 가리는 블록인가(Fingerprint::MASKED + 영역 안 core/post-content — 자기 본문 재귀). */
	private static function masked( string $name ): bool {
		return in_array( $name, Fingerprint::MASKED, true ) || 'core/post-content' === $name;
	}

	/**
	 * 표식이 든 HTML 에서 영역별 HTML(가림 블록은 토큰 '⟦이름⟧') — 영역이 여러 번이면 차례로 잇는다(없으면 ''). 표식 짝이 맞지 않으면 null(판정 불가).
	 *
	 * @return array<string, string>|null 조각 이름(out:body·out:title·out:sources) → HTML
	 */
	public static function regions( string $html, string $nonce ): ?array {
		if ( '' === $nonce ) {
			return null;
		}
		$q    = preg_quote( $nonce, '~' );
		$opens  = preg_match_all( "~<!--iwell:$q:(\d+):[rm]:~", $html );
		$closes = preg_match_all( "~<!--/iwell:$q:(\d+)-->~", $html );
		if ( $opens !== $closes ) {
			return null;
		}
		$out = array_fill_keys( array_values( self::REGIONS ), '' );
		if ( ! preg_match_all( "~<!--iwell:$q:(\d+):r:(out:[a-z]+)-->(.*?)<!--/iwell:$q:\\1-->~s", $html, $m, PREG_SET_ORDER ) ) {
			return 0 === $opens ? $out : null;
		}
		foreach ( $m as $region ) {
			if ( ! array_key_exists( $region[2], $out ) ) {
				return null;
			}
			$inner = (string) preg_replace_callback(
				"~<!--iwell:$q:(\d+):m:([^>]*?)-->.*?<!--/iwell:$q:\\1-->~s",
				static fn( array $mask ): string => '⟦' . $mask[2] . '⟧',
				$region[3]
			);
			if ( str_contains( $inner, "<!--iwell:$nonce:" ) || str_contains( $inner, "<!--/iwell:$nonce:" ) ) {
				return null; // 영역 안 표식이 짝을 이루지 않음.
			}
			$out[ $region[2] ] .= ( '' === $out[ $region[2] ] ? '' : "\n" ) . $inner;
		}
		return $out;
	}

	/** 응답에서 이 nonce 의 표식을 모두 지운다(내용은 그대로). 이스케이프된 꼴(&lt;!--…--&gt;)도. */
	public static function clean( string $html, string $nonce ): string {
		if ( '' === $nonce ) {
			return $html;
		}
		$q = preg_quote( $nonce, '~' );
		return (string) preg_replace( array( "~<!--/?iwell:$q:[^>]*?-->~", "~&lt;!--/?iwell:$q:.*?--&gt;~" ), '', $html );
	}

	/**
	 * 지금 메인 질의가 쓸 템플릿 파일(wp-includes/template-loader.php 와 같은 순서 — 블록 테마면 locate_block_template 이 전역
	 * $_wp_current_template_id·$_wp_current_template_content 를 정한다). template_include 필터는 거치지 않는다(공개 판정이 그 자리에서 버퍼를 건다).
	 */
	public static function template(): string {
		$tags = array(
			'is_embed'             => 'get_embed_template',
			'is_404'               => 'get_404_template',
			'is_search'            => 'get_search_template',
			'is_front_page'        => 'get_front_page_template',
			'is_home'              => 'get_home_template',
			'is_privacy_policy'    => 'get_privacy_policy_template',
			'is_post_type_archive' => 'get_post_type_archive_template',
			'is_tax'               => 'get_taxonomy_template',
			'is_attachment'        => 'get_attachment_template',
			'is_single'            => 'get_single_template',
			'is_page'              => 'get_page_template',
			'is_singular'          => 'get_singular_template',
			'is_category'          => 'get_category_template',
			'is_tag'               => 'get_tag_template',
			'is_author'            => 'get_author_template',
			'is_date'              => 'get_date_template',
			'is_archive'           => 'get_archive_template',
		);
		foreach ( $tags as $tag => $getter ) {
			if ( call_user_func( $tag ) ) {
				$template = (string) call_user_func( $getter );
				if ( '' !== $template ) {
					return $template;
				}
			}
		}
		return (string) get_index_template();
	}
}
