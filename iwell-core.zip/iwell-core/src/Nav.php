<?php
/**
 * 메뉴·브레드크럼·형제 이동(Task 7) — 저장해 둔 메뉴가 없다. 요청마다 **게시된** 고정 페이지 계층에서 만든다(계획 Global Constraints
 * "최종 기준은 워드프레스 게시 상태"). 머리 메가메뉴·모바일 드로어·바닥글 사이트맵·브레드크럼·형제 탭·이전/다음이 모두 이것을 쓴다.
 *
 * tree() — 1차 = 허브 7개 고정 목록(HUBS — 수정 1차 병원 의견 2026-11-19: 발달·언어 삭제, 성장·성조숙증을 진료 허브 맨 앞. 계획 Global Constraints 의 8개와 다르다. 코디네이터 Ruling ①: 최상위 비허브 페이지 = 지역 안내·법적
 *   페이지는 1차에 넣지 않는다 → 바닥글 전용 footerPages()). 하위 = 게시된 자식(menu_order → ID 순, 아래로 모두).
 *   고정 메뉴 항목 3개(FIXED)를 소속 허브 하위의 맨 끝에 끼운다 — 메뉴 소속 ≠ 주소 계층(/notices/ → 병원소개, /consult/ → 진료안내,
 *   /columns/ → 건강정보). 단 **목적지가 열린 항목만**(routeAvailable — 필터 iwell/nav/route_available, 기본 상담만 열림. 공지·칼럼 목록 주소는
 *   Task 9 Routes 가 그 카테고리에 게시 글이 1건 이상일 때 켠다(0건이면 목록 404), 상담 게시판은 Task 11 — 수정 1 R03: 메뉴에 404 링크를 내지 않는다).
 *   허브 열을 보이는 조건(클로드 판단): 허브 페이지가 게시됨 **또는** 게시된 하위·고정 항목이 있음. 허브 페이지가 비공개인데 열을 보일 때
 *   허브 링크는 공개 목적지 규칙(→ 홈)을 따르고 노드의 public = false — 하위가 먼저 게시되고 허브가 아직 비공개인 동안에도(Task 9 setup-site 는
 *   허브를 하위가 게시될 때까지 비공개로 만든다) 게시된 하위와 공지·상담·칼럼이 메뉴에서 사라지지 않게 한다. llms.txt(Task 9)처럼 공개 목록만
 *   필요한 곳은 public 을 거른다.
 *
 * publicUrl() — 공개 목적지 규칙(계획 Global Constraints): 대상이 공개면 그 주소, 아니면 그 1차 허브(공개일 때), 아니면 홈. 홈은 항상 공개.
 *   "그 1차 허브" = 주소 첫 단계(허브 목록에 있을 때). 고정 항목은 소속 허브(상담 → 진료안내). 앵커(#map)는 대상이 공개일 때만 남긴다.
 *   /notices/·/columns/ 는 페이지가 아니라 카테고리 목록 주소(재작성 규칙 = Task 9) — 목적지가 열렸을 때(routeAvailable)만 공개로 보고,
 *   닫혀 있으면 소속 허브 → 홈으로 대체한다.
 *
 * breadcrumb() — 홈 → 공개 조상 → 현재. 비공개 조상은 화면과 구조화 데이터(BreadcrumbList) 양쪽에서 똑같이 생략한다(수정 1 R04 — 홈 링크로
 *   바꾼 허브 이름을 화면에만 남기지 않는다).
 *
 * 공개 = 게시 상태(publish). 초안·검토 대기·예약·비공개·휴지통은 공개가 아니다. PublishPress 수정안(post_mime_type *-revision)과
 * 자동 초안은 보지 않는다.
 */

namespace Iwell\Core;

use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Nav {
	/**
	 * 1차 허브 7개 — slug → 기본 이름(허브 페이지가 없을 때만 쓴다). 순서 = 메뉴·바닥글·홈 클리닉 카드 순서.
	 * 수정 1차(병원 의견 2026-11-19): "발달·언어"(development) 삭제, 성장·성조숙증을 영유아검진 앞으로("키, 사춘기? … 앞에 보여야할 듯"). 계획 Global Constraints 와 다름.
	 */
	public const HUBS = array(
		'about'   => '병원소개',
		'guide'   => '진료안내',
		'growth'  => '성장·성조숙증',
		'checkup' => '영유아검진·예방접종',
		'allergy' => '알레르기·호흡기',
		'adult'   => '성인 진료',
		'health'  => '건강정보',
	);

	/** 고정 메뉴 항목 3개 — 주소 → [이름, 소속 허브]. 소속 허브 하위의 맨 끝에 이 순서로. */
	public const FIXED = array(
		'notices' => array( '공지사항', 'about' ),
		'consult' => array( '상담·예약 안내', 'guide' ), // 수정 1차: 네이버·카카오·전화 바로가기 안내(비밀 상담 게시판 아님)
		'columns' => array( '원장 칼럼', 'health' ),
	);

	/** 페이지가 아닌 공개 목록 주소(카테고리 목록 — 재작성은 Task 9). */
	public const ROUTES = array( 'notices', 'columns' );

	/** 목적지가 처음부터 열린 고정 항목(필터 iwell/nav/route_available 기본값). */
	private const OPEN_BY_DEFAULT = array( 'consult' );

	/** 보는 상태(공개 판정은 publish 만). */
	private const STATUSES = array( 'publish', 'draft', 'pending', 'future', 'private' );

	/** @var array{byId: array<int, array>, byPath: array<string, array>, children: array<int, list<int>>}|null 요청 안 색인. */
	private static ?array $index = null;

	public static function register(): void {
		// 페이지 저장·상태 변경·삭제 → 색인 다시 만들기(같은 요청 안에서도 게시 직후 바로 반영).
		add_action( 'clean_post_cache', array( self::class, 'flush' ) );
		add_action( 'transition_post_status', array( self::class, 'flush' ) );
		// 화면 브레드크럼 = 구조화 데이터 BreadcrumbList(Rank Math 가 만든다 — Task 6) 같은 원천.
		add_filter( 'rank_math/frontend/breadcrumb/items', array( self::class, 'rankMathCrumbs' ), 10, 1 );
	}

	public static function flush(): void {
		self::$index = null;
	}

	/**
	 * 메뉴 트리.
	 *
	 * @return list<array{id: int, path: string, title: string, url: string, public: bool, kind: string, children: list<array>}>
	 */
	public static function tree(): array {
		$index = self::index();
		$tree  = array();
		foreach ( self::HUBS as $slug => $label ) {
			$row      = $index['byPath'][ $slug ] ?? null;
			$public   = null !== $row && 'publish' === $row['status'];
			$children = null !== $row ? self::children( (int) $row['id'] ) : array();
			foreach ( self::FIXED as $path => list( $title, $hub ) ) {
				if ( $hub === $slug && self::routeAvailable( $path ) ) {
					$children[] = array(
						'id'       => (int) ( $index['byPath'][ $path ]['id'] ?? 0 ),
						'path'     => $path,
						'title'    => $title,
						'url'      => self::publicUrl( $path, $hub ),
						'public'   => self::isPublic( $path ),
						'kind'     => 'fixed',
						'children' => array(),
					);
				}
			}
			if ( ! $public && array() === $children ) {
				continue;
			}
			$tree[] = array(
				'id'       => null !== $row ? (int) $row['id'] : 0,
				'path'     => $slug,
				'title'    => $public ? $row['title'] : $label,
				'url'      => self::publicUrl( $slug ),
				'public'   => $public,
				'kind'     => 'hub',
				'children' => $children,
			);
		}
		return $tree;
	}

	/**
	 * 바닥글 전용 — 허브·고정 항목이 아닌 게시된 최상위 페이지(지역 안내·법적 페이지, 설계서 §4 바닥글), menu_order 순.
	 *
	 * @return list<array{id: int, path: string, title: string, url: string}>
	 */
	public static function footerPages(): array {
		$out = array();
		foreach ( self::children( 0, false ) as $node ) {
			// 언어 홈(/en/·/zh/·/ja/ — I18n)은 바닥글 지역 안내 줄이 아니라 머리 언어 전환 단추로 간다.
			if ( ! isset( self::HUBS[ $node['path'] ] ) && ! isset( self::FIXED[ $node['path'] ] ) && ! I18n::isRoot( $node['path'] ) ) {
				unset( $node['children'], $node['public'], $node['kind'] );
				$out[] = $node;
			}
		}
		return $out;
	}

	/**
	 * 고정 메뉴 항목의 목적지가 열려 있나 — 필터 `iwell/nav/route_available`( bool $open, string $path ). 기본은 상담(consult)만 true.
	 * Task 9(공지·칼럼 목록 주소)·Task 11(상담 게시판)이 경로를 만들 때 true 로 켠다. 닫힌 항목은 메뉴(머리·드로어·바닥글)에 나오지 않는다.
	 */
	public static function routeAvailable( string $path ): bool {
		$path = self::normalize( $path );
		return (bool) apply_filters( 'iwell/nav/route_available', in_array( $path, self::OPEN_BY_DEFAULT, true ), $path );
	}

	/** 경로(앞뒤 / 무관)가 공개인가. 홈은 항상 공개, 목록 주소는 목적지가 열렸을 때만. */
	public static function isPublic( string $path ): bool {
		$path = self::normalize( $path );
		if ( '' === $path ) {
			return true;
		}
		if ( in_array( $path, self::ROUTES, true ) ) {
			return self::routeAvailable( $path );
		}
		$row = self::index()['byPath'][ $path ] ?? null;
		return null !== $row && 'publish' === $row['status'];
	}

	/**
	 * 공개 목적지 규칙 — 공개면 그 주소, 아니면 1차 허브(공개일 때), 아니면 홈.
	 *
	 * @param string      $path 'growth/bone-age' · '/guide/hours/#map' 형식.
	 * @param string|null $hub  대체할 1차 허브(없으면 주소 첫 단계가 허브 목록에 있을 때 그 허브).
	 */
	public static function publicUrl( string $path, ?string $hub = null ): string {
		$anchor = '';
		$hash   = strpos( $path, '#' );
		if ( false !== $hash ) {
			$anchor = substr( $path, $hash );
			$path   = substr( $path, 0, $hash );
		}
		$path = self::normalize( $path );
		if ( '' === $path ) {
			return home_url( '/' ) . $anchor;
		}
		if ( in_array( $path, self::ROUTES, true ) ) {
			if ( self::routeAvailable( $path ) ) {
				return home_url( '/' . $path . '/' ) . $anchor;
			}
		} elseif ( self::isPublic( $path ) ) {
			return self::link( (int) self::index()['byPath'][ $path ]['id'] ) . $anchor;
		}
		$hub ??= self::FIXED[ $path ][1] ?? explode( '/', $path )[0];
		if ( isset( self::HUBS[ $hub ] ) && $hub !== $path && self::isPublic( $hub ) ) {
			return self::link( (int) self::index()['byPath'][ $hub ]['id'] );
		}
		return home_url( '/' );
	}

	/**
	 * 브레드크럼: 홈 → 공개 조상들 → 현재. 비공개 조상은 생략(화면·BreadcrumbList 같은 원천 — 수정 1 R04). 현재 항목은 current = true.
	 *
	 * @return list<array{title: string, url: string, public: bool, current?: bool}>
	 */
	public static function breadcrumb( int $post_id ): array {
		$crumbs = array(
			array(
				'title'  => '홈',
				'url'    => home_url( '/' ),
				'public' => true,
			),
		);
		$row    = self::index()['byId'][ $post_id ] ?? null;
		if ( null === $row ) {
			return $crumbs;
		}
		$chain = array();
		for ( $parent = (int) $row['parent']; $parent > 0 && isset( self::index()['byId'][ $parent ] ); $parent = (int) self::index()['byId'][ $parent ]['parent'] ) {
			array_unshift( $chain, self::index()['byId'][ $parent ] );
		}
		foreach ( $chain as $ancestor ) {
			if ( 'publish' !== $ancestor['status'] ) {
				continue;
			}
			$crumbs[] = array(
				'title'  => $ancestor['title'],
				'url'    => self::link( (int) $ancestor['id'] ),
				'public' => true,
			);
		}
		$crumbs[] = array(
			'title'   => $row['title'],
			'url'     => self::link( $post_id ),
			'public'  => 'publish' === $row['status'],
			'current' => true,
		);
		return $crumbs;
	}

	/**
	 * 같은 부모의 게시된 형제(menu_order → ID 순) 중 바로 앞·뒤. 최상위 페이지(허브·바닥글 페이지)는 형제 이동이 없다.
	 *
	 * @return array{prev: ?array{id: int, title: string, url: string}, next: ?array{id: int, title: string, url: string}}
	 */
	public static function siblings( int $post_id ): array {
		$none = array(
			'prev' => null,
			'next' => null,
		);
		$row  = self::index()['byId'][ $post_id ] ?? null;
		if ( null === $row || 0 === (int) $row['parent'] ) {
			return $none;
		}
		$ids = array_values(
			array_filter(
				self::index()['children'][ (int) $row['parent'] ] ?? array(),
				static fn( int $id ): bool => 'publish' === self::index()['byId'][ $id ]['status'] || $id === $post_id
			)
		);
		$at  = array_search( $post_id, $ids, true );
		if ( false === $at ) {
			return $none;
		}
		$pick = function ( int $i ) use ( $ids ): ?array {
			if ( ! isset( $ids[ $i ] ) ) {
				return null;
			}
			$sib = self::index()['byId'][ $ids[ $i ] ];
			return array(
				'id'    => (int) $sib['id'],
				'title' => $sib['title'],
				'url'   => self::link( (int) $sib['id'] ),
			);
		};
		return array(
			'prev' => $pick( $at - 1 ),
			'next' => $pick( $at + 1 ),
		);
	}

	/**
	 * 페이지가 속한 메뉴 구역: 1차 허브 노드(tree() 의 것)와 펼칠 2차 항목 경로(허브 자신이면 null).
	 * 고정 항목 주소의 페이지(예: /consult/)는 소속 허브 구역. 허브 밖 최상위 페이지는 null.
	 *
	 * @return array{hub: array, active: ?string}|null
	 */
	public static function section( int $post_id ): ?array {
		$row = self::index()['byId'][ $post_id ] ?? null;
		if ( null === $row ) {
			return null;
		}
		$parts = explode( '/', $row['path'] );
		$hub   = $parts[0];
		$item  = count( $parts ) > 1 ? $parts[0] . '/' . $parts[1] : null;
		if ( isset( self::FIXED[ $parts[0] ] ) ) {
			$hub  = self::FIXED[ $parts[0] ][1];
			$item = $parts[0];
		}
		if ( ! isset( self::HUBS[ $hub ] ) ) {
			return null;
		}
		foreach ( self::tree() as $node ) {
			if ( $node['path'] === $hub ) {
				return array(
					'hub'    => $node,
					'active' => $item,
				);
			}
		}
		return null;
	}

	/** 페이지 ID → 경로('growth/bone-age'). 색인에 없으면 ''. */
	public static function pathOf( int $post_id ): string {
		return self::index()['byId'][ $post_id ]['path'] ?? '';
	}

	/**
	 * 공개 경로의 페이지 제목 = isPublic() 이 확인한 그 색인 행(게시본)의 제목. 게시된 페이지가 아니면 ''(앵커 #… 무시).
	 * 테마가 다른 페이지 제목을 쓸 때는 이것만 쓴다(Task 7 수정 3 — 코디네이터 결정): 워드프레스 get_page_by_path() 는 상태 조건이 없어
	 * 같은 부모·같은 슬러그의 초안(직원이 만들 수 있다 — 초안은 슬러그 중복 검사를 건너뛴다)을 집을 수 있다.
	 */
	public static function title( string $path ): string {
		$row = self::index()['byPath'][ self::normalize( explode( '#', $path )[0] ) ] ?? null;
		return null !== $row && 'publish' === $row['status'] ? $row['title'] : '';
	}

	/**
	 * 관련 페이지(Task 7 수정 3 — 코디네이터 결정: 본문 블록 대신 템플릿이 그리는 탐색 장치) = 이 페이지가 속한 1차 허브의 게시된 하위 페이지(2차, 메뉴
	 * 순서 — tree() 와 같은 원천·같은 제목) 가운데 자기를 뺀 앞의 $max 개. 고정 메뉴 항목(공지·상담·칼럼 목록 주소)은 넣지 않는다. 허브 밖 페이지·허브 자신이
	 * 하위가 없으면 빈 목록.
	 *
	 * @return list<array{id: int, path: string, title: string, url: string}>
	 */
	public static function related( int $post_id, int $max = 3 ): array {
		$section = self::section( $post_id );
		if ( null === $section ) {
			return array();
		}
		$out = array();
		foreach ( $section['hub']['children'] as $child ) {
			if ( 'page' !== $child['kind'] || $child['id'] === $post_id ) {
				continue;
			}
			$out[] = array(
				'id'    => $child['id'],
				'path'  => $child['path'],
				'title' => $child['title'],
				'url'   => $child['url'],
			);
			if ( count( $out ) >= $max ) {
				break;
			}
		}
		return $out;
	}

	/**
	 * 게시판 목록 주소(공지·칼럼 — ROUTES)가 속한 메뉴 구역(Task 8 T6): 고정 메뉴 항목의 소속 허브 노드(tree() 의 것 — 메뉴 소속 ≠ 주소 계층)와 그 경로.
	 * 허브 열이 메뉴에 없으면 null. 목록 주소 항목이 아직 닫혀 있으면(Task 9 전) 허브 하위에 그 항목이 없을 뿐 구역은 같다.
	 *
	 * @return array{hub: array, active: string}|null
	 */
	public static function routeSection( string $route ): ?array {
		$route = self::normalize( $route );
		$hub   = self::FIXED[ $route ][1] ?? null;
		if ( null === $hub ) {
			return null;
		}
		foreach ( self::tree() as $node ) {
			if ( $node['path'] === $hub ) {
				return array(
					'hub'    => $node,
					'active' => $route,
				);
			}
		}
		return null;
	}

	/**
	 * 허브 하위 카드(Task 8 — page-hub.html iwell/child-list): 1차 허브면 메뉴(tree())의 그 허브 2차 항목 그대로(게시된 하위 + 열린 고정 항목, 메뉴 순서),
	 * 그 밖의 페이지면 게시된 바로 아래 자식(menu_order → ID). 제목·주소는 색인의 게시본 행(초안 제목이 나오지 않는다).
	 *
	 * @return list<array{id: int, path: string, title: string, url: string, kind: string}>
	 */
	public static function childCards( int $post_id ): array {
		$row = self::index()['byId'][ $post_id ] ?? null;
		if ( null === $row ) {
			return array();
		}
		$nodes = array();
		if ( 0 === (int) $row['parent'] && isset( self::HUBS[ $row['path'] ] ) ) {
			foreach ( self::tree() as $node ) {
				if ( $node['path'] === $row['path'] ) {
					$nodes = $node['children'];
					break;
				}
			}
		} else {
			$nodes = self::children( $post_id, false );
		}
		return array_map(
			static fn( array $n ): array => array(
				'id'    => (int) $n['id'],
				'path'  => $n['path'],
				'title' => $n['title'],
				'url'   => $n['url'],
				'kind'  => $n['kind'],
			),
			$nodes
		);
	}

	/**
	 * Rank Math 브레드크럼 항목(화면·BreadcrumbList 원천)을 우리 규칙으로: 고정 페이지면 breadcrumb() 그대로(비공개 조상은 이미 빠져 화면과 같다),
	 * 그 밖의 화면은 첫 항목(홈) 이름만 '홈'으로.
	 *
	 * @param mixed $crumbs Rank Math 항목 list<[0 => 이름, 1 => 주소, 'hide_in_schema' => bool]>.
	 */
	public static function rankMathCrumbs( $crumbs ) {
		if ( ! is_array( $crumbs ) ) {
			return $crumbs;
		}
		if ( function_exists( 'is_page' ) && is_page() && ! is_front_page() ) {
			$post_id = (int) get_queried_object_id();
			if ( $post_id > 0 && isset( self::index()['byId'][ $post_id ] ) ) {
				return array_map(
					static fn( array $c ): array => array(
						$c['title'],
						$c['url'],
						'hide_in_schema' => ! $c['public'],
					),
					self::breadcrumb( $post_id )
				);
			}
		}
		if ( isset( $crumbs[0][1] ) && untrailingslashit( (string) $crumbs[0][1] ) === untrailingslashit( home_url( '/' ) ) ) {
			$crumbs[0][0] = '홈';
		}
		return $crumbs;
	}

	/**
	 * 게시된 자식 노드(재귀). $post_parent = 0 이면 최상위.
	 *
	 * @return list<array>
	 */
	private static function children( int $post_parent, bool $deep = true ): array {
		$index = self::index();
		$out   = array();
		foreach ( $index['children'][ $post_parent ] ?? array() as $id ) {
			$row = $index['byId'][ $id ];
			if ( 'publish' !== $row['status'] ) {
				continue;
			}
			$out[] = array(
				'id'       => $id,
				'path'     => $row['path'],
				'title'    => $row['title'],
				'url'      => self::link( $id ),
				'public'   => true,
				'kind'     => 'page',
				'children' => $deep ? self::children( $id ) : array(),
			);
		}
		return $out;
	}

	private static function link( int $id ): string {
		return (string) get_permalink( $id );
	}

	private static function normalize( string $path ): string {
		return trim( $path, "/ \t\n\r\0\x0B" );
	}

	/** 고정 페이지 색인(요청 안에서 한 번, 저장·상태 변경 때 비움). */
	private static function index(): array {
		if ( null !== self::$index ) {
			return self::$index;
		}
		global $wpdb;
		$statuses = "'" . implode( "','", self::STATUSES ) . "'";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- 상수 목록만, 고정 페이지 몇십 개.
		$rows = $wpdb->get_results( "SELECT ID, post_parent, post_name, post_title, post_status, menu_order, post_mime_type FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status IN ($statuses) ORDER BY menu_order ASC, ID ASC", ARRAY_A );
		$by_id = array();
		foreach ( (array) $rows as $r ) {
			if ( str_ends_with( (string) $r['post_mime_type'], '-revision' ) ) {
				continue; // PublishPress 수정안.
			}
			$by_id[ (int) $r['ID'] ] = array(
				'id'     => (int) $r['ID'],
				'parent' => (int) $r['post_parent'],
				'slug'   => urldecode( (string) $r['post_name'] ),
				'title'  => html_entity_decode( (string) $r['post_title'], ENT_QUOTES, 'UTF-8' ),
				'status' => (string) $r['post_status'],
				'path'   => '',
			);
		}
		$children = array();
		foreach ( $by_id as $id => $r ) {
			$children[ isset( $by_id[ $r['parent'] ] ) ? $r['parent'] : 0 ][] = $id;
		}
		$by_path = array();
		$walk    = static function ( int $parent, string $prefix ) use ( &$walk, &$by_id, &$by_path, $children ): void {
			foreach ( $children[ $parent ] ?? array() as $id ) {
				if ( '' === $by_id[ $id ]['slug'] ) {
					continue; // slug 없는 초안·검토 대기는 주소로 찾을 수 없다(그 아래도).
				}
				$path                 = '' === $prefix ? $by_id[ $id ]['slug'] : $prefix . '/' . $by_id[ $id ]['slug'];
				$by_id[ $id ]['path'] = $path;
				// 같은 경로가 여럿이면 게시본 → 먼저 나온 것(작은 menu_order·ID).
				if ( ! isset( $by_path[ $path ] ) || ( 'publish' === $by_id[ $id ]['status'] && 'publish' !== $by_path[ $path ]['status'] ) ) {
					$by_path[ $path ] = &$by_id[ $id ];
				}
				$walk( $id, $path );
			}
		};
		$walk( 0, '' );
		self::$index = array(
			'byId'     => $by_id,
			'byPath'   => $by_path,
			'children' => $children,
		);
		return self::$index;
	}
}
