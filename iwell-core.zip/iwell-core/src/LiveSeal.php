<?php
/**
 * 공개 판정 = 실제로 보낸 화면(Task 6 수정 12 — Codex 재확인 8 C8-1 뒤 코디네이터 Ruling 1·2·4·5).
 *
 * 원칙(대표 결정): 원장 검토 기록(배지·JSON-LD reviewedBy/lastReviewed)은 원장이 승인한 내용에만 붙는다. 승인 지문 = 화면 결과(수정 10).
 * 수정 10·11 은 따로 돌린 렌더로 결과를 쟀는데 실제 화면은 다른 문맥(메인 루프·로그인·요청 종류)에서 그려져 공급 Rank Math HTML 사이트맵으로 직원 공지
 * 제목이 승인 페이지 본문에 들어가도 검토 표시가 남았다. 흉내 렌더를 실제와 맞추는 것은 문맥이 생길 때마다 또 뚫린다 — 실제로 보낸 출력을 잰다.
 *
 * 1. 무장(arm — template_include PHP_INT_MAX: 템플릿 파일을 포함하기 바로 전, 그 뒤의 출력 = 템플릿 전체·wp_head·wp_footer 를 모두 받는다): 원장 승인
 *    기록이 걸린 고정 페이지의 공개 단일 화면(익명·로그인 모두 — 미리보기·임베드·피드·404 제외)이면 출력 버퍼(finish)를 열고, Screen 표식(본문·제목·출처
 *    영역과 가림 블록)과 영역 안 렌더 감시(짧은 코드·목록 밖 블록 — Fingerprint 와 같은 함수)를 건다.
 * 2. 자리표시: 검토 배지 블록은 이 판정 안에서만 보이지 않는 자리표시(<!--iwell:{nonce}:{순번}:b-->)를 내고 배지 HTML 은 여기 들고 있는다(badge). JSON-LD
 *    (Graph::filterJsonLd → jsonLd)는 reviewedBy·lastReviewed 를 언제나 빼고, 판정 중인 페이지면 그 값만 들고 있는다. 판정을 거치지 않는 출력(REST
 *    content.rendered·피드·oEmbed·미리보기·발췌·버퍼를 못 잡은 응답)에는 그래서 검토 표시가 없다(Ruling 2·5 — 닫힌 쪽이 기본).
 * 3. 준비(prepare — wp_footer PHP_INT_MAX, 일반 실행 문맥): 렌더 없이 얻는 지문 조각(post·meta·expand·attachment·out:featured)과 검토 불가 사유(원본 검사
 *    Sources ∪ 영역 안 렌더 감시)를 계산하고 표식을 뗀다. 버퍼가 끝날 때 준비가 없으면(wp_footer 전에 버퍼가 끝남) 판정하지 않는다(닫힌 쪽).
 * 4. 판정(finish — 버퍼 끝): 응답에서 영역을 잘라 Fingerprint::normalize(가림 토큰)로 정규화 → 해시 → 승인 때 저장한 지문(Seal::approved)과 조각마다 비교.
 *    같으면 자리표시에 배지 HTML, 우리 Graph 스크립트의 MedicalWebPage 노드에 reviewedBy·lastReviewed 를 넣는다(디코드 → 필드 → 다시 인코드). 다르면
 *    자리표시를 비우고 모든 JSON-LD 스크립트에서 reviewedBy·lastReviewed 를 지운 뒤 알림할 것을 남긴다. 표식은 응답에서 지운다. 중간 flush(ob_flush)로 온
 *    조각은 내보내지 않고 모아 두었다가 끝에 한 번에 판정한다.
 * 5. 마무리(commit — shutdown 2, 버퍼가 끝난 뒤 — 수정 13, Codex 재확인 9 C9-1 뒤 코디네이터 Ruling 1·3): 공개 응답의 차이는 **그 응답만** 닫는다. 저장된 검토
 *    기록(lapse)은 쓰지 않는다 — 응답 차이는 방문자가 고를 수 있어서(본문 쪽 나눔 /2/, KBoard 가 $_GET 을 링크에 넣는 페이지의 ?utm_source=…) 그것으로
 *    원장 승인을 지우면 누구나 승인을 없앨 수 있다. 저장 기록을 지우는 것은 승인 계산(Fingerprint 고정 문맥 — 편집 패널·저장·cron·수정안 반영·점검)뿐이다.
 *    대신 점검 화면 알림 한 줄(Fingerprint::noteLive — 최근 시각·다른 조각·요청 경로와 쿼리 앞부분, 페이지당 10분에 한 번 비교-교체)만 덮어쓴다. 검토 기록·
 *    지문 캐시·세대는 건드리지 않는다(clean_post_cache 도 부르지 않는다 — 세대를 올린다). 출력 핸들러 안에서는 쓰지 않는다(쓰기 훅이 출력 버퍼를 쓰면 치명 오류).
 * 공개 판정은 매 요청 실제 출력으로 하므로 수정 10·11 의 지문 캐시를 쓰지 않는다(Ruling 4). 공개 요청에서는 PageMeta::verifiedReview 가 저장값을 그대로
 * 돌려준다(front — 지문 렌더 없음; 보이는 검토 표시는 여기서만 정해진다).
 */

namespace Iwell\Core;

use WP_Post;

defined( 'ABSPATH' ) || exit;

final class LiveSeal {
	/** JSON-LD 검토 필드. */
	private const FIELDS = array(
		'reviewedBy'   => true,
		'lastReviewed' => true,
	);

	/** 이번 요청이 공개 화면 요청인가(template_include 를 지났다 — verifiedReview 가 지문 렌더 없이 저장값을 돌려준다). */
	private static bool $front = false;

	/** 판정 중인 페이지. */
	private static ?WP_Post $post = null;

	/** Screen 표식 nonce. */
	private static string $nonce = '';

	/** @var array|null Screen::start() 바깥 표식. */
	private static ?array $screen = null;

	private static bool $screenOn = false;

	/** @var array|null Fingerprint::observeStart() 토큰(영역 안 렌더 감시). */
	private static ?array $watch = null;

	/** 중간 flush 로 받은 조각(판정 전에는 내보내지 않는다). */
	private static string $held = '';

	/** 판정을 마쳤나(버퍼 끝). */
	private static bool $done = false;

	/** @var array{stored: array<string, string>|null, static: array<string, string>, unresolved: string[], broken: bool}|null wp_footer 에서 준비한 것. */
	private static ?array $prepared = null;

	/** @var array<int, string> 순번 → 배지 HTML(통과하면 자리표시를 채운다). */
	private static array $badges = array();

	/** @var array{id: string, fields: array}|null 판정 중인 페이지의 JSON-LD 검토 필드(통과하면 넣는다). */
	private static ?array $jsonld = null;

	/** @var array{0: int, 1: string[]}|null commit 이 남길 공개 차이 알림 [글 ID, 다른 조각](수정 13 — 저장 기록은 쓰지 않는다). */
	private static ?array $note = null;

	/** 이 요청의 주소(알림용 — requestUrl: 경로·쿼리 앞부분만). */
	private static string $url = '';

	/** 알림 주소 길이 상한(바이트): 경로 앞부분·쿼리 앞부분(수정 13 Ruling 3 — 길이 제한, 개인정보·쿠키 없음). */
	private const NOTE_PATH  = 120;
	private const NOTE_QUERY = 80;

	/** @var array{ok: bool, parts: string[]}|null 마지막 판정(운영·시험 확인용). */
	private static ?array $verdict = null;

	public static function register(): void {
		add_filter( 'template_include', array( self::class, 'arm' ), PHP_INT_MAX );
		add_action( 'wp_footer', array( self::class, 'prepare' ), PHP_INT_MAX );
		add_action( 'shutdown', array( self::class, 'commit' ), 2 ); // wp_ob_end_flush_all(1 — 버퍼 끝 = 판정) 다음.
	}

	/** 공개 화면 요청인가(PageMeta::verifiedReview — 공개 화면에서는 지문 렌더 없이 저장값; 보이는 검토 표시는 이 판정만 정한다). */
	public static function front(): bool {
		return self::$front;
	}

	/** 지금 이 글의 공개 판정이 버퍼를 잡고 있나. */
	public static function judging( int $post_id ): bool {
		return null !== self::$post && ! self::$done && self::$post->ID === $post_id;
	}

	/**
	 * template_include(PHP_INT_MAX) — 원장 승인 기록이 걸린 고정 페이지의 공개 단일 화면이면 출력 버퍼·표식·감시를 건다.
	 *
	 * @param mixed $template
	 * @return mixed
	 */
	public static function arm( $template ) {
		self::reset();
		self::$front = true;
		if ( ! is_singular( PageMeta::POST_TYPE ) || is_embed() || is_preview() || is_feed() || is_404() || is_customize_preview() ) {
			return $template;
		}
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post || PageMeta::POST_TYPE !== $post->post_type || ! PageMeta::hasSealedApproval( $post ) ) {
			return $template;
		}
		self::$post     = $post;
		self::$url      = self::requestUrl();
		self::$screen   = Screen::start();
		self::$screenOn = true;
		self::$nonce    = Screen::nonce();
		self::$watch    = Fingerprint::observeStart();
		ob_start( array( self::class, 'finish' ) );
		return $template;
	}

	/**
	 * 검토 배지 블록(PageMeta::badgeBlock): 판정 중인 페이지면 보이지 않는 자리표시(배지 HTML 은 여기 — 통과해야 응답에 들어간다), 아니면 ''(Ruling 2).
	 *
	 * @param callable(): string $render 배지 HTML(블록 렌더 안에서 — 감싸기 속성)
	 */
	public static function badge( int $post_id, callable $render ): string {
		if ( ! self::judging( $post_id ) || '' === self::$nonce ) {
			return '';
		}
		$html = (string) $render();
		if ( '' === $html ) {
			return '';
		}
		$seq                  = Screen::next();
		self::$badges[ $seq ] = $html;
		return '<!--iwell:' . self::$nonce . ':' . $seq . ':b-->';
	}

	/**
	 * rank_math/json_ld 결과(Graph::filterJsonLd)에서 reviewedBy·lastReviewed 를 언제나 뺀다. 판정 중인 페이지의 MedicalWebPage 노드 값이면 들고 있다가
	 * 판정이 통과하면 응답에 넣는다(Ruling 1·2 — 판정을 거치지 않는 출력에는 없다).
	 */
	public static function jsonLd( array $data, ?WP_Post $post ): array {
		foreach ( $data as $key => $node ) {
			if ( ! is_array( $node ) ) {
				continue;
			}
			$picked = array_intersect_key( $node, self::FIELDS );
			if ( array() !== $picked && null !== $post && self::judging( $post->ID ) && in_array( $key, array( 'WebPage', 'iwellWebPage' ), true ) ) {
				self::$jsonld = array(
					'id'     => (string) ( $node['@id'] ?? '' ),
					'fields' => (array) wp_kses_post_deep( $picked ),
				);
			}
			$data[ $key ] = self::without( $node );
		}
		return $data;
	}

	/** 배열(중첩 포함)에서 검토 필드를 뺀다. */
	private static function without( array $node ): array {
		$node = array_diff_key( $node, self::FIELDS );
		foreach ( $node as $k => $v ) {
			if ( is_array( $v ) ) {
				$node[ $k ] = self::without( $v );
			}
		}
		return $node;
	}

	/** wp_footer(PHP_INT_MAX) — 렌더 없이 얻는 지문 조각·검토 불가 사유를 계산하고(일반 실행 문맥) 표식·감시를 뗀다. */
	public static function prepare(): void {
		if ( null === self::$post || self::$done || null !== self::$prepared ) {
			return;
		}
		$observed = null === self::$watch ? array( 'u' => array() ) : Fingerprint::observeStop( self::$watch );
		self::$watch = null;
		$marks       = self::$screenOn ? Screen::stop( self::$screen ) : array( 'broken' => true );
		self::$screenOn = false;
		$post           = get_post( self::$post->ID ); // 캐시를 비우지 않는다(clean_post_cache 는 세대를 올린다 — 공개 GET 은 쓰지 않는다).
		if ( ! $post instanceof WP_Post ) {
			return;
		}
		$stored     = Seal::approved( $post );
		$sources    = Sources::of( $post );
		$unresolved = array_values( array_unique( array_merge( $sources['unresolved'], array_map( 'strval', array_keys( $observed['u'] ) ) ) ) );
		$ids        = $sources['attachments'];
		foreach ( array_keys( $stored ?? array() ) as $key ) {
			if ( str_starts_with( (string) $key, 'attachment:' ) ) {
				$ids[] = (int) substr( (string) $key, 11 );
			}
		}
		self::$prepared = array(
			'stored'     => $stored,
			'static'     => Seal::partsWith( $post, array( 'out:featured' => Fingerprint::digest( Fingerprint::featured( $post ) ) ), $ids ),
			'unresolved' => $unresolved,
			'broken'     => (bool) $marks['broken'],
		);
	}

	/**
	 * 출력 버퍼 핸들러 — 끝에서 한 번 판정한다. 중간 flush 로 온 조각은 모아 두고 아무것도 내보내지 않는다. 다른 코드가 지운(ob_clean) 조각은 버린다.
	 *
	 * @param mixed $chunk
	 */
	public static function finish( $chunk, int $phase = PHP_OUTPUT_HANDLER_FINAL ): string {
		$chunk = (string) $chunk;
		if ( self::$done ) {
			return $chunk;
		}
		if ( ! ( $phase & PHP_OUTPUT_HANDLER_CLEAN ) ) {
			self::$held .= $chunk;
		}
		if ( ! ( $phase & PHP_OUTPUT_HANDLER_FINAL ) ) {
			return '';
		}
		self::$done = true;
		$html       = self::$held;
		self::$held = '';
		return self::judge( $html );
	}

	/** 실제로 보낸 응답을 판정해 검토 표시를 넣거나 지운다. */
	private static function judge( string $html ): string {
		$ok     = false;
		$parts  = array( 'buffer' );
		$differ = false;
		if ( null !== self::$post && null !== self::$prepared && ! self::$prepared['broken'] ) {
			$regions = Screen::regions( $html, self::$nonce );
			if ( null === $regions ) {
				$parts = array( 'markers' );
			} else {
				list( $ok, $parts ) = self::compare( $regions );
				$differ             = ! $ok;
			}
		}
		self::$verdict = array(
			'ok'    => $ok,
			'parts' => $parts,
		);
		$html = (string) preg_replace_callback(
			'~<!--iwell:' . preg_quote( self::$nonce, '~' ) . ':(\d+):b-->~',
			static fn( array $m ): string => $ok ? (string) ( self::$badges[ (int) $m[1] ] ?? '' ) : '',
			$html
		);
		$html = $ok ? self::addJsonLd( $html ) : self::stripJsonLd( $html );
		if ( $differ && null !== self::$post ) {
			self::$note = array( self::$post->ID, $parts );
		}
		return Screen::clean( $html, self::$nonce );
	}

	/**
	 * 영역(Screen::regions)을 정규화해 승인 지문과 비교. @param array<string, string> $regions
	 *
	 * @return array{0: bool, 1: string[]} [같은가, 다른 조각]
	 */
	private static function compare( array $regions ): array {
		$prep = self::$prepared;
		if ( null === $prep['stored'] ) {
			return array( false, array( 'format' ) );
		}
		if ( array() !== $prep['unresolved'] ) {
			return array( false, array( 'unresolved' ) );
		}
		$now = $prep['static'];
		foreach ( $regions as $part => $region ) {
			$now[ $part ] = Fingerprint::digest( Fingerprint::normalize( $region ) );
		}
		ksort( $now );
		$stored = $prep['stored'];
		$keys   = array_unique( array_merge( array_keys( $now ), array_keys( $stored ) ) );
		sort( $keys );
		$diff = array_values( array_filter( $keys, static fn( string $k ): bool => ( $now[ $k ] ?? null ) !== ( $stored[ $k ] ?? null ) ) );
		return array( array() === $diff, $diff );
	}

	/** 통과 — 우리 Graph 스크립트에서 판정 중인 페이지의 MedicalWebPage 노드(@id)에 reviewedBy·lastReviewed 를 넣는다(못 찾으면 넣지 않는다 — 닫힌 쪽). */
	private static function addJsonLd( string $html ): string {
		$stash = self::$jsonld;
		if ( null === $stash || array() === $stash['fields'] ) {
			return $html;
		}
		$done = false;
		return self::eachJsonLd(
			$html,
			static function ( $data ) use ( $stash, &$done ) {
				if ( $done || ! is_object( $data ) || ! isset( $data->{'@graph'} ) || ! is_array( $data->{'@graph'} ) ) {
					return null;
				}
				foreach ( $data->{'@graph'} as $node ) {
					if ( is_object( $node ) && (string) ( $node->{'@id'} ?? '' ) === $stash['id'] ) {
						foreach ( $stash['fields'] as $key => $value ) {
							$node->{$key} = json_decode( (string) wp_json_encode( $value ) ); // 배열 → 같은 모양의 JSON 값.
						}
						$done = true;
						return $data;
					}
				}
				return null;
			}
		);
	}

	/** 다름·판정 불가 — 모든 JSON-LD 스크립트에서 reviewedBy·lastReviewed 를 지운다(우리 Graph 는 이미 빠져 있다 — 겹 방어). */
	private static function stripJsonLd( string $html ): string {
		return self::eachJsonLd(
			$html,
			static function ( $data ) {
				$changed = false;
				$strip   = static function ( $v ) use ( &$strip, &$changed ) {
					if ( is_object( $v ) ) {
						foreach ( array_keys( self::FIELDS ) as $key ) {
							if ( property_exists( $v, $key ) ) {
								unset( $v->{$key} );
								$changed = true;
							}
						}
						foreach ( get_object_vars( $v ) as $k => $child ) {
							$v->{$k} = $strip( $child );
						}
					} elseif ( is_array( $v ) ) {
						foreach ( $v as $i => $child ) {
							$v[ $i ] = $strip( $child );
						}
					}
					return $v;
				};
				$data = $strip( $data );
				return $changed ? $data : null;
			}
		);
	}

	/**
	 * 응답의 application/ld+json 스크립트마다 $fn(디코드한 값 — 객체 유지)을 부르고, 값을 돌려주면 다시 인코드해 그 스크립트 내용을 바꾼다(null = 그대로).
	 * 인코드 옵션은 Rank Math json_ld() 와 같게(JSON_UNESCAPED_SLASHES, 원문이 여러 줄이면 JSON_PRETTY_PRINT 도).
	 */
	private static function eachJsonLd( string $html, callable $fn ): string {
		return (string) preg_replace_callback(
			'~(<script\b[^>]*\btype=(["\'])application/ld\+json\2[^>]*>)(.*?)(</script>)~is',
			static function ( array $m ) use ( $fn ): string {
				$data = json_decode( $m[3] );
				if ( null === $data && 'null' !== trim( $m[3] ) ) {
					return $m[0];
				}
				$new = $fn( $data );
				if ( null === $new ) {
					return $m[0];
				}
				$flags = JSON_UNESCAPED_SLASHES | ( str_contains( trim( $m[3] ), "\n" ) ? JSON_PRETTY_PRINT : 0 );
				$json  = wp_json_encode( $new, $flags );
				return false === $json ? $m[0] : $m[1] . $json . $m[4];
			},
			$html
		);
	}

	/**
	 * shutdown(2 — 버퍼가 끝난 뒤): 실제 응답이 승인 지문과 달랐던 페이지의 점검 화면 알림만 덮어쓴다(수정 13 Ruling 1·3 — 그 응답은 이미 닫혔다. 저장된
	 * 검토 기록·해제 기록·지문 캐시·세대는 그대로).
	 */
	public static function commit(): void {
		if ( null === self::$note ) {
			return;
		}
		list( $id, $parts ) = self::$note;
		self::$note         = null;
		Fingerprint::noteLive( $id, $parts, self::$url );
	}

	/**
	 * 알림에 남길 요청 주소: 경로 앞 NOTE_PATH 바이트 + 쿼리 앞 NOTE_QUERY 바이트(보이는 ASCII 밖 바이트는 퍼센트 인코딩). 쿠키·로그인 사용자·IP·브라우저는
	 * 남기지 않는다(쿼리 뒷부분도 — 길이 제한). 권한 없는 요청의 승인 계산 차이 알림(PageMeta::verifiedReview — 수정 14 C10-2)도 같은 함수.
	 */
	public static function requestUrl(): string {
		$uri   = (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 아래에서 보이는 ASCII 로만 바꾸고 길이를 자른다(화면 출력은 esc_html).
		$uri   = (string) preg_replace_callback( '/[^!-~]/', static fn( array $m ): string => rawurlencode( $m[0] ), $uri );
		$split = explode( '?', $uri, 2 );
		$path  = substr( $split[0], 0, self::NOTE_PATH );
		return isset( $split[1] ) && '' !== $split[1] ? $path . '?' . substr( $split[1], 0, self::NOTE_QUERY ) : $path;
	}

	/** @return array{ok: bool, parts: string[]}|null 마지막 판정(시험·운영 확인). */
	public static function verdict(): ?array {
		return self::$verdict;
	}

	/** 요청 상태를 비운다(새 공개 요청 — 시험은 한 PHP 요청에서 여러 번 그린다). 걸어 둔 표식·감시도 뗀다. 출력 버퍼는 건드리지 않는다. */
	public static function reset(): void {
		if ( null !== self::$watch ) {
			Fingerprint::observeStop( self::$watch );
		}
		if ( self::$screenOn ) {
			Screen::stop( self::$screen );
		}
		self::$front    = false;
		self::$post     = null;
		self::$nonce    = '';
		self::$screen   = null;
		self::$screenOn = false;
		self::$watch    = null;
		self::$held     = '';
		self::$done     = false;
		self::$prepared = null;
		self::$badges   = array();
		self::$jsonld   = null;
		self::$note     = null;
		self::$url      = '';
	}
}
