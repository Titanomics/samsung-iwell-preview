<?php
/**
 * 상담 댓글 비밀번호 잠금(Task 11 수정 1 — review34 N1).
 *
 * 왜: 보호자가 비밀 상담글에 비회원 댓글(이름·비밀번호)을 달면, 익명이 댓글 번호만으로 KBoard 댓글 확인 지점에 비밀번호를 무제한 넣어 볼 수 있었다
 * (KBComment::checkPassword 에는 필터가 없다). 맞히면 댓글 본문이 보이고, 보호자는 대개 글과 같은 값을 쓰므로 글도 열린다 → 글 잠금(Lockout) 우회.
 *
 * 대상: 상담 게시판(Policy::isConsultBoard) 댓글의 KBoard 댓글 5.7 확인 지점 넷 —
 *  - ?action=kboard_comment_edit    수정창(KBCommentTemplate::edit, template_redirect 10)
 *  - ?action=kboard_comment_confirm 확인창 → 맞으면 삭제 실행으로 넘김(KBCommentTemplate::confirm, template_redirect 10)
 *  - ?action=kboard_comment_update  수정 실행(KBCommentController::update, wp_loaded 10)
 *  - ?action=kboard_comment_delete  삭제 실행(KBCommentController::delete, wp_loaded 10)
 * 다른 KBoard 게시판 댓글은 KBoard 기본 그대로(Task 6 시험 게시판 포함).
 *
 * 방식(wp_loaded 우선순위 0 — KBoard 가 비밀번호를 비교하기 전):
 *  - 실패 수는 그 댓글이 달린 **글** 단위로 글 잠금과 같은 저장 행(Lockout iwell_lock_{글 번호} — 수정 2부터 원자적 증가)에 센다 → 글·댓글 어느 쪽으로 추측해도 함께 5회.
 *    5회째에 15분 잠금. 잠금 중 입력은 세지 않는다. 수정 3부터 비교 **전에** 시도 자리를 잡는다(Lockout::reserve — 자리 없음 = 잠김),
 *    맞으면 잡은 자리만 되돌린다(Lockout::release — 0 아래로 안 감).
 *  - 잠금 중이면 KBoard 가 비교할 비밀번호($_POST['password'])를 맞을 수 없는 값으로 바꾼다 → KBoard 가 틀린 비밀번호와 똑같이 답한다
 *    (맞는 값도 거부, 잠금 여부가 응답에 드러나지 않음).
 *  - 맞는 댓글 비밀번호는 실패 수를 지우지 않는다 — 누구나 그 글에 자기 비밀번호로 댓글을 달 수 있으면, 4회 추측 + 자기 댓글 1회 맞힘을
 *    되풀이해 잠금을 피할 수 있기 때문. 실패 수는 글 비밀번호가 맞을 때(Lockout::confirm) 또는 15분 뒤 지워진다.
 *  - 없는 댓글(지운 댓글 포함): KBoard 기본은 수정창·확인창에서 "댓글이 없습니다" 알림 → 번호로 댓글이 있는지 드러난다.
 *    수정창·확인창은 틀린 비밀번호와 같은 응답(같은 단계 template_redirect 에서 같은 확인 양식·같은 알림)을 그린다.
 *    수정 실행·삭제 실행은 KBoard 가 이미 틀린 비밀번호와 같은 알림을 낸다(그대로 둠). 어느 게시판 댓글인지 알 수 없으므로 모든 번호에 같다.
 *  - 댓글 작성자 본인·게시판 관리자(KBComment::isEditor)와 비밀번호 없는 회원 댓글은 비밀번호를 쓰지 않으므로 무관(KBoard 기본).
 *
 * 비회원 댓글 비밀번호 최소 6자(L1): kboard_comments_pre_insert 에서 Policy::passwordViolation 으로 거부(글과 같은 규칙), 댓글 양식에 안내.
 */

namespace Iwell\Core\Consult;

defined( 'ABSPATH' ) || exit;

final class CommentLock {
	/** KBoard 댓글 비밀번호 확인 지점(action 값). */
	public const ACTIONS = array( 'kboard_comment_edit', 'kboard_comment_confirm', 'kboard_comment_update', 'kboard_comment_delete' );

	public static function register(): void {
		add_action( 'wp_loaded', array( self::class, 'guard' ), 0 );
		add_action( 'kboard_comments_pre_insert', array( self::class, 'beforeInsert' ), 0, 3 );
		add_action( 'kboard_comments_field', array( self::class, 'passwordNotice' ), 20, 4 );
	}

	/**
	 * 댓글 비밀번호 시도 하나를 판정하고(틀리면 그 글의 실패 1회 기록) 결과를 돌려준다.
	 *  - 'skip'        대상 아님(다른 action·번호 0·다른 게시판·글 없음·작성자/관리자·비밀번호 없는 회원 댓글)
	 *  - 'missing'     없는 댓글
	 *  - 'no-password' 비밀번호를 넣지 않음(KBoard 확인 양식 — 세지 않음)
	 *  - 'locked'      그 글이 잠김(맞는 값도 거부 — 세지 않음)
	 *  - 'right'       맞음(실패 수는 그대로)
	 *  - 'wrong'       틀림(실패 1회 기록, 5회째 잠금)
	 */
	public static function check( string $action, int $uid, string $password, ?int $now = null ): string {
		if ( $uid <= 0 || ! in_array( $action, self::ACTIONS, true ) || ! class_exists( '\KBComment' ) ) {
			return 'skip';
		}
		$comment = new \KBComment();
		$comment->initWithUID( $uid );
		if ( ! $comment->uid ) {
			return 'missing';
		}
		$content_uid = (int) $comment->content_uid;
		if ( $content_uid <= 0 || ! Policy::isConsultBoard( $comment->getBoard() ) ) {
			return 'skip';
		}
		$stored = (string) $comment->getPassword();
		if ( '' === $stored || $comment->isEditor() ) {
			return 'skip';
		}
		if ( '' === $password ) {
			return 'no-password';
		}
		// 비교(bcrypt) 전에 시도 자리부터(수정 3) — 동시에 온 요청이 모두 "안 잠김"을 보고 비교까지 가지 않게. 자리 없음 = 잠김.
		if ( ! Lockout::reserve( $content_uid, $now ) ) {
			return 'locked';
		}
		if ( kboard_password_verify( $password, $stored ) ) {
			Lockout::release( $content_uid ); // 맞는 시도는 실패로 남지 않는다(잡은 자리만 되돌림 — 실패 수를 지우지는 않음).
			return 'right';
		}
		return 'wrong'; // 잡은 자리가 실패 1회로 남는다(5회째면 잠김).
	}

	/** wp_loaded 0 — KBoard 댓글 처리(wp_loaded 10·template_redirect 10)보다 먼저. */
	public static function guard(): void {
		$action = self::action();
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			return;
		}
		$result = self::check( $action, self::uid(), self::postedPassword( $action ) );
		if ( 'locked' === $result ) {
			// KBoard 가 비교할 값을 맞을 수 없는 값으로 → 응답이 틀린 비밀번호 응답 그대로.
			$_POST['password'] = 'iwell-locked-' . wp_generate_password( 32, false );
		} elseif ( 'missing' === $result && in_array( $action, array( 'kboard_comment_edit', 'kboard_comment_confirm' ), true ) ) {
			add_action( 'template_redirect', array( self::class, 'missingResponse' ), 0 );
		}
	}

	/**
	 * 없는 댓글의 수정창·확인창 — KBCommentTemplate 가 비밀번호 댓글에 틀린 비밀번호로 그리는 것과 같은 응답(같은 단계·같은 양식·같은 알림).
	 *  - 수정창 + 비밀번호 있음: "권한이 없습니다" 알림 후 뒤로(KBCommentTemplate::edit 의 틀린 비밀번호 줄)
	 *  - 수정창 비밀번호 없음 / 확인창: KBoard 댓글 비밀번호 확인 양식(template/confirm.php)
	 */
	public static function missingResponse(): void {
		$action = self::action();
		$url    = new \KBCommentUrl();
		$url->setCommentUID( self::uid() );
		if ( 'kboard_comment_edit' === $action ) {
			$password = isset( $_POST['password'] ) ? $_POST['password'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput -- KBoard 와 같은 판정(값은 쓰지 않음)
			if ( $password ) {
				die( "<script>alert('" . __( 'You do not have permission.', 'kboard-comments' ) . "');history.go(-1);</script>" ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- KBoard 원문과 같은 응답
			}
			$submit_action_url = $url->getEditURL();
		} else {
			$submit_action_url = $url->getConfirmURL();
		}
		include KBOARD_COMMENTS_DIR_PATH . '/template/confirm.php'; // $submit_action_url 을 쓴다.
		exit;
	}

	/** kboard_comments_pre_insert — 상담 게시판 비회원 댓글 비밀번호 6자 미만 거부(KBoard 와 같은 알림 후 뒤로). 첨부를 옮기기 전이다. */
	public static function beforeInsert( $comment_uid = 0, $content_uid = 0, $board = null ): void {
		if ( is_user_logged_in() || ! Policy::isConsultBoard( $board ) ) {
			return;
		}
		$password = isset( $_POST['password'] ) && is_string( $_POST['password'] ) ? sanitize_text_field( $_POST['password'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- KBoard 가 nonce 를 이미 봤다
		$message  = Policy::passwordViolation( $password );
		if ( null !== $message ) {
			die( '<script>alert(' . wp_json_encode( $message ) . ');history.go(-1);</script>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/** kboard_comments_field(20 — KBoard 가 입력 칸을 그린 뒤) — 비회원 상담 댓글 양식에 비밀번호 6자 안내. */
	public static function passwordNotice( $field_html = '', $board = null, $content_uid = 0, $builder = null ): void {
		if ( is_user_logged_in() || ! Policy::isConsultBoard( $board ) ) {
			return;
		}
		echo Policy::passwordNoticeHtml(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function action(): string {
		return isset( $_GET['action'] ) && is_string( $_GET['action'] ) ? $_GET['action'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput
	}

	/** KBoard 와 같은 번호 해석(intval($_GET['uid'])). */
	private static function uid(): int {
		return isset( $_GET['uid'] ) ? intval( $_GET['uid'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput
	}

	/** KBoard 가 비교하는 값과 같게 — 수정창·확인창·삭제 실행은 받은 그대로, 수정 실행은 stripslashes_deep 뒤(KBCommentController::update). */
	private static function postedPassword( string $action ): string {
		$raw = isset( $_POST['password'] ) && is_string( $_POST['password'] ) ? $_POST['password'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput
		return 'kboard_comment_update' === $action ? stripslashes( $raw ) : $raw;
	}
}
