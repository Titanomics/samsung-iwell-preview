<?php
/**
 * 상담 글 자동 삭제(Task 11) — **첫 답변 시각 + 30일** 또는 **작성 시각 + 90일** 중 먼저 오는 때(초 단위, KST — Global Constraints).
 *
 * "첫 답변" = 직원·원장 계정(역할 iwell_staff·iwell_director)이 그 글에 단 첫 KBoard 댓글(휴지통 댓글 제외). 관리자(유지보수) 댓글은 답변으로 세지 않는다.
 * 시각: KBoard 는 글 date·댓글 created 를 사이트 시간대 벽시계 'YmdHis' 로 저장한다(current_time) → wp_timezone()(로컬·운영 = Asia/Seoul)으로 읽는다.
 *       대한민국은 일광 절약 시간이 없어 +30일·+90일 = 정확히 30·90 × 86400초.
 * 대상 게시판: /consult/ 페이지가 쓰는 KBoard(본문 [kboard id=N] 또는 게시판 설정 auto_page = 그 페이지) — 필터 iwell/consult/board_ids 로 바꿀 수 있다.
 *       찾지 못하면 실행 오류(조용히 0건으로 끝내지 않음 — 크론이 실패로 알린다).
 * 삭제: KBoard 의 글 삭제(KBContent::remove) — 댓글·첨부·글 옵션·답글·검색 복제 글까지 같이 지운다. 휴지통 글도 대상(보관 중인 개인정보).
 *       작성 시각을 읽지 못하는 글은 삭제 대상으로 본다(개인정보가 기한 없이 남지 않는 쪽).
 * 실행: POST /wp-json/iwell/v1/consult/retention(Rest.php) ← GitHub Actions 매일 03:40 KST(.github/workflows/consult-retention.yml).
 * 같은 실행에서 15분 지난 비밀번호 잠금 행(iwell_lock_*)도 지운다(수정 3 — Lockout::purgeExpired). 응답 수(deleted)는 지운 글 수 그대로.
 */

namespace Iwell\Core\Consult;

use DateInterval;
use DateTimeImmutable;
use DateTimeZone;
use RuntimeException;

defined( 'ABSPATH' ) || exit;

final class Retention {
	public const ANSWER_DAYS  = 30;
	public const CREATED_DAYS = 90;

	/** 답변으로 세는 역할. */
	public const ANSWER_ROLES = array( 'iwell_staff', 'iwell_director' );

	/**
	 * 지금 지워야 할 글 번호.
	 *
	 * @param list<array{id: int, created_at: ?DateTimeImmutable, first_answer_at: ?DateTimeImmutable}> $docs
	 * @return list<int>
	 */
	public static function dueForDeletion( array $docs, DateTimeImmutable $now ): array {
		$due = array();
		foreach ( $docs as $doc ) {
			$created = $doc['created_at'] ?? null;
			if ( ! $created instanceof DateTimeImmutable ) {
				$due[] = (int) $doc['id']; // 작성 시각을 모르면 지운다(닫힌 쪽).
				continue;
			}
			$limit  = $created->add( new DateInterval( 'P' . self::CREATED_DAYS . 'D' ) );
			$answer = $doc['first_answer_at'] ?? null;
			if ( $answer instanceof DateTimeImmutable ) {
				$by_answer = $answer->add( new DateInterval( 'P' . self::ANSWER_DAYS . 'D' ) );
				if ( $by_answer < $limit ) {
					$limit = $by_answer;
				}
			}
			if ( $now >= $limit ) {
				$due[] = (int) $doc['id'];
			}
		}
		return $due;
	}

	/** KBoard 'YmdHis'(사이트 시간대) → 시각. 읽지 못하면 null. */
	public static function parseKboardTime( string $value, ?DateTimeZone $tz = null ): ?DateTimeImmutable {
		if ( ! preg_match( '/\A\d{14}\z/', $value ) ) {
			return null;
		}
		$t = DateTimeImmutable::createFromFormat( '!YmdHis', $value, $tz ?? wp_timezone() );
		if ( false === $t || $t->format( 'YmdHis' ) !== $value ) {
			return null;
		}
		return $t;
	}

	/**
	 * 상담 게시판 번호 — /consult/ 페이지 본문의 [kboard id=N] + 게시판 설정 auto_page = 그 페이지.
	 *
	 * @return list<int>
	 */
	public static function boardIds(): array {
		$ids = apply_filters( 'iwell/consult/board_ids', self::pageBoardIds() );
		$ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ), static fn( int $id ): bool => $id > 0 ) ) );
		sort( $ids );
		return $ids;
	}

	/** @var array{0: string, 1: list<int>}|null 요청 안 기억(열쇠 = 페이지 번호·본문 지문) — 목록 행마다 불려도 질의 1번. */
	private static ?array $pageBoards = null;

	/** @return list<int> /consult/ 페이지가 쓰는 게시판(필터 전). */
	private static function pageBoardIds(): array {
		global $wpdb;
		$page = get_page_by_path( 'consult', OBJECT, 'page' );
		if ( ! $page instanceof \WP_Post ) {
			return array();
		}
		$key = $page->ID . ':' . md5( (string) $page->post_content );
		if ( null !== self::$pageBoards && self::$pageBoards[0] === $key ) {
			return self::$pageBoards[1];
		}
		$ids = array();
		if ( preg_match_all( '/\[kboard\s[^\]]*?\bid\s*=\s*["\']?(\d+)/i', (string) $page->post_content, $m ) ) {
			foreach ( $m[1] as $id ) {
				$ids[] = (int) $id;
			}
		}
		$table = $wpdb->prefix . 'kboard_board_meta';
		$auto  = $wpdb->get_col( $wpdb->prepare( "SELECT `board_id` FROM `{$table}` WHERE `key` = 'auto_page' AND `value` = %s", (string) $page->ID ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( (array) $auto as $id ) {
			$ids[] = (int) $id;
		}
		self::$pageBoards = array( $key, $ids );
		return $ids;
	}

	/**
	 * 게시판들의 글(답글 문서 제외 — 부모 글을 지우면 KBoard 가 답글도 지운다)과 첫 답변 시각.
	 *
	 * @param list<int> $board_ids
	 * @return list<array{id: int, created_at: ?DateTimeImmutable, first_answer_at: ?DateTimeImmutable}>
	 */
	public static function collect( array $board_ids ): array {
		global $wpdb;
		$board_ids = array_values( array_filter( array_map( 'intval', $board_ids ), static fn( int $id ): bool => $id > 0 ) );
		if ( ! $board_ids ) {
			return array();
		}
		$content = $wpdb->prefix . 'kboard_board_content';
		$in      = implode( ',', $board_ids );
		$rows    = $wpdb->get_results( "SELECT `uid`, `date` FROM `{$content}` WHERE `board_id` IN ({$in}) AND `parent_uid` = 0" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $rows ) {
			return array();
		}
		$answers = self::firstAnswers( array_map( static fn( $r ): int => (int) $r->uid, $rows ) );
		$docs    = array();
		foreach ( $rows as $r ) {
			$uid    = (int) $r->uid;
			$docs[] = array(
				'id'              => $uid,
				'created_at'      => self::parseKboardTime( (string) $r->date ),
				'first_answer_at' => isset( $answers[ $uid ] ) ? self::parseKboardTime( $answers[ $uid ] ) : null,
			);
		}
		return $docs;
	}

	/**
	 * 글마다 직원·원장의 첫 댓글 시각('YmdHis').
	 *
	 * @param list<int> $uids
	 * @return array<int, string>
	 */
	public static function firstAnswers( array $uids ): array {
		global $wpdb;
		$uids = array_values( array_filter( array_map( 'intval', $uids ), static fn( int $id ): bool => $id > 0 ) );
		if ( ! $uids ) {
			return array();
		}
		$answerers = array_map( 'intval', get_users( array( 'role__in' => self::ANSWER_ROLES, 'fields' => 'ID' ) ) );
		if ( ! $answerers ) {
			return array();
		}
		if ( ! defined( 'KBOARD_COMMNETS_VERSION' ) ) {
			return array(); // KBoard 댓글 플러그인이 없으면 답변 없음(작성 + 90일만). 상수 철자는 KBoard 원문 그대로.
		}
		$table = $wpdb->prefix . 'kboard_comments';
		$in_docs  = implode( ',', $uids );
		$in_users = implode( ',', $answerers );
		$rows     = $wpdb->get_results( "SELECT `content_uid`, MIN(`created`) AS `first` FROM `{$table}` WHERE `content_uid` IN ({$in_docs}) AND `user_uid` IN ({$in_users}) AND `status` <> 'trash' GROUP BY `content_uid`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out      = array();
		foreach ( (array) $rows as $r ) {
			$out[ (int) $r->content_uid ] = (string) $r->first;
		}
		return $out;
	}

	/**
	 * 지금 지울 상담 글을 KBoard 로 지운다. @return int 지운 수
	 *
	 * @throws RuntimeException 상담 게시판을 찾지 못했거나 KBoard 가 없을 때.
	 */
	public static function run( ?DateTimeImmutable $now = null ): int {
		if ( ! class_exists( 'KBContent' ) ) {
			throw new RuntimeException( 'KBoard 가 켜져 있지 않습니다.' );
		}
		$now = $now ?? new DateTimeImmutable( 'now', wp_timezone() );
		Lockout::purgeExpired( $now->getTimestamp() ); // 15분 지난 상담 비밀번호 잠금 행 청소(수정 3) — 하루 1회 이 크론에 얹는다.
		$boards = self::boardIds();
		if ( ! $boards ) {
			throw new RuntimeException( '상담 게시판(/consult/ 페이지의 KBoard)을 찾지 못했습니다.' );
		}
		$deleted = 0;
		foreach ( self::dueForDeletion( self::collect( $boards ), $now ) as $uid ) {
			$content = new \KBContent();
			$content->initWithUID( $uid );
			if ( ! $content->uid ) {
				continue;
			}
			$content->remove( true );
			++$deleted;
		}
		return $deleted;
	}
}
