<?php
/**
 * 비밀글 상담 정책(Task 11) — KBoard 게시판 저장·글쓰기 화면·목록·읽기 권한.
 *
 * 필수 4개(Global Constraints — 하나라도 안 되면 상담 공개 보류):
 *  1) 비밀글 강제 — kboard_insert_data·kboard_update_data 에서 secret='true'(누가 쓰든, 체크를 꺼도). 공지 표시 끔, 워드프레스 검색 복제 글 안 만듦(search=3).
 *  2) 비회원 비밀번호 — 비회원(member_uid 0) 글은 비밀번호가 없거나 6자 미만이면 저장하지 않는다(수정 1 — 댓글도 같은 규칙: CommentLock).
 *     수정 2: AJAX 글 수정(kboard_content_update)의 새 비밀번호도 같은 규칙(beforeUpdate). 해시 모양 값은 글 수정 때 저장값과 같을 때만 통과.
 *     글쓰기 화면 작성자·비밀번호 칸 뒤에 "6자 이상" 안내.
 *  3) 개인정보 수집·이용 동의(필수) — 글쓰기 화면에 체크 상자(필수). 서버에서 다시 본다: 미체크면 저장 거부.
 *  4) 처리방침 링크 — 워드프레스 get_privacy_policy_url()(공개된 처리방침 페이지). 비어 있으면 글쓰기 양식 대신 "준비 중" 안내, 저장도 거부(닫힌 쪽).
 *     처리방침 본문은 병원 법무 문서라 여기서 쓰지 않는다(병원 확인 항목).
 * 선택: 건강정보 수집·이용 동의 — 미체크여도 저장한다. 글쓰기 화면에 "건강정보는 쓰지 마세요" 안내. 저장값 = 글 옵션 iwell_health_consent '1'/'0'.
 *
 * 범위: 상담 게시판 = /consult/ 페이지가 쓰는 KBoard(본문 [kboard id=N] 또는 게시판 auto_page — Retention::boardIds, 자동 삭제와 같은 판정).
 * 저장·화면·목록·읽기 권한·잠금은 그 게시판에만 건다(다른 KBoard 게시판 — 예: Task 2·6 시험 게시판 — 은 KBoard 기본 그대로).
 * 방문자가 상담 글을 쓰는 곳은 /consult/ 뿐이라 그 페이지가 쓰는 게시판이면 보호가 걸린다. 상담 게시판을 다른 페이지에 걸지 않는다(runbook).
 * 색인 차단(글 보기·쓰기·지우기 화면 noindex)과 kboard 글 종류 사이트맵 제외는 모든 게시판에 건다(해가 없는 쪽).
 *
 * 목록 제목(대표 결정 2026-11-17 23시 — Task 2 판단 ④): 가림. 목록·최신글·RSS 의 행 제목을 고정 문구로, 글쓴이는 첫 글자 + '**',
 * 글 보기 화면의 이전·다음 글 링크(다른 글 제목을 그림)는 없앤다.
 * 바꾸는 곳은 titleVisibleInList() 함수 하나다(설정 화면 없음). 상담 읽기 권한(iwell_read_consult — 직원·원장·관리자)은 원래 제목을 본다.
 * 가림 중에는 비권한자의 목록 검색어를 받지 않는다(검색 결과 유무로 제목을 알아내는 길을 막음).
 *
 * 읽기 권한(kboard_is_reader): iwell_read_consult 가 있으면 비밀글도 읽는다(답변용). 비로그인은 비밀글 읽기 권한 없음 —
 * KBoard 옵션 kboard_allow_search_engines_always_read(검색 로봇은 늘 읽음)가 켜져도 비밀글은 비밀번호로만.
 */

namespace Iwell\Core\Consult;

defined( 'ABSPATH' ) || exit;

final class Policy {
	public const MASKED_TITLE = '비밀 상담글입니다';

	/** 글쓰기 양식 이름(KBoard 는 kboard_option_ 접두어 값을 글 옵션으로 저장한다 — KBContent::updateOptions). */
	public const PRIVACY_FIELD = 'kboard_option_iwell_privacy_consent';
	public const HEALTH_FIELD  = 'kboard_option_iwell_health_consent';

	/** 저장되는 글 옵션 키(접두어 뺀 이름). */
	public const PRIVACY_KEY = 'iwell_privacy_consent';
	public const HEALTH_KEY  = 'iwell_health_consent';

	public const READ_CAP = 'iwell_read_consult';

	public const MSG_PRIVACY_CONSENT = '개인정보 수집·이용에 동의해야 상담 글을 남길 수 있습니다.';
	public const MSG_PASSWORD        = '비회원은 비밀번호를 입력해야 합니다.';
	public const MSG_NOT_READY       = '상담 글쓰기는 준비 중입니다. 개인정보처리방침을 준비하고 있습니다.';
	public const HEALTH_NOTICE       = '건강정보 수집·이용에 동의하지 않아도 글은 저장됩니다. 동의하지 않으면 건강정보는 쓰지 마세요.';

	/**
	 * 비회원 비밀번호 최소 길이(Task 11 수정 1 — review34 L1, 코디네이터 결정). 글·댓글 같은 규칙.
	 * 5회/15분 잠금만으로는 실패 수가 15분마다 사라져 4자리 숫자를 90일 보관 안에 맞힐 수 있다.
	 */
	public const PASSWORD_MIN       = 6;
	public const MSG_PASSWORD_SHORT = '비회원 비밀번호는 6자 이상이어야 합니다.';
	public const PASSWORD_NOTICE    = '비밀번호는 6자 이상으로 정해 주세요. 글과 댓글을 다시 볼 때 씁니다.';
	/** 해시 모양 값(KBoard 해시 접두어로 시작) — KBoard 가 그대로 저장하고 그 글자 그대로 맞는 비밀번호가 된다(접두어는 누구나 안다). 수정 2. */
	public const MSG_PASSWORD_HASHED = '이 비밀번호는 쓸 수 없습니다. 다른 비밀번호를 정해 주세요.';

	/** 글 수정 요청에서 그 글의 저장 비밀번호(beforeUpdate 가 기억 → updateData 가 저장값과 같은 해시인지 본다). 수정 2. */
	private static ?string $updatingStored = null;

	public static function register(): void {
		add_filter( 'kboard_insert_data', array( self::class, 'insertData' ), 20, 2 );
		// 글쓰기 화면: 작성자·비밀번호 칸 바로 뒤에 비밀번호 6자 안내(비회원에게만 — 비밀번호 칸이 보일 때).
		add_action( 'kboard_skin_field_after_author', array( self::class, 'editorPasswordNotice' ), 10, 3 );
		add_filter( 'kboard_update_data', array( self::class, 'updateData' ), 20, 2 );
		// 첨부 파일을 옮기기 전(KBContent::execute — initUploadAttachFiles 보다 먼저)에 거부해 남는 파일이 없게 한다.
		add_action( 'kboard_pre_document_insert', array( self::class, 'beforeInsert' ), 0, 4 );
		add_action( 'kboard_pre_document_update', array( self::class, 'beforeUpdate' ), 0, 4 );
		add_action( 'kboard_skin_field_after_content', array( self::class, 'consentFields' ), 10, 3 );
		add_filter( 'pre_do_shortcode_tag', array( self::class, 'closedEditor' ), 10, 3 );
		add_filter( 'kboard_is_reader', array( self::class, 'isReader' ), 20, 4 );
		add_filter( 'kboard_content_list_items', array( self::class, 'listItems' ), 20, 3 );
		add_filter( 'kboard_content_list_total_count', array( self::class, 'listTotal' ), 20, 3 );
		// 글 보기 화면 아래 이전·다음 글 링크는 다른 상담 글 제목을 그대로 그린다(document.php — 제목 필터 없음) → 가림 중 비권한자에게는 링크를 없앤다.
		add_filter( 'kboard_content_next_uid_query', array( self::class, 'navigationQuery' ), 20, 2 );
		add_filter( 'kboard_content_prev_uid_query', array( self::class, 'navigationQuery' ), 20, 2 );
		// 글 보기·쓰기·지우기 화면은 noindex(robots.txt 차단과 겹쳐 두는 안전 장치). 블록 테마는 get_header 를 부르지 않아
		// KBoard 자체 noindex(KBSeo, get_header 훅)가 나오지 않는다 — Rank Math robots 메타(없으면 워드프레스 wp_robots)에 넣는다.
		add_filter( 'rank_math/frontend/robots', array( self::class, 'rankMathRobots' ), 99 );
		add_filter( 'wp_robots', array( self::class, 'wpRobots' ), 99 );
		// KBoard 검색 복제 글 종류(kboard, public)는 사이트맵에 넣지 않는다(search=3 으로 만들지 않지만, 옛 글이 남아 있어도 0).
		add_filter( 'rank_math/sitemap/exclude_post_type', array( self::class, 'excludeSitemapType' ), 99, 2 );
		add_filter( 'wp_sitemaps_post_types', array( self::class, 'coreSitemapTypes' ), 99 );
	}

	public static function excludeSitemapType( $exclude, $type = '' ) {
		return 'kboard' === $type ? true : $exclude;
	}

	public static function coreSitemapTypes( $types ) {
		if ( is_array( $types ) ) {
			unset( $types['kboard'] );
		}
		return $types;
	}

	/** KBoard 글 보기·쓰기·지우기 화면 요청인가(mod 값 — 글이 있든 없든 같게). */
	public static function kboardPrivateView(): bool {
		$mod = isset( $_GET['mod'] ) && is_string( $_GET['mod'] ) ? sanitize_key( $_GET['mod'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return in_array( $mod, array( 'document', 'editor', 'remove' ), true );
	}

	/** @param array<string, string> $robots */
	public static function rankMathRobots( $robots ) {
		if ( ! is_array( $robots ) || ! self::kboardPrivateView() ) {
			return $robots;
		}
		$robots['index']  = 'noindex';
		$robots['follow'] = 'nofollow';
		return $robots;
	}

	/** @param array<string, bool|string> $robots */
	public static function wpRobots( $robots ) {
		if ( ! is_array( $robots ) || ! self::kboardPrivateView() ) {
			return $robots;
		}
		unset( $robots['index'], $robots['follow'] );
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
		return $robots;
	}

	/** 상담 게시판인가(번호 또는 KBoard 게시판 객체). */
	public static function isConsultBoard( $board ): bool {
		$id = is_object( $board ) ? (int) ( $board->id ?? $board->uid ?? 0 ) : (int) $board;
		return $id > 0 && in_array( $id, Retention::boardIds(), true );
	}

	/**
	 * 목록에 비밀 상담글 제목을 보일지 — 대표 결정(2026-11-17 23시, Task 2 판단 ④): 가림(false).
	 * 바꿀 때는 이 함수 하나만 고친다. 설정 화면은 만들지 않는다(대표 결정).
	 */
	public static function titleVisibleInList(): bool {
		return false;
	}

	/** 처리방침 주소 — 공개된 처리방침 페이지가 없으면 ''(→ 글쓰기 닫힘). */
	public static function privacyUrl(): string {
		return (string) get_privacy_policy_url();
	}

	/** 이 요청이 KBoard 글쓰기 양식 제출인가(KBController::editorExecute). */
	public static function isEditorRequest(): bool {
		return isset( $_POST['action'] ) && 'kboard_editor_execute' === $_POST['action']; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/** 동의·처리방침 검사를 할 요청인가 — 글쓰기 양식 제출은 누구든, 그 밖 경로는 상담 읽기 권한이 없을 때. */
	public static function consentRequired(): bool {
		return self::isEditorRequest() || ! current_user_can( self::READ_CAP );
	}

	/**
	 * 저장 데이터 고정값 — 비밀글·공지 아님·워드프레스 검색 복제 안 함.
	 *
	 * @param array<string, mixed> $data
	 * @return array<string, mixed>
	 */
	public static function normalize( array $data ): array {
		$data['secret'] = 'true';
		$data['notice'] = '';
		$data['search'] = 3;
		return $data;
	}

	/**
	 * 저장 데이터의 규칙 위반(없으면 null). 동의 여부는 $consent(요청 값)로 따로 받는다.
	 *
	 * @param array<string, mixed> $data
	 */
	public static function violation( array $data, bool $is_update, ?bool $privacy_consent, string $privacy_url, ?string $stored = null ): ?string {
		if ( array_key_exists( 'member_uid', $data ) && 0 === (int) $data['member_uid'] ) {
			$message = self::passwordViolation( $data['password'] ?? '', $is_update ? $stored : null );
			if ( null !== $message ) {
				return $message;
			}
		}
		if ( ! $is_update && null !== $privacy_consent ) {
			if ( '' === $privacy_url ) {
				return self::MSG_NOT_READY;
			}
			if ( ! $privacy_consent ) {
				return self::MSG_PRIVACY_CONSENT;
			}
		}
		return null;
	}

	/**
	 * 비회원 비밀번호 규칙(글·댓글 공용) — 없으면 MSG_PASSWORD, 6자 미만이면 MSG_PASSWORD_SHORT, 통과면 null.
	 * 글자 수(UTF-8)로 센다. 앞뒤 공백은 세지 않는다(KBoard 가 sanitize_text_field 로 저장).
	 * 해시 모양 값(KBoard 해시 접두어로 시작)은 수정 2부터: 글 수정 때 그 글의 저장값($stored)과 똑같을 때만 통과
	 * (고칠 때 비밀번호 칸을 그대로 두면 KBoard 가 가린 값을 저장 해시로 바꿔 보낸다 — KBController 마스크 처리). 새 글·댓글($stored = null)은 거부.
	 */
	public static function passwordViolation( $password, ?string $stored = null ): ?string {
		$password = is_string( $password ) ? trim( sanitize_text_field( $password ) ) : '';
		if ( '' === $password ) {
			return self::MSG_PASSWORD;
		}
		if ( self::hashShaped( $password ) ) {
			return null !== $stored && '' !== $stored && $password === trim( sanitize_text_field( $stored ) ) ? null : self::MSG_PASSWORD_HASHED;
		}
		return mb_strlen( $password, 'UTF-8' ) < self::PASSWORD_MIN ? self::MSG_PASSWORD_SHORT : null;
	}

	/** KBoard 해시 접두어로 시작하는가(KBoard 가 없을 때도 같은 접두어로 본다). */
	private static function hashShaped( string $password ): bool {
		$prefix = function_exists( 'kboard_password_prefix' ) ? (string) kboard_password_prefix() : '$kboard_password$v1$';
		return '' !== $prefix && 0 === strpos( $password, $prefix );
	}

	/**
	 * 비회원 글 수정 요청이 새로 정하려는 비밀번호의 규칙 위반(없으면 null) — 수정 2.
	 *  - 글쓰기 양식(kboard_editor_execute): $content->new_password(가린 값이면 KBoard 가 저장값으로 바꿔 둠)
	 *  - AJAX 글 수정(admin-ajax kboard_content_update, 비로그인 허용): $_POST['data']['password'] — 키가 없으면 비밀번호를 안 바꾸므로 검사 안 함
	 * 회원 글(member_uid ≠ 0)은 검사하지 않는다. 해시 모양 값은 그 글의 저장값과 같을 때만 통과.
	 */
	public static function updatePasswordViolation( $content ): ?string {
		if ( ! is_object( $content ) || 0 !== (int) $content->member_uid ) {
			return null;
		}
		$stored = method_exists( $content, 'getPassword' ) ? (string) $content->getPassword() : '';
		if ( self::isEditorRequest() ) {
			return self::passwordViolation( isset( $content->new_password ) ? (string) $content->new_password : '', $stored );
		}
		if ( self::isAjaxContentUpdate() && isset( $_POST['data'] ) && is_array( $_POST['data'] ) && array_key_exists( 'password', $_POST['data'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- KBoard 가 check_ajax_referer 를 이미 봤다
			$given = $_POST['data']['password']; // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput
			return self::passwordViolation( is_string( $given ) ? wp_unslash( $given ) : '', $stored );
		}
		return null;
	}

	/** 이 요청이 KBoard AJAX 글 수정(admin-ajax.php?action=kboard_content_update)인가. */
	private static function isAjaxContentUpdate(): bool {
		return wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'kboard_content_update' === $_REQUEST['action']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	public static function passwordNoticeHtml(): string {
		return '<p class="iwell-consult-password-notice">' . esc_html( self::PASSWORD_NOTICE ) . '</p>';
	}

	/** kboard_skin_field_after_author — 상담 게시판 글쓰기 화면, 비밀번호 칸이 보일 때(비회원) 6자 안내. */
	public static function editorPasswordNotice( $field = null, $content = null, $board = null ): void {
		if ( ! self::isConsultBoard( $board ) || ! is_object( $board ) || ! method_exists( $board, 'viewUsernameField' ) || ! $board->viewUsernameField() ) {
			return;
		}
		echo '<div class="kboard-attr-row iwell-consult-password-row"><div class="attr-name"></div><div class="attr-value">' . self::passwordNoticeHtml() . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** 요청의 필수 동의 값(검사 대상이 아니면 null). */
	private static function postedPrivacyConsent(): ?bool {
		if ( ! self::consentRequired() ) {
			return null;
		}
		return isset( $_POST[ self::PRIVACY_FIELD ] ) && '1' === $_POST[ self::PRIVACY_FIELD ]; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/** kboard_pre_document_insert — 첨부 이동 전 거부 + 동의 값 정리(체크 안 한 선택 동의 = '0'). */
	public static function beforeInsert( $uid, $board_id, $content = null, $board = null ): void {
		if ( ! self::isConsultBoard( $board_id ) ) {
			return;
		}
		$member_uid = is_object( $content ) && isset( $content->member_uid ) ? (int) $content->member_uid : get_current_user_id();
		$password   = is_object( $content ) && isset( $content->new_password ) ? (string) $content->new_password : '';
		$message    = self::violation( array( 'member_uid' => $member_uid, 'password' => $password ), false, self::postedPrivacyConsent(), self::privacyUrl() );
		if ( null !== $message ) {
			self::refuse( $message );
		}
		if ( self::isEditorRequest() ) {
			// KBContent::updateOptions 가 $_POST 의 kboard_option_* 를 글 옵션으로 저장한다 — 동의 값은 '1'/'0' 만.
			$_POST[ self::PRIVACY_FIELD ] = '1';
			$_POST[ self::HEALTH_FIELD ]  = isset( $_POST[ self::HEALTH_FIELD ] ) && '1' === $_POST[ self::HEALTH_FIELD ] ? '1' : '0'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
	}

	/**
	 * kboard_pre_document_update(글쓰기 양식·AJAX 글 수정 둘 다 — 저장 전) — 비회원 글의 새 비밀번호 규칙(수정 2: AJAX 는 data 에 member_uid 가 없어
	 * kboard_update_data 검사가 건너뛰었다). 거부: 글쓰기 양식은 알림 후 뒤로, AJAX 는 KBoard 와 같은 JSON {result: error, message}.
	 * 고칠 때는 동의 값을 다시 받지 않는다(처음 저장한 값 유지).
	 */
	public static function beforeUpdate( $uid, $board_id, $content = null, $board = null ): void {
		if ( ! self::isConsultBoard( $board_id ) ) {
			return;
		}
		self::$updatingStored = is_object( $content ) && method_exists( $content, 'getPassword' ) ? (string) $content->getPassword() : null;
		$message              = self::updatePasswordViolation( $content );
		if ( null !== $message ) {
			if ( self::isAjaxContentUpdate() ) {
				wp_send_json( array( 'result' => 'error', 'message' => $message ) );
			}
			self::refuse( $message );
		}
		unset( $_POST[ self::PRIVACY_FIELD ], $_POST[ self::HEALTH_FIELD ] );
	}

	/** kboard_insert_data */
	public static function insertData( $data, $board_id ) {
		if ( ! is_array( $data ) || ! self::isConsultBoard( $board_id ) ) {
			return $data;
		}
		$data    = self::normalize( $data );
		$message = self::violation( $data, false, self::postedPrivacyConsent(), self::privacyUrl() );
		if ( null !== $message ) {
			if ( self::isEditorRequest() ) {
				self::refuse( $message );
			}
			// 글쓰기 양식 밖 경로: 제목을 비우면 KBContent::insertContent 가 저장하지 않는다(0 반환).
			$data['title']    = '';
			$data['board_id'] = 0;
		}
		return $data;
	}

	/** kboard_update_data */
	public static function updateData( $data, $board_id ) {
		if ( ! is_array( $data ) || ! self::isConsultBoard( $board_id ) ) {
			return $data;
		}
		$data    = self::normalize( $data );
		$message = self::violation( $data, true, null, self::privacyUrl(), self::$updatingStored );
		if ( null !== $message ) {
			if ( self::isEditorRequest() ) {
				self::refuse( $message );
			}
			unset( $data['password'] ); // 저장된 비밀번호를 비우지 않는다.
		}
		return $data;
	}

	/** 거부 — KBoard 와 같은 방식(알림 후 뒤로). 저장하지 않고 끝낸다. */
	private static function refuse( string $message ): void {
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/html; charset=UTF-8' );
			nocache_headers();
		}
		die( '<script>alert(' . wp_json_encode( $message ) . ');history.go(-1);</script>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** 글쓰기 양식(새 글)의 본문 칸 뒤 — 필수·선택 동의와 안내. 고칠 때(uid 있음)는 다시 받지 않는다. */
	public static function consentFields( $field = null, $content = null, $board = null ): void {
		if ( ( is_object( $content ) && ! empty( $content->uid ) ) || ! self::isConsultBoard( $board ) ) {
			return;
		}
		echo self::consentHtml( self::privacyUrl() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function consentHtml( string $privacy_url ): string {
		$link = '' !== $privacy_url
			? sprintf( ' <a class="iwell-consult-privacy-link" href="%s" target="_blank" rel="noopener">개인정보처리방침 보기</a>', esc_url( $privacy_url ) )
			: '';
		return '<div class="kboard-attr-row iwell-consult-consent">'
			. '<div class="attr-name">동의</div><div class="attr-value">'
			. '<p class="iwell-consult-consent-summary">수집 항목: 작성자 이름·비밀번호·문의 내용·접속 IP / 목적: 상담 답변 / 보유 기간: 첫 답변 후 30일 또는 작성 후 90일 중 먼저 오는 날 자동 삭제</p>'
			. '<label class="iwell-consult-privacy"><input type="checkbox" name="' . esc_attr( self::PRIVACY_FIELD ) . '" value="1" required> [필수] 개인정보 수집·이용에 동의합니다.</label>' . $link
			. '<br><label class="iwell-consult-health"><input type="checkbox" name="' . esc_attr( self::HEALTH_FIELD ) . '" value="1"> [선택] 건강정보 수집·이용에 동의합니다.</label>'
			. '<p class="iwell-consult-health-notice">' . esc_html( self::HEALTH_NOTICE ) . '</p>'
			. '</div></div>';
	}

	/**
	 * pre_do_shortcode_tag — 처리방침이 없으면 새 글쓰기 양식 대신 준비 중 안내(닫힌 쪽).
	 * 고치기(uid 있음)·목록·글 보기는 그대로.
	 */
	public static function closedEditor( $output, $tag, $attr ) {
		if ( 'kboard' !== $tag || false !== $output || ! function_exists( 'kboard_mod' ) ) {
			return $output;
		}
		if ( 'editor' !== kboard_mod() || kboard_uid() || '' !== self::privacyUrl() ) {
			return $output;
		}
		if ( ! self::isConsultBoard( is_array( $attr ) && isset( $attr['id'] ) ? (int) $attr['id'] : 0 ) ) {
			return $output;
		}
		return '<div class="iwell-consult-closed" role="status"><p>' . esc_html( self::MSG_NOT_READY ) . '</p></div>';
	}

	/** kboard_is_reader — 상담 읽기 권한은 비밀글도 읽음, 비로그인은 비밀글 읽기 권한 없음(비밀번호로만). */
	public static function isReader( $is_reader, $user_id = 0, $secret = '', $board = null ) {
		if ( ! self::isConsultBoard( $board ) ) {
			return $is_reader;
		}
		if ( current_user_can( self::READ_CAP ) ) {
			return true;
		}
		if ( $secret && ! is_user_logged_in() ) {
			return false;
		}
		return $is_reader;
	}

	/** 목록에서 가릴 사람인가(상담 읽기 권한이 없으면 가림). */
	private static function masked(): bool {
		return ! current_user_can( self::READ_CAP );
	}

	/** 목록 검색어가 있는 요청인가(KBoard 가 읽는 $_GET['keyword'] — kboard_keyword() 는 요청 안 첫 값을 기억하므로 원래 값을 본다). */
	private static function keywordSearch(): bool {
		$keyword = $_GET['keyword'] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return is_string( $keyword ) ? '' !== trim( $keyword ) : ! empty( $keyword );
	}

	/** kboard_content_list_items — 목록·최신글·RSS 행(DB 행 객체). 상담 게시판 행만(행의 board_id — 여러 게시판을 섞는 최신글 모아보기 대비). */
	public static function listItems( $rows, $board = null, $list = null ) {
		if ( ! is_array( $rows ) || ! self::masked() ) {
			return $rows;
		}
		$out = array();
		foreach ( $rows as $key => $row ) {
			if ( ! is_object( $row ) || ! self::isConsultBoard( (int) ( $row->board_id ?? 0 ) ) ) {
				$out[ $key ] = $row;
				continue;
			}
			if ( ! self::titleVisibleInList() && self::keywordSearch() ) {
				continue; // 검색어로 상담 글 제목을 알아내지 못하게 뺀다.
			}
			$out[ $key ] = self::maskRow( $row );
		}
		return array_values( $out );
	}

	/** kboard_content_list_total_count — 상담 게시판 목록에서 검색어를 받지 않을 때는 0건. */
	public static function listTotal( $total, $board = null, $list = null ) {
		if ( self::masked() && ! self::titleVisibleInList() && self::keywordSearch() && self::isConsultBoard( $board ) ) {
			return 0;
		}
		return $total;
	}

	/** kboard_content_{next,prev}_uid_query — 상담 게시판·가림·비권한이면 이전·다음 글 없음(결과 0 → KBoard 가 링크를 그리지 않음). */
	public static function navigationQuery( $sql, $content = null ) {
		if ( self::titleVisibleInList() || ! self::masked() || ! is_object( $content ) || ! self::isConsultBoard( (int) ( $content->board_id ?? 0 ) ) ) {
			return $sql;
		}
		return 'SELECT 0';
	}

	/** 행 하나 — 제목(가림이면 고정 문구)·글쓴이(첫 글자 + '**'). 원본 객체는 건드리지 않는다. */
	public static function maskRow( $row ) {
		if ( ! is_object( $row ) ) {
			return $row;
		}
		$row = clone $row;
		if ( ! self::titleVisibleInList() ) {
			$row->title = self::MASKED_TITLE;
		}
		if ( isset( $row->member_display ) ) {
			$row->member_display = self::maskName( (string) $row->member_display );
		}
		return $row;
	}

	public static function maskName( string $name ): string {
		$name = trim( wp_strip_all_tags( $name ) );
		if ( '' === $name ) {
			return '**';
		}
		return mb_substr( $name, 0, 1, 'UTF-8' ) . '**';
	}
}
