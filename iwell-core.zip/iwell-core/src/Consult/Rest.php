<?php
/**
 * 상담 REST(Task 11) — POST /wp-json/iwell/v1/consult/retention → { deleted: int }.
 *
 * 인증: 머리 X-Iwell-Cron 값을 옵션 iwell_cron_secret_hash(CronSecret 이 만든 password_hash)와 password_verify.
 *  머리 없음·빈 값·틀림·저장된 해시 없음 → 401(닫힌 쪽 — 비밀값을 만들기 전에는 아무도 못 부른다). 로그인 쿠키는 보지 않는다.
 * 실패: 상담 게시판을 찾지 못하거나 KBoard 가 꺼져 있으면 500(iwell_consult_retention_failed) — 크론이 실패로 알린다.
 * (계획의 src/Rest.php 를 Task 11·12 동시 작업 충돌을 피해 src/Consult/Rest.php 로 둔다 — 주소는 계획 그대로.)
 */

namespace Iwell\Core\Consult;

use RuntimeException;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || exit;

final class Rest {
	public const NAMESPACE = 'iwell/v1';
	public const ROUTE     = '/consult/retention';
	public const HEADER    = 'X-Iwell-Cron';

	public static function register(): void {
		add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	public static function routes(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => 'POST',
				'permission_callback' => array( self::class, 'authorize' ),
				'callback'            => array( self::class, 'retention' ),
			)
		);
	}

	/** @return true|WP_Error */
	public static function authorize( WP_REST_Request $request ) {
		$given = $request->get_header( self::HEADER );
		$hash  = (string) get_option( CronSecret::OPTION, '' );
		if ( is_string( $given ) && '' !== $given && '' !== $hash && password_verify( $given, $hash ) ) {
			return true;
		}
		return new WP_Error( 'iwell_cron_unauthorized', '크론 비밀값이 없거나 맞지 않습니다.', array( 'status' => 401 ) );
	}

	/** @return WP_REST_Response|WP_Error */
	public static function retention( WP_REST_Request $request ) {
		nocache_headers();
		try {
			$deleted = Retention::run();
		} catch ( RuntimeException $e ) {
			return new WP_Error( 'iwell_consult_retention_failed', $e->getMessage(), array( 'status' => 500 ) );
		}
		return new WP_REST_Response( array( 'deleted' => $deleted ), 200 );
	}
}
