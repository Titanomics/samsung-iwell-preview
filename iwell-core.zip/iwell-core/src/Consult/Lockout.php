<?php
/**
 * 상담 글 비밀번호 잠금(Task 11) — 글당 5회 실패 → 15분 열람 불가(Global Constraints).
 *
 * 자리: KBoard 비밀번호 확인 필터 kboard_password_confirm(KBoard.class.php:495 — Task 2 측정). 이 필터는 KBoard 가 맞는지 본 결과를
 * 돌려주기 직전에 불리므로, **그 결과를 쓰기 전에** 잠금부터 본다:
 *  - 잠금 중이면 무조건 false + 그 글의 세션 확인 표시($_SESSION['kboard_confirm'][uid])를 지운다 — 잠금 중에 맞힌 비밀번호가 세션에 남아
 *    잠금이 풀린 뒤 다시 묻지 않고 열리는 길(여러 세션으로 나눠 맞혀 보기)을 막는다. 이미 확인된 세션도 잠금 중에는 열람 불가(열람 요청마다 검사).
 *  - 잠금이 아니고 입력한 비밀번호가 틀렸으면 실패 1회(한 요청에서 같은 글은 1회만 — KBoard 가 한 요청에서 필터를 여러 번 부른다).
 *    5회째에 잠금(지금부터 15분). 잠금 중 입력은 세지 않는다(잠금을 늘리지 않음). 맞으면 실패 수를 지운다.
 * 저장(수정 2): 옵션 행 iwell_lock_{document_id}(자동 불러오기 안 함) 하나 = 마지막으로 센 실패 시각 숫자 + 실패 수 두 자리.
 *   만료 15분(마지막으로 센 실패부터 — 실패 수도 15분 뒤 사라짐)은 그 저장 시각으로 판단한다. 실패 수는 DB 한 문장으로 원자적으로 늘리고(recordFailure),
 *   읽을 때도 요청 안 객체 캐시를 거치지 않는다 — 옛 트랜지언트는 요청 안에 캐시된 값 + 1 로 덮어써 동시 요청 N개가 1회로 쌓였다.
 *   밖으로 보이는 모양은 그대로 state() = { fails: int, until: int(유닉스 초, 0 = 잠금 아님) }.
 * 시도 자리(수정 3): 비밀번호 비교 결과를 쓰기 **전에** reserve() 가 DB 한 문장으로 "15분 지났거나 실패 수 < 5 이면 1 늘림"을 한다 —
 *   영향 행 1 = 시도 허용, 0 = 잠김(틀린 응답 그대로). 잡은 자리는 그대로 실패 1회이고, 맞으면 글 = clear()·댓글 = release()(1 되돌림).
 *   그래서 동시에 온 요청 N개도 남은 자리만큼만 비교 결과를 쓴다(전에는 모두 "안 잠김"을 보고 비교까지 갔다). 맞는 시도는 실패로 남지 않는다.
 *   KBoard 는 이 필터를 부르기 전에 이미 비교했지만, 그 결과는 자리를 잡은 요청만 쓴다(자리 없으면 false + 세션 확인 표시 지움).
 *   만료 행은 상담 자동 삭제 크론(Retention::run, 하루 1회)이 purgeExpired() 로 지운다.
 *
 * 응답: 잠금 중 응답 = 틀린 비밀번호 응답(KBoard 확인 양식 + "비밀번호가 틀렸습니다") — 잠금 여부를 알려 주지 않는다.
 * 없는 글(지운 글·다른 게시판 글 포함)도 같은 확인 양식으로 답한다(documentForm — KBoard 기본은 "잘못된 주소" 알림 후 목록으로 돌려보내
 * 글이 있는지 드러남). 상담 읽기 권한(직원·원장·관리자)은 비밀번호를 묻지 않으므로(Policy::isReader) 잠금과 무관하다.
 * 범위: 상담 게시판(Policy::isConsultBoard)만. 다른 KBoard 게시판은 KBoard 기본 그대로.
 * 댓글(수정 1 — review34 N1): 상담 게시판 비회원 댓글의 비밀번호 확인 지점(수정창·확인창·수정 실행·삭제 실행)도 그 댓글이 달린 글의
 * 이 저장 행에 실패를 센다(CommentLock — 글·댓글 합쳐 5회 → 15분). 맞는 댓글 비밀번호는 실패 수를 지우지 않는다.
 */

namespace Iwell\Core\Consult;

defined( 'ABSPATH' ) || exit;

final class Lockout {
	public const MAX_FAILURES = 5;
	public const LOCK_SECONDS = 900;
	public const PREFIX       = 'iwell_lock_';

	/** @var array<int, string> 이 요청에서 글마다 정한 결과(한 번만 자리를 잡는다) — 'right'(맞음·지움) | 'wrong'(틀림·실패 1회) | 'refused'(자리 없음·잠김) */
	private static array $attempts = array();

	public static function register(): void {
		// 시험 도우미(dev compat-gate, 우선순위 10)보다 뒤 — 마지막 판정.
		add_filter( 'kboard_password_confirm', array( self::class, 'confirm' ), 100, 6 );
		add_filter( 'pre_do_shortcode_tag', array( self::class, 'documentForm' ), 10, 3 );
		add_action( 'kboard_head', array( self::class, 'missingNoindex' ), 10 );
		// 댓글 비밀번호 확인 지점도 같은 저장 행에 센다(수정 1 — review34 N1). iwell-core.php 등록 줄을 늘리지 않으려고 여기서 건다.
		CommentLock::register();
	}

	/**
	 * kboard_head — 없는 글 번호의 글 보기에도 KBoard 가 비밀글에 내는 것과 같은 noindex 줄(KBSeo::noindex)을 낸다(머리도 같은 응답).
	 */
	public static function missingNoindex(): void {
		if ( ! function_exists( 'kboard_mod' ) || 'document' !== kboard_mod() || (int) kboard_uid() <= 0 || current_user_can( Policy::READ_CAP ) ) {
			return;
		}
		$content = new \KBContent();
		$content->initWithUID( (int) kboard_uid() );
		if ( ! $content->uid ) {
			echo '<meta name="robots" content="noindex">' . "\n";
		}
	}

	public static function key( int $uid ): string {
		return self::PREFIX . $uid;
	}

	/**
	 * 저장 행(옵션 iwell_lock_{글}, 자동 불러오기 안 함)의 값 — DB 에서 바로 읽는다(요청 안 객체 캐시를 거치지 않음 — 수정 2).
	 * 값 = 마지막으로 센 실패 시각(유닉스 초) 숫자 뒤에 실패 수 두 자리. 예) "176340000005" = 시각 1763400000, 5회. 없으면 null.
	 */
	private static function raw( int $uid ): ?string {
		global $wpdb;
		$v = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::key( $uid ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return is_string( $v ) && preg_match( '/^\d{3,}$/', $v ) ? $v : null;
	}

	/** @return array{0: int, 1: int}|null [마지막으로 센 실패 시각, 실패 수] — 15분이 지났으면 null(실패 수도 사라짐). PHP 정수 범위를 넘지 않게 글자로 나눈다. */
	private static function parsed( int $uid, int $now ): ?array {
		$v = self::raw( $uid );
		if ( null === $v ) {
			return null;
		}
		$at = (int) substr( $v, 0, -2 );
		return $at + self::LOCK_SECONDS > $now ? array( $at, (int) substr( $v, -2 ) ) : null;
	}

	/** @return array{fails: int, until: int} */
	public static function state( int $uid, ?int $now = null ): array {
		$p = self::parsed( $uid, $now ?? time() );
		if ( null === $p ) {
			return array( 'fails' => 0, 'until' => 0 );
		}
		return array(
			'fails' => $p[1],
			'until' => $p[1] >= self::MAX_FAILURES ? $p[0] + self::LOCK_SECONDS : 0,
		);
	}

	/** 저장한 실패 기록이 사라지는 시각(마지막으로 센 실패 + 15분, 없으면 0) — 관찰용. */
	public static function expiresAt( int $uid ): int {
		$v = self::raw( $uid );
		return null === $v ? 0 : (int) substr( $v, 0, -2 ) + self::LOCK_SECONDS;
	}

	public static function isLocked( int $uid, ?int $now = null ): bool {
		$now = $now ?? time();
		return self::state( $uid, $now )['until'] > $now;
	}

	/**
	 * 시도 자리 1개를 잡는다(수정 3) — 비밀번호 비교 결과를 쓰기 **전에** 부른다. @return bool true = 자리 잡음(시도 허용), false = 잠김
	 *
	 * DB 한 문장(조건부 UPDATE): WHERE 에 "15분 지났거나 실패 수 < 5" 를 두고 그때만 1 늘린다 — 판정과 증가가 한 문장이라 동시에 온 요청이
	 * 같은 "안 잠김"을 보고 함께 통과하지 못한다(InnoDB 행 잠금·SQLite BEGIN IMMEDIATE 쓰기 잠금). 영향 행 1 = 허용, 0 = 잠김(또는 행 없음).
	 *  - 15분 지난 행(마지막으로 센 시도 + 15분 ≤ 지금 — 풀린 잠금 포함) → 지금 시각·1회(0부터 다시)
	 *  - 실패 수 < 5 → 지금 시각·실패 수 + 1
	 *  - 실패 수 ≥ 5(잠금 중) → 그대로(영향 행 0 — 잠금 중 입력은 세지 않음·잠금을 늘리지 않음)
	 * 행이 없으면 조건 없이 INSERT 한다 — 다른 요청이 먼저 넣어 중복 키면 같은 조건부 UPDATE 를 다시(읽기 검사로 건너뛰지 않음 — 수정 2 의 첫 행 경쟁).
	 * 그 사이 행이 지워졌으면(맞는 글 비밀번호) 한 번 더 INSERT. 영향 행 수: 맞은 행은 값이 늘 바뀌므로(시각 또는 실패 수)
	 * MySQL(바뀐 행 수 — wpdb 는 CLIENT_FOUND_ROWS 를 켜지 않음)과 SQLite(맞은 행 수 — sqlite3_changes)가 같다.
	 * 큰 수 계산은 DB 가 한다(값이 12자리라 32비트 PHP 정수를 넘을 수 있음). $wpdb->prepare 표준 문장만(CASE·%·+ — MySQL·SQLite 둘 다).
	 */
	public static function reserve( int $uid, ?int $now = null ): bool {
		global $wpdb;
		$now   = $now ?? time();
		$key   = self::key( $uid );
		$stale = $now - self::LOCK_SECONDS + 1; // 이 시각보다 앞선 기록은 15분이 지났다.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$update = $wpdb->prepare(
			"UPDATE {$wpdb->options} SET option_value = CASE
				WHEN option_value + 0 < %d * 100 THEN %d * 100 + 1
				ELSE %d * 100 + option_value %% 100 + 1 END
			WHERE option_name = %s AND ( option_value + 0 < %d * 100 OR option_value %% 100 < %d )",
			$stale,
			$now,
			$now,
			$key,
			$stale,
			self::MAX_FAILURES
		);
		$insert = $wpdb->prepare( "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'off')", $key, $now . '01' );
		for ( $round = 0; $round < 2; $round++ ) {
			if ( 1 === (int) $wpdb->query( $update ) ) {
				return true;
			}
			// 0행 = 잠김 또는 행 없음 → 넣어 본다. 이미 있으면(중복 키) 실패 → 다음 바퀴에 같은 조건부 UPDATE.
			$suppress = $wpdb->suppress_errors( true );
			$inserted = $wpdb->query( $insert );
			$wpdb->suppress_errors( $suppress );
			if ( 1 === (int) $inserted ) {
				return true;
			}
		}
		// phpcs:enable
		return false;
	}

	/**
	 * 잡은 자리 1개를 되돌린다(수정 3 — 맞는 댓글 비밀번호). 실패 수만 1 줄이고 0 아래로 가지 않는다(시각은 그대로).
	 * 행이 없으면(그사이 맞는 글 비밀번호로 지워짐) 아무것도 하지 않는다.
	 */
	public static function release( int $uid ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = option_value - 1 WHERE option_name = %s AND option_value %% 100 > 0", self::key( $uid ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/** 실패 1회 기록(= 자리 1개를 잡고 되돌리지 않음). 5회째면 잠근다. 잠금 중이면 세지 않는다. @return array{fails: int, until: int} 기록 뒤 상태 */
	public static function recordFailure( int $uid, ?int $now = null ): array {
		$now = $now ?? time();
		self::reserve( $uid, $now );
		return self::state( $uid, $now );
	}

	public static function clear( int $uid ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", self::key( $uid ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * 15분 지난 잠금 행(iwell_lock_*)을 지운다(수정 3 — 상담 자동 삭제 크론 Retention::run 이 하루 1회 부른다). 살아 있는 행·잠긴 행은 남긴다.
	 * @return int 지운 행 수
	 */
	public static function purgeExpired( ?int $now = null ): int {
		global $wpdb;
		$stale = ( $now ?? time() ) - self::LOCK_SECONDS + 1;
		return (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value + 0 < %d * 100", $wpdb->esc_like( self::PREFIX ) . '%', $stale ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery,WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/** kboard_password_confirm( $confirm, $input_password, $content_password, $content_uid, $reauth, $board ) */
	public static function confirm( $confirm, $input_password = '', $content_password = '', $content_uid = 0, $reauth = false, $board = null ) {
		$uid = (int) $content_uid;
		if ( $uid <= 0 || ! Policy::isConsultBoard( $board ) ) {
			return $confirm;
		}
		if ( '' === (string) $input_password ) {
			// 비밀번호를 넣지 않은 확인(세션 확인 표시) — 추측이 아니므로 자리를 잡지 않는다. 잠금 중이면 거부.
			if ( self::isLocked( $uid ) ) {
				self::forgetSession( $uid );
				return false;
			}
			return $confirm;
		}
		if ( ! isset( self::$attempts[ $uid ] ) ) {
			// 비교 결과($confirm)를 쓰기 전에 자리부터(수정 3). 한 요청에서 같은 글은 1회 — KBoard 가 한 요청에서 필터를 여러 번 부른다.
			if ( ! self::reserve( $uid ) ) {
				self::$attempts[ $uid ] = 'refused';
			} elseif ( $confirm ) {
				self::clear( $uid );
				self::$attempts[ $uid ] = 'right';
			} else {
				// 잡은 자리가 실패 1회로 남는다. 5회째면 잠김 → 세션 확인 표시도 지운다.
				self::$attempts[ $uid ] = self::isLocked( $uid ) ? 'refused' : 'wrong';
			}
		}
		if ( 'right' === self::$attempts[ $uid ] ) {
			return $confirm;
		}
		if ( 'refused' === self::$attempts[ $uid ] ) {
			self::forgetSession( $uid );
		}
		return false;
	}

	/** 시험용 — 요청 안 기억(글마다 정한 결과)을 비운다. */
	public static function resetRequestMemory(): void {
		self::$attempts = array();
	}

	private static function forgetSession( int $uid ): void {
		if ( isset( $_SESSION['kboard_confirm'] ) && is_array( $_SESSION['kboard_confirm'] ) ) {
			unset( $_SESSION['kboard_confirm'][ $uid ] );
		}
	}

	/**
	 * pre_do_shortcode_tag — 글 보기(mod=document)인데 그 게시판에 보이는 글이 없으면(없는 번호·휴지통·다른 게시판) 틀린 비밀번호와 같은
	 * KBoard 확인 양식을 그린다. 상담 읽기 권한은 KBoard 기본 그대로(알림).
	 */
	public static function documentForm( $output, $tag, $attr ) {
		if ( 'kboard' !== $tag || false !== $output || ! class_exists( 'KBoardBuilder' ) || ! function_exists( 'kboard_mod' ) ) {
			return $output;
		}
		if ( 'document' !== kboard_mod() || current_user_can( Policy::READ_CAP ) ) {
			return $output;
		}
		$uid      = (int) kboard_uid();
		$board_id = is_array( $attr ) && isset( $attr['id'] ) ? (int) $attr['id'] : 0;
		if ( $uid <= 0 || ! Policy::isConsultBoard( $board_id ) ) {
			return $output;
		}
		$content = new \KBContent();
		$content->initWithUID( $uid );
		if ( $content->uid && ! $content->isTrash() && (int) $content->board_id === $board_id ) {
			return $output; // 있는 글 — KBoard 가 그린다(비밀글이면 확인 양식).
		}
		$board = new \KBoard();
		$board->setID( $board_id );
		if ( ! $board->id ) {
			return $output;
		}
		return self::confirmFormFor( $board, $uid );
	}

	/** KBoardBuilder::builderDocument 가 비밀글에 그리는 것과 같은 확인 양식(같은 스킨 confirm.php·같은 머리·꼬리 훅). */
	private static function confirmFormFor( \KBoard $board, int $uid ): string {
		$builder        = new \KBoardBuilder( $board->id );
		$builder->board = $board;
		$builder->setSkin( $board->skin );
		kboard_builder_mod( 'document' );

		$url = new \KBUrl();
		$url->setBoard( $board );
		$url->setPath( $builder->url );

		$placeholder           = new \KBContent();
		$placeholder->uid      = $uid;
		$placeholder->board_id = $board->id;
		$placeholder->board    = $board;
		$board->content        = $placeholder;

		$order           = new \KBOrder();
		$order->board    = $board;
		$order->board_id = $board->id;

		$vars = array(
			'content'      => $placeholder,
			'order'        => $order,
			'url'          => $url,
			'skin'         => $builder->skin,
			'skin_path'    => $builder->skin->url( $builder->skin_name ),
			'skin_dir'     => $builder->skin->dir( $builder->skin_name ),
			'board'        => $board,
			'boardBuilder' => $builder,
		);

		ob_start();
		$builder->printPreventCopy();
		do_action( 'kboard_skin_header', $builder );
		echo $builder->skin->load( $builder->skin_name, 'confirm.php', $vars ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		do_action( 'kboard_skin_footer', $builder );
		return (string) ob_get_clean();
	}
}
