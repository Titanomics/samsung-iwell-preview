<?php
/**
 * 관리자 화면 `설정 > iwell-core 설정` — 크론 비밀값 새로 만들기(Task 11) + 상담 바로가기 주소 3칸(수정 1차 — Links::settingsSection).
 *
 * 상담 자동 삭제 크론(GitHub Actions)이 보내는 머리 X-Iwell-Cron 의 비밀값. 파일 편집 없이 운영에서 만든다:
 *  1) 관리자(manage_options)가 "크론 비밀값 새로 만들기"를 누른다(POST + nonce).
 *  2) 무작위 32바이트(64자 16진수)를 만들어 password_hash 만 옵션 iwell_cron_secret_hash 에 저장하고, 비밀값은 그 응답 화면에 **한 번만** 보인다
 *     (다시 열면 "설정됨"과 만든 시각만). 평문은 어디에도 저장하지 않는다.
 *  3) 그 값을 GitHub 저장소 Secret IWELL_CRON_SECRET 에 넣는다. 새로 만들면 옛 값은 바로 무효(401).
 */

namespace Iwell\Core\Consult;

defined( 'ABSPATH' ) || exit;

final class CronSecret {
	public const OPTION     = 'iwell_cron_secret_hash';
	public const CREATED_AT = 'iwell_cron_secret_created_at';
	public const PAGE       = 'iwell-core-settings';
	public const NONCE      = 'iwell_cron_secret_new';
	public const CAPABILITY = 'manage_options';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
	}

	public static function menu(): void {
		add_options_page( 'iwell-core 설정', 'iwell-core 설정', self::CAPABILITY, self::PAGE, array( self::class, 'page' ) );
	}

	/** 새 비밀값을 만들어 해시만 저장한다. @return string 평문(호출한 화면에 한 번만 보인다) */
	public static function generate(): string {
		$secret = bin2hex( random_bytes( 32 ) );
		update_option( self::OPTION, password_hash( $secret, PASSWORD_DEFAULT ), false );
		update_option( self::CREATED_AT, time(), false );
		return $secret;
	}

	public static function page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.' ), 403 );
		}
		$secret = null;
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['iwell_cron_secret_new'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			check_admin_referer( self::NONCE );
			$secret = self::generate();
		}
		$created = (int) get_option( self::CREATED_AT, 0 );
		$has     = '' !== (string) get_option( self::OPTION, '' );
		echo '<div class="wrap"><h1>iwell-core 설정</h1>';
		echo '<h2>크론 비밀값</h2>';
		echo '<p>상담 자동 삭제(매일 03:40 KST, GitHub Actions)가 이 사이트를 부를 때 쓰는 비밀값입니다. 사이트에는 해시만 저장합니다.</p>';
		if ( null !== $secret ) {
			echo '<div class="notice notice-warning"><p><strong>이 값은 지금 한 번만 보입니다.</strong> GitHub 저장소 Settings → Secrets and variables → Actions 의 <code>IWELL_CRON_SECRET</code> 에 넣으세요. 옛 값은 이제 쓸 수 없습니다.</p></div>';
			printf( '<p><input type="text" id="iwell-cron-secret" class="large-text code" readonly value="%s" onfocus="this.select()"></p>', esc_attr( $secret ) );
		}
		if ( $has ) {
			printf( '<p id="iwell-cron-secret-status">상태: 설정됨 (만든 시각 %s)</p>', esc_html( $created ? wp_date( 'Y-m-d H:i:s T', $created ) : '알 수 없음' ) );
		} else {
			echo '<p id="iwell-cron-secret-status">상태: 없음 — 만들기 전에는 자동 삭제 호출이 모두 거부됩니다(401).</p>';
		}
		echo '<form method="post">';
		wp_nonce_field( self::NONCE );
		echo '<input type="hidden" name="iwell_cron_secret_new" value="1">';
		submit_button( '크론 비밀값 새로 만들기', $has ? 'secondary' : 'primary', 'submit', false );
		echo '</form>';
		Links::settingsSection();
		echo '</div>';
	}
}
