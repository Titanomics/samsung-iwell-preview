<?php
/**
 * 상담·예약 바로가기(수정 1차 — 대표 지시 2026-11-19 "상담 예약문의도 네이버나 카카오플친으로 되게끔").
 *
 * 사이트 안에서 상담 글을 받지 않고(비밀 상담 게시판은 만들지 않음 — 대표 결정 2026-11-19), 병원이 쓰는 네이버·카카오 창구로 보낸다.
 * 주소 3칸 = 옵션 iwell_consult_links {naver_booking, naver_talk, kakao_channel}. 화면(테마 예약 단추·하단 바·퀵바·/consult/ 안내)은
 * items() 만 읽는다 — 값이 있는 칸만 단추가 되고, 하나도 없으면 테마는 전화 단추만 그린다.
 *
 * 주소 규칙(sanitize — 저장할 때와 읽을 때 둘 다): https · 칸마다 허용 호스트 하나(대소문자 무관, 정확히 같음 — 하위 도메인·비슷한 이름 거부)
 *   · 사용자 정보·포트 없음 · 공백·제어문자·따옴표·꺾쇠 없음. 빈 값 = 그 칸 지움.
 * 저장(save): manage_options 만. 하나라도 규칙 밖이면 세 칸 모두 저장하지 않는다(옛 값 그대로 — 닫힌 쪽).
 * 화면: 설정 → iwell-core 설정(CronSecret 화면) 아래 "상담 바로가기" 칸 3개(settingsSection — POST + nonce).
 * 병원 실제 주소는 아직 모른다(runbook §7) — 기본값 없음. 다른 병원(코르디아) 주소를 넣지 않는다.
 */

namespace Iwell\Core\Consult;

defined( 'ABSPATH' ) || exit;

final class Links {
	public const OPTION     = 'iwell_consult_links';
	public const NONCE      = 'iwell_consult_links';
	public const CAPABILITY = 'manage_options';

	/** 칸 → [허용 호스트, 화면 이름(단추), 짧은 이름(하단 바), 아이콘], 하단 바에 하나만 낼 때의 우선순위 순. */
	public const FIELDS = array(
		'naver_booking' => array( 'booking.naver.com', '네이버 예약', '네이버 예약', 'calendar' ),
		'naver_talk'    => array( 'talk.naver.com', '네이버 톡톡', '톡톡', 'chat' ),
		'kakao_channel' => array( 'pf.kakao.com', '카카오톡 채널', '카카오톡', 'chat' ),
	);

	/** 하단 바 한 칸 우선순위(예약 → 카카오 → 톡톡). */
	private const PRIMARY = array( 'naver_booking', 'kakao_channel', 'naver_talk' );

	/**
	 * 주소 검사. 맞으면 정리한 주소(앞뒤 공백 뗌·호스트 소문자), 빈 값이면 '', 규칙 밖이면 null.
	 */
	public static function sanitize( string $key, mixed $value ): ?string {
		if ( ! isset( self::FIELDS[ $key ] ) || ! is_string( $value ) ) {
			return null;
		}
		$value = trim( $value, " \t" );
		if ( '' === $value ) {
			return '';
		}
		// 공백·제어문자·따옴표·꺾쇠·역슬래시 — 주소 안에 오면 거부(속성·HTML 탈출, 브라우저 정규화 차이).
		if ( 1 === preg_match( '~[\s\x00-\x1f\x7f"\'<>\\\\`]~', $value ) || 1 !== preg_match( '~^https://~i', $value ) ) {
			return null;
		}
		$parts = wp_parse_url( $value );
		if ( ! is_array( $parts ) || 'https' !== strtolower( (string) ( $parts['scheme'] ?? '' ) ) ) {
			return null;
		}
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['port'] ) ) {
			return null;
		}
		$host = strtolower( (string) ( $parts['host'] ?? '' ) );
		if ( self::FIELDS[ $key ][0] !== $host ) {
			return null;
		}
		// 호스트 부분만 소문자로(경로·쿼리는 그대로 — 대소문자를 구분하는 주소가 있다).
		$rest = substr( $value, strlen( 'https://' ) + strlen( $host ) );
		if ( '' !== $rest && ! in_array( $rest[0], array( '/', '?', '#' ), true ) ) {
			return null;
		}
		return 'https://' . $host . $rest;
	}

	/** 저장된 칸 값(규칙 밖 값·모르는 키는 버림, 빈 칸 포함). @return array<string, string> */
	public static function values(): array {
		$saved = get_option( self::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		$out   = array();
		foreach ( array_keys( self::FIELDS ) as $key ) {
			$clean = self::sanitize( $key, $saved[ $key ] ?? '' );
			$out[ $key ] = null === $clean ? '' : $clean;
		}
		return $out;
	}

	/**
	 * 단추가 될 칸(값이 있는 것만, FIELDS 순).
	 *
	 * @return list<array{key: string, label: string, short: string, icon: string, url: string}>
	 */
	public static function items(): array {
		$items = array();
		foreach ( self::values() as $key => $url ) {
			if ( '' !== $url ) {
				$items[] = array(
					'key'   => $key,
					'label' => self::FIELDS[ $key ][1],
					'short' => self::FIELDS[ $key ][2],
					'icon'  => self::FIELDS[ $key ][3],
					'url'   => $url,
				);
			}
		}
		return $items;
	}

	/** 하단 바 한 칸 — 우선순위(예약 → 카카오 → 톡톡)의 첫 값. 없으면 null. */
	public static function primary(): ?array {
		$items = array_column( self::items(), null, 'key' );
		foreach ( self::PRIMARY as $key ) {
			if ( isset( $items[ $key ] ) ) {
				return $items[ $key ];
			}
		}
		return null;
	}

	/**
	 * 칸 3개 저장 — 관리자만. 하나라도 규칙 밖이면 아무것도 저장하지 않는다. 받은 배열에 없는 칸은 빈 값.
	 *
	 * @param array<string, mixed> $input
	 */
	public static function save( array $input ): bool {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return false;
		}
		$clean = array();
		foreach ( array_keys( self::FIELDS ) as $key ) {
			$value = self::sanitize( $key, $input[ $key ] ?? '' );
			if ( null === $value ) {
				return false;
			}
			$clean[ $key ] = $value;
		}
		update_option( self::OPTION, $clean, false );
		return true;
	}

	/** 설정 화면 구역(설정 → iwell-core 설정 — CronSecret::page 가 부른다). POST 는 nonce 확인 뒤 save(). */
	public static function settingsSection(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$status = '';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['iwell_consult_links_save'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			check_admin_referer( self::NONCE );
			$input = isset( $_POST['iwell_consult_links'] ) && is_array( $_POST['iwell_consult_links'] ) ? wp_unslash( $_POST['iwell_consult_links'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitize() 가 칸마다 검사.
			$status = self::save( (array) $input )
				? '<div class="notice notice-success" id="iwell-consult-links-status"><p>저장했습니다.</p></div>'
				: '<div class="notice notice-error" id="iwell-consult-links-status"><p>저장하지 않았습니다 — https:// 로 시작하고 칸마다 정해진 주소(booking.naver.com · talk.naver.com · pf.kakao.com)만 넣을 수 있습니다. 옛 값을 그대로 둡니다.</p></div>';
		}
		echo '<h2 id="iwell-consult-links">상담 바로가기</h2>';
		echo '<p>홈·예약 단추·하단 바·상담·예약 안내(/consult/)에 나오는 바로가기입니다. 값이 있는 칸만 단추가 되고, 모두 비우면 전화 단추만 보입니다.</p>';
		echo $status; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 위 고정 문구.
		echo '<form method="post"><table class="form-table" role="presentation"><tbody>';
		wp_nonce_field( self::NONCE );
		foreach ( self::values() as $key => $url ) {
			printf(
				'<tr><th scope="row"><label for="iwell-consult-%1$s">%2$s</label></th><td><input type="url" class="regular-text code" id="iwell-consult-%1$s" name="iwell_consult_links[%1$s]" value="%3$s" placeholder="https://%4$s/…"><p class="description">https://%4$s/ 로 시작하는 주소만</p></td></tr>',
				esc_attr( $key ),
				esc_html( self::FIELDS[ $key ][1] ),
				esc_attr( $url ),
				esc_html( self::FIELDS[ $key ][0] )
			);
		}
		echo '</tbody></table>';
		echo '<input type="hidden" name="iwell_consult_links_save" value="1">';
		submit_button( '상담 바로가기 저장', 'primary', 'submit', false, array( 'id' => 'iwell-consult-links-save' ) );
		echo '</form>';
	}
}
