<?php
/**
 * 다음(카카오) 웹마스터도구 사이트 인증 줄(코디네이터 지시 2026-11-26 — 대표용 설치 매뉴얼 확인).
 *
 * 다음 웹마스터도구는 사이트 소유를 robots.txt 안의 한 줄로 확인한다 — 형식 `#DaumWebMasterTool:{64자 16진수}:{인증 문자열}`
 * (예: 2026-07 공개 글의 `#DaumWebMasterTool:0a11…4d3b:2nG8ivfYj6diA57DvzIb3A==`). 우리 robots.txt 는 Crawl::robots 가 만들고 설정 파일의
 * '#' 줄을 지우므로 관리 화면으로는 넣을 수 없었다 → 관리자가 이 한 줄만 넣는 칸을 둔다.
 *
 * 형식 검사(sanitize — 저장할 때와 내보낼 때 둘 다): 앞뒤 공백을 뗀 한 줄이 `#DaumWebMasterTool:` 로 시작하고(앞의 '#' 를 빼고 붙여 넣으면
 * 붙여 준다) 그 뒤는 영문·숫자·`+ / = : _ -` 만 8~200자. 줄바꿈·공백·다른 지시문(User-agent·Disallow·Sitemap 등)은 넣을 수 없다 —
 * 결과는 늘 '#' 주석 한 줄이라 크롤러 규칙을 바꾸지 못한다. 빈 값 = 줄 없음.
 * 저장(save): manage_options 만, 규칙 밖이면 저장하지 않는다(옛 값 그대로 — 닫힌 쪽).
 * 화면: 설정 → iwell-core 설정 아래 "다음 웹마스터도구 인증"(settingsSection — POST + nonce).
 * 내보내기: Crawl::robots 가 공개 사이트(blog_public=1)일 때 맨 첫 줄에 넣는다. 검색 엔진 차단 중에는 robots.txt 를 코어 그대로 두므로
 * 인증 줄도 나가지 않는다 — 공개로 바꾼 뒤 다음 웹마스터도구에서 인증한다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class DaumVerify {
	public const OPTION     = 'iwell_daum_webmaster_line';
	public const NONCE      = 'iwell_daum_webmaster';
	public const CAPABILITY = 'manage_options';
	public const PREFIX     = '#DaumWebMasterTool:';

	/** 맞으면 정리한 한 줄('#' 붙임), 빈 값이면 '', 규칙 밖이면 null. */
	public static function sanitize( mixed $value ): ?string {
		if ( ! is_string( $value ) ) {
			return null;
		}
		$value = trim( $value, " \t" );
		if ( '' === $value ) {
			return '';
		}
		if ( str_starts_with( $value, 'DaumWebMasterTool:' ) ) {
			$value = '#' . $value;
		}
		return 1 === preg_match( '~^#DaumWebMasterTool:[0-9A-Za-z+/=:_-]{8,200}\z~', $value ) ? $value : null;
	}

	/** 저장된 줄(규칙 밖이면 ''). */
	public static function line(): string {
		return self::sanitize( get_option( self::OPTION, '' ) ) ?? '';
	}

	/** 관리자만, 규칙 안이면 저장(빈 값 = 지움). */
	public static function save( mixed $value ): bool {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return false;
		}
		$clean = self::sanitize( $value );
		if ( null === $clean ) {
			return false;
		}
		update_option( self::OPTION, $clean, false );
		return true;
	}

	/** 설정 화면 구역(설정 → iwell-core 설정 — Consult\CronSecret::page 가 부른다). */
	public static function settingsSection(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$status = '';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['iwell_daum_webmaster_save'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			check_admin_referer( self::NONCE );
			$raw    = isset( $_POST['iwell_daum_webmaster_line'] ) && is_string( $_POST['iwell_daum_webmaster_line'] ) ? (string) wp_unslash( $_POST['iwell_daum_webmaster_line'] ) : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitize() 가 검사.
			$status = self::save( $raw )
				? '<div class="notice notice-success" id="iwell-daum-webmaster-status"><p>저장했습니다. robots.txt 맨 위에 그 한 줄이 나갑니다(사이트가 검색 엔진에 공개일 때).</p></div>'
				: '<div class="notice notice-error" id="iwell-daum-webmaster-status"><p>저장하지 않았습니다 — 다음 웹마스터도구가 준 "#DaumWebMasterTool:…" 한 줄만 넣을 수 있습니다(공백·줄바꿈·다른 지시문 불가). 옛 값을 그대로 둡니다.</p></div>';
		}
		echo '<h2 id="iwell-daum-webmaster">다음 웹마스터도구 인증</h2>';
		echo '<p>다음(카카오) 웹마스터도구가 사이트 인증용으로 준 한 줄을 그대로 붙여 넣습니다. robots.txt 맨 위에 그대로 나가며, 비우면 나가지 않습니다. 사이트가 검색 엔진에 공개(설정 → 읽기)일 때만 robots.txt 에 나옵니다.</p>';
		echo $status; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 위 고정 문구.
		echo '<form method="post"><table class="form-table" role="presentation"><tbody>';
		wp_nonce_field( self::NONCE );
		printf(
			'<tr><th scope="row"><label for="iwell-daum-webmaster-line">인증 줄</label></th><td><input type="text" class="large-text code" id="iwell-daum-webmaster-line" name="iwell_daum_webmaster_line" value="%s" placeholder="#DaumWebMasterTool:…" maxlength="220"><p class="description">"#DaumWebMasterTool:" 로 시작하는 한 줄만</p></td></tr>',
			esc_attr( self::line() )
		);
		echo '</tbody></table>';
		echo '<input type="hidden" name="iwell_daum_webmaster_save" value="1">';
		submit_button( '인증 줄 저장', 'primary', 'submit', false, array( 'id' => 'iwell-daum-webmaster-save' ) );
		echo '</form>';
	}
}
