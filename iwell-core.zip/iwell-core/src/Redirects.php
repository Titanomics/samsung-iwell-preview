<?php
/**
 * 옛 주소 301(Task 10) — 옛 사이트(samsungiwell.com PC /sub/·모바일 /m/·공지 상세 ?ptype=view&idx=…) → 새 주소.
 *
 * 표: config/redirects.csv, 열 from_path,from_query,to_path(매핑 근거는 보고서 logs/t10-report.md 매핑표).
 *   from_query 빈칸 = 쿼리 없을 때만 · `*` = 쿼리 무시(없어도·아무 쿼리) · 그 밖 = 정확 일치(키·값 같음, 순서 무관, 더 붙으면 아님).
 *   같은 경로에 여러 행이면 정확 일치 > 빈칸(쿼리 없음) > `*`, 같은 종류는 위 행이 먼저. 경로 비교는 대소문자·끝 / 무관.
 * match() = 표의 대상에 공개 목적지 규칙(계획 Global Constraints — Nav::publicUrl: 대상이 공개면 그 주소, 아니면 그 1차 허브(공개일 때), 아니면 홈)을
 *   씌운 홈 기준 경로('/growth/'). 게시판 대상(/notices/·/columns/)은 게시 글이 있을 때만 열림(Routes::boardOpen) — 닫히면 소속 허브 → 홈.
 * redirect()(template_redirect 2 — Routes 옛 /category/ 301(0)·빈 게시판 404(1) 다음, redirect_canonical(10) 보다 먼저):
 *   **요청이 404 일 때만** 본다 → 실제 있는 페이지·글·목록(새 주소)은 건드리지 않는다. 옛 쿼리는 새 주소에 붙이지 않는다.
 */

namespace Iwell\Core;

defined( 'ABSPATH' ) || exit;

final class Redirects {
	public const HEADER = array( 'from_path', 'from_query', 'to_path' );

	private const PRIORITY = 2;

	/** @var list<array{from_path: string, from_query: string, to_path: string}>|null 요청 안 기억(파일 한 번 읽기). */
	private static ?array $rows = null;

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'redirect' ), self::PRIORITY );
	}

	public static function csvPath(): string {
		return dirname( __DIR__ ) . '/config/redirects.csv';
	}

	/** @return list<array{from_path: string, from_query: string, to_path: string}> */
	public static function rows(): array {
		if ( null === self::$rows ) {
			$file       = self::csvPath();
			$csv        = is_readable( $file ) ? (string) file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- 플러그인 안 설정 파일.
			self::$rows = self::parse( $csv );
		}
		return self::$rows;
	}

	/**
	 * CSV 글 → 행. 첫 줄이 머리줄(from_path,from_query,to_path)이 아니면 0행. 빈 줄·열 수가 다른 줄·from/to 가 / 로 시작하지 않는 줄은 건너뛴다.
	 *
	 * @return list<array{from_path: string, from_query: string, to_path: string}>
	 */
	public static function parse( string $csv ): array {
		$lines = preg_split( '/\r\n|\r|\n/', preg_replace( '/^\xEF\xBB\xBF/', '', $csv ) );
		$lines = array_values( array_filter( $lines, static fn( string $l ): bool => '' !== trim( $l ) ) );
		if ( array() === $lines || self::HEADER !== array_map( 'trim', str_getcsv( $lines[0], ',', '"', '' ) ) ) {
			return array();
		}
		$rows = array();
		foreach ( array_slice( $lines, 1 ) as $line ) {
			$f = array_map( 'trim', str_getcsv( $line, ',', '"', '' ) );
			if ( 3 !== count( $f ) || ! str_starts_with( $f[0], '/' ) || ! str_starts_with( $f[2], '/' ) ) {
				continue;
			}
			$rows[] = array_combine( self::HEADER, $f );
		}
		return $rows;
	}

	/**
	 * 표에서 대상 찾기(공개 규칙 전 — 표에 적힌 to_path 그대로).
	 *
	 * @param list<array{from_path: string, from_query: string, to_path: string}> $rows
	 * @param array<string, mixed>                                               $query 요청 쿼리($_GET 꼴).
	 */
	public static function find( array $rows, string $path, array $query ): ?string {
		$key   = self::key( $path );
		$exact = null;
		$none  = null;
		$any   = null;
		foreach ( $rows as $row ) {
			if ( self::key( $row['from_path'] ) !== $key ) {
				continue;
			}
			if ( '*' === $row['from_query'] ) {
				$any ??= $row['to_path'];
			} elseif ( '' === $row['from_query'] ) {
				if ( array() === $query ) {
					$none ??= $row['to_path'];
				}
			} elseif ( null === $exact && self::sameQuery( $row['from_query'], $query ) ) {
				$exact = $row['to_path'];
			}
		}
		return $exact ?? $none ?? $any;
	}

	/**
	 * 옛 주소 → 보낼 새 경로(홈 기준, '/growth/' 꼴). 표에 없으면 null. 대상에는 공개 목적지 규칙을 씌운다(대상 → 1차 허브 → 홈).
	 *
	 * @param string               $path  요청 경로(홈 기준, '/sub/sub04_00.html').
	 * @param array<string, mixed> $query 요청 쿼리.
	 */
	public static function match( string $path, array $query ): ?string {
		$to = self::find( self::rows(), $path, $query );
		if ( null === $to ) {
			return null;
		}
		$url  = Nav::publicUrl( $to );
		$home = untrailingslashit( home_url() );
		$rel  = str_starts_with( $url, $home ) ? substr( $url, strlen( $home ) ) : (string) wp_parse_url( $url, PHP_URL_PATH );
		return '' === $rel ? '/' : $rel;
	}

	/** template_redirect 2: 404 인 옛 주소 → 301. */
	public static function redirect(): void {
		if ( ! is_404() ) {
			return; // 실제 있는 페이지·글·목록은 그대로.
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 표 비교에만 쓴다.
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		if ( '' !== $base && str_starts_with( $path, $base . '/' ) ) {
			$path = substr( $path, strlen( $base ) );
		}
		$query = array();
		wp_parse_str( (string) wp_parse_url( $uri, PHP_URL_QUERY ), $query );
		$target = self::match( $path, $query );
		if ( null === $target || self::key( $target ) === self::key( $path ) ) {
			return;
		}
		wp_safe_redirect( home_url( $target ), 301, 'iwell-core' );
		exit;
	}

	/** 경로 비교 열쇠 — 퍼센트 풀기·소문자·끝 / 떼기(홈은 '/'). */
	private static function key( string $path ): string {
		$path = strtolower( rawurldecode( $path ) );
		$path = '/' . trim( $path, '/' );
		return $path;
	}

	/** @param array<string, mixed> $query */
	private static function sameQuery( string $want, array $query ): bool {
		$expected = array();
		wp_parse_str( $want, $expected );
		return self::normQuery( $expected ) === self::normQuery( $query );
	}

	/**
	 * @param array<mixed> $q
	 * @return array<mixed>
	 */
	private static function normQuery( array $q ): array {
		ksort( $q, SORT_STRING );
		foreach ( $q as $k => $v ) {
			$q[ $k ] = is_array( $v ) ? self::normQuery( $v ) : (string) $v;
		}
		return $q;
	}
}
