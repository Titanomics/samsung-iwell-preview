<?php
/**
 * 재승인 필요 페이지 목록(Task 6 수정 10 결정 5 — 운영).
 *
 * 승인 지문이 "화면 결과"(Fingerprint)라서 워드프레스·플러그인·테마 업데이트가 이미지 주소·srcset·링크·글자 결과를 바꾸면 그 결과를 쓰는 승인 페이지의
 * 검토 표시가 다음 출력에서 풀린다(원장이 승인한 화면이 아니므로 — 원칙 그대로). 관리자가 그 목록을 보는 곳:
 *   - 관리 화면 도구 → "원장 검토 점검"(manage_options)
 *   - WP-CLI: wp iwell review-check [--format=table|json|csv]
 * 둘 다 rows() 하나를 쓴다. 상태:
 *   lapsed    승인 지문 불일치로 해제됐고(Fingerprint::LAPSE_KEY) 아직 원장이 다시 승인하지 않았다. 원장 승인 기록이 걸린 페이지의 지금 결과가 승인 지문과
 *             다르면 이 계산이 그 자리에서 해제한다(수정 13 Ruling 2 ② — 편집 패널 REST 와 같은 PageMeta::lapseFound. 공개 응답은 더 이상 해제하지 않으므로
 *             "다음 출력에서 해제됨"으로 미루지 않는다)
 *   live      승인은 그대로(승인 계산 = 승인 지문)인데 실제로 보낸 공개 응답이 승인과 달랐다(수정 13 Ruling 3 — Fingerprint::LIVE_KEY 알림: 최근 시각·
 *             다른 조각·요청 주소 앞부분). 그 응답은 검토 표시 없이 나갔다(닫힌 쪽). 예: 본문 쪽 나눔 2쪽 이후, 쿼리가 출력에 들어가는 페이지의 추적 인자
 * parts = 바뀐 지문 조각(out:body = 본문 결과, out:featured = 대표 이미지, out:sources = 출처, out:title, meta:{키}, expand:{SEO}, attachment:{ID}, post,
 * format = 수정 10 이전 지문 형식, unresolved = 지금 검토 불가 본문). 계산은 캐시를 쓰지 않고 새로 렌더한다(코드 배포처럼 쓰기 없는 변화도). 승인 계산은
 * 고정 문맥(Fingerprint::fixed — 익명·요청 인자·쿠키 없음)이라 누가 이 화면을 열어도 같다. 다름을 찾은 페이지의 저장된 지문 캐시도 지운다(수정 11 C7-1 ②).
 */

namespace Iwell\Core;

use WP_Post;

defined( 'ABSPATH' ) || exit;

final class ReviewAudit {
	public const PAGE = 'iwell-review-check';

	public static function register(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ) );
		if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( '\WP_CLI' ) ) {
			\WP_CLI::add_command( 'iwell review-check', array( self::class, 'cli' ) );
		}
	}

	/**
	 * 재승인이 필요한 페이지(고정 페이지·예약 승인 수정안).
	 *
	 * @return list<array{id: int, title: string, status: string, state: string, parts: string[], at: string, edit: string}>
	 */
	public static function rows(): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- 운영 점검(관리자만).
		$ids = array_map(
			'intval',
			$wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} m ON m.post_id = p.ID
					WHERE p.post_type = %s AND p.post_status NOT IN ('auto-draft', 'inherit', 'trash') AND m.meta_key IN (%s, %s, %s)",
					PageMeta::POST_TYPE,
					Seal::KEY,
					Fingerprint::LAPSE_KEY,
					PageMeta::PENDING_KEY
				)
			)
		);
		// phpcs:enable
		sort( $ids );
		$rows = array();
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			if ( PageMeta::hasSealedApproval( $post ) ) {
				$parts = Fingerprint::freshly( static fn(): array => Seal::valid( $post ) ? array() : Seal::diff( $post ) );
				if ( array() === $parts ) {
					$live = get_post_meta( $id, Fingerprint::LIVE_KEY, true );
					if ( is_array( $live ) && (int) ( $live['t'] ?? 0 ) > 0 ) {
						$rows[] = self::row( $post, 'live', array_map( 'strval', (array) ( $live['parts'] ?? array() ) ), (string) ( $live['at'] ?? '' ), (string) ( $live['url'] ?? '' ) );
					}
					continue;
				}
				// 수정 13 Ruling 2 ②: 승인 계산(고정 문맥)이 다르다고 보면 그 자리에서 해제(편집 패널 REST 와 같은 함수) — 공개 응답은 해제하지 않으므로 미루지 않는다.
				// 캐시 열쇠(세대·입력 값)에 못 넣는 워드프레스 밖 변화(파일 복사 배포·옵션 직접 SQL)도 이 화면을 열면 즉시. 지문 캐시도 지운다(수정 11 C7-1 ②).
				Fingerprint::forget( $post->ID );
				PageMeta::lapseFound( $post, $parts );
			}
			$lapsed = get_post_meta( $id, Fingerprint::LAPSE_KEY, true );
			if ( is_array( $lapsed ) ) {
				$rows[] = self::row( $post, 'lapsed', array_map( 'strval', (array) ( $lapsed['parts'] ?? array() ) ), (string) ( $lapsed['at'] ?? '' ) );
			}
		}
		return $rows;
	}

	private static function row( WP_Post $post, string $state, array $parts, string $at, string $url = '' ): array {
		return array(
			'id'     => $post->ID,
			'title'  => (string) $post->post_title,
			'status' => (string) $post->post_status . ( '' !== (string) $post->post_mime_type ? '/' . $post->post_mime_type : '' ),
			'state'  => $state,
			'parts'  => array_values( $parts ),
			'at'     => $at,
			'url'    => $url,
			'edit'   => (string) get_edit_post_link( $post->ID, 'raw' ),
		);
	}

	public static function menu(): void {
		add_management_page( '원장 검토 점검', '원장 검토 점검', 'manage_options', self::PAGE, array( self::class, 'screen' ) );
	}

	/** 관리 화면 도구 → 원장 검토 점검. */
	public static function screen(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$rows  = self::rows();
		$label = array(
			'lapsed' => '해제됨',
			'live'   => '공개 응답이 승인과 다름',
		);
		echo '<div class="wrap"><h1>원장 검토 점검</h1><p>원장 승인 뒤 공개 화면 결과(본문·대표 이미지·출처·SEO)가 달라져 원장 재승인이 필요한 페이지입니다. 워드프레스·플러그인·테마 업데이트 뒤 이 목록을 확인하고, 원장이 내용을 보고 다시 게시(승인)하면 목록에서 빠집니다. "공개 응답이 승인과 다름"은 승인은 그대로지만 그 주소의 공개 응답(본문 2쪽 이후·추적 인자가 출력에 들어가는 페이지 등)이 승인한 화면과 달라 검토 표시 없이 나갔다는 알림입니다(페이지당 10분에 한 번 갱신).</p>';
		if ( array() === $rows ) {
			echo '<p><strong>재승인이 필요한 페이지가 없습니다.</strong></p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>ID</th><th>제목</th><th>상태</th><th>검토</th><th>바뀐 결과</th><th>시각</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			printf(
				'<tr><td>%d</td><td><a href="%s">%s</a></td><td>%s</td><td>%s</td><td><code>%s</code></td><td>%s</td></tr>',
				(int) $r['id'],
				esc_url( $r['edit'] ),
				esc_html( '' !== $r['title'] ? $r['title'] : '(제목 없음)' ),
				esc_html( $r['status'] ),
				esc_html( ( $label[ $r['state'] ] ?? $r['state'] ) . ( 'live' === $r['state'] ? '(주소 ' . $r['url'] . ')' : '' ) ),
				esc_html( implode( ', ', $r['parts'] ) ),
				esc_html( $r['at'] )
			);
		}
		echo '</tbody></table></div>';
	}

	/**
	 * 재승인 필요 페이지 목록.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : table, json, csv
	 * ---
	 * default: table
	 * ---
	 *
	 * @param array $args
	 * @param array $assoc
	 */
	public static function cli( $args, $assoc ): void {
		$rows = array_map(
			static fn( array $r ): array => array( 'parts' => implode( ',', $r['parts'] ) ) + $r,
			self::rows()
		);
		\WP_CLI\Utils\format_items( (string) ( $assoc['format'] ?? 'table' ), $rows, array( 'id', 'title', 'status', 'state', 'parts', 'at', 'url' ) );
	}
}
