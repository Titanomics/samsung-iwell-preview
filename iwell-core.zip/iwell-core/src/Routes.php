<?php
/**
 * 주소 구조·빈 허브 비공개(Task 9).
 *
 * 고유주소(활성화 때 — install): 고정 페이지 /%pagename%/(워드프레스 계층 그대로), 글 /%category%/%postname%/ → 공지 /notices/{slug}/·칼럼 /columns/{slug}/.
 * 게시판 목록: 재작성 ^(notices|columns)/?$ · ^(notices|columns)/page/(\d+)/?$ → 카테고리 목록(맨 앞 — 고정 페이지 규칙보다 먼저), 카테고리 주소(term_link)도
 *   /notices/·/columns/ → 메뉴·브레드크럼·사이트맵이 /category/ 를 내지 않는다. 옛 /category/(notices|columns)(/page/N)/ → 새 주소 301(쿼리 유지).
 * 빈 게시판(코디네이터 2026-11-15 ③): 그 카테고리에 게시 글이 0건이면 목록 주소 404, Nav 고정 항목(iwell/nav/route_available)도 닫힘 → 메뉴·더보기·llms 에 없음.
 *   1건 이상이면 열림(설계서 §2 빈 메뉴 금지와 같은 뜻).
 * 빈 허브(Task 8 Codex F4 — 계획 L180·194 "허브는 하위가 게시될 때까지 비공개", 코디네이터 ② 승인):
 *   허브 = 템플릿 page-hub 고정 페이지(허브 생성 도구가 만든 것·편집기에서 고른 것 모두). 게시 상태인데 바로 아래 게시 하위가 0 → 비공개(private) + 표식
 *   HUB_WAITING. 표식 있는 비공개 허브에 하위가 게시되면 게시, 하위가 모두 내려가면(초안·휴지통·삭제·다른 부모로 이동) 다시 비공개.
 *   표식 없는 허브(사람이 손으로 초안·비공개로 둔 것, 직원이 만든 초안)는 자동 게시하지 않는다 — 직원은 비공개 페이지를 고칠 권한이 없어(Roles)
 *   대기 중 허브 본문을 바꿀 수 없다 → 원장 승인 우회 없음.
 *   전환은 워드프레스 경로(wp_update_post — 상태만)로, 그 순간만 사용자 0(코디네이터 결정: DB 직접 쓰기 금지 — 캐시·세대 훅을 건너뛴 결함 C7-1).
 *   사용자 0 은 원장이 아니라 검토 기록이 생기지 않는다(PageMeta::isReviewer). 사용자 0 은 unfiltered_html 이 없어 저장 때 본문을 kses 로 다시 거르므로
 *   그 순간만 kses 를 떼고(상태만 바꾸는 저장이 승인된 본문을 바꾸지 않게), 끝나면 원래 사용자·들어오기 전 kses 상태 그대로 되돌린다
 *   (수정 1 C04 — 무조건 kses_init 하지 않는다).
 * 비밀번호가 걸린 글·페이지(post_password <> '')는 게시판 열림·허브 하위의 근거로 세지 않는다(수정 1 C03 — 머리 메뉴 Nav 표시는 Task 7 범위라 그대로).
 */

namespace Iwell\Core;

use WP_Post;
use WP_Term;

defined( 'ABSPATH' ) || exit;

final class Routes {
	public const PERMALINK = '/%category%/%postname%/';

	/** 게시판 카테고리 slug = 목록 주소(Nav::ROUTES 와 같다). */
	public const BOARDS = array( 'notices', 'columns' );

	public const HUB_TEMPLATE = 'page-hub';

	/** 자동 비공개 표식(내부 보호 메타 — REST·편집기 노출 없음). '1' = 하위가 게시되면 자동 게시. */
	public const HUB_WAITING = '_iwell_hub_waiting';

	/** 재작성 규칙이 바뀌면 올린다 → 다음 요청에서 규칙 다시 만들기(활성화 없이 파일만 바꾼 업데이트 대비). */
	public const VERSION        = '1';
	public const VERSION_OPTION = 'iwell_routes_version';

	/** iwell/nav/route_available 우선순위 — 시험·다른 코드(10)가 이 값 위에서 덮을 수 있게 앞에. */
	private const ROUTE_PRIORITY = 5;

	/** @var array<string, bool> 요청 안 게시판 열림 기억(글 저장·상태 변경 때 비움). */
	private static array $open = array();

	/** @var array<int, true> 지금 상태를 바꾸는 허브(되부름 막기). */
	private static array $syncing = array();

	public static function register(): void {
		add_action( 'init', array( self::class, 'addRules' ) );
		add_action( 'wp_loaded', array( self::class, 'maybeFlush' ) );
		add_filter( 'query_vars', array( self::class, 'queryVars' ) );
		add_filter( 'term_link', array( self::class, 'termLink' ), 10, 3 );
		add_action( 'template_redirect', array( self::class, 'redirectLegacy' ), 0 );
		add_action( 'template_redirect', array( self::class, 'closeEmptyBoard' ), 1 );
		add_filter( 'iwell/nav/route_available', array( self::class, 'routeAvailable' ), self::ROUTE_PRIORITY, 2 );
		foreach ( array( 'transition_post_status', 'clean_post_cache', 'set_object_terms', 'deleted_post' ) as $hook ) {
			add_action( $hook, array( self::class, 'flush' ) );
		}
		// 빈 허브: 저장이 끝난 뒤(REST 는 템플릿·메타까지 쓴 뒤 — wp_after_insert_post) 그 페이지·부모·옛 부모를 다시 본다. 삭제는 deleted_post.
		add_action( 'wp_after_insert_post', array( self::class, 'afterSave' ), 100, 4 );
		add_action( 'deleted_post', array( self::class, 'afterDelete' ), 10, 2 );
	}

	/** 활성화: 고유주소·규칙·허브 상태 맞추기. */
	public static function install(): void {
		global $wp_rewrite;
		if ( self::PERMALINK !== get_option( 'permalink_structure' ) ) {
			$wp_rewrite->set_permalink_structure( self::PERMALINK );
		}
		self::addRules();
		flush_rewrite_rules();
		update_option( self::VERSION_OPTION, self::VERSION );
		self::syncAllHubs();
	}

	public static function addRules(): void {
		$boards = implode( '|', self::BOARDS );
		add_rewrite_rule( "^($boards)/?$", 'index.php?category_name=$matches[1]', 'top' );
		add_rewrite_rule( "^($boards)/page/(\\d+)/?$", 'index.php?category_name=$matches[1]&paged=$matches[2]', 'top' );
		add_rewrite_rule( '^llms\.txt$', 'index.php?' . Crawl::QUERY_VAR . '=1', 'top' );
	}

	/** 규칙 판이 바뀐 코드가 올라왔으면(활성화 없이) 한 번 다시 만든다. */
	public static function maybeFlush(): void {
		if ( self::VERSION !== get_option( self::VERSION_OPTION ) ) {
			flush_rewrite_rules( false );
			update_option( self::VERSION_OPTION, self::VERSION );
		}
	}

	public static function queryVars( $vars ): array {
		$vars   = is_array( $vars ) ? $vars : array();
		$vars[] = Crawl::QUERY_VAR;
		return $vars;
	}

	/** 게시판 카테고리 주소 = /notices/·/columns/. */
	public static function termLink( $url, $term, $taxonomy ) {
		if ( 'category' === $taxonomy && $term instanceof WP_Term && in_array( $term->slug, self::BOARDS, true ) ) {
			return home_url( '/' . $term->slug . '/' );
		}
		return $url;
	}

	/**
	 * 옛 목록 주소 → 새 주소(앞뒤 / 붙은 경로). 'category/notices(/page/N)' 만 — 다른 카테고리·피드는 null.
	 *
	 * @param string $request 홈 기준 경로(WP::$request — 앞뒤 / 없음).
	 */
	public static function legacyTarget( string $request ): ?string {
		$base = trim( (string) get_option( 'category_base' ), '/' );
		$base = '' === $base ? 'category' : $base;
		$re   = '#^' . preg_quote( $base, '#' ) . '/(' . implode( '|', self::BOARDS ) . ')(?:/page/([0-9]+))?$#';
		if ( 1 !== preg_match( $re, trim( $request, '/' ), $m ) ) {
			return null;
		}
		return '/' . $m[1] . '/' . ( isset( $m[2] ) && '' !== $m[2] ? 'page/' . $m[2] . '/' : '' );
	}

	/** template_redirect 0: 옛 /category/(notices|columns)… → 301(쿼리 유지). redirect_canonical(10)보다 먼저. */
	public static function redirectLegacy(): void {
		global $wp;
		$target = self::legacyTarget( (string) ( $wp->request ?? '' ) );
		if ( null === $target ) {
			return;
		}
		$query = isset( $_SERVER['QUERY_STRING'] ) ? (string) wp_unslash( $_SERVER['QUERY_STRING'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- 같은 사이트 주소에 그대로 붙인다.
		wp_safe_redirect( home_url( $target ) . ( '' === $query ? '' : '?' . $query ), 301, 'iwell-core' );
		exit;
	}

	/** template_redirect 1: 게시 글 0건 게시판 목록 = 404(빈 목록을 공개하지 않는다). */
	public static function closeEmptyBoard(): void {
		if ( ! is_category() || is_feed() ) {
			return;
		}
		$term = get_queried_object();
		if ( ! $term instanceof WP_Term || ! in_array( $term->slug, self::BOARDS, true ) || self::boardOpen( $term->slug ) ) {
			return;
		}
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}

	/** 게시판 목록 주소가 열렸나 = 카테고리가 있고 비밀번호 없는 게시 글이 1건 이상(비밀번호 글은 공개 근거가 아니다 — 수정 1 C03). 게시판이 아닌 slug 는 false. */
	public static function boardOpen( string $slug ): bool {
		if ( ! in_array( $slug, self::BOARDS, true ) ) {
			return false;
		}
		if ( isset( self::$open[ $slug ] ) ) {
			return self::$open[ $slug ];
		}
		$term = get_term_by( 'slug', $slug, 'category' );
		$open = false;
		if ( $term instanceof WP_Term ) {
			global $wpdb;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- 읽기 1건, 요청 안 기억.
			$open = null !== $wpdb->get_var(
				$wpdb->prepare(
					"SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID WHERE tr.term_taxonomy_id = %d AND p.post_type = 'post' AND p.post_status = 'publish' AND p.post_password = '' LIMIT 1",
					$term->term_taxonomy_id
				)
			);
		}
		self::$open[ $slug ] = $open;
		return $open;
	}

	/** Nav 고정 항목 목적지 열림 — 게시판은 boardOpen, 그 밖(상담 등)은 그대로. */
	public static function routeAvailable( $open, $path ): bool {
		return in_array( $path, self::BOARDS, true ) ? self::boardOpen( (string) $path ) : (bool) $open;
	}

	public static function flush(): void {
		self::$open = array();
	}

	// ── 빈 허브 ─────────────────────────────────────────────────────

	/** 허브 = 템플릿 page-hub 고정 페이지(PublishPress 수정안 제외). */
	public static function isHub( WP_Post $post ): bool {
		return 'page' === $post->post_type
			&& ! str_ends_with( (string) $post->post_mime_type, '-revision' )
			&& self::HUB_TEMPLATE === get_page_template_slug( $post );
	}

	/** wp_after_insert_post(100): 그 페이지(허브면)·부모·옛 부모. */
	public static function afterSave( $post_id, $post, $update = false, $post_before = null ): void {
		if ( ! $post instanceof WP_Post || 'page' !== $post->post_type ) {
			return;
		}
		self::syncHub( (int) $post->ID );
		if ( (int) $post->post_parent > 0 ) {
			self::syncHub( (int) $post->post_parent );
		}
		if ( $post_before instanceof WP_Post && (int) $post_before->post_parent > 0 && (int) $post_before->post_parent !== (int) $post->post_parent ) {
			self::syncHub( (int) $post_before->post_parent );
		}
	}

	/** deleted_post: 지운 페이지의 부모. */
	public static function afterDelete( $post_id, $post = null ): void {
		if ( $post instanceof WP_Post && 'page' === $post->post_type && (int) $post->post_parent > 0 ) {
			self::syncHub( (int) $post->post_parent );
		}
	}

	/** 모든 허브 상태 맞추기(활성화 때). */
	public static function syncAllHubs(): void {
		$ids = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => array( 'publish', 'private' ),
				'meta_key'         => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- 허브 몇 개.
				'meta_value'       => self::HUB_TEMPLATE, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'           => 'ids',
				'posts_per_page'   => -1,
				'suppress_filters' => true,
			)
		);
		foreach ( $ids as $id ) {
			self::syncHub( (int) $id );
		}
	}

	/** 허브 하나: 게시 + 게시 하위 0 → 비공개(표식), 표식 있는 비공개 + 게시 하위 → 게시. */
	public static function syncHub( int $id ): void {
		if ( isset( self::$syncing[ $id ] ) ) {
			return;
		}
		clean_post_cache( $id );
		$post = get_post( $id );
		if ( ! $post instanceof WP_Post || ! self::isHub( $post ) ) {
			return;
		}
		$waiting = '1' === (string) get_post_meta( $id, self::HUB_WAITING, true );
		$has     = self::hasPublishedChild( $id );
		if ( 'publish' === $post->post_status && ! $has ) {
			update_post_meta( $id, self::HUB_WAITING, '1' );
			self::setStatus( $post, 'private' );
		} elseif ( 'private' === $post->post_status && $waiting && $has ) {
			if ( self::setStatus( $post, 'publish' ) ) {
				delete_post_meta( $id, self::HUB_WAITING );
			}
		} elseif ( 'publish' === $post->post_status && $waiting ) {
			delete_post_meta( $id, self::HUB_WAITING ); // 사람이 직접 게시한 대기 허브 — 표식만 지운다.
		}
	}

	/** 바로 아래 비밀번호 없는 게시 하위 페이지가 있나(수정안 제외 · 비밀번호 하위는 공개 근거가 아니다 — 수정 1 C03). */
	public static function hasPublishedChild( int $id ): bool {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- 읽기 1건(전환 직후 값이 필요 — 캐시 없이).
		return null !== $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_parent = %d AND post_type = 'page' AND post_status = 'publish' AND post_password = '' AND post_mime_type NOT LIKE %s LIMIT 1",
				$id,
				'%-revision'
			)
		);
	}

	/**
	 * 상태만 바꾸는 저장 — 그 순간만 사용자 0·kses 뗌. 끝나면(예외여도) 원래 사용자로 돌리고, kses 는 **들어오기 전 상태 그대로**
	 * 다시 걸거나 뗀다(사용자 기준으로 새로 정하지 않음 — 수정 1 C04: 요청이 kses 를 떼 둔 상태였으면 뗀 채로).
	 */
	private static function setStatus( WP_Post $post, string $status ): bool {
		$before                     = get_current_user_id();
		$kses                       = self::ksesState();
		self::$syncing[ $post->ID ] = true;
		try {
			wp_set_current_user( 0 );
			kses_remove_filters();
			$result = wp_update_post(
				array(
					'ID'          => $post->ID,
					'post_status' => $status,
				),
				true
			);
		} finally {
			wp_set_current_user( $before ); // 사용자가 바뀌면 코어가 kses_init 을 부른다(set_current_user) → 아래에서 기록대로 맞춘다.
			self::restoreKses( $kses );
			unset( self::$syncing[ $post->ID ] );
		}
		return ! is_wp_error( $result ) && 0 !== $result;
	}

	/** kses_init_filters() 가 거는 필터 = kses_remove_filters() 가 떼는 것(훅·함수·우선순위 — WP 7.1 wp-includes/kses.php). */
	private const KSES_FILTERS = array(
		array( 'title_save_pre', 'wp_filter_kses', 10 ),
		array( 'pre_comment_content', 'wp_filter_post_kses', 10 ),
		array( 'pre_comment_content', 'wp_filter_kses', 10 ),
		array( 'content_save_pre', 'wp_filter_global_styles_post', 9 ),
		array( 'content_filtered_save_pre', 'wp_filter_global_styles_post', 9 ),
		array( 'content_save_pre', 'wp_filter_post_kses', 10 ),
		array( 'excerpt_save_pre', 'wp_filter_post_kses', 10 ),
		array( 'content_filtered_save_pre', 'wp_filter_post_kses', 10 ),
	);

	/** @return list<bool> KSES_FILTERS 순서대로 지금 걸려 있나. */
	private static function ksesState(): array {
		return array_map( static fn( array $f ): bool => has_filter( $f[0], $f[1], $f[2] ), self::KSES_FILTERS );
	}

	/** @param list<bool> $state ksesState() 기록 — 다른 것만 걸거나 뗀다. */
	private static function restoreKses( array $state ): void {
		foreach ( self::KSES_FILTERS as $i => list( $hook, $fn, $priority ) ) {
			$now = has_filter( $hook, $fn, $priority );
			if ( $state[ $i ] && ! $now ) {
				add_filter( $hook, $fn, $priority );
			} elseif ( ! $state[ $i ] && $now ) {
				remove_filter( $hook, $fn, $priority );
			}
		}
	}
}
