<?php
/**
 * Title: 질문형 가이드(T3)
 * Slug: iwell/guide-question
 * Categories: iwell
 * Post Types: page
 * Description: 증상 가이드·FAQ 에서 나눈 질문 하나. H1(질문) → 첫 문단 직답(40자 내외, 검토 배지) → 목차(h2 3개 이상이면 자동) → 근거 표(기준·수치·기준일) → 하위 질문 → "이럴 땐 바로 병원" 상자. 그 뒤 관련·예약·전화·출처는 템플릿이 그린다. 글은 원문 우선, 없으면 공신력 출처 3곳 교차검증(설계서 §6) — 검증 안 되면 [미검증]·"상담 시 안내".
 */

defined( 'ABSPATH' ) || exit;

echo iwell_t3_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'title'     => '[질문형 제목 — 보호자가 실제로 묻는 문장 하나]',
		'answer'    => '[첫 문단 직답 — 40자 내외로 질문에 바로 답한다]',
		'basis'     => array(
			'caption' => '[근거 표 설명 — 출처는 페이지 아래 출처 목록]',
			'head'    => array( '기준', '수치', '기준일' ),
			'rows'    => array(
				array( '[기준 1]', '[ ]', '[ ]' ),
				array( '[기준 2]', '[ ]', '[ ]' ),
			),
		),
		'questions' => array(
			array( '[하위 질문 1]', array( '[답 — 원문 우선]' ) ),
			array( '[하위 질문 2]', array( '[답 — 원문 우선]' ) ),
		),
		'urgent'    => array(
			'intro' => '[이런 증상이 있으면 진료를 미루지 않는다 — 원문 또는 공신력 출처의 기준만]',
			'items' => array( '[증상 1]', '[증상 2]', '[증상 3]' ),
		),
	)
);
