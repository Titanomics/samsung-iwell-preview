<?php
/**
 * Title: 홈 — 클리닉 카드
 * Slug: iwell/home-clinics
 * Categories: iwell
 * Inserter: no
 * Description: 허브 카드(이름 + 병원 자료 원문 한 줄 + 게시된 하위 3개). 가격·이벤트 카드 없음(설계서 §7).
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-clinics is-ivory","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-clinics is-ivory"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">진료 안내</h2>
<!-- /wp:heading -->

<!-- wp:iwell/clinic-cards /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
