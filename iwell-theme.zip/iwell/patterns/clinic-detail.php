<?php
/**
 * Title: 진료 상세(T2)
 * Slug: iwell/clinic-detail
 * Categories: iwell
 * Post Types: page
 * Description: 진료군 2차 페이지 본문. H1(질문형) → 핵심 답변(검토 배지) → 정의·원리 → 과정 → 비교 표 → 이런 분께 → 정보표 → FAQ(본문은 여기까지). 그 뒤 관련(같은 허브의 게시된 하위 자동) → 예약·전화 → 출처(페이지 메타)와 서브 비주얼·브레드크럼·형제 탭·이전/다음은 템플릿이 그린다. 글은 원문 우선, 없으면 공신력 출처 3곳 교차검증(설계서 §6) — 검증 안 되면 [미검증]·"상담 시 안내".
 */

defined( 'ABSPATH' ) || exit;

echo iwell_t2_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'title'     => '[질문형 제목 — 보호자가 실제로 묻는 문장 하나]',
		'answer'    => array( '[핵심 답변 3~4문장 — 질문에 바로 답한다. 원문 우선, 원문에 없으면 공신력 출처 3곳 교차검증]' ),
		'principle' => array( '[정의·원리 블록 1]', '[정의·원리 블록 2]' ),
		'process'   => array( '[1단계]', '[2단계]', '[3단계]' ),
		'compare'   => array(
			'caption' => '[비교 기준·기준일]',
			'head'    => array( '항목', '[검사·치료 A]', '[검사·치료 B]' ),
			'rows'    => array(
				array( '무엇을 보나', '[ ]', '[ ]' ),
				array( '방법', '[ ]', '[ ]' ),
				array( '소요시간', '[ ]', '[ ]' ),
				array( '비용 방식', '[ ]', '[ ]' ),
			),
		),
		'audience'  => array(
			'intro'  => '[추천 대상 안내 한 줄]',
			'groups' => array( '' => array( '[대상 1]', '[대상 2]', '[대상 3]' ) ),
		),
		'info'      => array(
			array( '소요시간', '[ ]' ),
			array( '금식', '[ ]' ),
			array( '비용 방식', '[ ] — 비급여 진료비 표(진료안내) 기준일과 같게' ),
			array( '준비물', '[ ]' ),
		),
		'faq'       => array(),
	)
);
