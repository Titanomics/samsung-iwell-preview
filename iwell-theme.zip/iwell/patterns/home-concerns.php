<?php
/**
 * Title: 홈 — 보호자 고민 6칸
 * Slug: iwell/home-concerns
 * Categories: iwell
 * Inserter: no
 * Description: 설계서 §5 T1 칸 이름 6개. 칸 설명은 병원 자료 원문. 목적지가 비공개인 칸은 숨는다(iwell/concerns).
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-concerns","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-concerns"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">어떤 진료가 필요하세요?</h2>
<!-- /wp:heading -->

<!-- wp:iwell/concerns /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
