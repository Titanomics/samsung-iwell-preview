<?php
/**
 * Title: 홈 — 오늘 진료·진료시간
 * Slug: iwell/home-hours
 * Categories: iwell
 * Inserter: no
 * Description: 진료시간 설정에서 계산하는 블록(iwell/today-bar·iwell/hours-table)만 쓴다 — 시간을 글로 다시 쓰지 않는다.
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-hours is-tint","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-hours is-tint"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">오늘 진료·진료시간</h2>
<!-- /wp:heading -->

<!-- wp:group {"tagName":"div","className":"iwell-hours-grid","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-hours-grid"><!-- wp:group {"tagName":"div","className":"iwell-hours-today","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-hours-today"><!-- wp:paragraph {"className":"iwell-eyebrow"} -->
<p class="iwell-eyebrow">오늘</p>
<!-- /wp:paragraph -->

<!-- wp:iwell/today-bar /-->

<!-- wp:iwell/cta {"variant":"inline"} /-->

<!-- wp:iwell/link {"path":"guide/hours","label":"진료시간·오시는 길·주차 자세히"} /--></div>
<!-- /wp:group -->

<!-- wp:iwell/hours-table /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
