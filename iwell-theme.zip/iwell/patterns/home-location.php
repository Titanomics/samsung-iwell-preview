<?php
/**
 * Title: 홈 — 오시는 길
 * Slug: iwell/home-location
 * Categories: iwell
 * Inserter: no
 * Description: 주소·전화 = config/clinic.php(iwell/location). 주차 = 병원 자료 원문(대수 72대는 근거 확인 대상 C25라 쓰지 않음). 지도 좌표는 병원 확인 전이라 지도 앱 검색 링크만.
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-location","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-location"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">오시는 길</h2>
<!-- /wp:heading -->

<!-- wp:iwell/location /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
