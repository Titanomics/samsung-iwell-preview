<?php
/**
 * Title: 홈 — 의료진
 * Slug: iwell/home-doctors
 * Categories: iwell
 * Inserter: no
 * Description: 확인된 사실만(이름·직함·자격 2줄, 병원 자료 의료진 페이지 원문). 경력·저서는 근거 확인 대상(C23·C24)이라 의료진 페이지(Task 8)에서. 정헌종 원장(매주 일요일 진료 — 대표 2026-11-26, 사진 없음)은 홈 의료진 구역에 넣지 않고 의료진 소개 쪽 카드와 진료시간 표 일요일 줄에서 보인다.
 */

defined( 'ABSPATH' ) || exit;
$iwell_img = esc_url( get_theme_file_uri( 'assets/img/doctor-01-director.webp' ) );
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-doctors","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-doctors"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">의료진</h2>
<!-- /wp:heading -->

<!-- wp:group {"tagName":"div","className":"iwell-doctor","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-doctor"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"iwell-doctor__photo"} -->
<figure class="wp-block-image size-full iwell-doctor__photo"><img src="<?php echo $iwell_img; // phpcs:ignore WordPress.Security.EscapeOutput -- esc_url 위 ?>" alt="고시환 대표원장"/></figure>
<!-- /wp:image -->

<!-- wp:group {"tagName":"div","className":"iwell-doctor__text","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-doctor__text"><!-- wp:paragraph {"className":"iwell-doctor__role"} -->
<p class="iwell-doctor__role">대표원장</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"className":"iwell-doctor__name"} -->
<h3 class="wp-block-heading iwell-doctor__name">고시환</h3>
<!-- /wp:heading -->

<!-- wp:list {"className":"iwell-doctor__creds"} -->
<ul class="wp-block-list iwell-doctor__creds"><!-- wp:list-item -->
<li>소아청소년과 전문의</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>순천향대학교 의학과 박사</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:iwell/link {"path":"about/doctors","label":"의료진 소개"} /--></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
