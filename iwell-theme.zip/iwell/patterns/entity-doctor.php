<?php
/**
 * Title: 의료진(T5)
 * Slug: iwell/entity-doctor
 * Categories: iwell
 * Post Types: page
 * Description: 원장 개별 페이지. H1(이름·직함) → 이력 표(직함·전문의·학력 — 의료진 목록 카드 요약) → 이력 네 칸(주요경력·학술활동·대외활동·출간 저서, 넓은 화면 2×2·휴대폰 한 줄씩) → 진료 철학. 외부 프로필 링크는 편집기 "의학 정보" 패널의 의료진 정보(sameAs)에서 템플릿이 본문 뒤에 그린다(구조화 데이터 Physician 과 같은 값). 이력은 증빙이 확인된 것만.
 */

defined( 'ABSPATH' ) || exit;

echo iwell_t5_doctor_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'title'      => '[이름] [직함]',
		'career'     => array(
			array( '직함', '[ ]' ),
			array( '전문의', '[ ]' ),
			array( '학력', '[ ]' ),
		),
		'history'    => array(
			array( '주요경력', array( '[ ]' ) ),
			array( '학술활동', array( '[ ]' ) ),
			array( '대외활동', array( '[ ]' ) ),
			array( '출간 저서', array( '[ ]' ) ),
		),
		'philosophy' => array( '[진료 철학 — 원장 본인 문장]' ),
	)
);
