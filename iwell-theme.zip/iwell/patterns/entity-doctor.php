<?php
/**
 * Title: 의료진(T5)
 * Slug: iwell/entity-doctor
 * Categories: iwell
 * Post Types: page
 * Description: 원장 개별 페이지. H1(이름·직함) → 이력 표(면허·전문의·학력·경력·학회·저서) → 진료 철학. 외부 프로필 링크는 편집기 "의학 정보" 패널의 의료진 정보(sameAs)에서 템플릿이 본문 뒤에 그린다(구조화 데이터 Physician 과 같은 값). 이력은 증빙이 확인된 것만.
 */

defined( 'ABSPATH' ) || exit;

echo iwell_t5_doctor_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'title'      => '[이름] [직함]',
		'career'     => array(
			array( '면허', '[ ]' ),
			array( '전문의', '[ ]' ),
			array( '학력', '[ ]' ),
			array( '경력', '[ ]' ),
			array( '학회', '[ ]' ),
			array( '저서', '[ ]' ),
		),
		'philosophy' => array( '[진료 철학 — 원장 본인 문장]' ),
	)
);
