<?php
/**
 * Title: 병원 소개(T5)
 * Slug: iwell/entity-clinic
 * Categories: iwell
 * Post Types: page
 * Description: 병원 엔티티 페이지. H1 → 사실 표(상호·대표원장·진료과목·전화·주소·주차) → 소개 문단. 사실 표의 상호·대표원장·전화·주소 기본값 = 병원 정보 설정(구조화 데이터 MedicalClinic 과 같은 원천) — 바뀌면 함께 고친다.
 */

defined( 'ABSPATH' ) || exit;

$iwell_clinic = Iwell_Theme_Blocks::clinic();

echo iwell_t5_clinic_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'title' => $iwell_clinic['name'],
		'facts' => array(
			array( '상호', $iwell_clinic['name'] ),
			array( '대표원장', (string) ( $iwell_clinic['representative'] ?? '' ) ),
			array( '진료과목', Iwell_Theme_Blocks::SPECIALTY ),
			array( '전화', $iwell_clinic['telephone'] ),
			array( '주소', $iwell_clinic['addressText'] ),
			array( '주차', Iwell_Theme_Blocks::PARKING ),
		),
		'intro' => array( '[병원 소개 문단 — 병원 자료 원문]' ),
	)
);
