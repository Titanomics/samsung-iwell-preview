<?php
/**
 * Title: 홈 — 원내 사진(삼성아이웰 둘러보기)
 * Slug: iwell/home-tour
 * Categories: iwell
 * Inserter: no
 * Description: 병원 원본 둘러보기 사진(웹용 사본, 옛 진료시간·과거 의료진이 보이는 부분은 잘라냄 — docs/design/photos.md). 가로 스크롤은 목록 상자 안에서만.
 */

defined( 'ABSPATH' ) || exit;
$iwell_tour = array(
	array( 'tour-09-waiting-crop.webp', '넓은 대기실과 접수 데스크, 기초검사실' ),
	array( 'tour-04-waiting-crop.webp', '대기실 소파와 접수 데스크' ),
	array( 'tour-12-waiting-respiratory-crop.webp', '대기실과 호흡기 치료실' ),
	array( 'tour-19-basic-exam-room.webp', '기초검사실' ),
	array( 'tour-17-exam-corridor.webp', '진료실 복도' ),
	array( 'tour-18-director-office.webp', '원장 진료실' ),
	array( 'tour-15-respiratory-room.webp', '호흡기 치료실' ),
	array( 'tour-16-treatment-room.webp', '처치·주사실 침상' ),
);
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-tour","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-tour"><!-- wp:group {"tagName":"div","className":"iwell-section__inner","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-section__inner"><!-- wp:heading -->
<h2 class="wp-block-heading">삼성아이웰 둘러보기</h2>
<!-- /wp:heading -->

<!-- wp:group {"tagName":"div","className":"iwell-tour","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-tour">
<?php foreach ( $iwell_tour as list( $iwell_file, $iwell_alt ) ) : ?>
<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"iwell-tour__item"} -->
<figure class="wp-block-image size-full iwell-tour__item"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/' . $iwell_file ) ); ?>" alt="<?php echo esc_attr( $iwell_alt ); ?>"/></figure>
<!-- /wp:image -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->

<!-- wp:iwell/link {"path":"about/tour","label":"병원 둘러보기"} /--></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
