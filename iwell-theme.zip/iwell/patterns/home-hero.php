<?php
/**
 * Title: 홈 — 히어로(사진 + 병원 이름·슬로건·사실 3개·버튼)
 * Slug: iwell/home-hero
 * Categories: iwell
 * Inserter: no
 * Description: 글자 이미지 없이 HTML 글자. 첫 줄 = H1(그 위 작은 글씨 지역·진료과 줄은 정의 문장과 겹쳐 뺐다 — 대표 결정 2026-11-14, Task 7 수정 3). H1 바로 다음 = 병원 정의 한 문장(iwell/clinic-definition — config/clinic.php, 수정 2). 슬로건 = 병원 캐치프레이즈 원문(공지 #31). 사진 = 원내 접수 데스크(원본 03_둘러보기03).
 */

defined( 'ABSPATH' ) || exit;
$iwell_img = esc_url( get_theme_file_uri( 'assets/img/tour-03-reception-front.webp' ) );
?>
<!-- wp:group {"tagName":"section","className":"iwell-section iwell-home-hero","layout":{"type":"default"}} -->
<section class="wp-block-group iwell-section iwell-home-hero"><!-- wp:group {"tagName":"div","className":"iwell-hero","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-hero"><!-- wp:group {"tagName":"div","className":"iwell-hero__text","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-hero__text"><!-- wp:heading {"level":1,"className":"iwell-hero__title"} -->
<h1 class="wp-block-heading iwell-hero__title">삼성아이웰소아청소년과</h1>
<!-- /wp:heading -->

<!-- wp:iwell/clinic-definition /-->

<!-- wp:paragraph {"className":"iwell-hero__lead"} -->
<p class="iwell-hero__lead">부모의 마음으로 미래의 건강과 꿈을 키웁니다</p>
<!-- /wp:paragraph -->

<!-- wp:group {"tagName":"div","className":"iwell-hero__facts","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-hero__facts"><!-- wp:iwell/topbar-note /-->

<!-- wp:paragraph -->
<p>온가족 진료: 성인진료, 예방접종, 수액치료</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>건물 뒤편 대형주차장</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:iwell/cta {"variant":"hero"} /--></div>
<!-- /wp:group -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"iwell-hero__media"} -->
<figure class="wp-block-image size-full iwell-hero__media"><img src="<?php echo $iwell_img; // phpcs:ignore WordPress.Security.EscapeOutput -- esc_url 위 ?>" alt="정면에서 본 접수 데스크와 병원 간판"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
