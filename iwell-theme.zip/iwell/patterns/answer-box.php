<?php
/**
 * Title: 핵심 답변 상자
 * Slug: iwell/answer-box
 * Categories: iwell
 * Post Types: page
 * Description: 질문에 바로 답하는 3~4문장 + 의학적 검토·기준일 배지(원장 승인 때 자동 기록 — 승인 전에는 배지가 보이지 않는다).
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"tagName":"div","className":"iwell-answer","layout":{"type":"default"}} -->
<div class="wp-block-group iwell-answer"><!-- wp:paragraph {"className":"iwell-answer__label"} -->
<p class="iwell-answer__label">핵심 답변</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>[핵심 답변 3~4문장]</p>
<!-- /wp:paragraph -->

<!-- wp:iwell/review-badge /--></div>
<!-- /wp:group -->
