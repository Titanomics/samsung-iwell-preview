<?php
/**
 * Title: 정보표(T4)
 * Slug: iwell/info-table-page
 * Categories: iwell
 * Post Types: page
 * Description: 진료시간·비급여·제증명·검사 안내·접종 일정 같은 표 페이지. 제목(H1)은 페이지 제목, 기준일은 편집기 "의학 정보" 패널의 기준일 — 둘 다 템플릿이 표 위에 그린다. 본문 = 가로 스크롤 반응형 표 → 주석·문의. 금액·시간은 병원 확인 값만(기준일과 함께).
 */

defined( 'ABSPATH' ) || exit;

echo iwell_t4_markup( // phpcs:ignore WordPress.Security.EscapeOutput -- 함수 안에서 글자마다 esc_html.
	array(
		'table'   => array(
			'caption' => '[표 설명 — 무엇을 어떤 기준으로 정리했는지]',
			'head'    => array( '[구분]', '[항목]', '[내용]', '[비고]' ),
			'rows'    => array(
				array( '[ ]', '[ ]', '[ ]', '[ ]' ),
				array( '[ ]', '[ ]', '[ ]', '[ ]' ),
				array( '[ ]', '[ ]', '[ ]', '[ ]' ),
			),
		),
		'notes'   => array( '[주석 — 표에 다 담지 못한 조건·예외]' ),
		'contact' => '진료문의 ' . Iwell_Theme_Blocks::clinic()['telephone'],
	)
);
