<?php
/**
 * 테마 서버 렌더 블록(Task 7) — 메뉴·브레드크럼·형제 탭·이전/다음·하단 바·퀵바·홈 구역. 모두 자바스크립트 없이 HTML 로 나온다.
 *
 * 링크 규칙: 사이트 안 링크는 전부 Iwell\Core\Nav::publicUrl()(공개 목적지 규칙 — 대상이 비공개면 1차 허브 → 홈)을 거친다.
 * 메뉴 데이터는 Nav::tree()(게시된 페이지 계층 + 고정 항목 3개). 병원 정보는 Graph::clinicInfo()(config/clinic.php 한 곳).
 * 플러그인이 꺼져 있으면 메뉴·브레드크럼 블록은 비고(치명 오류 없음), 링크는 홈으로.
 */

defined( 'ABSPATH' ) || exit;

final class Iwell_Theme_Blocks {
	/** PC 1차 메뉴 글씨 크기(px, 굵게) — 열 폭 추정용. */
	private const TOP_FONT_PX = 15;

	/** 메가메뉴 하위 항목 글씨 크기(px) — 열 폭 추정용. */
	private const SUB_FONT_PX = 14;

	/**
	 * 글자 폭 추정(px) — 메가 메뉴 열 비율·최소 폭 계산용. 글자 종류별 em 비율(한글 0.94 — Apple SD Gothic Neo·Noto Sans KR 쪽 넉넉히,
	 * 이 PC Malgun/Pretendard 실측 0.87), 영문·숫자 0.6, 띄어쓰기 0.28, 괄호·가운뎃점 등 0.4. 수정 1차(2026-11-19): 예전 "글자당 13.5px"은 띄어쓰기·괄호도
	 * 한글 폭으로 세어, 묶은 마디를 최소 폭에 넣자 1200px 에서 열 합이 자리를 35px 넘었다(실측).
	 */
	private static function textPx( string $text, int $font, float $bold = 1.0 ): float {
		$w = 0.0;
		foreach ( preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY ) ?: array() as $ch ) {
			if ( ' ' === $ch ) {
				$w += 0.28;
			} elseif ( 1 === preg_match( '/^[A-Za-z0-9]$/', $ch ) ) {
				$w += 0.6;
			} elseif ( 1 === preg_match( '/^[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E·]$/u', $ch ) ) {
				$w += 0.4;
			} else {
				$w += 0.94;
			}
		}
		return $w * $font * $bold;
	}

	/**
	 * 홈 "어떤 진료가 필요하세요?" 타일 — 수정 1차(병원 의견 2026-11-19): 키·사춘기·성조숙증을 맨 앞(첫 줄 전체 폭 강조 — concerns() 가 첫 칸에
	 * is-featured), 다음 영유아검진·예방접종 → 알레르기 → 온가족 접종·내과. "말 늦음"(발달·언어 허브 삭제)·"발열·독감"(계절성 — 병원 의견 "너무
	 * 계절성이라 이걸 굳이 앞에?")은 뺐다: 발열은 건강정보 → 발열·해열제·열성경련 페이지와 홈 FAQ 에서 찾는다(타일 대상이던 호흡기 신속검사 페이지도 삭제).
	 * 한 줄 설명 = 병원 자료의 이름만 뽑은 짧은 말(검사 이름 나열 없음 — 근거 docs/design/copy-sources.md §2-2·§2-5, docx L25·L168·L178·L591·L510·L100).
	 */
	public const CONCERNS = array(
		array( 'height', '키·사춘기·성조숙증', '성장 클리닉 · 성조숙증 검사·치료', 'growth' ),
		array( 'baby', '영유아검진·예방접종', '영유아 검진시기별 검진항목', 'checkup' ),
		array( 'leaf', '비염·아토피·알레르기', '알레르기 검사 · 면역치료', 'allergy' ),
		array( 'syringe', '온가족 접종·내과', '온가족 진료: 성인진료, 예방접종, 수액치료', 'adult' ),
	);

	/**
	 * 홈 클리닉 카드(허브) 한 줄 설명 = 병원 자료 원문·이름(copy-sources.md §2-5). 원문이 없는 허브는 설명 없음.
	 * 수정 1차: 발달·언어 카드 없음, 지운 진료(당뇨병 HbA1c·호흡기 신속검사)를 말하지 않는다.
	 */
	public const CLINIC_LINES = array(
		'growth'  => '성장 클리닉에서는 저신장의 원인과 치료 및 키를 키우기 위한 여러 가지 방법에 대한 진료를 하게 됩니다.',
		'checkup' => '영유아 검진시기별 검진항목 · 표준 예방접종 일정',
		'allergy' => '알러지검사(MAST) · 알레르기 면역치료',
		'adult'   => '고혈압 · 이상지질혈증 · 수액·영양주사',
		'health'  => '',
	);

	/**
	 * 홈 FAQ(수정 2 Ruling B, 오시는 길 바로 앞) — [질문, 답 줄 목록, 링크 경로(#앵커 가능)].
	 * 질문 = 보호자 실무 질문(새 의료 문장 없음). 답 = 병원 자료 원문 줄 그대로(띄어쓰기·오탈자만 정리). 링크 = 그 주제의 페이지 — 목적지가 공개일 때만.
	 * 원문 위치·고른 이유·뺀 후보는 docs/design/copy-sources.md §2-9. 예약 방식·주차 대수·임시공휴일은 넣지 않는다(병원 확인 대상). 일요일 진료 원장(매주 일요일 — 대표 2026-11-26)은 진료시간 표(설정 값) 한 곳에 둔다.
	 * 진료시간 답은 원문 글자라 진료시간 설정(Store)과 따로다 — 진료시간이 바뀌면 이 답도 같이 고친다.
	 */
	public const HOME_FAQ = array(
		array(
			'진료시간과 휴진일은 어떻게 되나요?',
			array( '화 ~ 금요일 AM 09:00 ~ PM 18:00 / 토, 일, 공휴일 AM 09:00 ~ PM 13:00 / 점심시간 PM 13:00 ~ PM 14:00', '※ 매주 월요일(공휴일 포함) 휴진, 마지막주 일요일 휴진 ※ 토, 일, 공휴일은 점심시간 없이 진료합니다.' ),
			'guide/hours',
		),
		array(
			'주차할 수 있나요?',
			array( '넓고 편리한 대형주차장: 건물 뒤편에 위치한 주차장이 구비되어 있습니다.' ),
			'guide/hours#map',
		),
		array(
			'예방접종을 하러 갈 때 무엇을 챙겨야 하나요?',
			array( '예방접종 수첩을 꼭 챙기시고, 수첩을 분실한 경우 이전 접종한 날짜를 확인하시고 오는 것이 좋습니다.' ),
			'checkup/vaccination-precautions',
		),
		array(
			'예방접종 시기를 놓쳤으면 어떻게 하나요?',
			array( '만약, 표준 예방접종 일정에 따라 접종하지 못한 경우는 접종연령 등에 따라 일정이 달라질 수 있습니다.', '자세한 접종 스케줄은 삼성아이웰소아청소년과에서 상담하세요!' ),
			'checkup/catch-up-vaccination',
		),
		array(
			'영유아검진 때 구강검진도 받나요?',
			array( '구강검진(구강사진 및 문진, 구강보건교육)은 치과병의원 검진 기관에서 실시' ),
			'checkup/infant-checkup',
		),
		array(
			'독감·코로나 검사도 받을 수 있나요?',
			array( '호흡기 검체 검사(자체 당일 검사): 독감 인플루엔자(Influenza A, B), 코로나-19(COVID-19), 아데노바이러스(Adenovirus), 마이코플라즈마(Mycoplasma), 호흡기세포융합바이러스(RSV)' ),
			'guide/tests', // 수정 1차: 호흡기 신속검사 페이지 삭제(병원 의견) → 검사 안내(T4 자체 당일 검사 표).
		),
	);

	/** 진료과목 화면 표기(병원 자료 진료과목 "소아청소년과" — config/clinic.php medicalSpecialty Pediatric 과 같은 뜻). T5 병원 사실 표 기본값. */
	public const SPECIALTY = '소아청소년과';

	/** 주차 = 병원 자료 원문(docx L118, 대수 72대는 근거 확인 대상 C25 라 뺌). 오시는 길·T5 병원 사실 표가 같은 글을 쓴다. */
	public const PARKING = '넓고 편리한 대형주차장: 건물 뒤편에 위치한 주차장이 구비되어 있습니다.';

	/** T3 목차를 내는 최소 h2 수(대표 승인 2026-11-13 — 2개 이하면 내지 않음). */
	public const TOC_MIN = 3;

	/** 칼럼 원문 링크 글자. */
	public const SOURCE_LABEL = '네이버 블로그 원문';

	/** 의료진 카드(doctor-cards)에 옮기는 원장 이력 표의 앞 줄 수 — 요약(직함·전문의·학력). 긴 경력 목록 줄은 원장 페이지에서만. */
	public const CARD_CAREER_ROWS = 3;

	/** 바닥글 법적 페이지(설계서 §4). 그 밖의 최상위 비허브 페이지는 지역 안내 줄. */
	private const LEGAL = array( 'privacy', 'patient-rights', 'terms' );

	public static function register(): void {
		add_action( 'init', array( self::class, 'registerBlocks' ) );
		add_filter( 'render_block_rank-math/faq-block', array( self::class, 'faqAccordion' ), 20 );
		add_filter( 'render_block_core/group', array( self::class, 'toc' ), 10, 2 );
	}

	/**
	 * FAQ 아코디언(설계서 §5 T2 "FAQ 4~6 아코디언", 수정 1 R05) — Rank Math FAQ 블록 출력의 질문 항목을 <details>/<summary> 로 바꾼다.
	 * 자바스크립트 없이 열고 닫히고(키보드 Enter·Space), 첫 질문만 펼침·나머지 접힘. 답 본문은 접혀 있어도 HTML 에 그대로(검색·AI 가 읽음).
	 * 질문 제목 h3·항목 id(#faq-n — FAQPage Question.url 앵커)·답 마크업은 Rank Math 출력 그대로 옮긴다. FAQPage JSON-LD 는 블록 속성에서
	 * 따로 만들어지므로 바뀌지 않는다. 출력 모양이 예상(div 목록)과 다르면 손대지 않고 그대로 돌려준다.
	 *
	 * @param mixed $html 블록 출력.
	 */
	public static function faqAccordion( $html ): string {
		$html  = (string) $html;
		$parts = preg_split( '~<div id="([^"]*)" class="rank-math-list-item">~', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) || count( $parts ) < 3 ) {
			return $html;
		}
		$count = intdiv( count( $parts ) - 1, 2 );
		$out   = $parts[0];
		for ( $i = 0; $i < $count; $i++ ) {
			$last = $i === $count - 1;
			// 항목 닫는 </div>(마지막 항목 뒤에는 목록·블록 닫는 </div> 두 개 더)를 떼어 내면 질문 h3 + 답 div 만 남는다.
			if ( ! preg_match( '~^(.*?)(?:\s*</div>){' . ( $last ? 3 : 1 ) . '}\s*$~s', $parts[ 2 + 2 * $i ], $m )
				|| ! preg_match( '~^\s*(<h3 class="rank-math-question[^"]*">.*?</h3>)\s*(<div class="rank-math-answer[^"]*">.*</div>)\s*$~s', $m[1], $qa ) ) {
				return $html;
			}
			$out .= sprintf(
				"\n<details id=\"%s\" class=\"rank-math-list-item iwell-faq\"%s><summary class=\"iwell-faq__summary\">%s</summary>\n%s\n</details>",
				esc_attr( $parts[ 1 + 2 * $i ] ),
				0 === $i ? ' open' : '',
				$qa[1],
				$qa[2]
			);
		}
		return $out . "\n</div>\n</div>";
	}

	public static function registerBlocks(): void {
		$blocks = array(
			'site-header'  => array( '머리(로고·메가메뉴·드로어)', array() ),
			'topbar-note'  => array( '슬림 바 진료 안내', array() ),
			'footer-nav'   => array( '바닥글 사이트맵', array() ),
			'clinic-info'  => array( '바닥글 병원 정보', array() ),
			'bottom-bar'   => array( '모바일 하단 4분할 바', array() ),
			'quick-bar'    => array( 'PC 우측 퀵바', array() ),
			'sub-visual'   => array( '서브 비주얼(1차 메뉴명)', array() ),
			'breadcrumb'   => array( '브레드크럼', array() ),
			'tabs'         => array( '형제 탭(2차 메뉴)', array() ),
			'page-title'   => array( '페이지 제목(본문에 H1 이 없을 때만)', array() ),
			'prev-next'    => array( '이전·다음 형제 페이지', array() ),
			'cta'          => array(
				'예약·전화 버튼',
				array(
					'variant' => array(
						'type'    => 'string',
						'default' => 'band',
					),
				),
			),
			'link'         => array(
				'사이트 안 링크(공개 목적지 규칙)',
				array(
					'path'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'label' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			),
			'related'      => array( '관련 페이지(같은 1차 허브의 게시된 하위 — 템플릿)', array() ),
			'sources'      => array( '출처 목록(페이지 메타 — 템플릿)', array() ),
			'concerns'     => array( '홈 — 보호자 고민 6칸', array() ),
			'clinic-cards' => array( '홈 — 클리닉 카드', array() ),
			'latest-board' => array( '홈 — 최신 공지·칼럼', array() ),
			'location'     => array( '오시는 길(주소·전화·주차·지도 앱 링크)', array() ),
			'clinic-definition' => array( '병원 정의 한 문장(홈 히어로 H1 다음)', array() ),
			'home-faq'     => array( '홈 — 자주 묻는 질문(Rank Math FAQ)', array() ),
			'consult-guide' => array( '상담·예약 안내(네이버·카카오 바로가기·전화 — 템플릿 page-consult)', array() ),
			// Task 8 — 템플릿 전용(본문에 넣으면 원장 검토 허용 목록 밖 → 검토 불가).
			'asof'           => array( '기준일(페이지 메타 — 템플릿이 제목을 그리는 페이지)', array() ),
			'profile-links'  => array( '외부 프로필(의료진 메타 sameAs — 템플릿)', array() ),
			'child-list'     => array( '허브 — 게시된 하위 페이지 카드(템플릿)', array() ),
			'doctor-cards'   => array( '의료진 — 게시된 하위 원장 카드(템플릿)', array() ),
			'post-meta'      => array( '글 — 작성일·수정일·작성자·칼럼 원문(템플릿)', array() ),
			'post-prev-next' => array( '글 — 같은 카테고리 이전·다음(템플릿)', array() ),
		);
		foreach ( $blocks as $name => list( $title, $attributes ) ) {
			$method = lcfirst( str_replace( ' ', '', ucwords( str_replace( '-', ' ', $name ) ) ) );
			register_block_type(
				'iwell/' . $name,
				array(
					'api_version'     => 3,
					'title'           => $title,
					'category'        => 'theme',
					'attributes'      => $attributes,
					'uses_context'    => array( 'postId', 'postType' ),
					'supports'        => array(
						'html'     => false,
						'reusable' => false,
					),
					'render_callback' => static fn( $attrs = array(), $content = '', $block = null ): string => self::$method( (array) $attrs, $block ),
				)
			);
		}
	}

	// ── 공통 ──────────────────────────────────────────────────────────

	private static function hasNav(): bool {
		return class_exists( '\Iwell\Core\Nav' );
	}

	/** 공개 목적지 규칙을 거친 사이트 안 주소. */
	public static function url( string $path, ?string $hub = null ): string {
		return self::hasNav() ? \Iwell\Core\Nav::publicUrl( $path, $hub ) : home_url( '/' );
	}

	private static function isPublic( string $path ): bool {
		return self::hasNav() && \Iwell\Core\Nav::isPublic( $path );
	}

	/** @return array{name: string, telephone: string, fax: string, addressText: string, representative?: string, businessNumber?: string, email?: string, youtube?: string, blog?: string} */
	public static function clinic(): array {
		if ( class_exists( '\Iwell\Core\Schema\Graph' ) ) {
			return \Iwell\Core\Schema\Graph::clinicInfo();
		}
		return array(
			'name'        => get_bloginfo( 'name' ),
			'telephone'   => '',
			'fax'         => '',
			'addressText' => '',
		);
	}

	public static function tel(): string {
		return 'tel:' . preg_replace( '/\D+/', '', self::clinic()['telephone'] );
	}

	private static function postId( $block ): int {
		if ( is_object( $block ) && isset( $block->context['postId'] ) ) {
			return (int) $block->context['postId'];
		}
		return is_singular() ? (int) get_queried_object_id() : 0;
	}

	private static function wrap( string $tag, string $class, string $inner, array $extra = array() ): string {
		return sprintf( '<%1$s %2$s>%3$s</%1$s>', $tag, get_block_wrapper_attributes( array( 'class' => $class ) + $extra ), $inner );
	}

	private static function a( string $url, string $text, string $class = '', string $extra = '' ): string {
		return sprintf( '<a%s href="%s"%s>%s</a>', '' === $class ? '' : ' class="' . esc_attr( $class ) . '"', esc_url( $url ), $extra, $text );
	}

	/**
	 * 상담·예약 바로가기(수정 1차 — 대표 지시 2026-11-19 "상담 예약문의도 네이버나 카카오플친으로") = iwell-core Consult\Links 의 값이 있는 칸.
	 * 플러그인이 없거나 값이 하나도 없으면 빈 목록 → 그리는 곳은 전화 단추만 남는다.
	 *
	 * @return list<array{key: string, label: string, short: string, icon: string, url: string}>
	 */
	private static function shortcuts(): array {
		return class_exists( '\Iwell\Core\Consult\Links' ) ? \Iwell\Core\Consult\Links::items() : array();
	}

	/** 바깥 바로가기 링크 하나(새 창, rel noopener — 다른 사이트에 이 창을 넘기지 않는다). */
	private static function external( string $url, string $inner, string $class = '' ): string {
		return self::a( $url, $inner, $class, ' rel="noopener" target="_blank"' );
	}

	/** 바로가기 단추들(값이 있는 칸만, FIELDS 순). */
	private static function shortcutButtons( string $class = 'iwell-btn iwell-btn--line' ): string {
		$html = '';
		foreach ( self::shortcuts() as $s ) {
			$html .= self::external( $s['url'], iwell_icon( $s['icon'] ) . '<span>' . esc_html( $s['label'] ) . '</span>', $class . ' iwell-btn--' . str_replace( '_', '-', $s['key'] ) );
		}
		return $html;
	}

	/** 메뉴 이름 한 마디로 묶는 최대 글자 수 — 넘으면 묶지 않고 띄어쓰기에서 끊기게 둔다(좁은 메뉴 열에서 넘치지 않게). */
	private const NOWRAP_MAX = 10;

	/**
	 * 메뉴 이름 HTML(수정 1차 — 대표 "줄넘김 이상하게 하지 말라고"): 끊을 자리를 '·' 뒤와 '(' 앞(괄호 밖)으로 정하고(<wbr>), 그 사이 마디가
	 * 짧으면(NOWRAP_MAX 이하) 한 줄로 묶는다(span.iwell-nw — white-space nowrap). 글자는 그대로(태그만 더함). 예:
	 * "진료시간·오시는 길·주차" → 진료시간· | 오시는 길· | 주차 ("오시는 / 길"로 끊기지 않음), "놓친 예방접종(따라잡기 접종)" → 놓친 예방접종 | (따라잡기 접종).
	 */
	/** 메뉴 이름 마디: '·' 뒤·'(' 앞(괄호 밖)에서 나눈 조각 목록(글자 그대로). @return list<string> */
	private static function menuChunks( string $title ): array {
		$chunks = array( '' );
		$depth  = 0;
		foreach ( preg_split( '//u', $title, -1, PREG_SPLIT_NO_EMPTY ) ?: array() as $ch ) {
			if ( '(' === $ch && 0 === $depth && '' !== trim( end( $chunks ) ) ) {
				$chunks[] = '';
			}
			$chunks[ count( $chunks ) - 1 ] .= $ch;
			if ( '(' === $ch ) {
				++$depth;
			} elseif ( ')' === $ch && $depth > 0 ) {
				--$depth;
			} elseif ( '·' === $ch && 0 === $depth ) {
				$chunks[] = '';
			}
		}
		return array_values( array_filter( $chunks, static fn( string $c ): bool => '' !== $c ) );
	}

	public static function menuLabel( string $title ): string {
		$parts = array();
		foreach ( self::menuChunks( $title ) as $chunk ) {
			$text    = esc_html( $chunk );
			$parts[] = mb_strlen( $chunk ) <= self::NOWRAP_MAX ? '<span class="iwell-nw">' . $text . '</span>' : $text;
		}
		// 바깥 span 하나로 감싼다 — 링크가 flex(드로어 칩)여도 마디가 각각 flex 항목이 되지 않게(그러면 <wbr> 가 무시되고 접근 이름에 공백이 낀다 — 실측).
		return '<span class="iwell-ml">' . implode( '<wbr>', $parts ) . '</span>';
	}

	/** 메뉴 트리(플러그인 없으면 빈 목록). */
	private static function tree(): array {
		return self::hasNav() ? \Iwell\Core\Nav::tree() : array();
	}

	// ── 머리 ──────────────────────────────────────────────────────────

	/** 로고 + PC 메가메뉴(≥1200px) + 모바일 드로어(<1200px). */
	public static function siteHeader( array $attrs, $block ): string {
		$tree   = self::tree();
		$clinic = self::clinic();
		$logo   = sprintf(
			'<a class="iwell-header__logo" href="%s" rel="home"><img src="%s" alt="%s" width="1146" height="154" decoding="async"></a>',
			esc_url( home_url( '/' ) ),
			esc_url( get_theme_file_uri( 'assets/img/logo-horizontal.png' ) ),
			esc_attr( $clinic['name'] )
		);

		// 열 너비 — 메가메뉴 패널이 1차 줄과 같은 격자 틀을 써서 하위 열이 1차 항목 바로 아래에 온다.
		// 최소 = 1차 이름 폭(한 줄)과 한 줄로 묶은 하위 마디 중 가장 긴 것(수정 1차 — 열이 이보다 좁으면 넘친다) 중 큰 값,
		// 남는 폭은 하위 항목이 긴 열에 더(최대 220px 기준). 틀이 내용과 무관한 값이라 두 격자의 열이 늘 같다.
		$cols = array();
		foreach ( $tree as $hub ) {
			$title   = (int) ceil( self::textPx( $hub['title'], self::TOP_FONT_PX, 1.03 ) ) + 20;
			$longest = 0;
			$unbreak = 0;
			foreach ( $hub['children'] as $child ) {
				$longest = max( $longest, (int) ceil( self::textPx( $child['title'], self::SUB_FONT_PX ) ) + 16 );
				foreach ( self::menuChunks( $child['title'] ) as $chunk ) {
					if ( mb_strlen( $chunk ) <= self::NOWRAP_MAX ) {
						$unbreak = max( $unbreak, (int) ceil( self::textPx( $chunk, self::SUB_FONT_PX ) ) + 16 ); // 좌우 여백 12 + 4
					}
				}
			}
			$min    = max( $title, $unbreak );
			$cols[] = sprintf( 'minmax(%dpx, %dfr)', $min, max( $min, min( $longest, 220 ) ) );
		}
		$style = '--iwell-gnb-cols: ' . ( array() === $cols ? '1fr' : implode( ' ', $cols ) ) . ';';

		$top  = '';
		$subs = '';
		foreach ( $tree as $hub ) {
			$top  .= sprintf( '<li>%s</li>', self::a( $hub['url'], esc_html( $hub['title'] ), 'iwell-gnb__hub', ' data-hub="' . esc_attr( $hub['path'] ) . '"' ) );
			$items = '';
			foreach ( $hub['children'] as $child ) {
				$items .= '<li>' . self::a( $child['url'], self::menuLabel( $child['title'] ) ) . '</li>';
			}
			$subs .= sprintf( '<ul class="iwell-gnb__sub" data-hub="%s" aria-label="%s">%s</ul>', esc_attr( $hub['path'] ), esc_attr( $hub['title'] . ' 하위 메뉴' ), $items );
		}
		$gnb = '' === $top ? '' : sprintf(
			'<nav class="iwell-gnb" aria-label="주 메뉴"><ul class="iwell-gnb__top">%s</ul><div class="iwell-mega"><div class="iwell-mega__inner">%s</div></div></nav>',
			$top,
			$subs
		);

		$groups = '';
		foreach ( $tree as $hub ) {
			$chips = '';
			foreach ( $hub['children'] as $child ) {
				$chips .= '<li>' . self::a( $child['url'], self::menuLabel( $child['title'] ) ) . '</li>';
			}
			$groups .= sprintf(
				'<li class="iwell-drawer__group">%s%s</li>',
				self::a( $hub['url'], esc_html( $hub['title'] ), 'iwell-drawer__hub' ),
				'' === $chips ? '' : '<ul class="iwell-drawer__chips">' . $chips . '</ul>'
			);
		}
		$drawer = sprintf(
			'<details class="iwell-drawer"><summary class="iwell-drawer__toggle"><span class="iwell-drawer__open">%s<span class="screen-reader-text">전체 메뉴 열기</span></span><span class="iwell-drawer__close">%s<span class="screen-reader-text">메뉴 닫기</span></span></summary>'
			. '<div class="iwell-drawer__panel"><nav aria-label="전체 메뉴"><ul class="iwell-drawer__list">%s</ul></nav>'
			. '<div class="iwell-drawer__actions">%s%s</div></div></details>',
			iwell_icon( 'menu' ),
			iwell_icon( 'close' ),
			$groups,
			self::a( self::tel(), iwell_icon( 'phone' ) . '<span>전화 ' . esc_html( $clinic['telephone'] ) . '</span>', 'iwell-btn iwell-btn--primary' ),
			self::shortcutButtons()
		);

		return sprintf(
			'<div %s><div class="iwell-header__inner">%s%s%s</div></div>',
			get_block_wrapper_attributes(
				array(
					'class' => 'iwell-header',
					'style' => $style,
				)
			),
			$logo,
			$gnb,
			$drawer
		);
	}

	/**
	 * 슬림 바·홈 히어로 체크 목록의 진료 안내 — 진료시간 설정에서 계산(iwell-core Hours\Render::summary: 일요일·공휴일 진료 · 매주 월요일 휴진 ·
	 * 매월 마지막주 일요일 휴진). 수정 1차(병원 의견 2026-11-19 "월요일 휴진도 빠졌음"): 정기 휴진 요일을 넣는다. 글로 다시 쓰지 않는다.
	 */
	public static function topbarNote( array $attrs, $block ): string {
		if ( ! class_exists( '\Iwell\Core\Hours\Render' ) || ! class_exists( '\Iwell\Core\Hours\Store' ) ) {
			return '';
		}
		$text = \Iwell\Core\Hours\Render::summary( \Iwell\Core\Hours\Store::config() );
		return '' === $text ? '' : self::wrap( 'p', 'iwell-topbar__note', esc_html( $text ) );
	}

	// ── 바닥글·고정 바 ─────────────────────────────────────────────────

	public static function footerNav( array $attrs, $block ): string {
		$cols = '';
		foreach ( self::tree() as $hub ) {
			$items = '';
			foreach ( $hub['children'] as $child ) {
				$items .= '<li>' . self::a( $child['url'], self::menuLabel( $child['title'] ) ) . '</li>';
			}
			$cols .= sprintf(
				'<li class="iwell-footer-nav__col">%s%s</li>',
				self::a( $hub['url'], esc_html( $hub['title'] ), 'iwell-footer-nav__hub' ),
				'' === $items ? '' : '<ul class="iwell-footer-nav__sub">' . $items . '</ul>'
			);
		}
		$local = '';
		$legal = '';
		if ( self::hasNav() ) {
			foreach ( \Iwell\Core\Nav::footerPages() as $p ) {
				// 개인정보처리방침만 굵게·구분(시행령 제31조 제2항 — 다른 링크와 구분해 계속 게재, 2026-11-25). 환자 권리·이용약관은 보통 굵기.
				$privacy = 'privacy' === $p['path'];
				$li      = '<li>' . self::a( $p['url'], esc_html( $p['title'] ), $privacy ? 'iwell-footer-nav__privacy' : '' ) . '</li>';
				if ( in_array( explode( '/', $p['path'] )[0], self::LEGAL, true ) ) {
					$legal .= $li;
				} else {
					$local .= $li;
				}
			}
		}
		if ( '' === $cols && '' === $local && '' === $legal ) {
			return '';
		}
		return self::wrap(
			'nav',
			'iwell-footer-nav',
			( '' === $cols ? '' : '<ul class="iwell-footer-nav__cols">' . $cols . '</ul>' )
			. ( '' === $local ? '' : '<ul class="iwell-footer-nav__local" aria-label="지역 안내">' . $local . '</ul>' )
			. ( '' === $legal ? '' : '<ul class="iwell-footer-nav__legal" aria-label="약관·정책">' . $legal . '</ul>' ),
			array( 'aria-label' => '사이트맵' )
		);
	}

	public static function clinicInfo( array $attrs, $block ): string {
		$c    = self::clinic();
		$rows = array_filter(
			array(
				'상호'       => $c['legalName'] ?? '', // 법적 명칭 "…의원"(처리방침과 같은 표기 — 2026-11-25). 위 굵은 제목은 화면 브랜드 이름.
				'주소'       => $c['addressText'] ?? '',
				'전화'       => $c['telephone'] ?? '',
				'팩스'       => $c['fax'] ?? '',
				'대표자'      => $c['representative'] ?? '',
				'사업자등록번호' => $c['businessNumber'] ?? '',
				'E-mail'   => $c['email'] ?? '',
			),
			static fn( $v ): bool => '' !== (string) $v
		);
		$dl   = '';
		foreach ( $rows as $k => $v ) {
			$value = '전화' === $k ? self::a( self::tel(), esc_html( $v ) ) : esc_html( $v );
			$dl   .= sprintf( '<div><dt>%s</dt><dd>%s</dd></div>', esc_html( $k ), $value );
		}
		return self::wrap(
			'div',
			'iwell-clinic-info',
			sprintf(
				'<p class="iwell-clinic-info__name">%s</p><dl>%s</dl><p class="iwell-clinic-info__copy">© %s %s</p>',
				esc_html( $c['name'] ),
				$dl,
				esc_html( wp_date( 'Y' ) ),
				esc_html( $c['name'] )
			)
		);
	}

	/**
	 * 모바일 하단 바(1280px 미만) — 전화 / 상담·예약 바로가기 한 칸(값이 있을 때만 — 네이버 예약 → 카카오톡 채널 → 네이버 톡톡 순 첫 값) / 진료시간 / 오시는 길.
	 * 수정 1차: 사이트 안 상담 페이지(/consult/)로 보내지 않는다. 바로가기 값이 없으면 3칸.
	 */
	public static function bottomBar( array $attrs, $block ): string {
		$html = '<li>' . self::a( self::tel(), iwell_icon( 'phone' ) . '<span>전화</span>', 'is-call' ) . '</li>';
		$main = class_exists( '\Iwell\Core\Consult\Links' ) ? \Iwell\Core\Consult\Links::primary() : null;
		if ( null !== $main ) {
			$html .= '<li>' . self::external( $main['url'], iwell_icon( $main['icon'] ) . '<span>' . esc_html( $main['short'] ) . '</span>', 'is-' . str_replace( '_', '-', $main['key'] ) ) . '</li>';
		}
		$html .= '<li>' . self::a( self::url( 'guide/hours' ), iwell_icon( 'clock' ) . '<span>진료시간</span>' ) . '</li>';
		$html .= '<li>' . self::a( self::url( 'guide/hours#map' ), iwell_icon( 'pin' ) . '<span>오시는 길</span>' ) . '</li>';
		return self::wrap( 'nav', 'iwell-bottom-bar' . ( null === $main ? ' is-3' : '' ), '<ul>' . $html . '</ul>', array( 'aria-label' => '빠른 연결' ) );
	}

	/**
	 * PC 우측 퀵바(1280px 이상, 본문 폭 바깥 여백) — 전화 · 바로가기(값마다 하나) · 진료시간 · 유튜브 · 블로그 · 맨 위로.
	 * 유튜브·블로그(대표 지시 2026-11-23) = config/clinic.php youtube·blog(병원 기본 정보 한 곳), 값이 있을 때만, 공식 로고(iwell_brand_logo).
	 * 모바일 하단 바에는 넣지 않는다.
	 */
	public static function quickBar( array $attrs, $block ): string {
		$html = '<li>' . self::a( self::tel(), iwell_icon( 'phone' ) . '<span>전화</span>' ) . '</li>';
		foreach ( self::shortcuts() as $s ) {
			$html .= '<li>' . self::external( $s['url'], iwell_icon( $s['icon'] ) . '<span>' . esc_html( $s['short'] ) . '</span>' ) . '</li>';
		}
		$html  .= '<li>' . self::a( self::url( 'guide/hours' ), iwell_icon( 'clock' ) . '<span>진료시간</span>' ) . '</li>';
		$clinic = self::clinic();
		foreach ( array( 'youtube' => array( 'youtube', '유튜브' ), 'blog' => array( 'naver-blog', '블로그' ) ) as $key => [ $logo, $name ] ) {
			$url = (string) ( $clinic[ $key ] ?? '' );
			if ( '' !== $url ) {
				$html .= '<li>' . self::external( $url, iwell_brand_logo( $logo ) . '<span>' . $name . '</span>' ) . '</li>';
			}
		}
		$html .= '<li>' . self::a( '#top', iwell_icon( 'arrow-up' ) . '<span>맨 위로</span>', 'is-top' ) . '</li>';
		return self::wrap( 'nav', 'iwell-quick-bar', '<ul>' . $html . '</ul>', array( 'aria-label' => '빠른 메뉴' ) );
	}

	// ── 페이지 틀(T2·허브 공통) ────────────────────────────────────────

	/** 서브 비주얼 — 1차 메뉴명(H1 아님). 허브 밖 최상위 페이지는 그 페이지 제목. 게시판(글·카테고리 목록 — Task 8 T6)은 소속 허브 이름. */
	public static function subVisual( array $attrs, $block ): string {
		$board = self::board( $block );
		if ( null !== $board ) {
			// 고정 메뉴 항목의 소속 허브(공지 → 병원소개, 칼럼 → 건강정보 — Nav::FIXED). 허브 열이 메뉴에 없으면 카테고리 이름.
			$section = self::hasNav() && '' !== $board['route'] ? \Iwell\Core\Nav::routeSection( $board['route'] ) : null;
			$title   = null !== $section ? $section['hub']['title'] : $board['name'];
		} else {
			$id = self::postId( $block );
			if ( $id <= 0 ) {
				return '';
			}
			$section = self::hasNav() ? \Iwell\Core\Nav::section( $id ) : null;
			$title   = null !== $section ? $section['hub']['title'] : get_the_title( $id );
		}
		return self::wrap( 'div', 'iwell-subvisual', '<div class="iwell-subvisual__inner"><p class="iwell-subvisual__title">' . esc_html( wp_strip_all_tags( $title ) ) . '</p></div>' );
	}

	public static function breadcrumb( array $attrs, $block ): string {
		if ( null !== self::board( $block ) ) {
			return self::boardBreadcrumb();
		}
		$id = self::postId( $block );
		if ( $id <= 0 || ! self::hasNav() ) {
			return '';
		}
		$items = '';
		foreach ( \Iwell\Core\Nav::breadcrumb( $id ) as $c ) {
			$items .= empty( $c['current'] )
				? '<li>' . self::a( $c['url'], esc_html( $c['title'] ) ) . '</li>'
				: '<li><span aria-current="page">' . esc_html( $c['title'] ) . '</span></li>';
		}
		return self::wrap( 'nav', 'iwell-breadcrumb', '<ol>' . $items . '</ol>', array( 'aria-label' => '현재 위치' ) );
	}

	/** 형제 탭 = 페이지가 속한 1차 허브의 2차 메뉴(고정 항목 포함). 현재 페이지 aria-current="page", 조상 2차는 "true". */
	public static function tabs( array $attrs, $block ): string {
		if ( ! self::hasNav() ) {
			return '';
		}
		$board = self::board( $block );
		if ( null !== $board ) {
			// 게시판: 소속 허브의 2차 메뉴. 목록 주소 항목이 열려 있으면(Task 9) 그 항목이 현재 — 목록 화면 = page, 글 상세 = true.
			$section = '' === $board['route'] ? null : \Iwell\Core\Nav::routeSection( $board['route'] );
			$here    = is_category() ? $board['route'] : '';
		} else {
			$id = self::postId( $block );
			if ( $id <= 0 ) {
				return '';
			}
			$section = \Iwell\Core\Nav::section( $id );
			$here    = \Iwell\Core\Nav::pathOf( $id );
		}
		if ( null === $section || array() === $section['hub']['children'] ) {
			return '';
		}
		$items = '';
		foreach ( $section['hub']['children'] as $child ) {
			$current = '';
			if ( $child['path'] === $here ) {
				$current = ' aria-current="page"';
			} elseif ( $child['path'] === $section['active'] ) {
				$current = ' aria-current="true"';
			}
			$items .= '<li>' . self::a( $child['url'], self::menuLabel( $child['title'] ), '', $current ) . '</li>';
		}
		return self::wrap( 'nav', 'iwell-tabs', '<ul>' . $items . '</ul>', array( 'aria-label' => $section['hub']['title'] . ' 메뉴' ) );
	}

	/** 페이지 제목 H1 — 본문이 질문형 H1 을 갖고 있으면(T2~T5 패턴) 내보내지 않는다(페이지당 H1 1개). */
	public static function pageTitle( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || self::hasBodyH1( $id ) ) {
			return '';
		}
		return self::wrap( 'h1', 'iwell-page-title', esc_html( wp_strip_all_tags( get_the_title( $id ) ) ) );
	}

	/** 본문이 H1 을 갖고 있나(T2·T3·T5 패턴 — 질문형·이름 H1). 없으면 템플릿이 페이지 제목을 H1 으로 그린다(T4 정보표 등). */
	private static function hasBodyH1( int $id ): bool {
		$content = (string) get_post_field( 'post_content', $id );
		return 1 === preg_match( '/<!--\s*wp:heading\s+\{[^}]*"level"\s*:\s*1\b/', $content ) || 1 === preg_match( '/<h1[\s>]/i', $content );
	}

	public static function prevNext( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! self::hasNav() ) {
			return '';
		}
		$s = \Iwell\Core\Nav::siblings( $id );
		if ( null === $s['prev'] && null === $s['next'] ) {
			return '';
		}
		$html  = null === $s['prev'] ? '<span class="iwell-prevnext__empty"></span>' : self::a( $s['prev']['url'], iwell_icon( 'arrow-left' ) . '<span><small>이전</small>' . esc_html( $s['prev']['title'] ) . '</span>', 'iwell-prevnext__prev', ' rel="prev"' );
		$html .= null === $s['next'] ? '' : self::a( $s['next']['url'], '<span><small>다음</small>' . esc_html( $s['next']['title'] ) . '</span>' . iwell_icon( 'arrow-right' ), 'iwell-prevnext__next', ' rel="next"' );
		return self::wrap( 'nav', 'iwell-prevnext', $html, array( 'aria-label' => '같은 메뉴의 이전·다음 페이지' ) );
	}

	/**
	 * 예약·전화 버튼. variant: band(고정 페이지 템플릿 page.html 이 본문·관련 페이지 뒤에 그리는 띠 — Task 7 수정 3) · hero(홈 첫 구역) · inline.
	 * 읽는 것 = 병원 정보(config/clinic.php — 코드, 직원이 관리 화면에서 못 바꿈), 상담 바로가기(관리자 설정 — Consult\Links), 진료시간 페이지의 공개 주소.
	 */
	public static function cta( array $attrs, $block ): string {
		$c       = self::clinic();
		$variant = in_array( $attrs['variant'] ?? 'band', array( 'band', 'hero', 'inline' ), true ) ? $attrs['variant'] : 'band';
		// 수정 1차: "상담·예약 문의" 단추 = 네이버·카카오 바로가기(값이 있는 칸만). 값이 없으면 전화 단추만.
		$buttons = self::a( self::tel(), iwell_icon( 'phone' ) . '<span>전화 ' . esc_html( $c['telephone'] ) . '</span>', 'iwell-btn iwell-btn--primary' )
			. self::shortcutButtons();
		if ( 'hero' === $variant ) {
			$buttons .= self::a( self::url( 'guide/hours' ), iwell_icon( 'clock' ) . '<span>진료시간</span>', 'iwell-btn iwell-btn--line' );
		}
		$lead = 'band' === $variant ? '<p class="iwell-cta__lead">진료 문의 ' . esc_html( $c['telephone'] ) . '</p>' : '';
		return self::wrap( 'div', 'iwell-cta iwell-cta--' . $variant, $lead . '<div class="iwell-cta__buttons">' . $buttons . '</div>' );
	}

	/** 사이트 안 링크 하나 — 목적지가 비공개면 규칙대로 대체, 홈으로 떨어지면 내보내지 않는다(같은 홈 링크 반복 방지). */
	public static function link( array $attrs, $block ): string {
		$path  = (string) ( $attrs['path'] ?? '' );
		$label = (string) ( $attrs['label'] ?? '' );
		if ( '' === $path || '' === $label ) {
			return '';
		}
		$url = self::url( $path );
		if ( untrailingslashit( $url ) === untrailingslashit( home_url( '/' ) ) ) {
			return '';
		}
		return self::wrap( 'p', 'iwell-more', self::a( $url, esc_html( $label ) . iwell_icon( 'chevron', '', 18 ) ) );
	}

	/**
	 * 관련 페이지 — 템플릿(page.html, 본문 바로 뒤)이 그리는 탐색 장치(Task 7 수정 3 — 코디네이터 결정: 본문 블록이면 다른 게시 페이지 제목·주소가
	 * 원장 검토 지문에 묶이므로 브레드크럼·형제 탭처럼 검토 범위 밖 템플릿으로). 목록 = Nav::related()(같은 1차 허브의 게시된 하위 최대 3개, 메뉴 순서,
	 * 자기 제외 — 제목·주소는 Nav 색인의 게시본 행). 없으면 구역 자체가 없다.
	 */
	public static function related( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! self::hasNav() ) {
			return '';
		}
		$items = '';
		foreach ( \Iwell\Core\Nav::related( $id ) as $page ) {
			$items .= '<li>' . self::a( $page['url'], esc_html( wp_strip_all_tags( $page['title'] ) ) . iwell_icon( 'chevron', '', 18 ) ) . '</li>';
		}
		if ( '' === $items ) {
			return '';
		}
		return self::wrap( 'section', 'iwell-related', '<h2 class="wp-block-heading">관련 페이지</h2><ul>' . $items . '</ul>' );
	}

	/**
	 * 출처 목록 = 페이지 메타 iwell_sources(구조화 데이터 citation 과 같은 원천, Task 6). 비어 있으면 없다.
	 * 템플릿(page.html, 예약·전화 띠 뒤)이 그린다(Task 7 수정 3). iwell_sources 는 검토 대상 메타(PageMeta::REVIEWED_META — 승인 지문 안)라
	 * 템플릿에서 그려도 바뀌면 원장 검토 기록이 빠진다(검토 범위 그대로).
	 */
	public static function sources( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! class_exists( '\Iwell\Core\PageMeta' ) ) {
			return '';
		}
		$sources = (array) ( \Iwell\Core\PageMeta::get( $id )['sources'] ?? array() );
		$items   = '';
		foreach ( $sources as $s ) {
			$title = trim( (string) ( $s['title'] ?? '' ) );
			$url   = trim( (string) ( $s['url'] ?? '' ) );
			if ( '' === $title ) {
				continue;
			}
			$text   = '' === $url ? esc_html( $title ) : sprintf( '<a href="%s" rel="noopener" target="_blank">%s</a>', esc_url( $url ), esc_html( $title ) );
			$date   = trim( (string) ( $s['accessed'] ?? '' ) );
			$items .= '<li>' . $text . ( '' === $date ? '' : ' <span class="iwell-sources__date">(확인 ' . esc_html( $date ) . ')</span>' ) . '</li>';
		}
		if ( '' === $items ) {
			return '';
		}
		return self::wrap( 'section', 'iwell-sources', '<h2 class="wp-block-heading">출처</h2><ol>' . $items . '</ol>' );
	}

	/**
	 * 게시된 바로 아래 T5 원장만, Nav 메뉴 순서. 모든 글자·사진은 그 게시본에서 읽는다(검토 대상 본문 밖).
	 * 비밀번호 보호 원장 쪽은 본문을 읽기 전에 뺀다(Codex 교차 검증 P1 2026-11-20 — 카드가 보호 본문의 사진·이력을 내보내지 않게).
	 */
	public static function doctorCards( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! self::hasNav() ) {
			return '';
		}
		$cards = '';
		$has_class = static fn( array $b, string $class ): bool => in_array( $class, preg_split( '/\s+/', (string) ( $b['attrs']['className'] ?? '' ) ), true );
		foreach ( \Iwell\Core\Nav::childCards( $id ) as $page ) {
			$post = 'page' === $page['kind'] ? get_post( $page['id'] ) : null;
			if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || $id !== (int) $post->post_parent || '' !== (string) $post->post_password ) {
				continue;
			}
			$roots = array_filter( parse_blocks( $post->post_content ), static fn( array $b ): bool => 'core/group' === $b['blockName'] && $has_class( $b, 'iwell-t5--doctor' ) );
			if ( array() === $roots ) {
				continue;
			}
			$title = wp_strip_all_tags( $page['title'] );
			$photo = '';
			$creds = '';
			$read = static function ( array $blocks ) use ( &$read, &$photo, &$creds, $has_class, $title ): void {
				foreach ( $blocks as $b ) {
					if ( 'core/image' === $b['blockName'] && $has_class( $b, 'iwell-t5__photo' ) && '' === $photo ) {
						$tags = new WP_HTML_Tag_Processor( $b['innerHTML'] );
						if ( $tags->next_tag( 'IMG' ) ) {
							$src = esc_url( (string) $tags->get_attribute( 'src' ) );
							if ( '' !== $src ) {
								$photo = '<figure class="iwell-doctor__photo"><img src="' . $src . '" alt="' . esc_attr( (string) $tags->get_attribute( 'alt' ) ) . '" loading="lazy" decoding="async"></figure>';
							}
						}
					}
					if ( 'core/group' === $b['blockName'] && $has_class( $b, 'iwell-sec-career' ) ) {
						preg_match_all( '~<td\b[^>]*>(.*?)</td>~si', serialize_blocks( $b['innerBlocks'] ), $values );
						// 카드는 이력 표의 앞 CARD_CAREER_ROWS 줄(요약 — 직함·전문의·학력)만. 주요경력·학술활동 같은 긴 목록 줄은 원장 페이지에서만(2026-11-25).
						foreach ( array_slice( $values[1], 0, self::CARD_CAREER_ROWS ) as $value ) {
							$text = trim( html_entity_decode( wp_strip_all_tags( $value ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
							if ( '' !== $text && ! str_contains( $title, $text ) ) {
								$creds .= '<li>' . esc_html( $text ) . '</li>';
							}
						}
					}
					$read( $b['innerBlocks'] ?? array() );
				}
			};
			$read( $roots );
			$cards .= '<article class="iwell-doctor' . ( '' === $photo ? ' iwell-doctor--no-photo' : '' ) . '">' . $photo
				. '<div class="iwell-doctor__text"><h2 class="iwell-doctor__name">' . esc_html( $title ) . '</h2>'
				. ( '' === $creds ? '' : '<ul class="iwell-doctor__creds">' . $creds . '</ul>' )
				. '<p class="iwell-more">' . self::a( $page['url'], '자세히 보기' . iwell_icon( 'chevron', '', 18 ), '', ' aria-label="' . esc_attr( $title . ' 자세히 보기' ) . '"' ) . '</p></div></article>';
		}
		return '' === $cards ? '' : self::wrap( 'section', 'iwell-doctor-cards', $cards, array( 'aria-label' => '의료진' ) );
	}

	// ── Task 8: T3 목차·T4 기준일·T5 외부 프로필·허브 하위 카드 ─────────────────

	/**
	 * T3 목차(대표 승인 2026-11-13 — 참고 사이트 흐름 분석): render_block_core/group 필터. 바깥 그룹 클래스가 iwell-t3 이고 그 안 h2 가 TOC_MIN(3)개
	 * 이상이면, 직답 상자(.iwell-t3__answer) 바로 뒤에 같은 페이지 앵커 목차(nav.iwell-toc — 자바스크립트 없이 HTML)를 넣고 id 없는 h2 에 id 를 단다.
	 * 2개 이하면 손대지 않는다.
	 * 앵커 = 제목 글자에서 만든다(anchor() — 순서·위치와 무관해 다른 구역을 넣고 빼도 기존 제목의 앵커는 그대로, 같은 글자는 -2·-3). 편집기에서
	 * 직접 단 id(HTML 앵커)는 그대로 쓴다. 본문(원장 검토 대상 — 저장된 글)은 바꾸지 않고 출력만 — 목차는 그 본문 제목에서만 만든다.
	 *
	 * @param mixed $html  그룹 출력.
	 * @param mixed $block 파싱된 블록.
	 */
	public static function toc( $html, $block = array() ): string {
		$html  = (string) $html;
		$class = (string) ( is_array( $block ) ? ( $block['attrs']['className'] ?? '' ) : '' );
		if ( 1 !== preg_match( '/(?:^|\s)iwell-t3(?:\s|$)/', $class )
			|| ! preg_match_all( '~<h2\b([^>]*)>(.*?)</h2>~s', $html, $heads, PREG_SET_ORDER | PREG_OFFSET_CAPTURE )
			|| count( $heads ) < self::TOC_MIN ) {
			return $html;
		}
		$used = array();
		if ( preg_match_all( '~(?:^|\s)id="([^"]*)"~', $html, $ids ) ) {
			foreach ( $ids[1] as $id ) {
				$used[ html_entity_decode( $id, ENT_QUOTES, 'UTF-8' ) ] = true;
			}
		}
		$out   = '';
		$last  = 0;
		$items = '';
		foreach ( $heads as $h ) {
			$attrs = $h[1][0];
			$text  = trim( wp_strip_all_tags( $h[2][0] ) );
			if ( preg_match( '~(?:^|\s)id="([^"]+)"~', $attrs, $own ) ) {
				$id  = html_entity_decode( $own[1], ENT_QUOTES, 'UTF-8' );
				$tag = $h[0][0];
			} else {
				$id  = self::anchor( $text, $used );
				$tag = '<h2' . $attrs . ' id="' . esc_attr( $id ) . '">' . $h[2][0] . '</h2>';
			}
			$out   .= substr( $html, $last, $h[0][1] - $last ) . $tag;
			$last   = $h[0][1] + strlen( $h[0][0] );
			$items .= '<li><a href="#' . esc_attr( $id ) . '">' . esc_html( $text ) . '</a></li>';
		}
		$out .= substr( $html, $last );
		$toc  = '<nav class="iwell-toc" aria-label="목차"><p class="iwell-toc__title">목차</p><ol>' . $items . '</ol></nav>';
		$at   = self::afterElement( $out, 'iwell-t3__answer' );
		if ( null === $at ) {
			// 직답 상자를 못 찾으면(잠금 해제 후 구조가 바뀐 경우) 첫 h2 를 담은 구역 앞 — 그래도 "목차 → 본문 제목" 순서는 지킨다.
			$first = strpos( $out, '<h2' );
			$open  = false === $first ? false : strrpos( substr( $out, 0, $first ), '<section' );
			$at    = false === $open ? (int) $first : $open;
		}
		return substr( $out, 0, $at ) . $toc . substr( $out, $at );
	}

	/** 제목 글자 → 앵커 id(유니코드 글자·숫자만, 나머지는 '-', 최대 60자). $used 와 겹치면 -2, -3 …. 만든 id 를 $used 에 더한다. */
	public static function anchor( string $text, array &$used ): string {
		$base = trim( (string) preg_replace( '/[^\p{L}\p{N}]+/u', '-', mb_strtolower( $text, 'UTF-8' ) ), '-' );
		$base = trim( mb_substr( $base, 0, 60, 'UTF-8' ), '-' );
		$base = '' === $base ? 'section' : $base;
		$id   = $base;
		for ( $n = 2; isset( $used[ $id ] ); $n++ ) {
			$id = $base . '-' . $n;
		}
		$used[ $id ] = true;
		return $id;
	}

	/** $class 를 가진 첫 div 요소가 끝나는 바로 뒤 위치(중첩 div 를 센다). 없으면 null. */
	private static function afterElement( string $html, string $class ): ?int {
		if ( ! preg_match( '~<div\b[^>]*\bclass="[^"]*\b' . preg_quote( $class, '~' ) . '\b[^"]*"[^>]*>~', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return null;
		}
		if ( ! preg_match_all( '~<(/?)div\b[^>]*>~', $html, $tags, PREG_SET_ORDER | PREG_OFFSET_CAPTURE, $m[0][1] ) ) {
			return null;
		}
		$depth = 0;
		foreach ( $tags as $t ) {
			$depth += '/' === $t[1][0] ? -1 : 1;
			if ( 0 === $depth ) {
				return $t[0][1] + strlen( $t[0][0] );
			}
		}
		return null;
	}

	/**
	 * T4 기준일(page.html — 페이지 제목 H1 바로 뒤): 본문에 H1 이 없어 템플릿이 제목을 그리는 고정 페이지(T4 정보표 등)에서 페이지 메타 기준일
	 * (iwell_data_asof — 편집기 "의학 정보" 패널, 원장 검토 대상 메타)이 있으면 "기준일 Y.m.d". 본문 H1 페이지(T2·T3 — 검토 배지가 기준일을 보인다)·
	 * 기준일 없는 페이지는 없음. 표의 값과 같은 원천에서 그리므로 본문에 날짜를 다시 쓰지 않는다.
	 */
	public static function asof( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || 'page' !== get_post_type( $id ) || self::hasBodyH1( $id ) || ! class_exists( '\Iwell\Core\PageMeta' ) ) {
			return '';
		}
		$asof = \Iwell\Core\PageMeta::sanitizeDate( get_post_meta( $id, 'iwell_data_asof', true ) );
		if ( '' === $asof ) {
			return '';
		}
		return self::wrap( 'p', 'iwell-asof', '기준일 <time datetime="' . esc_attr( $asof ) . '">' . esc_html( str_replace( '-', '.', $asof ) ) . '</time>' );
	}

	/**
	 * T5 원장 외부 프로필(page.html — 본문 바로 뒤) = 페이지 메타 iwell_physician.sameAs(구조화 데이터 Physician sameAs 와 같은 원천·순서 — 원장 검토 대상 메타).
	 * 없으면 구역 없음. 바깥 사이트라 새 창(rel noopener) — 출처 목록과 같은 규칙.
	 */
	public static function profileLinks( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! class_exists( '\Iwell\Core\PageMeta' ) ) {
			return '';
		}
		$items = '';
		foreach ( (array) ( \Iwell\Core\PageMeta::physician( $id )['sameAs'] ?? array() ) as $url ) {
			$label  = (string) preg_replace( '~^https?://~i', '', untrailingslashit( (string) $url ) );
			$items .= '<li>' . sprintf( '<a href="%s" rel="noopener" target="_blank">%s%s</a>', esc_url( (string) $url ), esc_html( $label ), iwell_icon( 'external', '', 18 ) ) . '</li>';
		}
		if ( '' === $items ) {
			return '';
		}
		return self::wrap( 'section', 'iwell-profiles', '<h2 class="wp-block-heading">외부 프로필</h2><ul>' . $items . '</ul>' );
	}

	/**
	 * 허브 하위 카드(page-hub.html — 소개 문단 뒤) = Nav::childCards()(게시된 하위 — 허브는 메뉴와 같은 2차 항목·고정 항목 포함, 메뉴 순서, 제목 = Nav 게시본).
	 * 카드 한 줄 설명 = 그 페이지의 게시본 요약(직접 쓴 발췌)만 — 본문에서 지어 내지 않는다. 하위가 없으면 구역 없음(허브를 하위가 게시될 때까지
	 * 비공개로 두는 것은 Task 9 setup-site).
	 */
	public static function childList( array $attrs, $block ): string {
		$id = self::postId( $block );
		if ( $id <= 0 || ! self::hasNav() ) {
			return '';
		}
		$items = '';
		foreach ( \Iwell\Core\Nav::childCards( $id ) as $card ) {
			$line   = 'page' === $card['kind'] && $card['id'] > 0 ? trim( (string) get_post_field( 'post_excerpt', $card['id'] ) ) : '';
			$items .= sprintf(
				'<li><a class="iwell-child-card" href="%s"><span class="iwell-child-card__title">%s</span>%s%s</a></li>',
				esc_url( $card['url'] ),
				esc_html( wp_strip_all_tags( $card['title'] ) ),
				'' === $line ? '' : '<span class="iwell-child-card__line">' . esc_html( $line ) . '</span>',
				iwell_icon( 'chevron', '', 20 )
			);
		}
		if ( '' === $items ) {
			return '';
		}
		$title = wp_strip_all_tags( '' !== \Iwell\Core\Nav::title( \Iwell\Core\Nav::pathOf( $id ) ) ? \Iwell\Core\Nav::title( \Iwell\Core\Nav::pathOf( $id ) ) : get_the_title( $id ) );
		return self::wrap( 'nav', 'iwell-child-list', '<ul>' . $items . '</ul>', array( 'aria-label' => $title . ' 하위 페이지' ) );
	}

	// ── Task 8: T6 게시판(글 상세·카테고리 목록) ────────────────────────────

	/**
	 * 지금 화면이 게시판(글 상세 또는 카테고리 목록)이면 {route: 고정 메뉴 경로(notices|columns, 없으면 ''), name: 카테고리 이름}, 아니면 null.
	 * 목록 화면의 맨 위 블록 문맥 postId 는 목록 첫 글이라(render_block 이 전역 글을 문맥으로 준다) 목록 판정을 먼저 한다.
	 */
	private static function board( $block ): ?array {
		$term = null;
		if ( is_category() ) {
			$term = get_queried_object();
		} else {
			$id = self::postId( $block );
			if ( $id <= 0 || 'post' !== get_post_type( $id ) ) {
				return null;
			}
			$terms = get_the_category( $id );
			foreach ( $terms as $t ) {
				if ( self::hasNav() && in_array( $t->slug, \Iwell\Core\Nav::ROUTES, true ) ) {
					$term = $t;
					break;
				}
			}
			$term ??= $terms[0] ?? null;
		}
		if ( ! $term instanceof WP_Term ) {
			return array(
				'route' => '',
				'name'  => '',
			);
		}
		return array(
			'route' => self::hasNav() && in_array( $term->slug, \Iwell\Core\Nav::ROUTES, true ) ? $term->slug : '',
			'name'  => $term->name,
		);
	}

	/**
	 * 게시판 브레드크럼 = Rank Math 브레드크럼 항목(구조화 데이터 BreadcrumbList 와 같은 원천 — 첫 항목 이름 '홈'은 Nav::rankMathCrumbs). 마지막 = 현재.
	 * Rank Math 가 없으면 홈 → 카테고리(→ 글 제목).
	 */
	private static function boardBreadcrumb(): string {
		$crumbs = array();
		$rm     = class_exists( '\RankMath\Frontend\Breadcrumbs' ) ? \RankMath\Frontend\Breadcrumbs::get() : false;
		if ( is_object( $rm ) && method_exists( $rm, 'get_crumbs' ) ) {
			foreach ( (array) $rm->get_crumbs() as $c ) {
				$crumbs[] = array( (string) ( $c[0] ?? '' ), (string) ( $c[1] ?? '' ) );
			}
		}
		if ( array() === $crumbs ) {
			$crumbs[] = array( '홈', home_url( '/' ) );
			$term     = is_category() ? get_queried_object() : ( get_the_category( (int) get_queried_object_id() )[0] ?? null );
			if ( $term instanceof WP_Term ) {
				$crumbs[] = array( $term->name, (string) get_term_link( $term ) );
			}
			if ( is_singular() ) {
				$crumbs[] = array( get_the_title( (int) get_queried_object_id() ), '' );
			}
		}
		$items = '';
		$last  = count( $crumbs ) - 1;
		foreach ( $crumbs as $i => list( $name, $link ) ) {
			$items .= $i === $last || '' === $link
				? '<li><span' . ( $i === $last ? ' aria-current="page"' : '' ) . '>' . esc_html( $name ) . '</span></li>'
				: '<li>' . self::a( $link, esc_html( $name ) ) . '</li>';
		}
		return self::wrap( 'nav', 'iwell-breadcrumb', '<ol>' . $items . '</ol>', array( 'aria-label' => '현재 위치' ) );
	}

	/**
	 * 글 상세 제목 아래 줄(single.html — 계획 Task 8 T6 + 대표 승인 GEO 2):
	 *   - 칼럼(columns)이고 메타 iwell_naver_log_no 가 있으면: "원문 게시 {post_date Y.m.d} · 홈페이지 정리 {iwell_imported_at Y.m.d}"(정리일 없으면 원문 게시만)
	 *     + "네이버 블로그 원문" 링크(https://blog.naver.com/samsungiwell/{logNo}, 같은 창 일반 링크). 작성일·수정일 줄 대신.
	 *   - 그 밖(공지·원문 번호 없는 칼럼): "작성일 Y.m.d" + "· 수정일 Y.m.d"(날짜가 다를 때만).
	 *   - 작성자: 칼럼 = 원장 이름(Graph::columnAuthor — config/clinic.php columnAuthor, 같은 이름의 게시된 의료진 페이지가 있으면 그 페이지 링크),
	 *     그 밖 = 병원 이름. 글 작성 계정(칼럼 봇·직원)의 프로필은 쓰지 않는다.
	 */
	public static function postMeta( array $attrs, $block ): string {
		$id   = self::postId( $block );
		$post = $id > 0 ? get_post( $id ) : null;
		if ( ! $post instanceof WP_Post || 'post' !== $post->post_type ) {
			return '';
		}
		$column = has_category( 'columns', $post );
		$source = $column && class_exists( '\Iwell\Core\Columns\Meta' ) ? \Iwell\Core\Columns\Meta::originalUrl( $id ) : '';
		$time   = static fn( string $ymd ): string => '<time datetime="' . esc_attr( $ymd ) . '">' . esc_html( str_replace( '-', '.', $ymd ) ) . '</time>';
		$posted = get_the_date( 'Y-m-d', $post );
		if ( '' !== $source ) {
			$imported = \Iwell\Core\Columns\Meta::importedAt( $id );
			$dates    = '<span>원문 게시 ' . $time( $posted ) . '</span>' . ( '' === $imported ? '' : ' · <span>홈페이지 정리 ' . $time( $imported ) . '</span>' );
		} else {
			$modified = get_the_modified_date( 'Y-m-d', $post );
			$dates    = '<span>작성일 ' . $time( $posted ) . '</span>' . ( $modified !== $posted && '' !== (string) $modified ? ' · <span>수정일 ' . $time( (string) $modified ) . '</span>' : '' );
		}
		$name = self::clinic()['name'];
		$link = '';
		if ( $column && class_exists( '\Iwell\Core\Schema\Graph' ) ) {
			$author = \Iwell\Core\Schema\Graph::columnAuthor();
			$name   = $author['label'];
			$link   = null !== $author['physician'] ? (string) $author['physician']['url'] : '';
		}
		$by  = '<p class="iwell-post-meta__author">작성자 ' . ( '' === $link ? esc_html( $name ) : self::a( $link, esc_html( $name ) ) ) . '</p>';
		$src = '' === $source ? '' : '<p class="iwell-post-meta__source">' . self::a( $source, esc_html( self::SOURCE_LABEL ) . iwell_icon( 'external', '', 18 ) ) . '</p>';
		return self::wrap( 'div', 'iwell-post-meta', '<p class="iwell-post-meta__dates">' . $dates . '</p>' . $by . $src );
	}

	/** 같은 카테고리의 이전(더 오래된)·다음(더 새) 글(single.html 끝 — T2 이전/다음과 같은 모양). 없으면 구역 없음. */
	public static function postPrevNext( array $attrs, $block ): string {
		$id   = self::postId( $block );
		$post = $id > 0 ? get_post( $id ) : null;
		if ( ! $post instanceof WP_Post || 'post' !== $post->post_type ) {
			return '';
		}
		$saved           = $GLOBALS['post'] ?? null;
		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- get_adjacent_post 는 전역 글 기준(끝나면 되돌림).
		try {
			$prev = get_adjacent_post( true, '', true, 'category' );
			$next = get_adjacent_post( true, '', false, 'category' );
		} finally {
			$GLOBALS['post'] = $saved; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		if ( ! $prev instanceof WP_Post && ! $next instanceof WP_Post ) {
			return '';
		}
		$title = static fn( WP_Post $p ): string => esc_html( wp_strip_all_tags( get_the_title( $p ) ) );
		$html  = $prev instanceof WP_Post ? self::a( (string) get_permalink( $prev ), iwell_icon( 'arrow-left' ) . '<span><small>이전 글</small>' . $title( $prev ) . '</span>', 'iwell-prevnext__prev', ' rel="prev"' ) : '<span class="iwell-prevnext__empty"></span>';
		$html .= $next instanceof WP_Post ? self::a( (string) get_permalink( $next ), '<span><small>다음 글</small>' . $title( $next ) . '</span>' . iwell_icon( 'arrow-right' ), 'iwell-prevnext__next', ' rel="next"' ) : '';
		return self::wrap( 'nav', 'iwell-prevnext', $html, array( 'aria-label' => '같은 게시판의 이전·다음 글' ) );
	}

	// ── 홈 구역 ───────────────────────────────────────────────────────

	/**
	 * 진료 타일 — 목적지(대체 규칙 적용 전)가 비공개인 칸은 숨긴다("홈 → 홈" 카드 방지). 모두 숨으면 구역 없음.
	 * 처음 그리는 칸(성장·성조숙증)은 is-featured — 첫 줄 전체 폭·큰 글씨(수정 1차 병원 의견 "성장·성조숙증이 앞에 보여야").
	 */
	public static function concerns( array $attrs, $block ): string {
		$cells = '';
		foreach ( self::CONCERNS as list( $icon, $label, $line, $path ) ) {
			if ( ! self::isPublic( $path ) ) {
				$hub = explode( '/', $path )[0];
				if ( $hub === $path || ! self::isPublic( $hub ) ) {
					continue;
				}
			}
			$cells .= sprintf(
				'<li%s><a class="iwell-concern" href="%s"><span class="iwell-concern__icon">%s</span><span class="iwell-concern__label">%s</span><span class="iwell-concern__line">%s</span>%s</a></li>',
				'' === $cells ? ' class="is-featured"' : '',
				esc_url( self::url( $path ) ),
				iwell_icon( $icon ),
				esc_html( $label ),
				esc_html( $line ),
				iwell_icon( 'chevron', '', 20 )
			);
		}
		if ( '' === $cells ) {
			return '';
		}
		return self::wrap( 'ul', 'iwell-concerns', $cells );
	}

	/** 클리닉 카드 — 허브(영유아검진~건강정보) 이름 + 원문 한 줄 + 게시된 하위 3개. 허브 열이 메뉴에 없으면 카드도 없다. */
	public static function clinicCards( array $attrs, $block ): string {
		$cards = '';
		foreach ( self::tree() as $hub ) {
			if ( ! array_key_exists( $hub['path'], self::CLINIC_LINES ) ) {
				continue;
			}
			$links = '';
			foreach ( array_slice( array_values( array_filter( $hub['children'], static fn( array $c ): bool => 'page' === $c['kind'] ) ), 0, 3 ) as $child ) {
				$links .= '<li>' . self::a( $child['url'], esc_html( $child['title'] ) ) . '</li>';
			}
			$line   = self::CLINIC_LINES[ $hub['path'] ];
			$cards .= sprintf(
				'<li class="iwell-clinic-card"><h3 class="iwell-clinic-card__title">%s</h3>%s%s</li>',
				self::a( $hub['url'], esc_html( $hub['title'] ) . iwell_icon( 'chevron', '', 20 ) ),
				'' === $line ? '' : '<p class="iwell-clinic-card__line">' . esc_html( $line ) . '</p>',
				'' === $links ? '' : '<ul class="iwell-clinic-card__links">' . $links . '</ul>'
			);
		}
		if ( '' === $cards ) {
			return '';
		}
		return self::wrap( 'ul', 'iwell-clinic-cards', $cards );
	}

	/**
	 * 오시는 길 — 주소·전화 = config/clinic.php, 주차 = 병원 자료 원문(대수는 근거 확인 대상 C25라 뺌).
	 * 지도: 좌표가 병원 확인 전(content-inventory §1-3)이라 지도를 박아 넣지 않고 지도 앱 주소 검색 링크만(외부 스크립트 없음).
	 */
	public static function location( array $attrs, $block ): string {
		$c       = self::clinic();
		$address = (string) ( $c['addressText'] ?? '' );
		$query   = rawurlencode( trim( explode( ',', $address )[0] ) );
		$rows    = array(
			array( 'pin', '주소', esc_html( $address ) ),
			array( 'phone', '전화', self::a( self::tel(), esc_html( $c['telephone'] ) ) ),
			array( 'parking', '주차', esc_html( self::PARKING ) ),
		);
		$dl      = '';
		foreach ( $rows as list( $icon, $label, $value ) ) {
			$dl .= sprintf( '<div><dt>%s<span>%s</span></dt><dd>%s</dd></div>', iwell_icon( $icon ), esc_html( $label ), $value );
		}
		$maps = '' === $query ? '' : sprintf(
			'<p class="iwell-location__maps">%s%s</p>',
			self::a( 'https://map.kakao.com/link/search/' . $query, '카카오맵에서 보기' . iwell_icon( 'external', '', 18 ), 'iwell-btn iwell-btn--line', ' rel="noopener" target="_blank"' ),
			self::a( 'https://map.naver.com/p/search/' . $query, '네이버 지도에서 보기' . iwell_icon( 'external', '', 18 ), 'iwell-btn iwell-btn--line', ' rel="noopener" target="_blank"' )
		);
		return self::wrap( 'div', 'iwell-location', '<dl>' . $dl . '</dl>' . $maps );
	}

	/**
	 * 상담·예약 안내(템플릿 page-consult — /consult/, 수정 1차 대표 결정 2026-11-19): 네이버 예약·네이버 톡톡·카카오톡 채널 바로가기(값이 있는 칸만) +
	 * 전화 + 개인정보 주의. 사이트 안 비밀 상담 게시판은 연결하지 않는다(만들지 않음). 문구는 의료 내용 없이 연락 방법만.
	 */
	public static function consultGuide( array $attrs, $block ): string {
		$c     = self::clinic();
		$has   = array() !== self::shortcuts();
		$lead  = $has ? '진료 예약·문의는 아래 네이버·카카오톡 창구나 전화로 해 주세요.' : '진료 예약·문의는 전화로 해 주세요.';
		$links = self::shortcutButtons( 'iwell-btn iwell-btn--line' )
			. self::a( self::tel(), iwell_icon( 'phone' ) . '<span>전화 ' . esc_html( $c['telephone'] ) . '</span>', 'iwell-btn iwell-btn--primary' );
		return self::wrap(
			'div',
			'iwell-consult-guide',
			'<p class="iwell-consult-guide__lead">' . esc_html( $lead ) . '</p>'
			. '<div class="iwell-cta__buttons iwell-consult-guide__buttons">' . $links . '</div>'
			. '<p class="iwell-consult-guide__note">' . iwell_icon( 'info', '', 20 ) . '<span>증상이나 주민등록번호 같은 개인정보는 채팅·예약 메모에 자세히 쓰지 마세요.</span></p>'
		);
	}

	/**
	 * 병원 정의 한 문장(수정 2 Ruling A) — 홈 히어로 H1 바로 다음, 자바스크립트 없이 HTML 글자. 문장은 Graph::clinicSentence()
	 * (config/clinic.php 이름·주소 — 홈 meta description 첫머리와 같은 값). 플러그인이 없거나 문장을 못 만들면 아무것도 내지 않는다.
	 */
	public static function clinicDefinition( array $attrs, $block ): string {
		$sentence = class_exists( '\Iwell\Core\Schema\Graph' ) ? \Iwell\Core\Schema\Graph::clinicSentence() : '';
		return '' === $sentence ? '' : self::wrap( 'p', 'iwell-hero__definition', esc_html( $sentence ) );
	}

	/**
	 * 홈 자주 묻는 질문(수정 2 Ruling B) — HOME_FAQ 를 Rank Math FAQ 블록으로 그린다(수정 1 아코디언 필터가 details 로 바꿈: 첫 질문만 펼침).
	 * 같은 블록이 FAQPage 의 원본이다(Graph::captureFaq → frontFaq, 홈 ld+json 한 @graph) — 화면 문답 = JSON-LD 문답.
	 * 답 끝 링크는 목적지가 공개일 때만(Nav::isPublic — 대체 목적지로 바꾸지 않고 링크를 뺀다). Rank Math 가 꺼져 있으면 구역 없음.
	 */
	public static function homeFaq( array $attrs, $block ): string {
		$questions = array();
		foreach ( self::HOME_FAQ as $i => list( $question, $lines, $path ) ) {
			// 수정 1차(대표 "줄넘김 이상하게 하지 말라고"): 원문 줄은 손으로 넣은 줄바꿈 대신 문단(<p>)으로 — 문단 여백 토큰을 따른다.
			$answer      = implode( '', array_map( static fn( string $l ): string => '<p>' . esc_html( $l ) . '</p>', $lines ) );
			$link        = self::faqLink( $path );
			$questions[] = array(
				'id'      => 'faq-' . ( $i + 1 ),
				'title'   => esc_html( $question ),
				'content' => '' === $link ? $answer : $answer . '<p>' . $link . '</p>',
				'visible' => true,
			);
		}
		$faq = render_block(
			array(
				'blockName'    => 'rank-math/faq-block',
				'attrs'        => array( 'questions' => $questions ),
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			)
		);
		if ( '' === trim( $faq ) ) {
			return '';
		}
		return self::wrap( 'section', 'iwell-section iwell-home-faq', '<div class="iwell-section__inner"><h2 class="wp-block-heading">자주 묻는 질문</h2>' . $faq . '</div>' );
	}

	/**
	 * FAQ 답 끝 링크 — 목적지 페이지가 공개면 "{페이지 제목} 안내", 아니면 ''. 경로의 #앵커는 주소에만. 제목 = Nav::title()(공개 판정과 같은 게시본 행 —
	 * get_page_by_path 는 같은 부모·같은 슬러그의 직원 초안을 집을 수 있다, 수정 3).
	 */
	private static function faqLink( string $path ): string {
		$page = explode( '#', $path )[0];
		if ( ! self::isPublic( $page ) ) {
			return '';
		}
		$title = trim( wp_strip_all_tags( \Iwell\Core\Nav::title( $page ) ) );
		if ( '' === $title ) {
			return '';
		}
		// "검사 안내" 처럼 이미 '안내'로 끝나는 제목에 또 붙이지 않는다.
		$label = str_ends_with( $title, '안내' ) ? $title : $title . ' 안내';
		return self::a( self::url( $path ), esc_html( $label ), 'iwell-faq__more' );
	}

	/** 최신 공지·칼럼(각 5건, 제목·작성일). 0건인 칸은 숨기고 둘 다 0건이면 구역 자체가 없다("등록된 글이 없습니다" 금지 — 설계서 §2). */
	public static function latestBoard( array $attrs, $block ): string {
		$columns = '';
		foreach ( array(
			'notices' => '공지사항',
			'columns' => '원장 칼럼',
		) as $slug => $label ) {
			$posts = get_posts(
				array(
					'post_type'        => 'post',
					'post_status'      => 'publish',
					'category_name'    => $slug,
					'posts_per_page'   => 5,
					'orderby'          => 'date',
					'order'            => 'DESC',
					'suppress_filters' => false,
				)
			);
			if ( array() === $posts ) {
				continue;
			}
			$items = '';
			foreach ( $posts as $p ) {
				$items .= sprintf(
					'<li>%s<time datetime="%s">%s</time></li>',
					self::a( get_permalink( $p ), esc_html( wp_strip_all_tags( get_the_title( $p ) ) ) ),
					esc_attr( get_the_date( 'Y-m-d', $p ) ),
					esc_html( get_the_date( 'Y.m.d', $p ) )
				);
			}
			// "더보기" = 목록 주소 — 목적지가 열리기 전(Task 9 재작성 전)엔 내지 않는다(수정 1 R03: 404 링크 금지). 글 링크는 그대로.
			$columns .= sprintf(
				'<div class="iwell-board__col"><h3 class="iwell-board__title">%s</h3><ul>%s</ul>%s</div>',
				esc_html( $label ),
				$items,
				self::isPublic( $slug ) ? self::a( self::url( $slug ), '더보기' . iwell_icon( 'chevron', '', 18 ), 'iwell-board__more' ) : ''
			);
		}
		if ( '' === $columns ) {
			return '';
		}
		return self::wrap(
			'section',
			'iwell-section iwell-home-board is-tint',
			'<div class="iwell-section__inner"><h2 class="wp-block-heading">삼성아이웰 소식</h2><p class="iwell-section__lead">공지사항, 병원소식, 정보 등 다양한 정보를 확인하세요.</p><div class="iwell-board">' . $columns . '</div></div>'
		);
	}
}
