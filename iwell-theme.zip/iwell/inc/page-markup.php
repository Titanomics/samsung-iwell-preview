<?php
/**
 * T3·T4·T5 본문 블록 마크업(Task 8) — 패턴(patterns/guide-question·info-table-page·entity-clinic·entity-doctor)과 로컬 시드(병원 원문 시험 페이지)가
 * 같은 구조를 쓰게 하는 한 곳. T2 는 inc/t2-markup.php.
 *
 * 본문 블록 = 정적 블록(group·heading·paragraph·list·table·image)과 원장 검토 허용 목록 안 블록(iwell/review-badge)뿐 — 서버 렌더 블록을 새로 넣지 않는다
 * (Task 6 수정 8·9: 허용 목록 밖 서버 렌더 블록이 본문에 있으면 그 페이지는 검토 불가). 다른 페이지·메타에서 읽는 것은 템플릿이 그린다:
 *   - 관련·예약·전화·출처·이전/다음(page.html — Task 7 수정 3), T4 기준일(iwell/asof — 페이지 메타 기준일), T5 원장 외부 프로필(iwell/profile-links —
 *     메타 iwell_physician.sameAs), 허브 하위 카드(page-hub.html iwell/child-list).
 * 바깥 그룹 = templateLock "contentOnly"(직원은 글자만, 구역 추가·삭제·이동 불가 — 잠금 해제는 iwell_unlock_blocks 권한, functions.php).
 *
 * 구성(설계서 §5, 계획 Task 8 Interfaces):
 *   T3 질문형 가이드  H1 질문 → 첫 문단 직답(40자 내외, 검토 배지) → [목차 — h2 3개 이상이면 렌더 때 자동, Iwell_Theme_Blocks::toc] → 근거 표(기준·수치·기준일) →
 *                     하위 질문(h2 하나씩) → "이럴 땐 바로 병원" 상자 → (관련 — 템플릿)
 *   T4 정보표         (H1 = 페이지 제목 — 템플릿 iwell/page-title) → (기준일 — 템플릿 iwell/asof) → 검토 배지 → 가로 스크롤 반응형 표 → 주석·문의
 *   T5 병원           H1 → 검토 배지 → 사실 표(상호·대표원장·진료과목·전화·주소·주차) → 소개 문단(있을 때)
 *   T5 원장           H1(이름·직함) → 검토 배지 → (사진) → 이력 표(면허·전문의·학력·경력·학회·저서) → 진료 철학 → (외부 프로필 — 템플릿, 메타 sameAs)
 * 검토 배지(iwell/review-badge — 수정 9 허용 목록 안) = 본문에 한 번씩(Task 8 수정 1 F1 — T3 처럼 T4·T5 도 원장 승인 페이지에서 화면 배지와 JSON-LD reviewedBy 가
 * 같은 조건 PageMeta::verifiedReview 로 함께 나온다. 템플릿은 배지를 그리지 않으므로 한 페이지에 배지 1개). 승인 전·직원 변경 공개 뒤에는 아무것도 그리지 않는다.
 * 사실·이력 표(T5)의 첫 열 = 행 머리글 th scope="row"(수정 1 F3 — 항목 이름과 값의 관계, core/table 본문 칸 tag·scope 속성 그대로 직렬화).
 */

defined( 'ABSPATH' ) || exit;

/** 블록 마크업 조각(글자는 모두 esc_html). */
final class Iwell_Markup {
	public static function p( string $text, string $class = '' ): string {
		return '' === $class
			? "<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->"
			: '<!-- wp:paragraph {"className":"' . esc_attr( $class ) . "\"} -->\n<p class=\"" . esc_attr( $class ) . '">' . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->";
	}

	public static function h( int $level, string $text, string $class = '' ): string {
		$attrs = array_filter(
			array(
				'level'     => 2 === $level ? null : $level,
				'className' => '' === $class ? null : $class,
			),
			static fn( $v ): bool => null !== $v
		);
		$json  = array() === $attrs ? '' : ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		return "<!-- wp:heading$json -->\n<h$level class=\"wp-block-heading" . ( '' === $class ? '' : ' ' . esc_attr( $class ) ) . '">' . esc_html( $text ) . "</h$level>\n<!-- /wp:heading -->";
	}

	/** @param list<string> $items */
	public static function ul( array $items, bool $ordered = false ): string {
		$tag = $ordered ? 'ol' : 'ul';
		$out = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . " -->\n<$tag class=\"wp-block-list\">";
		foreach ( $items as $item ) {
			$out .= "<!-- wp:list-item -->\n<li>" . esc_html( (string) $item ) . "</li>\n<!-- /wp:list-item -->";
		}
		return $out . "</$tag>\n<!-- /wp:list -->";
	}

	/**
	 * 표 — 좁은 화면에서는 표 상자(figure) 안에서만 가로 스크롤(site.css .iwell-table). $wide = 넓은 표(T4 — 390 에서도 열을 눌러 담지 않는다).
	 * $row_head = 각 행의 첫 칸을 행 머리글로(<th scope="row"> — core/table 저장 형식: 본문 칸 tag th·scope row, 편집기 검증 그대로).
	 *
	 * @param list<string>       $head 머리 칸(비면 머리 없음).
	 * @param list<list<string>> $rows
	 */
	public static function table( array $head, array $rows, string $caption = '', bool $wide = false, bool $row_head = false ): string {
		$class = 'iwell-table' . ( $wide ? ' iwell-table--wide' : '' );
		$out   = "<!-- wp:table {\"hasFixedLayout\":false,\"className\":\"$class\"} -->\n<figure class=\"wp-block-table $class\"><table>";
		if ( array() !== $head ) {
			$out .= '<thead><tr>' . implode( '', array_map( static fn( $t ): string => '<th>' . esc_html( (string) $t ) . '</th>', $head ) ) . '</tr></thead>';
		}
		$out .= '<tbody>';
		foreach ( $rows as $row ) {
			$cells = array();
			foreach ( array_values( $row ) as $i => $t ) {
				$cells[] = $row_head && 0 === $i ? '<th scope="row">' . esc_html( (string) $t ) . '</th>' : '<td>' . esc_html( (string) $t ) . '</td>';
			}
			$out .= '<tr>' . implode( '', $cells ) . '</tr>';
		}
		$out .= '</tbody></table>';
		if ( '' !== $caption ) {
			$out .= '<figcaption class="wp-element-caption">' . esc_html( $caption ) . '</figcaption>';
		}
		return $out . "</figure>\n<!-- /wp:table -->";
	}

	/** 구역 그룹 <section class="iwell-sec iwell-sec-{slug}">(T2 와 같은 간격·모양). */
	public static function section( string $slug, string $inner, string $extra = '' ): string {
		$class = trim( 'iwell-sec iwell-sec-' . $slug . ' ' . $extra );
		return '<!-- wp:group {"tagName":"section","className":"' . esc_attr( $class ) . "\",\"layout\":{\"type\":\"default\"}} -->\n<section class=\"wp-block-group " . esc_attr( $class ) . "\">$inner</section>\n<!-- /wp:group -->";
	}

	/**
	 * 바깥 그룹 — templateLock contentOnly(안쪽: 글자만) + lock{move, remove}(그룹 자체를 통째로 지우거나 옮기지 못함 — 편집기 실측: 맨 위 그룹은
	 * templateLock 만으로는 삭제 가능했다). 두 잠금 모두 canLockBlocks(iwell_unlock_blocks) 계정만 푼다. @param list<string> $parts
	 */
	public static function locked( string $class, array $parts ): string {
		return '<!-- wp:group {"tagName":"div","templateLock":"contentOnly","lock":{"move":true,"remove":true},"className":"' . esc_attr( $class ) . "\",\"layout\":{\"type\":\"constrained\"}} -->\n<div class=\"wp-block-group " . esc_attr( $class ) . '">'
			. implode( "\n\n", array_filter( $parts, static fn( string $s ): bool => '' !== $s ) ) . "</div>\n<!-- /wp:group -->";
	}

	/** 2열 사실 표(첫 칸 = 항목 이름 = 행 머리글 th scope="row", 값 = td — 수정 1 F3. 정적 table 블록 그대로). @param list<array{0: string, 1: string}> $rows */
	public static function facts( array $rows ): string {
		return self::table( array(), array_map( static fn( array $r ): array => array( (string) $r[0], (string) $r[1] ), $rows ), '', false, true );
	}
}

/**
 * T3 질문형 가이드.
 *
 * @param array{
 *   title: string,
 *   answer: string,
 *   basis: array{caption?: string, head: list<string>, rows: list<list<string>>},
 *   questions: list<array{0: string, 1: list<string>}>,
 *   urgent: array{intro?: string, items: list<string>},
 *   headings?: array<string, string>
 * } $c
 */
function iwell_t3_markup( array $c ): string {
	$h = ( $c['headings'] ?? array() ) + array(
		'basis'  => '한눈에 보는 기준',
		'urgent' => '이럴 땐 바로 병원',
	);

	$parts   = array( Iwell_Markup::h( 1, $c['title'], 'iwell-t3__title' ) );
	// 첫 문단 = 직답(설계서 §5 T3 "첫 문단 40자 내외 직답") + 검토 배지(원장 승인 때 자동 — 기준일·검토자).
	$parts[] = "<!-- wp:group {\"tagName\":\"div\",\"className\":\"iwell-answer iwell-t3__answer\",\"layout\":{\"type\":\"default\"}} -->\n<div class=\"wp-block-group iwell-answer iwell-t3__answer\">"
		. Iwell_Markup::p( $c['answer'], 'iwell-t3__lead' ) . "\n\n<!-- wp:iwell/review-badge /--></div>\n<!-- /wp:group -->";

	$basis = (array) ( $c['basis'] ?? array() );
	if ( array() !== (array) ( $basis['rows'] ?? array() ) ) {
		$parts[] = Iwell_Markup::section( 'basis', Iwell_Markup::h( 2, $h['basis'] ) . "\n\n" . Iwell_Markup::table( (array) ( $basis['head'] ?? array() ), (array) $basis['rows'], (string) ( $basis['caption'] ?? '' ) ) );
	}
	foreach ( (array) ( $c['questions'] ?? array() ) as list( $question, $answers ) ) {
		$parts[] = Iwell_Markup::section( 'question', Iwell_Markup::h( 2, (string) $question ) . "\n\n" . implode( "\n\n", array_map( static fn( $a ): string => Iwell_Markup::p( (string) $a ), (array) $answers ) ) );
	}
	$urgent = (array) ( $c['urgent'] ?? array() );
	if ( array() !== (array) ( $urgent['items'] ?? array() ) ) {
		$intro   = trim( (string) ( $urgent['intro'] ?? '' ) );
		$parts[] = Iwell_Markup::section( 'urgent', Iwell_Markup::h( 2, $h['urgent'] ) . ( '' === $intro ? '' : "\n\n" . Iwell_Markup::p( $intro ) ) . "\n\n" . Iwell_Markup::ul( (array) $urgent['items'] ), 'iwell-urgent' );
	}
	return Iwell_Markup::locked( 'iwell-t3', $parts );
}

/**
 * T4 정보표 — 본문은 표와 주석·문의. 제목(H1)은 페이지 제목을 템플릿(iwell/page-title)이, 기준일은 페이지 메타 기준일을 템플릿(iwell/asof)이 그 사이에 그린다.
 *
 * @param array{
 *   table: array{caption?: string, head: list<string>, rows: list<list<string>>},
 *   notes: list<string>,
 *   contact?: string,
 *   headings?: array<string, string>
 * } $c
 */
function iwell_t4_markup( array $c ): string {
	$h     = ( $c['headings'] ?? array() ) + array( 'notes' => '안내·문의' );
	$table = (array) $c['table'];
	$parts = array(
		// 검토 배지(원장 승인 때만 — 템플릿 기준일 줄 바로 아래, 수정 1 F1).
		'<!-- wp:iwell/review-badge /-->',
		Iwell_Markup::section( 'table', Iwell_Markup::table( (array) ( $table['head'] ?? array() ), (array) ( $table['rows'] ?? array() ), (string) ( $table['caption'] ?? '' ), true ) ),
	);
	$notes = array_values( array_filter( array_map( 'strval', (array) ( $c['notes'] ?? array() ) ), static fn( string $s ): bool => '' !== trim( $s ) ) );
	$tel   = trim( (string) ( $c['contact'] ?? '' ) );
	if ( '' !== $tel ) {
		$notes[] = $tel;
	}
	if ( array() !== $notes ) {
		$parts[] = Iwell_Markup::section( 'notes', Iwell_Markup::h( 2, $h['notes'] ) . "\n\n" . implode( "\n\n", array_map( static fn( string $n ): string => Iwell_Markup::p( $n, 'iwell-table-note' ), $notes ) ) );
	}
	return Iwell_Markup::locked( 'iwell-t4', $parts );
}

/**
 * T5 병원 — 사실 표 + 소개 문단.
 *
 * @param array{title: string, facts: list<array{0: string, 1: string}>, intro?: list<string>, headings?: array<string, string>} $c
 */
function iwell_t5_clinic_markup( array $c ): string {
	$h     = ( $c['headings'] ?? array() ) + array(
		'facts' => '병원 정보',
		'intro' => '병원 소개',
	);
	$parts = array(
		Iwell_Markup::h( 1, $c['title'], 'iwell-t5__title' ),
		'<!-- wp:iwell/review-badge /-->', // 검토 배지(원장 승인 때만 — 제목 바로 아래, 수정 1 F1).
		Iwell_Markup::section( 'facts', Iwell_Markup::h( 2, $h['facts'] ) . "\n\n" . Iwell_Markup::facts( $c['facts'] ) ),
	);
	$intro = (array) ( $c['intro'] ?? array() );
	if ( array() !== $intro ) {
		$parts[] = Iwell_Markup::section( 'intro', Iwell_Markup::h( 2, $h['intro'] ) . "\n\n" . implode( "\n\n", array_map( static fn( $p ): string => Iwell_Markup::p( (string) $p ), $intro ) ) );
	}
	return Iwell_Markup::locked( 'iwell-t5 iwell-t5--clinic', $parts );
}

/**
 * T5 원장 — 이력 표 + 진료 철학. 외부 프로필(sameAs)은 페이지 메타 iwell_physician 에서 템플릿(iwell/profile-links)이 본문 바로 뒤에 그린다
 * (구조화 데이터 Physician sameAs 와 같은 원천 — 본문에 주소를 다시 쓰지 않는다).
 *
 * @param array{
 *   title: string,
 *   photo?: array{src: string, alt: string},
 *   career: list<array{0: string, 1: string}>,
 *   philosophy: list<string>,
 *   headings?: array<string, string>
 * } $c
 */
function iwell_t5_doctor_markup( array $c ): string {
	$h     = ( $c['headings'] ?? array() ) + array(
		'career'     => '이력',
		'philosophy' => '진료 철학',
	);
	$parts = array(
		Iwell_Markup::h( 1, $c['title'], 'iwell-t5__title' ),
		'<!-- wp:iwell/review-badge /-->', // 검토 배지(원장 승인 때만 — 제목 바로 아래, 수정 1 F1).
	);
	$photo = (array) ( $c['photo'] ?? array() );
	if ( '' !== (string) ( $photo['src'] ?? '' ) ) {
		$parts[] = "<!-- wp:image {\"sizeSlug\":\"full\",\"linkDestination\":\"none\",\"className\":\"iwell-t5__photo\"} -->\n<figure class=\"wp-block-image size-full iwell-t5__photo\"><img src=\""
			. esc_url( (string) $photo['src'] ) . '" alt="' . esc_attr( (string) ( $photo['alt'] ?? '' ) ) . "\"/></figure>\n<!-- /wp:image -->";
	}
	$parts[] = Iwell_Markup::section( 'career', Iwell_Markup::h( 2, $h['career'] ) . "\n\n" . Iwell_Markup::facts( $c['career'] ) );
	$philosophy = (array) ( $c['philosophy'] ?? array() );
	if ( array() !== $philosophy ) {
		$parts[] = Iwell_Markup::section( 'philosophy', Iwell_Markup::h( 2, $h['philosophy'] ) . "\n\n" . implode( "\n\n", array_map( static fn( $p ): string => Iwell_Markup::p( (string) $p ), $philosophy ) ) );
	}
	return Iwell_Markup::locked( 'iwell-t5 iwell-t5--doctor', $parts );
}
