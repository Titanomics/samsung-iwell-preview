<?php
/**
 * 코드로 그린 선 아이콘(설계서 §7) — 24px 격자, 선 두께 1.8, 채우기 없음, 색 = currentColor. 그림 파일·외부 아이콘 글꼴 없음.
 * 모양은 이 파일에서 직접 그린 단순 도형이다(외부 아이콘 세트 복사 아님).
 */

defined( 'ABSPATH' ) || exit;

/** 아이콘 이름 → SVG 내부(path·circle). */
function iwell_icon_shapes(): array {
	return array(
		'phone'       => '<path d="M6.6 3.5h3l1.6 4.2-2.1 1.5a12 12 0 0 0 5.7 5.7l1.5-2.1 4.2 1.6v3a2 2 0 0 1-2.1 2A16.5 16.5 0 0 1 4.6 5.6a2 2 0 0 1 2-2.1z"/>',
		'chat'        => '<path d="M4.5 5.5h15v10h-9l-4.5 3.5v-3.5h-1.5z"/><path d="M8.5 10.5h7"/>',
		'clock'       => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
		'pin'         => '<path d="M12 21s-6.5-5.8-6.5-11a6.5 6.5 0 0 1 13 0c0 5.2-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.4"/>',
		'arrow-up'    => '<path d="M12 19V5.5M6 11.5l6-6 6 6"/>',
		'menu'        => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'       => '<path d="M6 6l12 12M18 6L6 18"/>',
		'chevron'     => '<path d="M9.5 6l6 6-6 6"/>',
		'arrow-left'  => '<path d="M19 12H5.5M11 6l-6 6 6 6"/>',
		'arrow-right' => '<path d="M5 12h13.5M13 6l6 6-6 6"/>',
		'parking'     => '<rect x="4" y="4" width="16" height="16" rx="3.5"/><path d="M10 16.5v-9h3.2a2.6 2.6 0 0 1 0 5.2H10"/>',
		'external'    => '<path d="M14 5h5v5M19 5l-8 8M17 13.5V19H5V7h5.5"/>',
		// 상담·예약 바로가기(수정 1차) — 예약 달력·안내.
		'calendar'    => '<rect x="4" y="5.5" width="16" height="14" rx="2.5"/><path d="M4 10h16M8.5 3.5v4M15.5 3.5v4"/>',
		'info'        => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8h.01"/>',
		// 보호자 고민 6칸.
		'height'      => '<path d="M6 3.5h4v17H6z"/><path d="M6 7.5h2M6 11.5h2M6 15.5h2"/><path d="M16.5 4.5v15M14 7l2.5-2.5L19 7M14 17l2.5 2.5L19 17"/>',
		'baby'        => '<circle cx="12" cy="9" r="4.5"/><path d="M10.4 8.6h.01M13.6 8.6h.01M10.6 10.8c.8.6 2 .6 2.8 0"/><path d="M5.5 20.5c.6-3.4 3.3-5.5 6.5-5.5s5.9 2.1 6.5 5.5"/>',
		'speech'      => '<path d="M3.5 5.5h11v7.5H8.5l-3.5 3v-3H3.5z"/><path d="M17.5 9.5h3v7.5H19v3l-3.5-3h-4v-2"/>',
		'leaf'        => '<path d="M5 19.5C5 11 10.5 5 19.5 4.5 19 13.5 13 19 5 19.5z"/><path d="M5 19.5l8.5-8.5"/>',
		'thermometer' => '<path d="M10 5a2 2 0 0 1 4 0v9.2a4 4 0 1 1-4 0z"/><path d="M12 9v8"/>',
		'syringe'     => '<path d="M15.5 3.5l5 5M18 6l-9.5 9.5-3.5.5.5-3.5L15 3M8.5 12.5l3 3M7 14l-3.5 3.5M3.5 20.5l2-2"/>',
		'stethoscope' => '<path d="M6 3.5v5a4 4 0 0 0 8 0v-5"/><path d="M10 12.5v2a4.5 4.5 0 0 0 9 0v-2"/><circle cx="19" cy="10.5" r="2"/>',
		'book'        => '<path d="M4.5 5.5c2.5-1 5-1 7.5.5 2.5-1.5 5-1.5 7.5-.5v13c-2.5-1-5-1-7.5.5-2.5-1.5-5-1.5-7.5-.5z"/><path d="M12 6v13"/>',
	);
}

/** 인라인 SVG. $label 이 있으면 role="img" + aria-label, 없으면 장식(aria-hidden). */
function iwell_icon( string $name, string $label = '', int $size = 24 ): string {
	$shapes = iwell_icon_shapes();
	if ( ! isset( $shapes[ $name ] ) ) {
		return '';
	}
	$a11y = '' === $label ? 'aria-hidden="true" focusable="false"' : 'role="img" aria-label="' . esc_attr( $label ) . '"';
	return sprintf(
		'<svg class="iwell-icon iwell-icon--%1$s" width="%2$d" height="%2$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" %3$s>%4$s</svg>',
		esc_attr( $name ),
		$size,
		$a11y,
		$shapes[ $name ]
	);
}
