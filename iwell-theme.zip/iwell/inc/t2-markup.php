<?php
/**
 * T2 진료 상세 본문 블록 마크업 — 패턴 iwell/clinic-detail(빈칸 안내 글)과 로컬 시험 페이지(병원 원문)가 같은 구조를 쓰게 하는 한 곳.
 *
 * 순서(계획 Task 7 Interfaces — 본문 부분): H1(질문형) → 핵심 답변 상자(검토 배지 = 의학적 검토·기준일) → 정의·원리 → 과정 → 비교 표 →
 * 이런 분께 → 정보표 → FAQ(Rank Math FAQ 블록 — 화면 FAQ = FAQPage 같은 원본). 본문은 FAQ 까지.
 * 그 뒤 관련 → 예약·전화 → 출처(페이지 메타) → 이전/다음은 템플릿 page.html 이 본문 바로 뒤에 그린다(Task 7 수정 3 — 코디네이터 결정:
 * 본문의 서버 렌더 블록은 원장 검토 지문 허용 목록 밖이면 그 페이지를 검토 불가로 만든다. 관련 페이지는 탐색 장치라 검토 범위 밖, 예약·전화·출처도
 * 템플릿으로 옮겨 설계서 §5 T2 순서 FAQ → 관련 → 예약·전화 → 출처를 지킨다). 서브 비주얼·브레드크럼·형제 탭은 본문 위(모든 페이지 공통).
 */

defined( 'ABSPATH' ) || exit;

/**
 * @param array{
 *   title: string,
 *   answer: list<string>,
 *   principle: list<string>,
 *   process: list<string>,
 *   compare: array{caption: string, head: list<string>, rows: list<list<string>>, notes?: list<string>},
 *   audience: array{intro: string, groups: array<string, list<string>>},
 *   info: list<array{0: string, 1: string}>,
 *   faq: list<array{0: string, 1: string}>,
 *   headings?: array<string, string>
 * } $c
 */
function iwell_t2_markup( array $c ): string {
	$h = ( $c['headings'] ?? array() ) + array(
		'principle' => '정의와 원리',
		'process'   => '진행 과정',
		'compare'   => '한눈에 비교',
		'audience'  => '이런 분께 권합니다',
		'info'      => '검사·진료 정보',
		'faq'       => '자주 묻는 질문',
	);
	$p       = static fn( string $text, string $class = '' ): string => '' === $class
		? "<!-- wp:paragraph -->\n<p>" . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->"
		: '<!-- wp:paragraph {"className":"' . esc_attr( $class ) . "\"} -->\n<p class=\"" . esc_attr( $class ) . '">' . esc_html( $text ) . "</p>\n<!-- /wp:paragraph -->";
	$h2      = static fn( string $text ): string => "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $text ) . "</h2>\n<!-- /wp:heading -->";
	$h3      = static fn( string $text ): string => "<!-- wp:heading {\"level\":3} -->\n<h3 class=\"wp-block-heading\">" . esc_html( $text ) . "</h3>\n<!-- /wp:heading -->";
	$list    = static function ( array $items, bool $ordered = false ): string {
		$tag  = $ordered ? 'ol' : 'ul';
		$out  = '<!-- wp:list' . ( $ordered ? ' {"ordered":true}' : '' ) . " -->\n<$tag class=\"wp-block-list\">";
		foreach ( $items as $item ) {
			$out .= "<!-- wp:list-item -->\n<li>" . esc_html( $item ) . "</li>\n<!-- /wp:list-item -->";
		}
		return $out . "</$tag>\n<!-- /wp:list -->";
	};
	$table   = static function ( array $head, array $rows, string $caption ): string {
		$out = "<!-- wp:table {\"hasFixedLayout\":false,\"className\":\"iwell-table\"} -->\n<figure class=\"wp-block-table iwell-table\"><table>";
		if ( array() !== $head ) {
			$out .= '<thead><tr>' . implode( '', array_map( static fn( $t ): string => '<th>' . esc_html( $t ) . '</th>', $head ) ) . '</tr></thead>';
		}
		$out .= '<tbody>';
		foreach ( $rows as $row ) {
			$out .= '<tr>' . implode( '', array_map( static fn( $t ): string => '<td>' . esc_html( $t ) . '</td>', $row ) ) . '</tr>';
		}
		$out .= '</tbody></table>';
		if ( '' !== $caption ) {
			$out .= '<figcaption class="wp-element-caption">' . esc_html( $caption ) . '</figcaption>';
		}
		return $out . "</figure>\n<!-- /wp:table -->";
	};
	$section = static fn( string $slug, string $inner ): string => '<!-- wp:group {"tagName":"section","className":"iwell-sec iwell-sec-' . $slug . "\",\"layout\":{\"type\":\"default\"}} -->\n<section class=\"wp-block-group iwell-sec iwell-sec-" . $slug . "\">$inner</section>\n<!-- /wp:group -->";

	$out = array();

	$out[] = "<!-- wp:heading {\"level\":1,\"className\":\"iwell-t2__title\"} -->\n<h1 class=\"wp-block-heading iwell-t2__title\">" . esc_html( $c['title'] ) . "</h1>\n<!-- /wp:heading -->";

	$answer = $p( '핵심 답변', 'iwell-answer__label' );
	foreach ( $c['answer'] as $sentence ) {
		$answer .= "\n\n" . $p( $sentence );
	}
	$answer .= "\n\n<!-- wp:iwell/review-badge /-->";
	$out[]   = "<!-- wp:group {\"tagName\":\"div\",\"className\":\"iwell-answer\",\"layout\":{\"type\":\"default\"}} -->\n<div class=\"wp-block-group iwell-answer\">$answer</div>\n<!-- /wp:group -->";

	$out[] = $section( 'principle', $h2( $h['principle'] ) . "\n\n" . implode( "\n\n", array_map( $p, $c['principle'] ) ) );
	$out[] = $section( 'process', $h2( $h['process'] ) . "\n\n" . $list( $c['process'], true ) );
	// 표 아래 안내 줄(notes) — 원문이 여러 검사를 묶어 말한 내용(시간·금식·비급여 항목 등)은 특정 검사 열에 확정하지 않고 여기에 원문대로(수정 1 R06).
	$notes = '';
	foreach ( (array) ( $c['compare']['notes'] ?? array() ) as $note ) {
		$notes .= "\n\n" . $p( (string) $note, 'iwell-table-note' );
	}
	$out[] = $section( 'compare', $h2( $h['compare'] ) . "\n\n" . $table( $c['compare']['head'], $c['compare']['rows'], $c['compare']['caption'] ) . $notes );

	$aud = $h2( $h['audience'] ) . ( '' === $c['audience']['intro'] ? '' : "\n\n" . $p( $c['audience']['intro'] ) );
	foreach ( $c['audience']['groups'] as $label => $items ) {
		$aud .= ( '' === (string) $label ? '' : "\n\n" . $h3( (string) $label ) ) . "\n\n" . $list( $items );
	}
	$out[] = $section( 'audience', $aud );

	$out[] = $section( 'info', $h2( $h['info'] ) . "\n\n" . $table( array(), $c['info'], '' ) );

	$questions = array();
	foreach ( $c['faq'] as $i => list( $q, $a ) ) {
		$questions[] = array(
			'id'      => 'faq-' . ( $i + 1 ),
			'title'   => $q,
			'content' => $a,
			'visible' => true,
		);
	}
	// FAQ 저장 HTML = 설치본 Rank Math 1.0.282 FAQ 블록 save 출력(includes/modules/schema/blocks/faq/assets/src/save.js — 질문 없으면 null,
	// 있으면 div.wp-block-rank-math-faq-block > 보이는 질문마다 div.rank-math-faq-item > h3.rank-math-question(titleWrapper 기본 h3) + div.rank-math-answer).
	// Task 8 수정 1 F6: 속성만 있는 빈 블록 주석으로 저장하면 편집기가 "Block contains unexpected or invalid content"로 막아 직원이 FAQ 글자를
	// 고칠 수 없었다. 공개 화면은 서버 렌더(속성만 읽음 — class-block-faq.php render)라 이 HTML 과 무관하게 그대로. 글자는 esc_html(save 는
	// RichText 값을 그대로 쓰므로 일반 글자는 같은 값 — 편집기 검증은 문자 참조를 풀어 비교).
	if ( array() === $questions ) {
		$faq = '<!-- wp:rank-math/faq-block /-->';
	} else {
		$items = '';
		foreach ( $questions as $q ) {
			$items .= '<div class="rank-math-faq-item"><h3 class="rank-math-question">' . esc_html( $q['title'] ) . '</h3><div class="rank-math-answer">' . esc_html( $q['content'] ) . '</div></div>';
		}
		$faq = '<!-- wp:rank-math/faq-block ' . serialize_block_attributes( array( 'questions' => $questions ) ) . " -->\n<div class=\"wp-block-rank-math-faq-block\">$items</div>\n<!-- /wp:rank-math/faq-block -->";
	}
	$out[] = $section( 'faq', $h2( $h['faq'] ) . "\n\n" . $faq );

	// 바깥 그룹 templateLock contentOnly + lock{move, remove}(Task 8 — 직원은 글자만, 구역 추가·삭제·이동 불가, 그룹 자체도 지울 수 없음.
	// 잠금 해제 = iwell_unlock_blocks 권한, functions.php). Iwell_Markup::locked(inc/page-markup.php)와 같은 잠금.
	return "<!-- wp:group {\"tagName\":\"div\",\"templateLock\":\"contentOnly\",\"lock\":{\"move\":true,\"remove\":true},\"className\":\"iwell-t2\",\"layout\":{\"type\":\"constrained\"}} -->\n<div class=\"wp-block-group iwell-t2\">" . implode( "\n\n", $out ) . "</div>\n<!-- /wp:group -->";
}
