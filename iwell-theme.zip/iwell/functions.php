<?php
/**
 * iwell 자식 테마(부모 Twenty Twenty-Five) — Task 7 공통 틀·홈(T1)·진료 상세(T2).
 *
 * 디자인(설계서 §7): 로고 원본 주조색(네이비 #153B7A·스카이 #009FE3 — theme.json 팔레트, 근거 docs/design/colors.md),
 * 바탕 흰색·웜 아이보리, 코드로 그린 선 아이콘, 병원 원본 사진만(assets/img — 목록 docs/design/photos.md).
 * 배제: 블랙·골드·화보 톤, 가격·이벤트 압박 카드, 스크롤에 따라 흐려지는 애니메이션, 고정폭.
 *
 * 메뉴·브레드크럼·형제 이동의 데이터는 플러그인 iwell-core 의 Iwell\Core\Nav(게시된 페이지 계층)에서 오고,
 * 이 테마는 서버 렌더 블록(inc/class-blocks.php)으로 그린다 — 자바스크립트 없이 HTML 에 링크가 들어 있다.
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/inc/icons.php';
require_once __DIR__ . '/inc/class-blocks.php';
require_once __DIR__ . '/inc/t2-markup.php';
require_once __DIR__ . '/inc/page-markup.php';

Iwell_Theme_Blocks::register();

/**
 * 블록 잠금(Task 8 — 계획 Interfaces): T2~T5 패턴 바깥 그룹은 templateLock "contentOnly"(직원은 글자만). 잠금을 풀거나 바꾸는 권한(canLockBlocks)은
 * iwell_unlock_blocks 권한(Roles — 원장·관리자)만. 같은 권한이 없으면 코드 편집기·"HTML 로 편집"도 끈다(잠금 속성 글자를 지워 푸는 길 — 판단:
 * 잠금이 화면 도구만으로 끝나지 않게). 직원이 고친 게시 페이지는 어차피 원장 승인 전 공개되지 않는다(Task 3·6) — 이 잠금은 구조를 지키는 편집 도구다.
 */
add_filter(
	'block_editor_settings_all',
	static function ( $settings ): array {
		$settings                       = (array) $settings;
		$unlock                         = current_user_can( 'iwell_unlock_blocks' );
		$settings['canLockBlocks']      = $unlock;
		$settings['codeEditingEnabled'] = $unlock && ( $settings['codeEditingEnabled'] ?? true );
		return $settings;
	},
	20
);

/**
 * contentOnly 잠금 안의 Rank Math FAQ 블록 글자 편집(Task 8): 워드프레스는 contentOnly 구역에서 "글자 역할(role: content)" 속성이 있는 블록만 고치게
 * 한다. Rank Math 1.0.282 FAQ 블록(includes/modules/schema/blocks/faq/block.json)의 questions 속성에는 역할이 없어 그대로면 직원이 FAQ 를 고칠 수
 * 없다 → 편집기에서 blocks.registerBlockType 필터로 questions 에 role content 를 단다(블록 등록 전 — wp-blocks 바로 뒤 인라인). 삭제·이동은 여전히
 * 잠금(바깥 그룹 contentOnly). 화면·저장 형식은 바뀌지 않는다.
 */
add_action(
	'enqueue_block_editor_assets',
	static function (): void {
		wp_add_inline_script(
			'wp-blocks',
			"wp.hooks.addFilter('blocks.registerBlockType','iwell/faq-content-role',function(s,n){if(n!=='rank-math/faq-block'||!s.attributes||!s.attributes.questions){return s;}var a=Object.assign({},s.attributes);a.questions=Object.assign({},a.questions,{role:'content'});return Object.assign({},s,{attributes:a});});",
			'after'
		);
	}
);

add_action(
	'wp_enqueue_scripts',
	static function (): void {
		$file = get_theme_file_path( 'assets/css/site.css' );
		wp_enqueue_style( 'iwell-site', get_theme_file_uri( 'assets/css/site.css' ), array(), (string) ( is_file( $file ) ? filemtime( $file ) : '0' ) );
		// 점진 향상(수정 1 R01·R02) — 드로어 초점 가두기·Escape, 모바일 현재 탭 가로 위치. 없어도 details·링크는 그대로 동작.
		$js = get_theme_file_path( 'assets/js/site.js' );
		wp_enqueue_script(
			'iwell-site',
			get_theme_file_uri( 'assets/js/site.js' ),
			array(),
			(string) ( is_file( $js ) ? filemtime( $js ) : '0' ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
);

// 편집기에서도 같은 모양(블록 편집기 iframe).
add_action(
	'after_setup_theme',
	static function (): void {
		add_editor_style( 'assets/css/site.css' );
		// 워드프레스 기본 예시 패턴(영문)은 편집기 목록에서 뺀다. 부모 테마 패턴은 부모 템플릿(글 목록 등)이 쓰므로 그대로 둔다.
		remove_theme_support( 'core-block-patterns' );
	},
	20
);

add_action(
	'init',
	static function (): void {
		register_block_pattern_category( 'iwell', array( 'label' => '삼성아이웰' ) );
	}
);
